import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = Number(process.env.PORT) || 3000;

// CORS para permitir chamadas seguras do APK Android Capacitor (https://localhost / capacitor://localhost)
app.use('/api', (req, res, next) => {
  const origin = req.headers.origin || '*';
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'AURUS_GYM_BACKEND' });
});

// Gemini API Route
app.post('/api/gemini/generate', async (req, res) => {
  try {
    const { contents, systemInstruction, generationConfig } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      return res.status(200).json({
        fallback: true,
        text: 'AUREUS IA offline ou chave de API não configurada no servidor. Usando recalibração biométrica interna do AUREUS.'
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Choose model
    const model = 'gemini-2.5-flash';

    const requestPayload: any = {
      model,
      contents: Array.isArray(contents) ? contents : [{ role: 'user', parts: [{ text: String(contents) }] }]
    };

    if (systemInstruction) {
      requestPayload.config = {
        ...requestPayload.config,
        systemInstruction: typeof systemInstruction === 'string' ? systemInstruction : systemInstruction.parts?.[0]?.text
      };
    }

    if (generationConfig) {
      requestPayload.config = {
        ...requestPayload.config,
        ...(generationConfig.responseMimeType ? { responseMimeType: generationConfig.responseMimeType } : {}),
        ...(generationConfig.responseSchema ? { responseSchema: generationConfig.responseSchema } : {})
      };
    }

    const response = await ai.models.generateContent(requestPayload);
    const text = response.text;

    return res.json({ text, fallback: false });
  } catch (error: any) {
    console.error('Error in /api/gemini/generate:', error);
    return res.status(500).json({
      error: error.message || 'Erro ao processar chamada Gemini',
      fallback: true
    });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer();
