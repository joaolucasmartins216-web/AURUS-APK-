# Como gerar o APK do AURUS GYM

O projeto já é um app Capacitor (pasta `android/`). Duas formas de gerar o APK:

## Opção A — GitHub (sem instalar nada no PC)
1. Crie um repositório no GitHub (pode ser privado) e envie esta pasta:
   ```
   git init && git add . && git commit -m "AURUS GYM"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/aurus-gym.git
   git push -u origin main
   ```
2. No GitHub, abra a aba **Actions** → "Gerar APK (AURUS GYM)" → **Run workflow**.
3. Quando terminar (uns 5–10 min), baixe `aurus-gym-apk` em *Artifacts*, descompacte e você terá o `app-debug.apk`.

## Opção B — Android Studio
```
npm install --legacy-peer-deps
npm run cap:sync
npm run cap:open        # abre no Android Studio → Build > Build APK(s)
```
Ou, pelo terminal (precisa de JDK 21 e Android SDK 36):
```
cd android && ./gradlew assembleDebug
```
APK em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no celular
Copie o `.apk` para o Android e abra; permita "instalar apps de fontes desconhecidas" se pedir.

## Observações
- O APK é **debug** (assinado com a chave de debug): instala direto, mas não serve para a Play Store. Para publicar é preciso gerar um AAB/APK *release* assinado com sua própria keystore.
- A IA (Gemini) só funciona no APK se `VITE_API_BASE_URL` apontar para um backend seu em HTTPS. Sem isso, o app usa só o motor biomecânico offline. Nunca coloque `GEMINI_API_KEY` dentro do APK.
- Se `npm install` reclamar de `esbuild`/`vite`, use `--legacy-peer-deps` (ou `bun install`, já que o projeto tem `bun.lock`).
