package com.aurusgym.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
