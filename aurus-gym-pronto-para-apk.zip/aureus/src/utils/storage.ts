import {
  ActiveWorkoutSession,
  AppPreferences,
  BackupData,
  BiometricMetrics,
  CatalogExercise,
  CompletedWorkout,
  CheckinRecord,
  UserProfile,
  WorkoutDay
} from '../types';
import { DEFAULT_METRICS, DEFAULT_PROFILE, INITIAL_AI_WORKOUTS } from './constants';
import {
  exportFileCompat,
  hydrateLocalStorageFromNativePreferences,
  mirrorKeyToNativePreferences
} from './capacitorBridge';

export const STORAGE_KEYS = {
  PROFILE: 'aureus_profile_v2',
  METRICS: 'aureus_metrics_v2',
  CUSTOM_WORKOUTS: 'aureus_custom_workouts_v2',
  LAST_WEIGHTS: 'aureus_last_weights_v2',
  CHECKINS: 'aureus_checkins_v2',
  WORKOUT_HISTORY: 'aureus_workout_history_v2',
  ONBOARDING_DONE: 'aureus_onboarding_done_v2',
  ACTIVE_SESSION: 'aureus_active_session_v2',
  CUSTOM_EXERCISES: 'aureus_custom_exercises_v2',
  PREFERENCES: 'aureus_preferences_v2',
  LAST_BACKUP_AT: 'aureus_last_backup_at_v2'
};

export const DEFAULT_PREFERENCES: AppPreferences = {
  enhancedContrast: false,
  restSoundEnabled: true,
  vibrationEnabled: true,
  keepScreenAwake: true,
  weightUnit: 'kg',
  workoutReminderEnabled: true,
  preferredWorkoutTime: '18:00',
  weeklySummaryEnabled: true,
  textScale: 'default',
  reducedMotion: false,
  privateHistoryMode: false,
  autoSyncCalendar: true,
  logRealDurationToCalendar: true
};

function setStorageItemWithNativeMirror(key: string, value: string): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(key, value);
  }
  void mirrorKeyToNativePreferences(key, value);
}

function removeStorageItemWithNativeMirror(key: string): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem(key);
  }
  void mirrorKeyToNativePreferences(key, null);
}

/**
 * Sincroniza todas as chaves `aureus_*_v2` entre o `localStorage` da WebView
 * e o armazenamento nativo Android (`SharedPreferences` via `@capacitor/preferences`).
 * Se o Android tiver limpado o cache da WebView, restaura os dados nativos de volta ao `localStorage`.
 */
export async function syncAllStorageWithNativePreferences(): Promise<{
  restoredKeys: string[];
  backedUpKeys: string[];
}> {
  return hydrateLocalStorageFromNativePreferences(Object.values(STORAGE_KEYS));
}

export function loadProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading profile:', e);
  }
  return DEFAULT_PROFILE;
}

export function saveProfile(profile: UserProfile): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  } catch (e) {
    console.error('Error saving profile:', e);
  }
}

export function loadMetrics(): BiometricMetrics {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.METRICS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading metrics:', e);
  }
  return DEFAULT_METRICS;
}

export function saveMetrics(metrics: BiometricMetrics): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.METRICS, JSON.stringify(metrics));
  } catch (e) {
    console.error('Error saving metrics:', e);
  }
}

export function loadCustomWorkouts(): WorkoutDay[] | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOM_WORKOUTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading custom workouts:', e);
  }
  return INITIAL_AI_WORKOUTS;
}

export function saveCustomWorkouts(workouts: WorkoutDay[] | null): void {
  try {
    if (workouts) {
      setStorageItemWithNativeMirror(STORAGE_KEYS.CUSTOM_WORKOUTS, JSON.stringify(workouts));
    } else {
      removeStorageItemWithNativeMirror(STORAGE_KEYS.CUSTOM_WORKOUTS);
    }
  } catch (e) {
    console.error('Error saving custom workouts:', e);
  }
}

export function loadLastWeights(): Record<string, number> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LAST_WEIGHTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading weights:', e);
  }
  return {};
}

export function saveLastWeights(weights: Record<string, number>): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.LAST_WEIGHTS, JSON.stringify(weights));
  } catch (e) {
    console.error('Error saving weights:', e);
  }
}

export function loadCheckins(): CheckinRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHECKINS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading checkins:', e);
  }
  return [];
}

export function saveCheckins(checkins: CheckinRecord[]): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.CHECKINS, JSON.stringify(checkins));
  } catch (e) {
    console.error('Error saving checkins:', e);
  }
}

export function loadWorkoutHistory(): CompletedWorkout[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORKOUT_HISTORY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading workout history:', e);
  }
  return [];
}

export function saveWorkoutHistory(history: CompletedWorkout[]): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.WORKOUT_HISTORY, JSON.stringify(history));
  } catch (e) {
    console.error('Error saving workout history:', e);
  }
}

export function loadOnboardingCompleted(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEYS.ONBOARDING_DONE) === 'true';
  } catch {
    return false;
  }
}

export function saveOnboardingCompleted(completed: boolean): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.ONBOARDING_DONE, String(completed));
  } catch (e) {
    console.error('Error saving onboarding state:', e);
  }
}

export function isValidActiveSession(candidate: unknown): candidate is ActiveWorkoutSession {
  if (!candidate || typeof candidate !== 'object') return false;
  const obj = candidate as Record<string, unknown>;
  return (
    typeof obj.sessionId === 'string' &&
    obj.sessionId.length > 0 &&
    typeof obj.dayId === 'string' &&
    (obj.status === 'running' || obj.status === 'paused') &&
    typeof obj.startedAtMs === 'number' &&
    obj.sessionSets !== null &&
    typeof obj.sessionSets === 'object' &&
    obj.stopwatch !== null &&
    typeof obj.stopwatch === 'object' &&
    obj.restTimer !== null &&
    typeof obj.restTimer === 'object'
  );
}

export function loadActiveSession(): ActiveWorkoutSession | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_SESSION);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (isValidActiveSession(parsed)) {
      return parsed;
    }
  } catch (e) {
    console.warn('Error loading active session:', e);
  }
  return null;
}

export function saveActiveSession(session: ActiveWorkoutSession | null): void {
  try {
    if (typeof localStorage === 'undefined') return;
    if (session && (session.status === 'running' || session.status === 'paused')) {
      setStorageItemWithNativeMirror(STORAGE_KEYS.ACTIVE_SESSION, JSON.stringify(session));
    } else {
      removeStorageItemWithNativeMirror(STORAGE_KEYS.ACTIVE_SESSION);
    }
  } catch (e) {
    console.error('Error saving active session:', e);
  }
}

export function clearActiveSession(): void {
  try {
    if (typeof localStorage === 'undefined') return;
    removeStorageItemWithNativeMirror(STORAGE_KEYS.ACTIVE_SESSION);
  } catch (e) {
    console.error('Error clearing active session:', e);
  }
}

export function loadCustomExercises(): CatalogExercise[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOM_EXERCISES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(
          (item) =>
            item &&
            typeof item === 'object' &&
            typeof item.id === 'string' &&
            item.id.trim().length > 0 &&
            typeof item.name === 'string' &&
            item.name.trim().length > 0
        );
      }
    }
  } catch (e) {
    console.warn('Error loading custom exercises:', e);
  }
  return [];
}

export function saveCustomExercises(exercises: CatalogExercise[]): void {
  try {
    setStorageItemWithNativeMirror(STORAGE_KEYS.CUSTOM_EXERCISES, JSON.stringify(exercises));
  } catch (e) {
    console.error('Error saving custom exercises:', e);
  }
}

export function loadPreferences(): AppPreferences {
  try {
    if (typeof localStorage === 'undefined') return { ...DEFAULT_PREFERENCES };
    const raw = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return {
          ...DEFAULT_PREFERENCES,
          ...parsed
        };
      }
    }
  } catch (e) {
    console.warn('Error loading preferences:', e);
  }
  return { ...DEFAULT_PREFERENCES };
}

export function savePreferences(preferences: AppPreferences): void {
  try {
    if (typeof localStorage === 'undefined') return;
    setStorageItemWithNativeMirror(STORAGE_KEYS.PREFERENCES, JSON.stringify(preferences));
  } catch (e) {
    console.error('Error saving preferences:', e);
  }
}

export function loadLastBackupAt(): string | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    return localStorage.getItem(STORAGE_KEYS.LAST_BACKUP_AT);
  } catch {
    return null;
  }
}

export function saveLastBackupAt(isoTimestamp: string): void {
  try {
    if (typeof localStorage === 'undefined') return;
    setStorageItemWithNativeMirror(STORAGE_KEYS.LAST_BACKUP_AT, isoTimestamp);
  } catch (e) {
    console.error('Error saving last backup timestamp:', e);
  }
}

export function calculateLocalStorageUsageBytes(): {
  totalBytes: number;
  formattedSize: string;
} {
  let totalBytes = 0;
  try {
    if (typeof localStorage !== 'undefined') {
      const keys = Object.values(STORAGE_KEYS);
      for (const key of keys) {
        const val = localStorage.getItem(key);
        if (val) {
          totalBytes += (key.length + val.length) * 2;
        }
      }
    }
  } catch {
    // ignore
  }
  const kb = totalBytes / 1024;
  const formattedSize =
    kb >= 1024
      ? `${(kb / 1024).toFixed(2)} MB`
      : `${Math.max(1, Math.round(kb))} KB`;
  return { totalBytes, formattedSize };
}

export function buildWorkoutHistoryCSV(
  workoutHistory: CompletedWorkout[],
  checkins: CheckinRecord[] = []
): string {
  const escapeCsv = (val: unknown): string => {
    const str = val === null || val === undefined ? '' : String(val);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const lines: string[] = [];
  lines.push(
    [
      'Tipo',
      'ID',
      'Data',
      'Dia / Nota',
      'Titulo',
      'Duracao (min)',
      'Series Concluidas',
      'Total Series',
      'Volume Total (kg)',
      'RPE Sessao',
      'Exercicios / Medidas'
    ]
      .map(escapeCsv)
      .join(',')
  );

  for (const w of workoutHistory) {
    const durationMin = Math.max(1, Math.round((w.durationSec || 0) / 60));
    const exSummary = (w.exercisesSummary || [])
      .map((ex) => `${ex.name}: ${ex.maxWeight}kg (${ex.setsCompleted}/${ex.totalSets})`)
      .join(' | ');
    lines.push(
      [
        'TREINO',
        w.id,
        w.dateFormatted || new Date(w.timestamp).toLocaleDateString('pt-BR'),
        w.dayName,
        w.title,
        durationMin,
        w.completedSets,
        w.totalSets,
        w.tonnage,
        w.sessionRpe ?? '',
        exSummary
      ]
        .map(escapeCsv)
        .join(',')
    );
  }

  for (const c of checkins) {
    const isDemo = c.id.startsWith('chk_demo_');
    lines.push(
      [
        isDemo ? 'CHECKIN_SIMULACAO' : 'CHECKIN_REAL',
        c.id,
        c.dateFormatted,
        c.note,
        `Peso ${c.peso}kg`,
        '',
        '',
        '',
        '',
        '',
        `Ombros:${c.ombros}cm | Peito:${c.peito}cm | Cintura:${c.cintura}cm | Braco:${c.braco}cm | Coxa:${c.coxa}cm | Adonis:${c.indiceAdonis}`
      ]
        .map(escapeCsv)
        .join(',')
    );
  }

  return lines.join('\n');
}

export function exportWorkoutHistoryCSV(
  workoutHistory: CompletedWorkout[],
  checkins: CheckinRecord[] = []
): string {
  const csvContent = buildWorkoutHistoryCSV(workoutHistory, checkins);
  const filename = `aurus-gym-historico-${new Date().toISOString().slice(0, 10)}.csv`;
  void exportFileCompat({
    filename,
    content: csvContent,
    mimeType: 'text/csv;charset=utf-8;',
    shareTitle: 'Exportar Histórico AURUS GYM (.csv)'
  });
  return csvContent;
}

export function buildFullBackupPayload(
  profile: UserProfile,
  metrics: BiometricMetrics,
  customAiWorkouts: WorkoutDay[] | null,
  lastExerciseWeights: Record<string, number>,
  checkins: CheckinRecord[],
  workoutHistory: CompletedWorkout[],
  activeSession?: ActiveWorkoutSession | null,
  customExercises?: CatalogExercise[],
  preferences?: AppPreferences
): BackupData {
  const resolvedActiveSession =
    activeSession !== undefined ? activeSession : loadActiveSession();
  const resolvedCustomExercises =
    customExercises !== undefined ? customExercises : loadCustomExercises();
  const resolvedPreferences =
    preferences !== undefined ? preferences : loadPreferences();

  return {
    app: 'AUREUS_FORJA_CORPORAL',
    exportedAt: new Date().toISOString(),
    profile,
    metrics,
    customAiWorkouts,
    lastExerciseWeights,
    checkins,
    workoutHistory,
    activeSession: resolvedActiveSession ?? null,
    customExercises: resolvedCustomExercises,
    preferences: resolvedPreferences
  };
}

export interface BackupValidationResult {
  valid: boolean;
  data?: Partial<BackupData>;
  hasActiveSessionInBackup: boolean;
  error?: string;
}

export function validateBackupPayload(raw: unknown): BackupValidationResult {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      valid: false,
      hasActiveSessionInBackup: false,
      error: 'O arquivo selecionado não é um objeto JSON válido.'
    };
  }

  const obj = raw as Record<string, unknown>;
  const hasKnownKey =
    (obj.profile && typeof obj.profile === 'object') ||
    (obj.metrics && typeof obj.metrics === 'object') ||
    Array.isArray(obj.workoutHistory) ||
    Array.isArray(obj.checkins) ||
    Array.isArray(obj.customAiWorkouts) ||
    Array.isArray(obj.customExercises) ||
    (obj.lastExerciseWeights && typeof obj.lastExerciseWeights === 'object') ||
    (obj.preferences && typeof obj.preferences === 'object') ||
    isValidActiveSession(obj.activeSession);

  if (!hasKnownKey) {
    return {
      valid: false,
      hasActiveSessionInBackup: false,
      error: 'O arquivo não contém dados compatíveis com o AURUS GYM / AUREUS.'
    };
  }

  if (obj.activeSession !== undefined && obj.activeSession !== null) {
    if (!isValidActiveSession(obj.activeSession)) {
      return {
        valid: false,
        hasActiveSessionInBackup: false,
        error: 'A sessão ativa contida no backup está corrompida ou incompleta.'
      };
    }
  }

  const validatedActiveSession = isValidActiveSession(obj.activeSession)
    ? obj.activeSession
    : obj.activeSession === null
    ? null
    : undefined;

  return {
    valid: true,
    hasActiveSessionInBackup: isValidActiveSession(validatedActiveSession),
    data: {
      app: typeof obj.app === 'string' ? obj.app : 'AUREUS_FORJA_CORPORAL',
      exportedAt: typeof obj.exportedAt === 'string' ? obj.exportedAt : undefined,
      profile:
        obj.profile && typeof obj.profile === 'object'
          ? (obj.profile as UserProfile)
          : undefined,
      metrics:
        obj.metrics && typeof obj.metrics === 'object'
          ? (obj.metrics as BiometricMetrics)
          : undefined,
      customAiWorkouts:
        Array.isArray(obj.customAiWorkouts) || obj.customAiWorkouts === null
          ? (obj.customAiWorkouts as WorkoutDay[] | null)
          : undefined,
      lastExerciseWeights:
        obj.lastExerciseWeights && typeof obj.lastExerciseWeights === 'object'
          ? (obj.lastExerciseWeights as Record<string, number>)
          : undefined,
      checkins: Array.isArray(obj.checkins)
        ? (obj.checkins as CheckinRecord[])
        : undefined,
      workoutHistory: Array.isArray(obj.workoutHistory)
        ? (obj.workoutHistory as CompletedWorkout[])
        : undefined,
      activeSession: validatedActiveSession,
      customExercises: Array.isArray(obj.customExercises)
        ? (obj.customExercises as CatalogExercise[])
        : undefined,
      preferences:
        obj.preferences && typeof obj.preferences === 'object'
          ? ({ ...DEFAULT_PREFERENCES, ...(obj.preferences as Partial<AppPreferences>) })
          : undefined
    }
  };
}

export function exportFullBackupJSON(
  profile: UserProfile,
  metrics: BiometricMetrics,
  customAiWorkouts: WorkoutDay[] | null,
  lastExerciseWeights: Record<string, number>,
  checkins: CheckinRecord[],
  workoutHistory: CompletedWorkout[],
  activeSession?: ActiveWorkoutSession | null,
  customExercises?: CatalogExercise[],
  preferences?: AppPreferences
): BackupData {
  const backup = buildFullBackupPayload(
    profile,
    metrics,
    customAiWorkouts,
    lastExerciseWeights,
    checkins,
    workoutHistory,
    activeSession,
    customExercises,
    preferences
  );

  saveLastBackupAt(backup.exportedAt);

  const filename = `aureus-backup-${new Date().toISOString().slice(0, 10)}.json`;
  void exportFileCompat({
    filename,
    content: JSON.stringify(backup, null, 2),
    mimeType: 'application/json',
    shareTitle: 'Exportar Backup Completo AURUS GYM (.json)'
  });

  return backup;
}
