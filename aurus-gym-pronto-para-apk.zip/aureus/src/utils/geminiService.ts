import { BiometricMetrics, GoldenAnalysis, UserProfile, WorkoutDay, ExerciseItem } from '../types';
import { ALL_WEEK_DAYS, HYBRID_WORKOUT_TEMPLATE } from './constants';
import { resolveApiEndpoint } from './capacitorBridge';

export async function requestGeminiApi(payload: any): Promise<string> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    throw new Error('Dispositivo offline. Usando motor biomecânico local do AURUS GYM.');
  }

  const endpoint = resolveApiEndpoint('/api/gemini/generate');
  if (!endpoint) {
    throw new Error(
      'VITE_API_BASE_URL remota não configurada para o APK. Usando recalibração biomecânica local.'
    );
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    const data = await response.json();
    if (data.fallback) {
      throw new Error(data.text || 'Fallback mode');
    }
    return data.text || '';
  } finally {
    clearTimeout(timeoutId);
  }
}

export function generateAlgorithmicWorkoutPlan(
  profile: UserProfile,
  metrics: BiometricMetrics,
  goldenAnalysis: GoldenAnalysis,
  activeSelectedDays: string[],
  scope: 'week' | 'day',
  currentDayId?: string,
  userPrompt?: string
): WorkoutDay[] {
  const targetDaysMeta =
    scope === 'day' && currentDayId
      ? ALL_WEEK_DAYS.filter((d) => d.id === currentDayId)
      : ALL_WEEK_DAYS.filter((d) => activeSelectedDays.includes(d.id));

  const isDumbbellOnly = (userPrompt || '').toLowerCase().includes('halter') || (userPrompt || '').toLowerCase().includes('lotada');
  const isExpress = (userPrompt || '').toLowerCase().includes('40 min') || (userPrompt || '').toLowerCase().includes('rapido') || (userPrompt || '').toLowerCase().includes('rápido');
  const isLowImpact = (userPrompt || '').toLowerCase().includes('articular') || (userPrompt || '').toLowerCase().includes('impacto') || (userPrompt || '').toLowerCase().includes('dor');
  const isLegSave = (userPrompt || '').toLowerCase().includes('jogo') || (userPrompt || '').toLowerCase().includes('perna') || (userPrompt || '').toLowerCase().includes('poupar');

  return targetDaysMeta.map((dayMeta, idx) => {
    const templateDay = HYBRID_WORKOUT_TEMPLATE.find((t) => t.id === dayMeta.id) || HYBRID_WORKOUT_TEMPLATE[idx % HYBRID_WORKOUT_TEMPLATE.length];

    let adaptedExercises = templateDay.exercises.map((ex) => {
      let name = ex.name;
      let tip = ex.tip;
      let rest = isExpress ? Math.min(ex.rest, 60) : ex.rest;

      if (isDumbbellOnly) {
        if (name.includes('Barra') || name.includes('Máquina') || name.includes('Smith')) {
          name = name.replace('com Barra', 'com Halteres').replace('na Máquina', 'com Halteres').replace('no Smith', 'com Halteres');
          tip = 'Variação livre com halteres para contornar aparelhos ocupados na academia.';
        }
      }

      if (isLowImpact) {
        tip = 'Cadência controlada 3-1-2-1 com foco na conexão mente-músculo e proteção ligamentar.';
      }

      if (isLegSave && (ex.targetGroup === 'coxa' || ex.targetGroup === 'panturrilha')) {
        tip = 'Carga moderada e sem dano excêntrico excessivo para preservar potência do jogo amanhã.';
      }

      return {
        ...ex,
        name,
        rest,
        tip
      };
    });

    return {
      ...templateDay,
      id: dayMeta.id,
      dayName: dayMeta.full,
      shortDay: dayMeta.short,
      exercises: adaptedExercises
    };
  });
}

export function generateAlgorithmicExerciseSwap(
  exercise: ExerciseItem,
  reason: string
): ExerciseItem {
  const replacements: Record<string, Array<{ name: string; tip: string }>> = {
    ombros: [
      { name: 'Desenvolvimento com Halteres no Banco 75°', tip: 'Excelente alternativa com halteres livres sem ocupar máquinas.' },
      { name: 'Elevação Lateral na Polia Baixa', tip: 'Tensão contínua em todo o arco de movimento do deltoide lateral.' },
      { name: 'Crucifixo Invertido com Halteres Inclinado', tip: 'Isolamento estrito do deltoide posterior.' }
    ],
    peito: [
      { name: 'Supino Reto com Halteres', tip: 'Permite maior arco de adução e alivia estresse nos ombros.' },
      { name: 'Crucifixo no Banco Inclinado', tip: 'Alongamento profundo da porção clavicular do peitoral.' },
      { name: 'Flexão de Braço com Pés Elevados', tip: 'Ótima variação com peso corporal quando tudo está ocupado.' }
    ],
    braco: [
      { name: 'Rosca Martelo Alternada com Halteres', tip: 'Constrói o braquial e antebraço com halteres simples.' },
      { name: 'Tríceps Francês Unilateral com Halter', tip: 'Alongamento máximo da cabeça longa do tríceps.' },
      { name: 'Rosca Concentrada Apoiada na Coxa', tip: 'Pico isolado de bíceps sem necessidade de aparelhos.' }
    ],
    coxa: [
      { name: 'Afundo Búlgaro com Halteres', tip: 'Recrutamento unilateral intenso com apenas um par de halteres.' },
      { name: 'Agachamento Goblet com Halter', tip: 'Excelente ergonomia para joelhos e quadril com peso livre.' },
      { name: 'Stiff Unilateral com Halter', tip: 'Estabilidade e foco máximo em isquiotibiais.' }
    ],
    panturrilha: [
      { name: 'Panturrilha Unilateral no Degrau', tip: 'Amplitude máxima de alongamento e contração sem máquina.' },
      { name: 'Panturrilha com Halter em Pé', tip: 'Carga direta mantendo postura atlética ereta.' }
    ],
    cintura: [
      { name: 'Stomach Vacuum em 4 Apoios', tip: 'Controle respiratório do transverso do abdômen.' },
      { name: 'Prancha Lateral Estática', tip: 'Estabilidade de oblíquos sem hipertrofiar a linha de cintura.' }
    ],
    pescoco: [
      { name: 'Flexão Cervical Controlada no Banco', tip: 'Trabalho cuidadoso e seguro para simetria McCallum.' }
    ],
    quadril: [
      { name: 'Elevação Pélvica com Halter no Chão', tip: 'Ativação de glúteos e cadeia posterior sem máquina.' }
    ]
  };

  const pool = replacements[exercise.targetGroup] || replacements.ombros;
  const match = pool.find((item) => item.name !== exercise.name) || pool[0];

  return {
    ...exercise,
    id: `ex_swap_${Date.now()}`,
    name: match.name,
    tip: `${match.tip} (Substituído: ${reason})`
  };
}

export function generateAlgorithmicCoachReply(
  prompt: string,
  profile: UserProfile,
  metrics: BiometricMetrics,
  goldenAnalysis: GoldenAnalysis
): string {
  const lower = prompt.toLowerCase();
  const redSummary = goldenAnalysis.redZones
    .map((r) => `${r.shortLabel} (faltam +${r.delta}cm)`)
    .join(', ');

  if (lower.includes('ponto vermelho') || lower.includes('melhorar') || lower.includes('corrigir')) {
    return `Analisando seu Avatar 3D, suas prioridades imediatas são: ${redSummary || 'manter simetria'}.
1. Aumente o volume semanal para 16-18 séries dedicadas a esses grupos.
2. Priorize a fase excêntrica (3 segundos descendo) para criar maior microlesão seletiva.
3. Treine esses músculos no início da sessão quando seu glicogênio e foco neural estão no ápice.`;
  }

  if (lower.includes('cintura') || lower.includes('adônis') || lower.includes('adonis') || lower.includes('afinar')) {
    return `Para otimizar seu Índice de Adônis (atual: ${goldenAnalysis.indiceAdonisAtual} vs Meta 1.618):
1. Pratique Stomach Vacuum diariamente (4 a 5 séries de 25-30s em jejum ou pós-treino) para contrair o transverso.
2. Evite exercícios que hipertrofiem os oblíquos com cargas pesadas laterais.
3. Combine com cardio em Zona 2 (frequência entre 120-135 bpm) por 30-40 min em dias alternados para oxidar gordura visceral.`;
  }

  if (lower.includes('esporte') || lower.includes('futsal') || lower.includes('vôlei') || lower.includes('perna')) {
    return `Para casar a hipertrofia com ${profile.esporteComplementar}:
1. Nos dias que antecedem partidas ou treinos intensos do seu esporte, reduza o volume excêntrico de membros inferiores em 40%.
2. Foque em pliometria limpa e mobilidade de tornozelo/quadril na Fase 1.
3. Mantenha os treinos de força pura (agachamento/RDL) 48h longe dos jogos mais decisivos para evitar fadiga neuromuscular no joelho.`;
  }

  return `Com base na Proporção Áurea (Φ = 1.618) e Fórmula de McCallum para sua altura de ${metrics.altura}cm e pulso de ${metrics.pulso}cm:
- Sua simetria global atual está em ${goldenAnalysis.overallScore}%.
- Mantenha a cadência biomecânica anotada na Arena em cada série.
- Hidrate-se com eletrólitos e busque progressão de sobrecarga gradual (mesmo que de +1kg ou +1 repetição por treino).`;
}
