import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addOrUpdateExerciseInRoutine,
  BASE_EXERCISE_CATALOG,
  buildExerciseCatalog,
  createCustomCatalogExercise,
  filterExerciseCatalog,
  getExercisePersonalHistorySummary
} from './exerciseCatalog';
import { INITIAL_AI_WORKOUTS, DEFAULT_METRICS, DEFAULT_PROFILE } from './constants';
import { buildFullBackupPayload, validateBackupPayload } from './storage';
import { CompletedWorkout, SetLog } from '../types';

test('1. Carregamento do catálogo: preserva todos os IDs originais (e1..e27) da Arena e inclui variações clássicas', () => {
  const catalog = buildExerciseCatalog({
    workouts: INITIAL_AI_WORKOUTS
  });

  assert.ok(catalog.length >= 36, 'Catálogo deve ter pelo menos os 36 exercícios estruturados');

  for (let i = 1; i <= 27; i++) {
    const id = `e${i}`;
    const found = catalog.find((item) => item.id === id);
    assert.ok(found, `Exercício original ${id} deve existir no catálogo`);
    assert.ok(found.name.length > 0);
    assert.ok(found.executionSteps.length >= 3);
    assert.ok(found.safetyNotes.length >= 2);
  }
});

test('2 & 3. Pesquisa por nome e sem diferenciar acentos ou maiúsculas/minúsculas', () => {
  const catalog = buildExerciseCatalog();

  const resSupino = filterExerciseCatalog(catalog, { query: 'SUPINO RETO' });
  assert.ok(resSupino.some((ex) => ex.id === 'e1'));

  const resBulgaroSemAcento = filterExerciseCatalog(catalog, { query: 'bulgaro' });
  const resBulgaroComAcento = filterExerciseCatalog(catalog, { query: 'Búlgaro' });
  assert.equal(resBulgaroSemAcento.length, resBulgaroComAcento.length);
  assert.ok(resBulgaroSemAcento.some((ex) => ex.id === 'e24'));

  const resTricepsSemAcento = filterExerciseCatalog(catalog, { query: 'triceps frances' });
  assert.ok(resTricepsSemAcento.some((ex) => ex.id === 'e36'));
});

test('4, 5, 6 & 7. Filtros por grupo muscular, equipamento, combinação de filtros e estado sem resultados', () => {
  const catalog = buildExerciseCatalog();

  const chestOnly = filterExerciseCatalog(catalog, { muscleFilter: 'peito' });
  assert.ok(chestOnly.length > 0);
  assert.ok(chestOnly.every((ex) => ex.muscleFilter === 'peito'));

  const cableOnly = filterExerciseCatalog(catalog, { equipmentFilter: 'cabo' });
  assert.ok(cableOnly.length > 0);
  assert.ok(cableOnly.every((ex) => ex.equipmentCategory === 'cabo'));

  const chestAndBarbell = filterExerciseCatalog(catalog, {
    muscleFilter: 'peito',
    equipmentFilter: 'barra',
    query: 'supino'
  });
  assert.equal(chestAndBarbell.length, 1);
  assert.equal(chestAndBarbell[0].id, 'e1');

  const noMatch = filterExerciseCatalog(catalog, {
    muscleFilter: 'pescoco',
    equipmentFilter: 'maquinas',
    query: 'inexistente_xyz_999'
  });
  assert.equal(noMatch.length, 0);
});

test('8, 9, 10 & 11. Detalhes, Histórico real do exercício, Exercício sem histórico e ID para Evolução', () => {
  const catalog = buildExerciseCatalog();
  const supino = catalog.find((ex) => ex.id === 'e1')!;
  const elevacaoPelvica = catalog.find((ex) => ex.id === 'e34')!;

  const mockHistory: CompletedWorkout[] = [
    {
      id: 'wk_1',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 3000,
      durationSec: 2700,
      completedSets: 4,
      totalSets: 4,
      cardioCompleted: true,
      dateFormatted: '01/11/2026',
      timestamp: Date.parse('2026-11-01T10:00:00Z'),
      exercisesSummary: [
        {
          exerciseId: 'e1',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 4,
          totalSets: 4,
          maxWeight: 100,
          bestSetReps: 8,
          volumeKg: 3000
        }
      ]
    },
    {
      id: 'wk_2',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 3240,
      durationSec: 2800,
      completedSets: 4,
      totalSets: 4,
      cardioCompleted: true,
      dateFormatted: '08/11/2026',
      timestamp: Date.parse('2026-11-08T10:00:00Z'),
      exercisesSummary: [
        {
          exerciseId: 'e1',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 4,
          totalSets: 4,
          maxWeight: 110,
          bestSetReps: 6,
          volumeKg: 3240
        }
      ]
    }
  ];

  const supinoHistory = getExercisePersonalHistorySummary(supino, mockHistory, {});
  assert.equal(supinoHistory.hasHistory, true);
  assert.equal(supinoHistory.resolvedHistoryExerciseId, 'e1');
  assert.equal(supinoHistory.bestWeightKg, 110);
  assert.equal(supinoHistory.bestReps, 6);
  assert.equal(supinoHistory.lastWeightKg, 110);
  assert.equal(supinoHistory.sessionsCount, 2);
  assert.equal(supinoHistory.progressionDeltaKg, 10);

  const emptyHistory = getExercisePersonalHistorySummary(elevacaoPelvica, mockHistory, {});
  assert.equal(emptyHistory.hasHistory, false);
  assert.equal(emptyHistory.resolvedHistoryExerciseId, null);
  assert.equal(emptyHistory.bestWeightKg, null);
  assert.equal(emptyHistory.lastWeightKg, null);
  assert.equal(emptyHistory.sessionsCount, 0);
});

test('12, 13 & 14. Adição a uma rotina existente, prevenção de duplicatas e atualização controlada', () => {
  const catalog = buildExerciseCatalog();
  const crossover = catalog.find((ex) => ex.id === 'e32')!;
  const supino = catalog.find((ex) => ex.id === 'e1')!;

  // 1. Tentar adicionar Supino Reto (que já existe em 'seg') sem allowUpdateExisting -> bloqueia duplicata
  const duplicateAttempt = addOrUpdateExerciseInRoutine({
    currentCustomWorkouts: null,
    baseTemplate: INITIAL_AI_WORKOUTS,
    targetDayId: 'seg',
    catalogExercise: supino,
    plannedSets: 5,
    plannedReps: '6-8',
    position: 'start',
    allowUpdateExisting: false
  });
  assert.equal(duplicateAttempt.status, 'duplicate_blocked');

  // 2. Adicionar Crossover (novo em 'seg') no final da rotina
  const addResult = addOrUpdateExerciseInRoutine({
    currentCustomWorkouts: null,
    baseTemplate: INITIAL_AI_WORKOUTS,
    targetDayId: 'seg',
    catalogExercise: crossover,
    plannedSets: 4,
    plannedReps: '12-15',
    position: 'end',
    allowUpdateExisting: false
  });
  assert.equal(addResult.status, 'added');
  const updatedSeg = addResult.updatedWorkouts.find((d) => d.id === 'seg')!;
  assert.equal(updatedSeg.exercises[updatedSeg.exercises.length - 1].id, 'e32');
  assert.equal(updatedSeg.exercises[updatedSeg.exercises.length - 1].baseSets, 4);
  assert.equal(addResult.updatedSessionSets['e32'].length, 4);
});

test('15. Proteção de sessão em andamento ao editar ou adicionar exercício na rotina ativa', () => {
  const catalog = buildExerciseCatalog();
  const supino = catalog.find((ex) => ex.id === 'e1')!;
  const crossover = catalog.find((ex) => ex.id === 'e32')!;

  const activeSessionSets: Record<string, SetLog[]> = {
    e1: [
      { setNumber: 1, weight: 90, reps: 10, rpe: 8, completed: true },
      { setNumber: 2, weight: 100, reps: 8, rpe: 8.5, completed: true },
      { setNumber: 3, weight: 100, reps: 8, rpe: 8, completed: false },
      { setNumber: 4, weight: 100, reps: 8, rpe: 8, completed: false }
    ]
  };

  // Atualizar Supino durante sessão ativa preserva as 2 séries concluídas intactas!
  const protectedUpdate = addOrUpdateExerciseInRoutine({
    currentCustomWorkouts: null,
    baseTemplate: INITIAL_AI_WORKOUTS,
    targetDayId: 'seg',
    catalogExercise: supino,
    plannedSets: 5,
    plannedReps: '6-8',
    position: 'start',
    allowUpdateExisting: true,
    sessionSets: activeSessionSets,
    isSessionActiveOnTargetDay: true
  });

  assert.equal(protectedUpdate.status, 'protected_completed_sets');
  const updatedE1Sets = protectedUpdate.updatedSessionSets['e1'];
  assert.equal(updatedE1Sets.length, 5);
  assert.equal(updatedE1Sets[0].completed, true);
  assert.equal(updatedE1Sets[0].weight, 90);
  assert.equal(updatedE1Sets[1].completed, true);
  assert.equal(updatedE1Sets[1].weight, 100);
  assert.equal(updatedE1Sets[2].completed, false);

  // Adicionar um novo exercício durante sessão ativa não afeta as séries concluídas do Supino
  const addDuringActive = addOrUpdateExerciseInRoutine({
    currentCustomWorkouts: protectedUpdate.updatedWorkouts,
    baseTemplate: INITIAL_AI_WORKOUTS,
    targetDayId: 'seg',
    catalogExercise: crossover,
    plannedSets: 3,
    plannedReps: '12-15',
    position: 'end',
    sessionSets: protectedUpdate.updatedSessionSets,
    isSessionActiveOnTargetDay: true
  });

  assert.equal(addDuringActive.status, 'added');
  assert.equal(
    addDuringActive.updatedSessionSets['e1'].filter((s) => s.completed).length,
    2
  );
  assert.equal(addDuringActive.updatedSessionSets['e32'].length, 3);
});

test('16 & 17. Criação/preservação de exercícios personalizados e compatibilidade com backups JSON', () => {
  const existingCatalog = buildExerciseCatalog();

  // Impede sobrescrever exercício existente
  const duplicateCreation = createCustomCatalogExercise({
    name: 'Supino reto com barra',
    muscleFilter: 'peito',
    equipmentCategory: 'barra',
    existingCatalog
  });
  assert.equal(duplicateCreation.ok, false);

  // Cria novo exercício personalizado com sucesso
  const customCreation = createCustomCatalogExercise({
    name: 'Remada Cavalinho Articulada',
    muscleFilter: 'costas',
    equipmentCategory: 'maquinas',
    shortDescription: 'Tração com apoio peitoral para espessura dorsal.',
    existingCatalog,
    nowMs: 1700000000000
  });
  assert.equal(customCreation.ok, true);
  assert.ok(customCreation.exercise);
  assert.equal(customCreation.exercise!.isCustom, true);

  // Reconhece no catálogo unificado
  const mergedCatalog = buildExerciseCatalog({
    customExercises: [customCreation.exercise!]
  });
  assert.ok(mergedCatalog.some((ex) => ex.id === customCreation.exercise!.id));

  // Exporta e valida backup com customExercises e retrocompatibilidade sem customExercises
  const backupWithCustom = buildFullBackupPayload(
    DEFAULT_PROFILE,
    DEFAULT_METRICS,
    null,
    {},
    [],
    [],
    null,
    [customCreation.exercise!]
  );
  const validatedNew = validateBackupPayload(backupWithCustom);
  assert.equal(validatedNew.valid, true);
  assert.equal(validatedNew.data?.customExercises?.length, 1);

  const legacyBackup = {
    app: 'AUREUS_FORJA_CORPORAL',
    profile: DEFAULT_PROFILE,
    metrics: DEFAULT_METRICS,
    workoutHistory: []
  };
  const validatedLegacy = validateBackupPayload(legacyBackup);
  assert.equal(validatedLegacy.valid, true);
  assert.equal(validatedLegacy.data?.customExercises, undefined);
});
