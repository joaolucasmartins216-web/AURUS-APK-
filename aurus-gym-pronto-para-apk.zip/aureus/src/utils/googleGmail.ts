import { GoogleGmailMessage } from '../types';

function createMimeMessage(to: string, from: string, subject: string, bodyHtml: string): string {
  const boundary = '==_boundary_' + Date.now();
  const nl = '\r\n';

  const messageParts = [
    `To: ${to}`,
    `From: ${from}`,
    `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    btoa(unescape(encodeURIComponent(bodyHtml.replace(/<[^>]*>?/gm, '')))),
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    btoa(unescape(encodeURIComponent(bodyHtml))),
    '',
    `--${boundary}--`
  ];

  const raw = messageParts.join(nl);
  // Base64url encode
  return btoa(unescape(encodeURIComponent(raw)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

export async function fetchRecentGmailMessages(
  accessToken: string,
  maxResults = 10,
  query = ''
): Promise<GoogleGmailMessage[]> {
  const url = `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}${
    query ? `&q=${encodeURIComponent(query)}` : ''
  }`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Erro ${res.status} ao carregar mensagens do Gmail`);
  }

  const listData = await res.json();
  const messageSummaries = listData.messages || [];

  const detailedMessages: GoogleGmailMessage[] = await Promise.all(
    messageSummaries.slice(0, 8).map(async (m: any) => {
      try {
        const detailRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`
            }
          }
        );
        if (!detailRes.ok) return { id: m.id, threadId: m.threadId };
        const d = await detailRes.json();
        const headers: Record<string, string> = {};
        (d.payload?.headers || []).forEach((h: any) => {
          headers[h.name.toLowerCase()] = h.value;
        });

        return {
          id: d.id,
          threadId: d.threadId,
          snippet: d.snippet,
          subject: headers.subject || '(Sem assunto)',
          from: headers.from || 'Desconhecido',
          date: headers.date || '',
          internalDate: d.internalDate
        };
      } catch {
        return { id: m.id, threadId: m.threadId };
      }
    })
  );

  return detailedMessages;
}

export async function sendGmailMessage(
  accessToken: string,
  to: string,
  subject: string,
  bodyHtml: string,
  userEmail?: string
): Promise<{ id: string; threadId: string }> {
  const rawEmail = createMimeMessage(to, userEmail || 'me', subject, bodyHtml);
  const url = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw: rawEmail })
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Erro ${res.status} ao enviar email pelo Gmail`);
  }

  return await res.json();
}
