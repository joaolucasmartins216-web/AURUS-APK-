import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildRecordedLoadsList,
  calculateCurrentWeekStats,
  calculatePredictedWorkoutLoad,
  cleanDisplayText,
  getCurrentWeekBounds,
  getShortMuscleLabel,
  getWeekdayIdFromTimestamp,
  isDemoCheckin,
  isUserDataConfirmed,
  resolveWorkoutSchedule,
  splitCheckinsByOrigin
} from './dashboardLogic';
import { DEFAULT_METRICS, DEFAULT_PROFILE, INITIAL_AI_WORKOUTS } from './constants';
import { CheckinRecord, CompletedWorkout } from '../types';

test('Correction 1: isUserDataConfirmed differentiates default unconfirmed values from confirmed user data', () => {
  // Fresh state with default values and onboardingCompleted = false
  assert.equal(
    isUserDataConfirmed({
      onboardingCompleted: false,
      profile: { ...DEFAULT_PROFILE },
      metrics: { ...DEFAULT_METRICS }
    }),
    false
  );

  // Confirmed via onboarding wizard
  assert.equal(
    isUserDataConfirmed({
      onboardingCompleted: true,
      profile: { ...DEFAULT_PROFILE },
      metrics: { ...DEFAULT_METRICS }
    }),
    true
  );

  // Confirmed because user customized their weight
  assert.equal(
    isUserDataConfirmed({
      onboardingCompleted: false,
      profile: { ...DEFAULT_PROFILE },
      metrics: { ...DEFAULT_METRICS, peso: 88.5 }
    }),
    true
  );
});

test('Correction 2: splitCheckinsByOrigin separates demo simulation check-ins from real check-ins', () => {
  const sampleCheckins: CheckinRecord[] = [
    {
      id: 'chk_demo_1',
      note: 'Mês 1 // Ponto de Partida',
      peso: 98.5,
      ombros: 125,
      cintura: 100.5,
      peito: 94,
      braco: 36.5,
      coxa: 56.5,
      panturrilha: 42,
      indiceAdonis: 1.244,
      overallScore: 84.5,
      dateFormatted: '90 dias atrás',
      timestamp: 1000
    },
    {
      id: 'chk_1762588000000',
      note: 'Avaliação Real de Novembro',
      peso: 93.2,
      ombros: 130,
      cintura: 94,
      peito: 99,
      braco: 38.5,
      coxa: 59,
      panturrilha: 43,
      indiceAdonis: 1.383,
      overallScore: 89.1,
      dateFormatted: '08 de nov.',
      timestamp: 2000
    }
  ];

  assert.equal(isDemoCheckin(sampleCheckins[0]), true);
  assert.equal(isDemoCheckin(sampleCheckins[1]), false);

  const { realCheckins, demoCheckins } = splitCheckinsByOrigin(sampleCheckins);
  assert.equal(realCheckins.length, 1);
  assert.equal(realCheckins[0].id, 'chk_1762588000000');
  assert.equal(demoCheckins.length, 1);
  assert.equal(demoCheckins[0].id, 'chk_demo_1');
});

test('Correction 3: calculateCurrentWeekStats uses Monday-Sunday local week, real timestamp weekday, and separates sessions vs trained days', () => {
  // Wednesday, Nov 11, 2026 at 14:00 local time
  const wednesdayNow = new Date(2026, 10, 11, 14, 0, 0, 0).getTime();
  const bounds = getCurrentWeekBounds(wednesdayNow);

  const mondayMorning = new Date(2026, 10, 9, 9, 30, 0, 0).getTime();
  const mondayEvening = new Date(2026, 10, 9, 19, 15, 0, 0).getTime();
  const previousSunday = new Date(2026, 10, 8, 18, 0, 0, 0).getTime(); // Last week!

  assert.equal(getWeekdayIdFromTimestamp(mondayMorning), 'seg');
  assert.equal(getWeekdayIdFromTimestamp(wednesdayNow), 'qua');
  assert.equal(getWeekdayIdFromTimestamp(previousSunday), 'dom');
  assert.ok(previousSunday < bounds.mondayStartMs);

  // Two workouts completed on Monday (even if one used Terça sheet 'ter'), plus one from previous Sunday
  const history: CompletedWorkout[] = [
    {
      id: 'wk_2',
      dayId: 'ter', // User executed Terça sheet on Monday evening!
      dayName: 'Terça-feira',
      title: 'Treino B',
      tonnage: 4000,
      durationSec: 1800,
      completedSets: 10,
      totalSets: 10,
      cardioCompleted: true,
      dateFormatted: '09/11/2026',
      timestamp: mondayEvening,
      exercisesSummary: []
    },
    {
      id: 'wk_1',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 5000,
      durationSec: 2400,
      completedSets: 12,
      totalSets: 12,
      cardioCompleted: false,
      dateFormatted: '09/11/2026',
      timestamp: mondayMorning,
      exercisesSummary: []
    },
    {
      id: 'wk_prev_week',
      dayId: 'sab',
      dayName: 'Sábado',
      title: 'Treino F',
      tonnage: 6000,
      durationSec: 3000,
      completedSets: 15,
      totalSets: 15,
      cardioCompleted: true,
      dateFormatted: '08/11/2026',
      timestamp: previousSunday,
      exercisesSummary: []
    }
  ];

  const stats = calculateCurrentWeekStats(history, 5, wednesdayNow);
  assert.equal(stats.totalSessionsAllTime, 3);
  assert.equal(stats.weeklySessionsCount, 2); // 2 sessions in current Mon-Sun week
  assert.equal(stats.trainedDaysCount, 1); // Both occurred on Monday ('seg')
  assert.equal(stats.trainedWeekdayIds.has('seg'), true);
  assert.equal(stats.trainedWeekdayIds.has('ter'), false); // Tuesday was NOT trained according to real timestamp!
  assert.equal(stats.weeklyFrequencyPct, 20); // 1 trained day out of 5 target days = 20%
  assert.equal(stats.weeklyTonnage, 9000);
  assert.equal(stats.weeklyCompletedSets, 22);
});

test('Correction 4: resolveWorkoutSchedule identifies today scheduled workout vs manual selection', () => {
  // Wednesday, Nov 11, 2026 ('qua')
  const wednesdayNow = new Date(2026, 10, 11, 10, 0, 0, 0).getTime();
  const trainedDays = new Set<string>(['seg', 'ter']);

  // When selectedDayId matches today's workout ('qua')
  const resToday = resolveWorkoutSchedule(INITIAL_AI_WORKOUTS, 'qua', trainedDays, wednesdayNow);
  assert.equal(resToday.statusKind, 'today_scheduled');
  assert.equal(resToday.isManualSelection, false);
  assert.equal(resToday.recommendedWorkout?.id, 'qua');
  assert.equal(resToday.badgeLabel, 'Treino de hoje');

  // When user manually selects 'sex' on Wednesday
  const resManual = resolveWorkoutSchedule(INITIAL_AI_WORKOUTS, 'sex', trainedDays, wednesdayNow);
  assert.equal(resManual.statusKind, 'manual_selection');
  assert.equal(resManual.isManualSelection, true);
  assert.equal(resManual.displayedWorkout?.id, 'sex');
  assert.equal(resManual.recommendedWorkout?.id, 'qua');
});

test('Correction 5: buildRecordedLoadsList works with both workoutHistory and lastExerciseWeights without false record claims', () => {
  // Case A: Only lastExerciseWeights (no workoutHistory)
  const fromWeightsOnly = buildRecordedLoadsList([], { e1: 65, e11: 90 }, INITIAL_AI_WORKOUTS);
  assert.equal(fromWeightsOnly.length, 2);
  assert.equal(fromWeightsOnly[0].name, 'Supino Reto com Barra');
  assert.equal(fromWeightsOnly[0].lastWeight, 65);
  assert.equal(fromWeightsOnly[0].hasProgressionHistory, false);
  assert.equal(fromWeightsOnly[0].statusLabel, 'Última carga salva');

  // Case B: Multi-session progression in workoutHistory
  const history: CompletedWorkout[] = [
    {
      id: 'wk_2',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 3000,
      durationSec: 1800,
      completedSets: 4,
      totalSets: 4,
      cardioCompleted: false,
      dateFormatted: '10/11',
      timestamp: 2000,
      exercisesSummary: [
        {
          exerciseId: 'e1',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 4,
          totalSets: 4,
          maxWeight: 70
        }
      ]
    },
    {
      id: 'wk_1',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 2500,
      durationSec: 1800,
      completedSets: 4,
      totalSets: 4,
      cardioCompleted: false,
      dateFormatted: '03/11',
      timestamp: 1000,
      exercisesSummary: [
        {
          exerciseId: 'e1',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 4,
          totalSets: 4,
          maxWeight: 62
        }
      ]
    }
  ];

  const merged = buildRecordedLoadsList(history, { e1: 70, e2: 18 }, INITIAL_AI_WORKOUTS);
  const e1 = merged.find((i) => i.id === 'e1');
  const e2 = merged.find((i) => i.id === 'e2');
  assert.ok(e1);
  assert.equal(e1.sessionsCount, 2);
  assert.equal(e1.maxWeight, 70);
  assert.equal(e1.hasProgressionHistory, true);

  assert.ok(e2);
  assert.equal(e2.sessionsCount, 0);
  assert.equal(e2.lastWeight, 18);
  assert.equal(e2.hasProgressionHistory, false);
});

test('Stitch Design System Helpers: cleanDisplayText, getShortMuscleLabel, and calculatePredictedWorkoutLoad', () => {
  assert.equal(
    cleanDisplayText('Treino A // Hipertrofia de Peitoral & Braço'),
    'Treino A · Hipertrofia de Peitoral & Braço'
  );
  assert.equal(getShortMuscleLabel(INITIAL_AI_WORKOUTS[0]), 'Peito');
  assert.equal(getShortMuscleLabel(INITIAL_AI_WORKOUTS[1]), 'Costas');
  assert.equal(getShortMuscleLabel(INITIAL_AI_WORKOUTS[2]), 'Pernas');
  assert.equal(getShortMuscleLabel(null), 'Off');

  // Without saved weights, predicted load is 0 (never invented)
  const emptyLoad = calculatePredictedWorkoutLoad(INITIAL_AI_WORKOUTS[0], {});
  assert.equal(emptyLoad.predictedLoadKg, 0);
  assert.equal(emptyLoad.exercisesWithLoadCount, 0);

  // With real saved weight for e1 (4 sets * 8 reps * 60 kg = 1920 kg)
  const realLoad = calculatePredictedWorkoutLoad(INITIAL_AI_WORKOUTS[0], { e1: 60 });
  assert.equal(realLoad.exercisesWithLoadCount, 1);
  assert.equal(realLoad.predictedLoadKg, 1920);
});
