import test from 'node:test';
import assert from 'node:assert';
import { buildWorkoutEventDescription } from './googleCalendar';
import { WorkoutDay } from '../types';

test('buildWorkoutEventDescription includes workout title, subtitle and exercises', () => {
  const mockWorkout: WorkoutDay = {
    id: 'seg',
    dayName: 'Segunda-feira',
    shortDay: 'SEG',
    title: 'Peito & Deltoide Lateral',
    subtitle: 'Foco no V-Taper Áureo',
    exercises: [
      {
        id: 'ex1',
        name: 'Supino Inclinado com Halteres',
        targetGroup: 'peito',
        baseSets: 4,
        totalSets: 4,
        reps: '8-10',
        rest: 90,
        cadence: '3-0-1-0',
        defaultWeight: 30,
        tip: 'Controle na descida'
      },
      {
        id: 'ex2',
        name: 'Elevação Lateral na Polia',
        targetGroup: 'ombros',
        baseSets: 4,
        totalSets: 4,
        reps: '12-15',
        rest: 60,
        cadence: '2-1-1-1',
        defaultWeight: 10,
        tip: 'Foco no deltóide medial'
      }
    ],
    mobility: [
      { id: 'm1', name: 'Rotação Externa de Ombro', duration: '2 min', focus: 'Manguito rotador' }
    ]
  };

  const desc = buildWorkoutEventDescription(mockWorkout);
  assert.ok(desc.includes('Peito & Deltoide Lateral'));
  assert.ok(desc.includes('Foco no V-Taper Áureo'));
  assert.ok(desc.includes('Supino Inclinado com Halteres'));
  assert.ok(desc.includes('Elevação Lateral na Polia'));
  assert.ok(desc.includes('Rotação Externa de Ombro'));
  assert.ok(desc.includes('1.618'));
});
