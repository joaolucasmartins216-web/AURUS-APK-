import { GoogleCalendarEvent, WorkoutDay } from '../types';

export async function fetchCalendarEvents(accessToken: string, maxResults = 15): Promise<GoogleCalendarEvent[]> {
  const timeMin = new Date().toISOString();
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?orderBy=startTime&singleEvents=true&timeMin=${encodeURIComponent(
    timeMin
  )}&maxResults=${maxResults}`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Erro ${res.status} ao carregar eventos do Google Calendar`);
  }

  const data = await res.json();
  return (data.items || []).map((item: any) => ({
    id: item.id,
    summary: item.summary || 'Treino / Evento',
    description: item.description,
    start: item.start || {},
    end: item.end || {},
    location: item.location,
    htmlLink: item.htmlLink
  }));
}

export async function createCalendarEvent(
  accessToken: string,
  event: {
    summary: string;
    description?: string;
    startDateTime: string;
    endDateTime: string;
    location?: string;
  }
): Promise<GoogleCalendarEvent> {
  const url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Sao_Paulo';

  const body = {
    summary: event.summary,
    description: event.description,
    start: {
      dateTime: event.startDateTime,
      timeZone
    },
    end: {
      dateTime: event.endDateTime,
      timeZone
    },
    location: event.location || 'Academia',
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'popup', minutes: 30 },
        { method: 'popup', minutes: 10 }
      ]
    }
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Erro ${res.status} ao criar evento no Google Calendar`);
  }

  const data = await res.json();
  return {
    id: data.id,
    summary: data.summary,
    description: data.description,
    start: data.start,
    end: data.end,
    location: data.location,
    htmlLink: data.htmlLink
  };
}

export async function deleteCalendarEvent(accessToken: string, eventId: string): Promise<void> {
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });

  if (!res.ok && res.status !== 404) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Erro ${res.status} ao excluir evento do Google Calendar`);
  }
}

export function buildWorkoutEventDescription(workoutDay: WorkoutDay): string {
  const exercisesText = workoutDay.exercises
    .map(
      (ex, i) =>
        `${i + 1}. ${ex.name} — ${ex.totalSets || ex.baseSets} séries × ${ex.reps} (Descanso: ${ex.rest}s)`
    )
    .join('\n');

  const mobilityText = workoutDay.mobility
    ? '\nMOBILIDADE PREPARATÓRIA:\n' +
      workoutDay.mobility.map((m) => `• ${m.name} (${m.duration})`).join('\n')
    : '';

  return `🏛️ AUREUS // FORJA CORPORAL
Sessão: ${workoutDay.title}
Foco: ${workoutDay.subtitle}
${mobilityText}

EXERCÍCIOS PROGRAMADOS:
${exercisesText}

Cadência e sobrecarga progressiva guiadas pelo Índice de Adônis (Φ = 1.618).`;
}
