import { CompletedWorkout, ExerciseItem, SetLog } from '../types';

export interface ArenaSessionStats {
  totalSets: number;
  completedSets: number;
  tonnage: number;
  progressPct: number;
}

/**
 * Calculates live session metrics strictly from real session sets.
 * Only completed sets contribute to total volume (tonnage) and completedSets count.
 */
export function calculateArenaSessionStats(
  exercises: ExerciseItem[],
  sessionSets: Record<string, SetLog[]>
): ArenaSessionStats {
  let totalSets = 0;
  let completedSets = 0;
  let tonnage = 0;

  exercises.forEach((ex) => {
    const sets = sessionSets[ex.id] || [];
    sets.forEach((s) => {
      totalSets += 1;
      if (s.completed) {
        completedSets += 1;
        const w = Math.max(0, Number(s.weight) || 0);
        const r = Math.max(0, Number(s.reps) || 0);
        tonnage += w * r;
      }
    });
  });

  const progressPct = totalSets > 0 ? Math.min(100, Math.round((completedSets / totalSets) * 100)) : 0;

  return {
    totalSets,
    completedSets,
    tonnage: Math.round(tonnage * 10) / 10,
    progressPct
  };
}

/**
 * Formats seconds into HH:MM:SS (for main session timer) or MM:SS (for rest timer).
 */
export function formatArenaTimer(sec: number, includeHours = false): string {
  const safe = Math.max(0, Math.floor(Number(sec) || 0));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const rem = safe % 60;

  if (includeHours || hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

export interface ExercisePreviousReference {
  hasHistory: boolean;
  lastWeightKg: number | null;
  bestWeightKg: number | null;
  lastDateLabel: string | null;
  summaryText: string;
  tableCellText: string;
}

/**
 * Extracts real historical load reference for an exercise from lastExerciseWeights and workoutHistory.
 * Never fabricates static weights or PRs when no history exists.
 */
export function getExercisePreviousReference(
  exercise: ExerciseItem,
  lastExerciseWeights?: Record<string, number>,
  workoutHistory?: CompletedWorkout[]
): ExercisePreviousReference {
  const directLastWeight =
    lastExerciseWeights && typeof lastExerciseWeights[exercise.id] === 'number' && lastExerciseWeights[exercise.id] > 0
      ? lastExerciseWeights[exercise.id]
      : null;

  let bestHistoricalWeight: number | null = directLastWeight;
  let latestHistoricalWeight: number | null = directLastWeight;
  let lastDateLabel: string | null = null;

  if (Array.isArray(workoutHistory) && workoutHistory.length > 0) {
    for (const wk of workoutHistory) {
      const match = wk.exercisesSummary?.find(
        (s) => s.exerciseId === exercise.id || s.name.toLowerCase() === exercise.name.toLowerCase()
      );
      if (match && match.maxWeight > 0) {
        if (latestHistoricalWeight === null) {
          latestHistoricalWeight = match.maxWeight;
        }
        if (lastDateLabel === null && wk.dateFormatted) {
          lastDateLabel = wk.dateFormatted.split(',')[0] || wk.dateFormatted;
        }
        if (bestHistoricalWeight === null || match.maxWeight > bestHistoricalWeight) {
          bestHistoricalWeight = match.maxWeight;
        }
      }
    }
  }

  const targetRepsText = String(exercise.reps || '').split('-')[0]?.trim() || '10';

  if (bestHistoricalWeight !== null && bestHistoricalWeight > 0) {
    const dateSuffix = lastDateLabel ? ` · ${lastDateLabel}` : ' · Histórico confirmado';
    return {
      hasHistory: true,
      lastWeightKg: latestHistoricalWeight ?? bestHistoricalWeight,
      bestWeightKg: bestHistoricalWeight,
      lastDateLabel,
      summaryText: `${bestHistoricalWeight} kg (meta ${exercise.reps} reps)${dateSuffix}`,
      tableCellText: `${latestHistoricalWeight ?? bestHistoricalWeight} kg × ${targetRepsText}`
    };
  }

  return {
    hasHistory: false,
    lastWeightKg: null,
    bestWeightKg: null,
    lastDateLabel: null,
    summaryText: `Sem histórico anterior · Base sugerida: ${exercise.defaultWeight} kg`,
    tableCellText: 'Sem registro'
  };
}

/**
 * Resolves which set index is currently focused in the active set editor.
 * If the user manually selected a valid set index, use that; otherwise pick the first uncompleted set,
 * or the last set if all sets are completed.
 */
export function resolveFocusedSetIndex(sets: SetLog[], manualFocusedIndex: number | null): number {
  if (!sets || sets.length === 0) return 0;
  if (
    manualFocusedIndex !== null &&
    manualFocusedIndex >= 0 &&
    manualFocusedIndex < sets.length
  ) {
    return manualFocusedIndex;
  }
  const firstPendingIdx = sets.findIndex((s) => !s.completed);
  return firstPendingIdx >= 0 ? firstPendingIdx : sets.length - 1;
}
