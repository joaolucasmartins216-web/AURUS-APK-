import { BiometricMetrics, UserProfile, WorkoutDay } from '../types';

export const ALL_WEEK_DAYS = [
  { id: 'seg', short: 'SEG', label: 'Segunda', full: 'Segunda-feira' },
  { id: 'ter', short: 'TER', label: 'Terça', full: 'Terça-feira' },
  { id: 'qua', short: 'QUA', label: 'Quarta', full: 'Quarta-feira' },
  { id: 'qui', short: 'QUI', label: 'Quinta', full: 'Quinta-feira' },
  { id: 'sex', short: 'SEX', label: 'Sexta', full: 'Sexta-feira' },
  { id: 'sab', short: 'SÁB', label: 'Sábado', full: 'Sábado' },
  { id: 'dom', short: 'DOM', label: 'Domingo', full: 'Domingo' }
];

export const AI_REFORMULATION_PRESETS = [
  {
    id: 'dias',
    label: 'Adaptar divisão aos meus dias marcados',
    scope: 'week' as const,
    prompt:
      'Redistribua todo o volume semanal perfeitamente apenas nos dias da semana que marquei como ativos, priorizando meus pontos vermelhos do Avatar 3D.'
  },
  {
    id: 'lotada',
    label: 'Academia lotada: só halteres e peso livre',
    scope: 'day' as const,
    prompt:
      'A academia está lotada hoje. Substitua as máquinas e polias disputadas deste treino por variações equivalentes usando apenas halteres, barras livres ou peso corporal, mantendo o foco biomecânico.'
  },
  {
    id: 'rapido',
    label: 'Treino expresso de 40 min (Alta densidade)',
    scope: 'day' as const,
    prompt:
      'Tenho apenas 40 minutos hoje. Reformule o treino de hoje com exercícios compostos de alto recrutamento, descansos de 45-60s e técnicas agonista/antagonista sem perder estímulo hipertrófico.'
  },
  {
    id: 'esporte',
    label: 'Jogo amanhã: poupar fadiga nas pernas',
    scope: 'day' as const,
    prompt:
      'Tenho partida intensa do meu esporte complementar amanhã. Reduza o dano muscular excêntrico nos membros inferiores hoje, foque em potência limpa, estabilidade articular, mobilidade de quadril/tornozelo e estímulo na parte superior.'
  },
  {
    id: 'articular',
    label: 'Desconforto articular: baixo impacto',
    scope: 'day' as const,
    prompt:
      'Estou sentindo leve fadiga articular hoje. Substitua exercícios de alta compressão axial ou estresse nos tendões por variações mais ergonômicas, cadência controlada e isometria.'
  }
];

export const DEFAULT_PROFILE: UserProfile = {
  nome: 'JOÃO',
  experiencia: 'Intermediário',
  diasSemana: 6,
  diasSelecionados: ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'],
  esporteComplementar: 'Futsal / Futebol & Vôlei',
  focoMobilidade: 'Quadril, Tornozelo e Estabilidade de Joelho',
  objetivoPrincipal: 'Estética Áurea (V-Taper) + Performance Atlética'
};

export const DEFAULT_METRICS: BiometricMetrics = {
  idade: 24,
  peso: 95,
  altura: 176,
  pulso: 20, // McCallum anchor
  ombros: 129,
  peito: 97, // Red Zone -> needs massive focus
  cintura: 96, // Red Zone -> trim line
  quadril: 106,
  braco: 38,
  coxa: 58,
  panturrilha: 43,
  pescoco: 40
};

export const INITIAL_AI_WORKOUTS: WorkoutDay[] = [
  {
    id: 'seg',
    dayName: 'Segunda-feira',
    shortDay: 'SEG',
    title: 'Treino A // Hipertrofia de Peitoral & Braço',
    subtitle: 'Expansão de Caixa Torácica (Delta 33cm) e Tríceps',
    focusGroups: ['peito', 'braco', 'pescoco'],
    mobility: [
      {
        id: 'm1',
        name: 'Mobilidade de Tornozelo na Parede',
        duration: '3 min',
        focus: 'Dorsiflexão para estabilidade em esportes'
      },
      {
        id: 'm2',
        name: 'Abertura de Peitoral com Bastão / Parede',
        duration: '2 min',
        focus: 'Expansão da caixa torácica e mobilidade escapular'
      }
    ],
    exercises: [
      {
        id: 'e1',
        name: 'Supino Reto com Barra',
        targetGroup: 'peito',
        baseSets: 4,
        reps: '8-10',
        rest: 90,
        cadence: '3-0-1-1',
        defaultWeight: 60,
        tip: 'Foco na fase excêntrica de 3s para recrutar o máximo de fibras torácicas.'
      },
      {
        id: 'e2',
        name: 'Crucifixo Inclinado com Halteres (30°)',
        targetGroup: 'peito',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '2-0-2-0',
        defaultWeight: 16,
        tip: 'Maximize o alongamento na base do movimento sem hiperestender ombros.'
      },
      {
        id: 'e3',
        name: 'Tríceps Testa com Barra EZ',
        targetGroup: 'braco',
        baseSets: 4,
        reps: '10-12',
        rest: 60,
        cadence: '3-0-1-0',
        defaultWeight: 24,
        tip: 'Mantenha os cotovelos alinhados e fechados para isolar a cabeça longa.'
      },
      {
        id: 'e4',
        name: 'Tríceps Corda na Polia',
        targetGroup: 'braco',
        baseSets: 3,
        reps: '12-15',
        rest: 45,
        cadence: '2-0-2-2',
        defaultWeight: 25,
        tip: 'Abra a corda no final da contração e segure 2 segundos.'
      },
      {
        id: 'e5',
        name: 'Flexão de Pescoço Controlada com Peso',
        targetGroup: 'pescoco',
        baseSets: 3,
        reps: '15-20',
        rest: 60,
        cadence: '2-0-2-0',
        defaultWeight: 5,
        tip: 'Tríade McCallum: pescoço, panturrilha e braço equilibrados.'
      }
    ]
  },
  {
    id: 'ter',
    dayName: 'Terça-feira',
    shortDay: 'TER',
    title: 'Treino B // Dorsais, Bíceps Progressivo & Cintura',
    subtitle: 'Manutenção de Simetria, Pico de Bíceps e Compactação do Core',
    focusGroups: ['ombros', 'braco', 'cintura'],
    mobility: [
      {
        id: 'm3',
        name: 'Gato-Camelo Dinâmico + Rotação Torácica',
        duration: '2 min',
        focus: 'Saúde da coluna e mobilidade escapular'
      }
    ],
    exercises: [
      {
        id: 'e6',
        name: 'Puxada Aberta no Pulley / Barra Fixa',
        targetGroup: 'ombros',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '2-0-2-0',
        defaultWeight: 55,
        tip: 'Manutenção de largura de ombros e expansão do V-Taper.'
      },
      {
        id: 'e7',
        name: 'Rosca Direta com Barra W',
        targetGroup: 'braco',
        baseSets: 4,
        reps: '8-10',
        rest: 75,
        cadence: '3-0-1-1',
        defaultWeight: 26,
        tip: 'Sem balanço de tronco; aperte o bíceps no topo.'
      },
      {
        id: 'e8',
        name: 'Rosca Martelo com Halteres',
        targetGroup: 'braco',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '2-0-2-0',
        defaultWeight: 14,
        tip: 'Foco no braquiorradial para conferir espessura maciça ao braço.'
      },
      {
        id: 'e9',
        name: 'Prancha Abdominal RKC',
        targetGroup: 'cintura',
        baseSets: 4,
        reps: '45 seg',
        rest: 45,
        cadence: 'Isometria',
        defaultWeight: 0,
        tip: 'Mantenha o core rígido para compactar a circunferência da cintura.'
      },
      {
        id: 'e10',
        name: 'Abdominal Supra na Polia Alta',
        targetGroup: 'cintura',
        baseSets: 3,
        reps: '15-20',
        rest: 60,
        cadence: '2-0-2-1',
        defaultWeight: 35,
        tip: 'Foque no controle e na contração profunda do reto abdominal.'
      }
    ]
  },
  {
    id: 'qua',
    dayName: 'Quarta-feira',
    shortDay: 'QUA',
    title: 'Treino C // Potência & Volume de Membros Inferiores',
    subtitle: 'Foco em Coxas e Estabilidade de Joelho para Futsal/Vôlei',
    focusGroups: ['coxa', 'panturrilha'],
    mobility: [
      {
        id: 'm4',
        name: 'Mobilidade de Quadril 90/90 Dinâmica',
        duration: '4 min',
        focus: 'Amplitude para movimentos laterais e giros no esporte'
      }
    ],
    exercises: [
      {
        id: 'e11',
        name: 'Agachamento Livre com Barra',
        targetGroup: 'coxa',
        baseSets: 4,
        reps: '8-10',
        rest: 120,
        cadence: '3-0-1-1',
        defaultWeight: 80,
        tip: 'Base sólida com amplitude completa para construir volume nas coxas.'
      },
      {
        id: 'e12',
        name: 'Leg Press 45°',
        targetGroup: 'coxa',
        baseSets: 3,
        reps: '10-12',
        rest: 90,
        cadence: '2-0-2-0',
        defaultWeight: 160,
        tip: 'Pés na largura dos ombros para foco balanceado no quadríceps.'
      },
      {
        id: 'e13',
        name: 'Cadeira Extensora (Pausa no topo)',
        targetGroup: 'coxa',
        baseSets: 3,
        reps: '12-15',
        rest: 45,
        cadence: '2-0-2-2',
        defaultWeight: 50,
        tip: 'Pico de contração de 2s no topo para reforço do vasto medial.'
      },
      {
        id: 'e14',
        name: 'Cadeira Flexora / Mesa Flexora',
        targetGroup: 'coxa',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '2-0-2-1',
        defaultWeight: 45,
        tip: 'Essencial para prevenir lesões e estiramentos em arrancadas.'
      },
      {
        id: 'e15',
        name: 'Gêmeos em Pé (Panturrilha Smith)',
        targetGroup: 'panturrilha',
        baseSets: 4,
        reps: '15-20',
        rest: 45,
        cadence: '2-1-2-1',
        defaultWeight: 60,
        tip: 'Alongue ao máximo embaixo antes de subir com explosão.'
      }
    ]
  },
  {
    id: 'qui',
    dayName: 'Quinta-feira',
    shortDay: 'QUI',
    title: 'Treino D // Reforço AUREUS: Peito e Braços',
    subtitle: 'Ataque Intensivo às Zonas Vermelhas (Peito e Braços)',
    focusGroups: ['peito', 'braco', 'pescoco'],
    mobility: [
      {
        id: 'm5',
        name: 'Liberação e Abertura Peitoral',
        duration: '3 min',
        focus: 'Melhorar recrutamento das fibras superiores claviculares'
      }
    ],
    exercises: [
      {
        id: 'e16',
        name: 'Supino Inclinado com Halteres',
        targetGroup: 'peito',
        baseSets: 4,
        reps: '8-10',
        rest: 90,
        cadence: '3-0-1-1',
        defaultWeight: 22,
        tip: 'Foco na porção clavicular para preencher a parte superior do tórax.'
      },
      {
        id: 'e17',
        name: 'Dips / Paralelas ou Graviton',
        targetGroup: 'peito',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '2-0-1-0',
        defaultWeight: 0,
        tip: 'Incline o tronco à frente para acionar o peitoral inferior.'
      },
      {
        id: 'e18',
        name: 'Rosca Scott com Barra W',
        targetGroup: 'braco',
        baseSets: 3,
        reps: '10-12',
        rest: 60,
        cadence: '3-0-1-0',
        defaultWeight: 22,
        tip: 'Isolamento estrito do bíceps sem impulso do ombro.'
      },
      {
        id: 'e19',
        name: 'Extensão de Tríceps Unilateral na Polia',
        targetGroup: 'braco',
        baseSets: 3,
        reps: '12-15',
        rest: 45,
        cadence: '2-0-2-0',
        defaultWeight: 12,
        tip: 'Corrige assimetrias sutis entre os dois braços.'
      },
      {
        id: 'e20',
        name: 'Extensão de Pescoço com Resistência',
        targetGroup: 'pescoco',
        baseSets: 3,
        reps: '15-20',
        rest: 60,
        cadence: '2-0-2-0',
        defaultWeight: 5,
        tip: 'Fortalece a cadeia posterior cervical e postura atlética.'
      }
    ]
  },
  {
    id: 'sex',
    dayName: 'Sexta-feira',
    shortDay: 'SEX',
    title: 'Treino E // Recuperação Ativa, Mobilidade & Vacuum',
    subtitle: 'Dia Específico do Atleta: Mobilidade, Alongamento e Redução de Cintura',
    focusGroups: ['cintura', 'panturrilha'],
    mobility: [
      {
        id: 'm6',
        name: 'Fluxo Completo de Mobilidade (World’s Greatest Stretch)',
        duration: '10 min',
        focus: 'Quadril, Tornozelo e Descompressão Torácica'
      },
      {
        id: 'm7',
        name: 'Alongamento Estático Global de Cadeia Posterior',
        duration: '8 min',
        focus: 'Isquiotibiais, Psoas e Panturrilhas'
      }
    ],
    exercises: [
      {
        id: 'e21',
        name: 'Cardio Contínuo em Ritmo Moderado (Zona 2)',
        targetGroup: 'cintura',
        baseSets: 1,
        reps: '30-40 min',
        rest: 0,
        cadence: 'Contínuo',
        defaultWeight: 0,
        tip: 'Estímulo oxidativo lipolítico para queima visceral de gordura abdominal.'
      },
      {
        id: 'e22',
        name: 'Stomach Vacuum (Vácuo Abdominal Clássico)',
        targetGroup: 'cintura',
        baseSets: 5,
        reps: '25 seg',
        rest: 40,
        cadence: 'Isometria',
        defaultWeight: 0,
        tip: 'Trabalho neuromuscular do transverso para estreitar a linha de cintura.'
      }
    ]
  },
  {
    id: 'sab',
    dayName: 'Sábado',
    shortDay: 'SÁB',
    title: 'Treino F // Híbrido de Simetria & Esporte',
    subtitle: 'Refino de Posteriores, Panturrilhas, Core e Bíceps',
    focusGroups: ['coxa', 'cintura', 'panturrilha', 'braco'],
    mobility: [
      {
        id: 'm8',
        name: 'Ponte de Glúteo Unilateral Dinâmica',
        duration: '3 min',
        focus: 'Ativação do quadril e glúteo para saltos e impulsão'
      }
    ],
    exercises: [
      {
        id: 'e23',
        name: 'Stiff com Halteres ou Barra (RDL)',
        targetGroup: 'coxa',
        baseSets: 4,
        reps: '10-12',
        rest: 90,
        cadence: '3-0-1-0',
        defaultWeight: 50,
        tip: 'Foco total na cadeia posterior e descompressão do joelho.'
      },
      {
        id: 'e24',
        name: 'Afundo com Halteres / Búlgaro',
        targetGroup: 'coxa',
        baseSets: 3,
        reps: '10-12 / perna',
        rest: 60,
        cadence: '2-0-1-0',
        defaultWeight: 16,
        tip: 'Excelente para estabilidade unilateral e desaceleração esportiva.'
      },
      {
        id: 'e25',
        name: 'Elevação de Pernas Suspenso na Barra',
        targetGroup: 'cintura',
        baseSets: 4,
        reps: '12-15',
        rest: 60,
        cadence: '2-0-1-1',
        defaultWeight: 0,
        tip: 'Enrole a pelve sem usar impulso para recrutar o infra-abdominal.'
      },
      {
        id: 'e26',
        name: 'Panturrilha Sentado (Foco no Sóleo)',
        targetGroup: 'panturrilha',
        baseSets: 4,
        reps: '15-20',
        rest: 45,
        cadence: '2-1-2-1',
        defaultWeight: 35,
        tip: 'Treino do músculo sóleo para conferir largura lateral à perna.'
      },
      {
        id: 'e27',
        name: 'Rosca Concentrada com Halter',
        targetGroup: 'braco',
        baseSets: 3,
        reps: '12',
        rest: 45,
        cadence: '2-0-2-1',
        defaultWeight: 12,
        tip: 'Toque final no pico do bíceps para fechar a semana com chave de ouro.'
      }
    ]
  }
];

export const HYBRID_WORKOUT_TEMPLATE: WorkoutDay[] = INITIAL_AI_WORKOUTS;
