import test from 'node:test';
import assert from 'node:assert/strict';
import {
  adjustRestTimerState,
  applyAiReformulationWithSessionProtection,
  canSwapExerciseInSession,
  computeMainElapsedSec,
  computeRestRemainingSec,
  createActiveWorkoutSession,
  createInitialStopwatchState,
  createSessionId,
  finalizeWorkoutSessionIdempotent,
  pauseRestTimerState,
  pauseStopwatchState,
  resumeRestTimerState,
  resumeStopwatchState,
  skipRestTimerState,
  startRestTimerState,
  startStopwatchState,
  syncRestTimerState,
  toggleSetCompletionPure
} from './sessionEngine';
import {
  buildFullBackupPayload,
  isValidActiveSession,
  validateBackupPayload
} from './storage';
import { DEFAULT_METRICS, DEFAULT_PROFILE } from './constants';
import { CompletedWorkout, SetLog, WorkoutDay } from '../types';

const mockDayWorkout: WorkoutDay = {
  id: 'seg',
  dayName: 'Segunda-feira',
  shortDay: 'SEG',
  title: 'Treino A // Hipertrofia de Peitoral & Braço',
  subtitle: 'Foco em Peitoral',
  mobility: [],
  exercises: [
    {
      id: 'supino_reto',
      name: 'Supino Reto com Barra',
      targetGroup: 'peito',
      baseSets: 3,
      reps: '8-10',
      rest: 90,
      cadence: '2-0-1-0',
      defaultWeight: 60,
      tip: 'Escápulas retraídas.'
    },
    {
      id: 'crucifixo_inclinado',
      name: 'Crucifixo Inclinado com Halteres',
      targetGroup: 'peito',
      baseSets: 3,
      reps: '10-12',
      rest: 75,
      cadence: '3-1-1-0',
      defaultWeight: 22,
      tip: 'Alongue bem na base.'
    }
  ]
};

test('Case A & D: Main stopwatch tracks active time, ignores paused time, and prevents double counting', () => {
  const t0 = 1_000_000;
  let sw = createInitialStopwatchState();
  assert.equal(computeMainElapsedSec(sw, t0 + 50_000), 0); // Not started yet

  // Start at t0
  sw = startStopwatchState(sw, t0);
  // Calling start again while running does not reset lastResumedAtMs
  sw = startStopwatchState(sw, t0 + 10_000);
  assert.equal(computeMainElapsedSec(sw, t0 + 30_000), 30);

  // Pause at t0 + 30s
  sw = pauseStopwatchState(sw, t0 + 30_000);
  assert.equal(computeMainElapsedSec(sw, t0 + 30_000), 30);

  // Simulate 5 minutes passing while paused (Case D)
  assert.equal(computeMainElapsedSec(sw, t0 + 330_000), 30);

  // Resume at t0 + 330s and run for 45s more
  sw = resumeStopwatchState(sw, t0 + 330_000);
  assert.equal(computeMainElapsedSec(sw, t0 + 375_000), 75);
});

test('Case C & E: Rest timer recomputes accurately after backgrounding, adjustments, pause, resume, and completion', () => {
  const t0 = 2_000_000;
  let rest = startRestTimerState(90, t0, {
    exerciseId: 'supino_reto',
    exerciseName: 'Supino Reto com Barra',
    completedSetNumber: 1,
    nextSetNumber: 2,
    nextSetWeight: 60,
    nextSetReps: 10
  });

  assert.equal(rest.status, 'running');
  assert.equal(computeRestRemainingSec(rest, t0), 90);

  // Simulate 20s passing in background
  assert.equal(computeRestRemainingSec(rest, t0 + 20_000), 70);

  // Adjust +30s at t0 + 20s -> remaining becomes 100s, target becomes 100s
  rest = adjustRestTimerState(rest, 30, t0 + 20_000);
  assert.equal(computeRestRemainingSec(rest, t0 + 20_000), 100);
  assert.equal(rest.targetSec, 100);

  // Adjust -15s at t0 + 20s -> remaining becomes 85s
  rest = adjustRestTimerState(rest, -15, t0 + 20_000);
  assert.equal(computeRestRemainingSec(rest, t0 + 20_000), 85);

  // Pause at t0 + 25s (80s remaining)
  rest = pauseRestTimerState(rest, t0 + 25_000);
  assert.equal(rest.status, 'paused');
  assert.equal(computeRestRemainingSec(rest, t0 + 25_000), 80);

  // Simulate 60s passing while paused -> still 80s remaining
  assert.equal(computeRestRemainingSec(rest, t0 + 85_000), 80);

  // Resume at t0 + 85s
  rest = resumeRestTimerState(rest, t0 + 85_000);
  assert.equal(rest.status, 'running');
  assert.equal(computeRestRemainingSec(rest, t0 + 105_000), 60);

  // Simulate background sleep past deadline -> clamps to 00:00 (never negative) and marks completed
  assert.equal(computeRestRemainingSec(rest, t0 + 500_000), 0);
  const synced = syncRestTimerState(rest, t0 + 500_000);
  assert.equal(synced.justCompleted, true);
  assert.equal(synced.nextState.status, 'completed');

  // Skip/end rest
  const skipped = skipRestTimerState(synced.nextState);
  assert.equal(skipped.status, 'idle');
  assert.equal(skipped.isModalOpen, false);
});

test('Teste 1 & 2: Conclusão de série sem duplicação de descanso e Reversão de série sem efeitos colaterais', () => {
  const initialSets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: false },
      { setNumber: 2, weight: 80, reps: 10, rpe: 8, completed: false }
    ]
  };

  // Teste 1: Concluir série 1 -> pura, sem mutar estado anterior, shouldStartRest = true uma única vez
  const completionResult = toggleSetCompletionPure(
    initialSets,
    mockDayWorkout.exercises[0],
    0
  );

  assert.equal(initialSets.supino_reto[0].completed, false); // original imutável
  assert.equal(completionResult.toggledSet?.completed, true);
  assert.equal(completionResult.shouldStartRest, true);
  assert.equal(completionResult.restDurationSec, 90);
  assert.equal(completionResult.updatedSessionSets.supino_reto[0].completed, true);

  // Teste 2: Reverter série 1 (desmarcar) -> shouldStartRest = false (nunca inicia descanso ao reverter)
  const revertResult = toggleSetCompletionPure(
    completionResult.updatedSessionSets,
    mockDayWorkout.exercises[0],
    0
  );

  assert.equal(revertResult.toggledSet?.completed, false);
  assert.equal(revertResult.shouldStartRest, false);
  assert.equal(revertResult.restDurationSec, 90);
  assert.equal(revertResult.updatedSessionSets.supino_reto[0].completed, false);
});

test('Teste 3: Reformulação por IA durante sessão ativa preserva séries concluídas no modo preserve_active', () => {
  const currentWorkouts: WorkoutDay[] = [
    mockDayWorkout,
    {
      id: 'ter',
      dayName: 'Terça-feira',
      shortDay: 'TER',
      title: 'Treino B // Dorsal',
      subtitle: 'Foco em Largura',
      mobility: [],
      exercises: [
        {
          id: 'puxada_frente',
          name: 'Puxada Frontal',
          targetGroup: 'ombros',
          baseSets: 4,
          reps: '8-12',
          rest: 90,
          cadence: '2-1-1-0',
          defaultWeight: 70,
          tip: 'Cotovelos para baixo.'
        }
      ]
    }
  ];

  const aiGeneratedWorkouts: WorkoutDay[] = [
    {
      ...mockDayWorkout,
      title: 'Treino A Reformulado IA',
      exercises: [
        {
          id: 'supino_inclinado_halter',
          name: 'Supino Inclinado com Halteres',
          targetGroup: 'peito',
          baseSets: 4,
          reps: '8-10',
          rest: 90,
          cadence: '2-0-1-0',
          defaultWeight: 34,
          tip: 'Controle excêntrico.'
        }
      ]
    },
    {
      ...currentWorkouts[1],
      title: 'Treino B Reformulado IA'
    }
  ];

  const activeSessionSets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 85, reps: 10, rpe: 8, completed: true },
      { setNumber: 2, weight: 85, reps: 10, rpe: 8, completed: false }
    ],
    crucifixo_inclinado: [
      { setNumber: 1, weight: 22, reps: 12, rpe: 8, completed: false }
    ]
  };

  // Modo preserve_active: preserva exercício com série concluída (supino_reto) no dia ativo e atualiza os demais dias
  const preserved = applyAiReformulationWithSessionProtection({
    currentCustomWorkouts: null,
    baseTemplate: currentWorkouts,
    generatedWorkouts: aiGeneratedWorkouts,
    scope: 'week',
    currentDayWorkout: mockDayWorkout,
    sessionSets: activeSessionSets,
    isSessionActive: true,
    resolution: 'preserve_active'
  });

  assert.equal(preserved.shouldResetActiveSession, false);
  assert.equal(preserved.preservedCompletedExercisesCount, 1);
  // O exercício já iniciado (supino_reto) permanece intacto no dia ativo
  assert.equal(
    preserved.updatedCustomWorkouts[0].exercises.some((ex) => ex.id === 'supino_reto'),
    true
  );
  // As séries concluídas continuam preservadas
  assert.equal(preserved.updatedSessionSets.supino_reto[0].completed, true);
  assert.equal(preserved.updatedSessionSets.supino_reto[0].weight, 85);
  // O próximo dia (ter) recebeu a atualização da IA normalmente
  assert.equal(preserved.updatedCustomWorkouts[1].title, 'Treino B Reformulado IA');

  // Modo replace_active: quando o usuário confirma explicitamente substituir a sessão ativa
  const replaced = applyAiReformulationWithSessionProtection({
    currentCustomWorkouts: null,
    baseTemplate: currentWorkouts,
    generatedWorkouts: aiGeneratedWorkouts,
    scope: 'day',
    currentDayWorkout: mockDayWorkout,
    sessionSets: activeSessionSets,
    isSessionActive: true,
    resolution: 'replace_active'
  });

  assert.equal(replaced.shouldResetActiveSession, true);
  assert.equal(replaced.updatedCustomWorkouts[0].exercises[0].id, 'supino_inclinado_halter');
});

test('Teste 4: Substituição de exercício com séries registradas é bloqueada para proteger o histórico da sessão', () => {
  const sessionSets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: true },
      { setNumber: 2, weight: 80, reps: 10, rpe: 8, completed: false }
    ],
    crucifixo_inclinado: [
      { setNumber: 1, weight: 22, reps: 12, rpe: 8, completed: false }
    ]
  };

  const blockedCheck = canSwapExerciseInSession('supino_reto', sessionSets);
  assert.equal(blockedCheck.allowed, false);
  assert.equal(blockedCheck.completedSetsCount, 1);

  const allowedCheck = canSwapExerciseInSession('crucifixo_inclinado', sessionSets);
  assert.equal(allowedCheck.allowed, true);
  assert.equal(allowedCheck.completedSetsCount, 0);
});

test('Teste 5: Finalização e início de uma nova sessão geram identificadores independentes', () => {
  const sameTimestamp = 1_762_620_000_000;
  const firstSessionId = createSessionId(sameTimestamp, 'seg');
  const secondSessionId = createSessionId(sameTimestamp, 'seg');

  assert.notEqual(firstSessionId, secondSessionId);
  assert.ok(firstSessionId.startsWith('sess_1762620000000_'));
  assert.ok(secondSessionId.startsWith('sess_1762620000000_'));
});

test('Teste 6: Resumo sem RPE informado mantém sessionRpe como undefined (sem atribuir 8.5 automaticamente)', () => {
  const sessionSets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: true }
    ]
  };

  const finalized = finalizeWorkoutSessionIdempotent({
    sessionId: createSessionId(1_762_620_000_000, 'seg'),
    startedAtMs: 1_762_618_000_000,
    durationSec: 1200,
    dayWorkout: mockDayWorkout,
    sessionSets,
    cardioCompleted: false,
    workoutHistory: [],
    lastExerciseWeights: {},
    nowMs: 1_762_620_000_000
    // sessionRpe omitido
  });

  assert.equal(finalized.completedWorkout.sessionRpe, undefined);

  const draft = createActiveWorkoutSession(mockDayWorkout, sessionSets, 1_762_620_000_000);
  assert.equal(draft.sessionRpe, undefined);
});

test('Teste 7, 8 & 9: Exportação/importação de backup com sessão ativa, compatibilidade com backups antigos e recuperação de progresso', () => {
  const activeSession = createActiveWorkoutSession(
    mockDayWorkout,
    {
      supino_reto: [
        { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: true }
      ]
    },
    1_762_600_000_000
  );
  activeSession.sessionId = 'sess_active_backup_test';

  // Teste 9: Validação estrutural do snapshot salvo para recuperação após F5
  assert.equal(isValidActiveSession(activeSession), true);

  // Teste 7: Exportação inclui activeSession e validação de importação preserva-a
  const backupWithActive = buildFullBackupPayload(
    DEFAULT_PROFILE,
    DEFAULT_METRICS,
    null,
    { supino_reto: 80 },
    [],
    [],
    activeSession
  );

  assert.equal(backupWithActive.activeSession?.sessionId, 'sess_active_backup_test');

  const validatedNewBackup = validateBackupPayload(JSON.parse(JSON.stringify(backupWithActive)));
  assert.equal(validatedNewBackup.valid, true);
  assert.equal(validatedNewBackup.hasActiveSessionInBackup, true);
  assert.equal(validatedNewBackup.data?.activeSession?.sessionId, 'sess_active_backup_test');
  assert.equal(
    validatedNewBackup.data?.activeSession?.sessionSets.supino_reto[0].completed,
    true
  );

  // Teste 8: Compatibilidade com backups anteriores (sem campo activeSession)
  const legacyBackupRaw = {
    app: 'AUREUS_FORJA_CORPORAL',
    exportedAt: '2026-10-01T12:00:00.000Z',
    profile: DEFAULT_PROFILE,
    metrics: DEFAULT_METRICS,
    workoutHistory: [],
    checkins: [],
    lastExerciseWeights: { supino_reto: 75 }
  };

  const validatedLegacy = validateBackupPayload(legacyBackupRaw);
  assert.equal(validatedLegacy.valid, true);
  assert.equal(validatedLegacy.hasActiveSessionInBackup, false);
  assert.equal(validatedLegacy.data?.activeSession, undefined);
  assert.equal(validatedLegacy.data?.lastExerciseWeights?.supino_reto, 75);
});

test('Teste 10 (Case G & H): finalizeWorkoutSessionIdempotent evita duplicação de histórico e detecta PR real', () => {
  const sessionSets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: true },
      { setNumber: 2, weight: 90, reps: 8, rpe: 9, completed: true },
      { setNumber: 3, weight: 90, reps: 8, rpe: 9, completed: false }
    ]
  };

  const priorHistory: CompletedWorkout[] = [
    {
      id: 'wk_old_1',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 1500,
      durationSec: 1800,
      completedSets: 3,
      totalSets: 3,
      cardioCompleted: false,
      dateFormatted: '01 de nov. de 2026',
      timestamp: 1_700_000_000_000,
      exercisesSummary: [
        {
          exerciseId: 'supino_reto',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 3,
          totalSets: 3,
          maxWeight: 85
        }
      ]
    }
  ];

  // Primeira chamada de finalização
  const firstCall = finalizeWorkoutSessionIdempotent({
    sessionId: 'sess_1762615800000_seg',
    startedAtMs: 1_762_615_800_000,
    durationSec: 2400,
    dayWorkout: mockDayWorkout,
    sessionSets,
    cardioCompleted: true,
    workoutHistory: priorHistory,
    lastExerciseWeights: { supino_reto: 85 },
    nowMs: 1_762_618_200_000,
    sessionRpe: 8.5,
    sessionNotes: 'Excelente estabilidade.'
  });

  assert.equal(firstCall.alreadyRecorded, false);
  assert.equal(firstCall.updatedHistory.length, 2);
  assert.equal(firstCall.completedWorkout.tonnage, 80 * 10 + 90 * 8); // 1520
  assert.equal(firstCall.completedWorkout.completedSets, 2);
  assert.equal(firstCall.completedWorkout.exercisesSummary[0].maxWeight, 90);
  assert.equal(firstCall.completedWorkout.exercisesSummary[0].isPersonalRecord, true);
  assert.equal(firstCall.completedWorkout.exercisesSummary[0].previousBestWeight, 85);
  assert.equal(firstCall.updatedLastWeights.supino_reto, 90);
  assert.equal(firstCall.completedWorkout.sessionRpe, 8.5);

  // Segunda chamada repetida com o MESMO sessionId (Teste 10: Idempotência)
  const secondCall = finalizeWorkoutSessionIdempotent({
    sessionId: 'sess_1762615800000_seg',
    startedAtMs: 1_762_615_800_000,
    durationSec: 2405,
    dayWorkout: mockDayWorkout,
    sessionSets,
    cardioCompleted: true,
    workoutHistory: firstCall.updatedHistory,
    lastExerciseWeights: firstCall.updatedLastWeights,
    nowMs: 1_762_618_205_000
  });

  assert.equal(secondCall.alreadyRecorded, true);
  assert.equal(secondCall.updatedHistory.length, 2); // Continua 2, sem duplicar!
});
