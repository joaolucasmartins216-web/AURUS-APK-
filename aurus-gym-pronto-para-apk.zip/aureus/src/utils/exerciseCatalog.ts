import {
  BodyPartKey,
  CatalogExercise,
  CompletedWorkout,
  ExerciseEquipmentCategory,
  ExerciseItem,
  ExerciseMuscleFilter,
  SetLog,
  WorkoutDay
} from '../types';
import { cleanDisplayText } from './dashboardLogic';
import { getExerciseEvolutionDetail, getRegisteredExercisesList } from './evolutionLogic';

export const MUSCLE_FILTER_OPTIONS: Array<{
  id: ExerciseMuscleFilter;
  label: string;
}> = [
  { id: 'all', label: 'Todos' },
  { id: 'peito', label: 'Peito' },
  { id: 'costas', label: 'Costas' },
  { id: 'pernas', label: 'Pernas' },
  { id: 'ombros', label: 'Ombros' },
  { id: 'bracos', label: 'Braços' },
  { id: 'abdomen', label: 'Abdômen' },
  { id: 'panturrilha', label: 'Panturrilhas' },
  { id: 'pescoco', label: 'Pescoço' }
];

export const EQUIPMENT_FILTER_OPTIONS: Array<{
  id: ExerciseEquipmentCategory | 'all';
  label: string;
}> = [
  { id: 'all', label: 'Todos equipamentos' },
  { id: 'barra', label: 'Barra olímpica' },
  { id: 'halteres', label: 'Halteres' },
  { id: 'cabo', label: 'Polia / Cabo' },
  { id: 'maquinas', label: 'Máquinas' },
  { id: 'livre', label: 'Peso corporal' }
];

export function normalizeSearchText(text: string): string {
  return String(text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function mapMuscleFilterToBodyPartKey(
  muscle: Exclude<ExerciseMuscleFilter, 'all'>
): BodyPartKey {
  switch (muscle) {
    case 'peito':
      return 'peito';
    case 'costas':
    case 'ombros':
      return 'ombros';
    case 'pernas':
      return 'coxa';
    case 'bracos':
      return 'braco';
    case 'abdomen':
      return 'cintura';
    case 'panturrilha':
      return 'panturrilha';
    case 'pescoco':
      return 'pescoco';
  }
}

export function getEquipmentLabel(category: ExerciseEquipmentCategory): string {
  switch (category) {
    case 'barra':
      return 'Barra olímpica';
    case 'halteres':
      return 'Halteres';
    case 'cabo':
      return 'Polia / Cabo';
    case 'maquinas':
      return 'Máquina articulada';
    case 'livre':
      return 'Peso corporal';
  }
}

export function getPrimaryMuscleDefaultLabel(
  muscle: Exclude<ExerciseMuscleFilter, 'all'>
): string {
  switch (muscle) {
    case 'peito':
      return 'Peitoral maior';
    case 'costas':
      return 'Grande dorsal';
    case 'pernas':
      return 'Quadríceps e glúteos';
    case 'ombros':
      return 'Deltoide';
    case 'bracos':
      return 'Bíceps e tríceps';
    case 'abdomen':
      return 'Reto abdominal e core';
    case 'panturrilha':
      return 'Gastrocnêmio e sóleo';
    case 'pescoco':
      return 'Musculatura cervical';
  }
}

/**
 * Catálogo base oficial do AURUS GYM.
 * Preserva 100% dos identificadores originais (e1..e27) de INITIAL_AI_WORKOUTS
 * e adiciona variações clássicas da musculação (e28..e38) com metadados biomecânicos reais.
 */
export const BASE_EXERCISE_CATALOG: CatalogExercise[] = [
  {
    id: 'e1',
    name: 'Supino Reto com Barra',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral maior',
    auxiliaryMuscles: ['Tríceps braquial', 'Deltoide anterior'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra olímpica',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 90,
    defaultCadence: '3-0-1-1',
    defaultWeight: 60,
    shortDescription:
      'Posicionamento estável com arco lombar natural, escápulas retraídas no banco e pegada média na barra. Desça a carga de forma controlada até a linha inferior do peitoral e empurre mantendo cotovelos a cerca de 60°.',
    biomechanicalSubtitle: 'Peito · Força e Hipertrofia',
    angleCue: 'Ângulo cotovelos: ~60°',
    postureCue: 'Escápulas aduzidas',
    kinematicChainLabel: 'Cadeia Anterior',
    executionSteps: [
      {
        title: 'Posicionamento e pegada',
        description:
          'Alinhe os olhos sob a barra no suporte. Segure um pouco além da largura dos ombros mantendo os punhos firmes e neutros.'
      },
      {
        title: 'Retração escapular e base',
        description:
          'Encaixe as escápulas contra o banco e mantenha os pés firmes no solo durante toda a série.'
      },
      {
        title: 'Descida controlada e subida',
        description:
          'Desça em cerca de 3 segundos até próximo ao esterno inferior e empurre de maneira contínua sem perder o encaixe dos ombros.'
      }
    ],
    safetyNotes: [
      'Evite bater a barra no tórax para ganhar impulso no início da subida.',
      'Não abra os cotovelos a 90° em relação ao tronco para proteger a articulação do ombro.'
    ],
    searchAliases: ['bench press', 'supino barra', 'peitoral', 'supino reto']
  },
  {
    id: 'e2',
    name: 'Crucifixo Inclinado com Halteres (30°)',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral clavicular',
    auxiliaryMuscles: ['Deltoide anterior', 'Bíceps (estabilizador)'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 16,
    shortDescription:
      'Movimento de adução horizontal no banco inclinado a 30°, focado no alongamento controlado das fibras superiores do peitoral com mínima participação do tríceps.',
    biomechanicalSubtitle: 'Peito · Isolamento Clavicular',
    angleCue: 'Banco inclinado: 30°',
    postureCue: 'Cotovelos semiflexionados',
    kinematicChainLabel: 'Adução Horizontal',
    executionSteps: [
      {
        title: 'Ajuste do banco a 30°',
        description:
          'Posicione o encosto entre 30° e 35° para focar na porção superior do peitoral sem sobrecarregar o deltoide.'
      },
      {
        title: 'Abertura em arco amplo',
        description:
          'Abra os braços mantendo leve flexão fixa nos cotovelos até sentir alongamento confortável no peitoral.'
      },
      {
        title: 'Adução sem bater os halteres',
        description:
          'Aproxime os halteres no topo mantendo a tensão constante no peitoral antes de iniciar a próxima repetição.'
      }
    ],
    safetyNotes: [
      'Não desça os cotovelos muito abaixo da linha do tronco sob cargas elevadas.',
      'Mantenha o ângulo do cotovelo constante para não transformar o exercício em supino.'
    ],
    searchAliases: ['fly inclinado', 'crucifixo halteres', 'peito superior']
  },
  {
    id: 'e3',
    name: 'Tríceps Testa com Barra EZ',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Tríceps braquial',
    auxiliaryMuscles: ['Ancôneo', 'Flexores do punho (estabilização)'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra W / EZ',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '3-0-1-0',
    defaultWeight: 24,
    shortDescription:
      'Extensão de cotovelos deitado no banco com barra W, enfatizando o recrutamento da cabeça longa e lateral do tríceps com conforto para os punhos.',
    biomechanicalSubtitle: 'Braços · Extensão de Cotovelos',
    angleCue: 'Úmero inclinado ~15° atrás',
    postureCue: 'Cotovelos alinhados',
    kinematicChainLabel: 'Isolamento de Tríceps',
    executionSteps: [
      {
        title: 'Pegada na curvatura interna',
        description:
          'Segure a barra W na pegada angulada para reduzir a tensão nos punhos e posicione os braços levemente inclinados para trás.'
      },
      {
        title: 'Flexão controlada dos cotovelos',
        description:
          'Desça a barra em direção à testa ou levemente acima da cabeça mantendo os cotovelos apontados para a frente.'
      },
      {
        title: 'Extensão firme',
        description:
          'Estenda os antebraços sem mover os ombros para manter a tensão contínua na cabeça longa do tríceps.'
      }
    ],
    safetyNotes: [
      'Evite abrir os cotovelos lateralmente durante a subida.',
      'Aqueça bem a articulação do cotovelo antes de utilizar cargas pesadas.'
    ],
    searchAliases: ['skullcrusher', 'triceps testa', 'barra w', 'barra ez']
  },
  {
    id: 'e4',
    name: 'Tríceps Corda na Polia',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Tríceps (cabeça lateral)',
    auxiliaryMuscles: ['Ancôneo'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia alta / Corda',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '12-15',
    defaultRestSec: 45,
    defaultCadence: '2-0-2-2',
    defaultWeight: 25,
    shortDescription:
      'Extensão de cotovelos na polia alta com corda, permitindo leve pronação no final do movimento para máxima contração da cabeça lateral do tríceps.',
    biomechanicalSubtitle: 'Braços · Contração de Pico',
    angleCue: 'Cotovelos fixos ao tronco',
    postureCue: 'Tronco levemente inclinado',
    kinematicChainLabel: 'Isolamento na Polia',
    executionSteps: [
      {
        title: 'Postura estável diante da polia',
        description:
          'Incline discretamente o tronco à frente e cole os cotovelos na lateral das costelas.'
      },
      {
        title: 'Extensão com abertura final',
        description:
          'Empurre a corda para baixo até estender totalmente os cotovelos, afastando as pontas da corda na base.'
      },
      {
        title: 'Retorno controlado',
        description:
          'Suba controlando o peso até cerca de 90° de flexão sem deixar os cotovelos avançarem para a frente.'
      }
    ],
    safetyNotes: [
      'Não jogue o peso do corpo sobre a corda; o movimento deve ocorrer apenas nos cotovelos.',
      'Mantenha os ombros baixos e afastados das orelhas.'
    ],
    searchAliases: ['triceps polia', 'triceps corda', 'pushdown']
  },
  {
    id: 'e5',
    name: 'Flexão de Pescoço Controlada com Peso',
    targetGroup: 'pescoco',
    muscleFilter: 'pescoco',
    primaryMuscleLabel: 'Esternocleidomastoideo',
    auxiliaryMuscles: ['Escalenos', 'Flexores cervicais profundos'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Anilha leve / Peso livre',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '15-20',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 5,
    shortDescription:
      'Trabalho progressivo e controlado da musculatura anterior do pescoço para estabilidade cervical e proporção simétrica com braços e panturrilhas.',
    biomechanicalSubtitle: 'Pescoço · Estabilidade Cervical',
    angleCue: 'Amplitude suave e limpa',
    postureCue: 'Escápulas apoiadas no banco',
    kinematicChainLabel: 'Estabilidade Cervical',
    executionSteps: [
      {
        title: 'Apoio dorsal no banco reto',
        description:
          'Deite de costas no banco deixando apenas a cabeça para fora da borda com uma toalha e carga leve apoiada na testa.'
      },
      {
        title: 'Flexão cervical cadenciada',
        description:
          'Aproxime o queixo da região superior do peito em movimento lento de 2 segundos.'
      },
      {
        title: 'Retorno neutro',
        description:
          'Retorne até a linha neutra sem deixar a cabeça cair brusca para trás.'
      }
    ],
    safetyNotes: [
      'Utilize sempre cargas leves a moderadas e altas repetições.',
      'Nunca faça movimentos bruscos ou rotações forçadas da coluna cervical.'
    ],
    searchAliases: ['pescoco', 'cervical', 'neck curl']
  },
  {
    id: 'e6',
    name: 'Puxada Aberta no Pulley / Barra Fixa',
    targetGroup: 'ombros',
    muscleFilter: 'costas',
    primaryMuscleLabel: 'Grande dorsal',
    auxiliaryMuscles: ['Redondo maior', 'Bíceps braquial', 'Trapézio inferior'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia alta / Barra',
    categoryLabel: 'Composto',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 55,
    shortDescription:
      'Tracionamento vertical na polia alta com pegada pronada aberta, fundamental para expansão da largura dorsal (V-Taper) e controle escapular.',
    biomechanicalSubtitle: 'Costas · Largura Dorsal',
    angleCue: 'Tronco a ~10–15° de inclinação',
    postureCue: 'Depressão escapular ativa',
    kinematicChainLabel: 'Tração Vertical',
    executionSteps: [
      {
        title: 'Pegada pronada aberta',
        description:
          'Segure a barra um pouco além da largura dos ombros e ajuste o apoio das coxas no equipamento.'
      },
      {
        title: 'Início pelas escápulas',
        description:
          'Abaixe os ombros primeiro e puxe a barra em direção à parte alta do peitoral, apontando os cotovelos para o chão.'
      },
      {
        title: 'Alongamento superior controlado',
        description:
          'Estenda os braços no topo controlando a carga para alongar as dorsais sem perder a estabilidade lombar.'
      }
    ],
    safetyNotes: [
      'Nunca puxe a barra por trás da nuca para evitar compressão cervical e impacto no ombro.',
      'Evite inclinar excessivamente o tronco para trás como em uma remada.'
    ],
    searchAliases: ['puxada frontal', 'pulldown', 'pulley frente', 'barra fixa', 'dorsal']
  },
  {
    id: 'e7',
    name: 'Rosca Direta com Barra W',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Bíceps braquial',
    auxiliaryMuscles: ['Braquial', 'Braquiorradial'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra W / EZ',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 75,
    defaultCadence: '3-0-1-1',
    defaultWeight: 26,
    shortDescription:
      'Flexão de cotovelos em pé com barra W, proporcionando sobrecarga direta sobre as duas cabeças do bíceps com ângulo ergonômico para os punhos.',
    biomechanicalSubtitle: 'Braços · Flexão de Cotovelos',
    angleCue: 'Cotovelos fixos ao lado do tronco',
    postureCue: 'Coluna neutra e abdômen firme',
    kinematicChainLabel: 'Isolamento de Bíceps',
    executionSteps: [
      {
        title: 'Base firme na largura do quadril',
        description:
          'Segure a barra W na curvatura externa com postura ereta e escápulas estabilizadas.'
      },
      {
        title: 'Subida sem impulso lombar',
        description:
          'Flexione os cotovelos levando a barra até a altura do peitoral e contraia o bíceps por 1 segundo.'
      },
      {
        title: 'Fase excêntrica controlada',
        description:
          'Desça a barra em 3 segundos até a extensão quase completa dos braços mantendo tensão muscular.'
      }
    ],
    safetyNotes: [
      'Evite balançar o quadril ou jogar os ombros para trás para levantar a carga.',
      'Mantenha os punhos firmes sem dobrá-los no topo do movimento.'
    ],
    searchAliases: ['rosca direta', 'biceps barra w', 'biceps barra']
  },
  {
    id: 'e8',
    name: 'Rosca Martelo com Halteres',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Braquial e braquiorradial',
    auxiliaryMuscles: ['Bíceps braquial (cabeça longa)'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 14,
    shortDescription:
      'Flexão de cotovelos com pegada neutra (palmas voltadas uma para a outra), excelente para espessura lateral do braço e fortalecimento do antebraço.',
    biomechanicalSubtitle: 'Braços · Espessura e Antebraço',
    angleCue: 'Pegada 100% neutra',
    postureCue: 'Ombros estabilizados',
    kinematicChainLabel: 'Flexão Neutra',
    executionSteps: [
      {
        title: 'Pegada neutra firme',
        description:
          'Segure os halteres ao lado do corpo com os polegares apontados para a frente.'
      },
      {
        title: 'Flexão estrita',
        description:
          'Suba os halteres mantendo as palmas frente a frente até contrair fortemente o braquiorradial e o bíceps.'
      },
      {
        title: 'Descida cadenciada',
        description:
          'Retorne devagar até a posição inicial sem balançar os halteres na lateral das coxas.'
      }
    ],
    safetyNotes: [
      'Não gire os punhos durante o trajeto para manter o foco no braquial.',
      'Evite avançar o cotovelo excessivamente para a frente.'
    ],
    searchAliases: ['hammer curl', 'rosca martelo', 'antebraco', 'braquial']
  },
  {
    id: 'e9',
    name: 'Prancha Abdominal RKC',
    targetGroup: 'cintura',
    muscleFilter: 'abdomen',
    primaryMuscleLabel: 'Transverso e reto abdominal',
    auxiliaryMuscles: ['Glúteos', 'Oblíquos', 'Serrátil anterior'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Peso corporal',
    categoryLabel: 'Estabilidade & Core',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '45 seg',
    defaultRestSec: 45,
    defaultCadence: 'Isometria',
    defaultWeight: 0,
    shortDescription:
      'Variação de alta tensão da prancha abdominal tradicional, puxando isometricamente os cotovelos em direção às pontas dos pés para máxima ativação do core.',
    biomechanicalSubtitle: 'Abdômen · Estabilidade Isométrica',
    angleCue: 'Pelve em leve retroversão',
    postureCue: 'Tensão isométrica global',
    kinematicChainLabel: 'Estabilização do Core',
    executionSteps: [
      {
        title: 'Apoio de antebraços no solo',
        description:
          'Posicione os cotovelos logo abaixo da linha dos ombros e estenda as pernas mantendo o corpo alinhado.'
      },
      {
        title: 'Ativação RKC de alta tensão',
        description:
          'Contraia glúteos e quadríceps e faça força como se quisesse puxar o chão com os cotovelos em direção aos pés.'
      },
      {
        title: 'Respiração curta sob tensão',
        description:
          'Sustente a contração máxima do abdômen pelo tempo planejado sem deixar o quadril cair.'
      }
    ],
    safetyNotes: [
      'Interrompa a série se sentir a região lombar arquear para baixo.',
      'Não prenda totalmente a respiração durante a isometria.'
    ],
    searchAliases: ['prancha', 'plank', 'core', 'abdominal isometrico']
  },
  {
    id: 'e10',
    name: 'Abdominal Supra na Polia Alta',
    targetGroup: 'cintura',
    muscleFilter: 'abdomen',
    primaryMuscleLabel: 'Reto abdominal',
    auxiliaryMuscles: ['Oblíquos externos'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia alta / Corda',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '15-20',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-1',
    defaultWeight: 35,
    shortDescription:
      'Flexão dinâmica da coluna torácica ajoelhado na polia alta com corda, permitindo progressão real de carga no reto abdominal.',
    biomechanicalSubtitle: 'Abdômen · Flexão com Carga',
    angleCue: 'Quadril fixo e estável',
    postureCue: 'Enrolamento torácico',
    kinematicChainLabel: 'Flexão de Tronco',
    executionSteps: [
      {
        title: 'Posição ajoelhada com a corda',
        description:
          'Ajoelhe-se diante da polia alta segurando as pontas da corda ao lado da cabeça.'
      },
      {
        title: 'Flexão da coluna ("enrolar")',
        description:
          'Solte o ar enquanto aproxima as costelas da pelve, curvando a coluna superior sem sentar nos calcanhares.'
      },
      {
        title: 'Retorno alongando o abdômen',
        description:
          'Suba devagar sentindo o reto abdominal alongar sem perder a tensão do cabo.'
      }
    ],
    safetyNotes: [
      'Não flexione apenas o quadril com a coluna reta; o movimento deve curvar o tronco.',
      'Evite cargas que forcem o pescoço contra a corda.'
    ],
    searchAliases: ['abdominal polia', 'cable crunch', 'abdominal corda']
  },
  {
    id: 'e11',
    name: 'Agachamento Livre com Barra',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Quadríceps e glúteos',
    auxiliaryMuscles: ['Adutores', 'Eretores da espinha', 'Core'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra olímpica',
    categoryLabel: 'Composto',
    difficultyLabel: 'Avançado',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 120,
    defaultCadence: '3-0-1-1',
    defaultWeight: 80,
    shortDescription:
      'Movimento multiarticular base para força e hipertrofia dos membros inferiores. Exige alinhamento entre joelhos e pontas dos pés, estabilidade de core e amplitude segura.',
    biomechanicalSubtitle: 'Pernas · Força e Hipertrofia',
    angleCue: 'Joelhos alinhados aos pés',
    postureCue: 'Bracing abdominal 360°',
    kinematicChainLabel: 'Cadeia Inferior Completa',
    executionSteps: [
      {
        title: 'Apoio da barra no trapézio',
        description:
          'Apoie a barra sobre o trapézio superior (ou deltoide posterior), retire do rack e posicione os pés na largura dos ombros.'
      },
      {
        title: 'Descida controlada com bracing',
        description:
          'Inspire travando o abdômen e flexione quadris e joelhos simultaneamente mantendo os calcanhares plantados no chão.'
      },
      {
        title: 'Subida potente',
        description:
          'Empurre o solo com todo o pé mantendo o peito aberto e os joelhos estáveis até ficar em pé.'
      }
    ],
    safetyNotes: [
      'Não permita que os joelhos colapsem para dentro (valgo dinâmico) na subida.',
      'Respeite sua mobilidade de quadril e tornozelo para manter a coluna neutra na base.'
    ],
    searchAliases: ['squat', 'agachamento livre', 'agachamento barra', 'quadriceps']
  },
  {
    id: 'e12',
    name: 'Leg Press 45°',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Quadríceps femoral',
    auxiliaryMuscles: ['Glúteo máximo', 'Isquiotibiais'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina 45°',
    categoryLabel: 'Composto',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 90,
    defaultCadence: '2-0-2-0',
    defaultWeight: 160,
    shortDescription:
      'Empurrar guiado em ângulo de 45°, permitindo alto volume mecânico sobre quadríceps e glúteos com a coluna lombar totalmente apoiada.',
    biomechanicalSubtitle: 'Pernas · Sobrecarga Guiada',
    angleCue: 'Lombar 100% no encosto',
    postureCue: 'Sem hiperextensão de joelhos',
    kinematicChainLabel: 'Empurrar Membros Inferiores',
    executionSteps: [
      {
        title: 'Posicionamento dos pés na plataforma',
        description:
          'Apoie os pés no centro da plataforma na largura dos ombros e encaixe o quadril firmemente no banco.'
      },
      {
        title: 'Descida ampla sem tirar o quadril',
        description:
          'Destrave o aparelho e desça a plataforma até cerca de 90° nos joelhos, mantendo o quadril colado no assento.'
      },
      {
        title: 'Empurrada contínua',
        description:
          'Empurre com os calcanhares até quase estender as pernas, mantendo uma leve flexão de segurança nos joelhos.'
      }
    ],
    safetyNotes: [
      'Nunca trave totalmente os joelhos em hiperextensão no topo do movimento.',
      'Não desça a ponto de a lombar sair do encosto (retroversão pélvica forçada).'
    ],
    searchAliases: ['leg press', 'leg 45', 'prensa de pernas']
  },
  {
    id: 'e13',
    name: 'Cadeira Extensora (Pausa no topo)',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Quadríceps (reto femoral e vastos)',
    auxiliaryMuscles: [],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina extensora',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '12-15',
    defaultRestSec: 45,
    defaultCadence: '2-0-2-2',
    defaultWeight: 50,
    shortDescription:
      'Isolamento puro do quadríceps por extensão de joelhos sentado, com pausa isométrica no topo para enfatizar o vasto medial e o reto femoral.',
    biomechanicalSubtitle: 'Pernas · Isolamento de Quadríceps',
    angleCue: 'Joelho alinhado ao eixo da máquina',
    postureCue: 'Pausa de 2s no topo',
    kinematicChainLabel: 'Cadeia Cinética Aberta',
    executionSteps: [
      {
        title: 'Alinhamento do encosto e rolo',
        description:
          'Ajuste o encosto para que seus joelhos fiquem alinhados ao eixo de rotação e o rolo apoie sobre a parte inferior da canela.'
      },
      {
        title: 'Extensão completa com pausa',
        description:
          'Estenda os joelhos segurando nas alças laterais e mantenha 1 a 2 segundos de contração máxima no topo.'
      },
      {
        title: 'Retorno controlado',
        description:
          'Desça o peso devagar sem deixar as placas baterem entre as repetições.'
      }
    ],
    safetyNotes: [
      'Evite chutar o apoio de forma balística no início da repetição.',
      'Mantenha o quadril preso ao banco usando os apoios laterais.'
    ],
    searchAliases: ['extensora', 'leg extension', 'vasto medial', 'quadriceps']
  },
  {
    id: 'e14',
    name: 'Cadeira Flexora / Mesa Flexora',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Isquiotibiais (posteriores de coxa)',
    auxiliaryMuscles: ['Gastrocnêmio'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina flexora',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-1',
    defaultWeight: 45,
    shortDescription:
      'Flexão de joelhos guiada em máquina para fortalecimento direto dos posteriores de coxa e proteção ligamentar do joelho em desacelerações.',
    biomechanicalSubtitle: 'Pernas · Posteriores de Coxa',
    angleCue: 'Tornozelos em dorsiflexão neutra',
    postureCue: 'Pelve colada ao apoio',
    kinematicChainLabel: 'Isolamento Posterior',
    executionSteps: [
      {
        title: 'Ajuste do rolo no tendão de Aquiles',
        description:
          'Posicione o rolo acolchoado logo acima dos calcanhares e trave o apoio sobre as coxas (na cadeira) ou alinhe o quadril (na mesa).'
      },
      {
        title: 'Flexão máxima controlada',
        description:
          'Puxe o rolo dobrando os joelhos ao máximo e segure 1 segundo na contração final.'
      },
      {
        title: 'Alongamento excêntrico',
        description:
          'Retorne controlando a subida do peso em 2 segundos até estender quase totalmente os joelhos.'
      }
    ],
    safetyNotes: [
      'Não arqueie a lombar nem levante o quadril do banco para roubar no final da série.',
      'Controle toda a fase excêntrica para proteger os tendões posteriores.'
    ],
    searchAliases: ['flexora', 'leg curl', 'posterior de coxa', 'isquiotibiais']
  },
  {
    id: 'e15',
    name: 'Gêmeos em Pé (Panturrilha Smith)',
    targetGroup: 'panturrilha',
    muscleFilter: 'panturrilha',
    primaryMuscleLabel: 'Gastrocnêmio',
    auxiliaryMuscles: ['Sóleo'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina / Smith',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '15-20',
    defaultRestSec: 45,
    defaultCadence: '2-1-2-1',
    defaultWeight: 60,
    shortDescription:
      'Flexão plantar em pé com joelhos estendidos, recrutando prioritariamente as cabeças medial e lateral do gastrocnêmio em amplitude completa.',
    biomechanicalSubtitle: 'Panturrilhas · Gastrocnêmio',
    angleCue: 'Pausa de 1s no alongamento',
    postureCue: 'Joelhos estendidos sem travar',
    kinematicChainLabel: 'Flexão Plantar em Pé',
    executionSteps: [
      {
        title: 'Apoio do antepé na plataforma',
        description:
          'Posicione a parte anterior dos pés sobre o degrau deixando os calcanhares livres para descer.'
      },
      {
        title: 'Alongamento profundo na base',
        description:
          'Desça os calcanhares abaixo do nível da plataforma e pause 1 segundo para dissipar o reflexo elástico do tendão.'
      },
      {
        title: 'Subida máxima na ponta dos pés',
        description:
          'Suba o mais alto possível contraindo forte as panturrilhas por 1 segundo no topo.'
      }
    ],
    safetyNotes: [
      'Não faça repetições curtas e rápidas quicando na base.',
      'Mantenha a coluna alinhada sob o apoio de ombros.'
    ],
    searchAliases: ['panturrilha em pe', 'gemeos', 'calf raise', 'panturrilha smith']
  },
  {
    id: 'e16',
    name: 'Supino Inclinado com Halteres',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral superior (clavicular)',
    auxiliaryMuscles: ['Deltoide anterior', 'Tríceps braquial'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 90,
    defaultCadence: '3-0-1-1',
    defaultWeight: 22,
    shortDescription:
      'Pressão inclinada com halteres livres, oferecendo liberdade articular para os ombros e excelente convergência no topo para o peitoral superior.',
    biomechanicalSubtitle: 'Peito · Hipertrofia Superior',
    angleCue: 'Inclinação do banco: 30°–45°',
    postureCue: 'Liberdade escapular e convergente',
    kinematicChainLabel: 'Empurrar Inclinado',
    executionSteps: [
      {
        title: 'Entrada segura com apoio nas coxas',
        description:
          'Sente-se com os halteres apoiados nas coxas e use o impulso das pernas ao deitar para posicioná-los ao lado do peito.'
      },
      {
        title: 'Descida controlada a ~60°',
        description:
          'Desça os halteres em 3 segundos mantendo os antebraços verticais e os cotovelos levemente abaixo da linha dos ombros.'
      },
      {
        title: 'Empurrada convergente',
        description:
          'Empurre os halteres para cima aproximando-os suavemente sem chocá-los no topo.'
      }
    ],
    safetyNotes: [
      'Evite inclinações acima de 45°, que transferem grande parte do esforço para os ombros.',
      'Ao finalizar a série, traga os joelhos para receber os halteres em vez de soltá-los lateralmente.'
    ],
    searchAliases: ['supino inclinado', 'incline dumbbell press', 'peitoral superior']
  },
  {
    id: 'e17',
    name: 'Dips / Paralelas ou Graviton',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral inferior e tríceps',
    auxiliaryMuscles: ['Deltoide anterior', 'Peitoral menor'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Peso corporal / Graviton',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-1-0',
    defaultWeight: 0,
    shortDescription:
      'Mergulho nas barras paralelas com tronco levemente inclinado à frente, recrutando fortemente as fibras inferiores do peitoral e o tríceps.',
    biomechanicalSubtitle: 'Peito & Tríceps · Calistenia / Graviton',
    angleCue: 'Tronco inclinado ~20° à frente',
    postureCue: 'Ombros deprimidos',
    kinematicChainLabel: 'Cadeia Cinética Fechada',
    executionSteps: [
      {
        title: 'Apoio firme nas barras paralelas',
        description:
          'Sustente o corpo com os braços estendidos, ombros encaixados para baixo e tronco levemente inclinado à frente.'
      },
      {
        title: 'Descida até ~90° nos cotovelos',
        description:
          'Flexione os cotovelos de maneira controlada até que os braços fiquem paralelos ao solo.'
      },
      {
        title: 'Subida estável',
        description:
          'Empurre as barras até retornar ao topo mantendo o controle do core.'
      }
    ],
    safetyNotes: [
      'Não desça além do limite de conforto da cápsula anterior do ombro.',
      'Utilize o Graviton caso ainda não consiga realizar 8 repetições limpas com o peso do corpo.'
    ],
    searchAliases: ['paralelas', 'mergulho', 'dips', 'graviton', 'peito inferior']
  },
  {
    id: 'e18',
    name: 'Rosca Scott com Barra W',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Bíceps (cabeça curta)',
    auxiliaryMuscles: ['Braquial'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra W / Banco Scott',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '3-0-1-0',
    defaultWeight: 22,
    shortDescription:
      'Flexão de cotovelos com os braços apoiados no banco Scott, eliminando qualquer balanço de tronco e isolando o bíceps na porção inicial do movimento.',
    biomechanicalSubtitle: 'Braços · Isolamento no Banco Scott',
    angleCue: 'Tríceps 100% apoiado',
    postureCue: 'Sem impulso dos ombros',
    kinematicChainLabel: 'Isolamento Estrito',
    executionSteps: [
      {
        title: 'Ajuste da altura do banco',
        description:
          'Regule o assento para que as axilas fiquem encaixadas na borda superior da almofada e toda a parte de trás do braço fique apoiada.'
      },
      {
        title: 'Descida lenta e controlada',
        description:
          'Desça a barra W em 3 segundos até quase estender totalmente os cotovelos.'
      },
      {
        title: 'Flexão sem desencostar os cotovelos',
        description:
          'Suba a carga contraindo o bíceps sem levantar os cotovelos da almofada.'
      }
    ],
    safetyNotes: [
      'Evite relaxar brusco no fundo do movimento com cargas altas para proteger o tendão distal do bíceps.',
      'Mantenha os punhos alinhados durante toda a série.'
    ],
    searchAliases: ['preacher curl', 'rosca scott', 'biceps scott']
  },
  {
    id: 'e19',
    name: 'Extensão de Tríceps Unilateral na Polia',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Tríceps braquial',
    auxiliaryMuscles: ['Ancôneo'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia alta',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '12-15',
    defaultRestSec: 45,
    defaultCadence: '2-0-2-0',
    defaultWeight: 12,
    shortDescription:
      'Trabalho unilateral de extensão de cotovelo no cabo para corrigir assimetrias de força e volume entre o braço direito e o esquerdo.',
    biomechanicalSubtitle: 'Braços · Simetria Unilateral',
    angleCue: 'Cotovelo fixo na linha do tronco',
    postureCue: 'Execução unilateral simétrica',
    kinematicChainLabel: 'Isolamento Unilateral',
    executionSteps: [
      {
        title: 'Pegada no puxador individual',
        description:
          'Segure a manopla ou o próprio cabo na polia alta mantendo o cotovelo próximo ao corpo.'
      },
      {
        title: 'Extensão completa do braço',
        description:
          'Estenda o antebraço até o final do curso e segure a contração do tríceps por 1 segundo.'
      },
      {
        title: 'Mesmo volume nos dois lados',
        description:
          'Inicie pelo braço menos dominante e iguale o número de repetições no outro lado.'
      }
    ],
    safetyNotes: [
      'Não gire o tronco para ajudar a descer o cabo.',
      'Mantenha o punho firme sem dobrá-lo.'
    ],
    searchAliases: ['triceps unilateral', 'triceps cabo unilateral', 'simetria braco']
  },
  {
    id: 'e20',
    name: 'Extensão de Pescoço com Resistência',
    targetGroup: 'pescoco',
    muscleFilter: 'pescoco',
    primaryMuscleLabel: 'Esplênio e semiespinhal cervical',
    auxiliaryMuscles: ['Trapézio superior'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Anilha leve / Faixa',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '15-20',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 5,
    shortDescription:
      'Fortalecimento controlado da cadeia cervical posterior para equilíbrio postural, proteção articular e simetria cervical.',
    biomechanicalSubtitle: 'Pescoço · Cadeia Posterior Cervical',
    angleCue: 'Movimento suave e contínuo',
    postureCue: 'Peito apoiado no banco',
    kinematicChainLabel: 'Extensão Cervical',
    executionSteps: [
      {
        title: 'Apoio ventral no banco',
        description:
          'Deite de bruços em um banco levemente inclinado com a cabeça para fora e resistência leve apoiada na nuca.'
      },
      {
        title: 'Extensão controlada',
        description:
          'Eleve a cabeça suavemente até alinhar ou passar discretamente da linha neutra da coluna.'
      },
      {
        title: 'Descida cadenciada',
        description:
          'Desça em 2 segundos sentindo o alongamento suave da nuca.'
      }
    ],
    safetyNotes: [
      'Nunca utilize cargas excessivas nem realize hiperextensão forçada do pescoço.',
      'Priorize controle técnico absoluto sobre carga.'
    ],
    searchAliases: ['extensao pescoco', 'nuca', 'cervical posterior']
  },
  {
    id: 'e21',
    name: 'Cardio Contínuo em Ritmo Moderado (Zona 2)',
    targetGroup: 'cintura',
    muscleFilter: 'abdomen',
    primaryMuscleLabel: 'Sistema cardiorrespiratório',
    auxiliaryMuscles: ['Membros inferiores', 'Core postural'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Esteira / Bike / Remo',
    categoryLabel: 'Condicionamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 1,
    defaultReps: '30-40 min',
    defaultRestSec: 0,
    defaultCadence: 'Contínuo',
    defaultWeight: 0,
    shortDescription:
      'Sessão aeróbica contínua em Zona 2 (65–75% da FC máx), otimizando a capacidade mitocondrial, recuperação entre séries e oxidação lipídica.',
    biomechanicalSubtitle: 'Condicionamento · Zona 2 Aeróbica',
    angleCue: 'Frequência cardíaca: 120–135 bpm',
    postureCue: 'Ritmo constante e conversacional',
    kinematicChainLabel: 'Metabolismo Oxidativo',
    executionSteps: [
      {
        title: 'Escolha da modalidade ergonômica',
        description:
          'Utilize caminhada inclinada na esteira, bicicleta ergométrica ou remo conforme sua recuperação articular do dia.'
      },
      {
        title: 'Manutenção na Zona 2',
        description:
          'Mantenha um ritmo constante no qual você consiga respirar de forma controlada e falar frases completas.'
      },
      {
        title: 'Desaceleração gradual',
        description:
          'Nos últimos 3 minutos, reduza progressivamente a intensidade para normalizar a frequência cardíaca.'
      }
    ],
    safetyNotes: [
      'Evite transformar o treino de Zona 2 em tiros de alta intensidade nos dias de recuperação.',
      'Mantenha hidratação adequada durante toda a sessão.'
    ],
    searchAliases: ['cardio', 'esteira', 'bike', 'zona 2', 'aerobico']
  },
  {
    id: 'e22',
    name: 'Stomach Vacuum (Vácuo Abdominal Clássico)',
    targetGroup: 'cintura',
    muscleFilter: 'abdomen',
    primaryMuscleLabel: 'Transverso do abdômen',
    auxiliaryMuscles: ['Diafragma', 'Assoalho pélvico'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Peso corporal',
    categoryLabel: 'Estabilidade & Core',
    difficultyLabel: 'Iniciante',
    defaultSets: 5,
    defaultReps: '25 seg',
    defaultRestSec: 40,
    defaultCadence: 'Isometria',
    defaultWeight: 0,
    shortDescription:
      'Técnica clássica de ativação neuromuscular profunda do transverso abdominal para controle da pressão intra-abdominal e redução da circunferência de cintura.',
    biomechanicalSubtitle: 'Abdômen · Controle do Transverso',
    angleCue: 'Expiração total antes da sucção',
    postureCue: 'Costelas expandidas e coluna longa',
    kinematicChainLabel: 'Controle Neuromuscular',
    executionSteps: [
      {
        title: 'Expiração completa do ar',
        description:
          'Em pé, sentado ou em quatro apoios, solte todo o ar dos pulmões pela boca.'
      },
      {
        title: 'Recolhimento profundo do umbigo',
        description:
          'Traga o umbigo o mais próximo possível da coluna vertebral como se estivesse fechando uma cinta interna.'
      },
      {
        title: 'Sustentação controlada',
        description:
          'Sustente a contração de 15 a 25 segundos e depois inspire suavemente relaxando o abdômen.'
      }
    ],
    safetyNotes: [
      'Pratique preferencialmente com o estômago leve.',
      'Caso sinta tontura, reduza o tempo de apneia e respire curto mantendo a tensão.'
    ],
    searchAliases: ['vacuum', 'vacuo abdominal', 'afinar cintura', 'transverso']
  },
  {
    id: 'e23',
    name: 'Stiff com Halteres ou Barra (RDL)',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Isquiotibiais e glúteos',
    auxiliaryMuscles: ['Eretores da espinha', 'Grande dorsal (estabilização)'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra / Halteres',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '10-12',
    defaultRestSec: 90,
    defaultCadence: '3-0-1-0',
    defaultWeight: 50,
    shortDescription:
      'Dobradiça de quadril (Hip Hinge) com joelhos semiflexionados, promovendo alongamento sob carga e fortalecimento de posteriores de coxa e glúteos.',
    biomechanicalSubtitle: 'Pernas · Cadeia Posterior (Hip Hinge)',
    angleCue: 'Joelhos em leve flexão fixa (~15°)',
    postureCue: 'Barra colada às coxas e canelas',
    kinematicChainLabel: 'Cadeia Posterior',
    executionSteps: [
      {
        title: 'Postura inicial e escápulas firmes',
        description:
          'Segure a barra ou os halteres encostados nas coxas com peito aberto e leve flexão nos joelhos.'
      },
      {
        title: 'Projeção do quadril para trás',
        description:
          'Empurre o quadril para trás deslizando o peso rente às pernas até sentir forte alongamento nos posteriores de coxa.'
      },
      {
        title: 'Extensão de quadril',
        description:
          'Retorne à posição em pé contraindo glúteos e posteriores sem hiperestender a lombar no topo.'
      }
    ],
    safetyNotes: [
      'A descida termina quando o quadril para de ir para trás (geralmente no meio da canela).',
      'Nunca arredonde a coluna lombar para tentar tocar o chão.'
    ],
    searchAliases: ['rdl', 'stiff', 'levantamento terra romeno', 'posterior']
  },
  {
    id: 'e24',
    name: 'Afundo com Halteres / Búlgaro',
    targetGroup: 'coxa',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Quadríceps e glúteo máximo',
    auxiliaryMuscles: ['Glúteo médio (estabilizador)', 'Adutores'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12 / perna',
    defaultRestSec: 60,
    defaultCadence: '2-0-1-0',
    defaultWeight: 16,
    shortDescription:
      'Agachamento unilateral com halteres (passada ou pé traseiro apoiado no banco), desenvolvendo força independente em cada perna e estabilidade de quadril e joelho.',
    biomechanicalSubtitle: 'Pernas · Força e Estabilidade Unilateral',
    angleCue: 'Tronco levemente inclinado à frente',
    postureCue: 'Joelho alinhado ao 2º dedo do pé',
    kinematicChainLabel: 'Unilateral de Membros Inferiores',
    executionSteps: [
      {
        title: 'Base unilateral estável',
        description:
          'Posicione um pé à frente e o outro atrás (no solo ou apoiado em um banco baixo no agachamento búlgaro).'
      },
      {
        title: 'Descida vertical controlada',
        description:
          'Flexione o joelho da frente mantendo o calcanhar firme até que a coxa fique próxima da linha paralela ao solo.'
      },
      {
        title: 'Subida pela perna da frente',
        description:
          'Empurre o chão com a perna da frente concentrando 85% ou mais da força nela.'
      }
    ],
    safetyNotes: [
      'Mantenha os pés afastados lateralmente na largura do quadril (como em trilhos de trem, não em linha única) para melhorar o equilíbrio.',
      'Evite que o joelho da frente oscile para dentro.'
    ],
    searchAliases: ['bulgaro', 'afundo', 'passada', 'avanço', 'lunge']
  },
  {
    id: 'e25',
    name: 'Elevação de Pernas Suspenso na Barra',
    targetGroup: 'cintura',
    muscleFilter: 'abdomen',
    primaryMuscleLabel: 'Reto abdominal (porção infra)',
    auxiliaryMuscles: ['Flexores do quadril', 'Antebraço (pegada)'],
    equipmentCategory: 'livre',
    equipmentLabel: 'Barra fixa / Paralela',
    categoryLabel: 'Estabilidade & Core',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '12-15',
    defaultRestSec: 60,
    defaultCadence: '2-0-1-1',
    defaultWeight: 0,
    shortDescription:
      'Elevação das pernas com flexão ativa da pelve suspenso na barra fixa, trabalhando intensamente a porção inferior do reto abdominal e a estabilidade escapular.',
    biomechanicalSubtitle: 'Abdômen · Porção Infra e Core',
    angleCue: 'Retroversão pélvica no topo',
    postureCue: 'Sem balanço pendular',
    kinematicChainLabel: 'Flexão Pélvica Suspensa',
    executionSteps: [
      {
        title: 'Suspensão ativa na barra',
        description:
          'Segure na barra fixa com os ombros estáveis e as pernas unidas à frente do corpo.'
      },
      {
        title: 'Elevação enrolando a pelve',
        description:
          'Suba os joelhos ou as pernas estendidas trazendo a pelve para cima no final do movimento para ativar o abdômen.'
      },
      {
        title: 'Descida sem pêndulo',
        description:
          'Desça as pernas de forma controlada evitando que o corpo balance para trás.'
      }
    ],
    safetyNotes: [
      'Se ainda houver dificuldade, execute com os joelhos flexionados priorizando enrolar a pelve.',
      'Não use impulso de balanço para subir as pernas.'
    ],
    searchAliases: ['abdominal infra', 'hanging leg raise', 'elevacao de pernas']
  },
  {
    id: 'e26',
    name: 'Panturrilha Sentado (Foco no Sóleo)',
    targetGroup: 'panturrilha',
    muscleFilter: 'panturrilha',
    primaryMuscleLabel: 'Músculo sóleo',
    auxiliaryMuscles: ['Gastrocnêmio'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina de panturrilha sentado',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '15-20',
    defaultRestSec: 45,
    defaultCadence: '2-1-2-1',
    defaultWeight: 35,
    shortDescription:
      'Flexão plantar sentado com joelhos a 90°, isolando biomecanicamente o músculo sóleo para espessura lateral da perna e resistência do tendão de Aquiles.',
    biomechanicalSubtitle: 'Panturrilhas · Isolamento do Sóleo',
    angleCue: 'Joelhos flexionados a 90°',
    postureCue: 'Amplitude máxima no tornozelo',
    kinematicChainLabel: 'Flexão Plantar Sentado',
    executionSteps: [
      {
        title: 'Apoio sobre a porção distal das coxas',
        description:
          'Sente-se no aparelho ajustando o apoio acolchoado firme logo acima dos joelhos.'
      },
      {
        title: 'Descida completa dos calcanhares',
        description:
          'Desça devagar em 2 segundos e segure 1 segundo no ponto de maior alongamento.'
      },
      {
        title: 'Contração máxima no topo',
        description:
          'Eleve os calcanhares ao máximo e sustente 1 segundo antes de descer.'
      }
    ],
    safetyNotes: [
      'Posicione o apoio próximo ao joelho, não no meio da coxa.',
      'Mantenha cadência controlada em todas as repetições.'
    ],
    searchAliases: ['soleo', 'panturrilha sentado', 'seated calf raise']
  },
  {
    id: 'e27',
    name: 'Rosca Concentrada com Halter',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Bíceps braquial (pico)',
    auxiliaryMuscles: ['Braquial'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halter',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '12',
    defaultRestSec: 45,
    defaultCadence: '2-0-2-1',
    defaultWeight: 12,
    shortDescription:
      'Flexão unilateral de cotovelo sentado com a parte posterior do braço apoiada na face interna da coxa, garantindo isolamento máximo e supinação completa.',
    biomechanicalSubtitle: 'Braços · Pico de Contração do Bíceps',
    angleCue: 'Tríceps apoiado na coxa interna',
    postureCue: 'Supinação ativa no topo',
    kinematicChainLabel: 'Isolamento Unilateral',
    executionSteps: [
      {
        title: 'Apoio firme na face interna da coxa',
        description:
          'Sente-se na ponta do banco com as pernas afastadas e apoie a parte de trás do braço contra a coxa.'
      },
      {
        title: 'Subida com supinação',
        description:
          'Suba o halter girando o dedo mínimo levemente para cima e contraia o bíceps por 1 segundo.'
      },
      {
        title: 'Descida estrita',
        description:
          'Desça controladamente até estender o braço sem tirar o apoio da coxa.'
      }
    ],
    safetyNotes: [
      'Não incline o ombro sobre o braço para alavancar o peso.',
      'Use uma carga que permita execução limpa nas duas últimas repetições.'
    ],
    searchAliases: ['rosca concentrada', 'concentration curl', 'pico de biceps']
  },
  {
    id: 'e28',
    name: 'Remada Curvada com Barra',
    targetGroup: 'ombros',
    muscleFilter: 'costas',
    primaryMuscleLabel: 'Dorsal, romboides e trapézio médio',
    auxiliaryMuscles: ['Deltoide posterior', 'Bíceps braquial', 'Eretores da espinha'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra olímpica',
    categoryLabel: 'Composto',
    difficultyLabel: 'Avançado',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 90,
    defaultCadence: '2-0-1-1',
    defaultWeight: 60,
    shortDescription:
      'Exercício base de tração horizontal com peso livre para densidade e espessura de toda a musculatura das costas.',
    biomechanicalSubtitle: 'Costas · Densidade e Espessura Dorsal',
    angleCue: 'Tronco inclinado a ~45°',
    postureCue: 'Coluna neutra e retraída',
    kinematicChainLabel: 'Tração Horizontal',
    executionSteps: [
      {
        title: 'Inclinação de quadril com coluna neutra',
        description:
          'Flexione levemente os joelhos e incline o tronco à frente mantendo a lombar firme e o peito aberto.'
      },
      {
        title: 'Puxada em direção ao abdômen',
        description:
          'Traga a barra até a linha do umbigo retraindo fortemente as escápulas no topo.'
      },
      {
        title: 'Descida controlada',
        description:
          'Estenda os braços controlando o peso sem perder a postura do tronco.'
      }
    ],
    safetyNotes: [
      'Evite dar arrancadas com a lombar para subir a barra.',
      'Se sentir fadiga excessiva na lombar, apoie o peito em um banco inclinado.'
    ],
    searchAliases: ['barbell row', 'remada curvada', 'costas barra', 'espessura dorsal']
  },
  {
    id: 'e29',
    name: 'Remada Baixa no Triângulo (Polia)',
    targetGroup: 'ombros',
    muscleFilter: 'costas',
    primaryMuscleLabel: 'Grande dorsal e romboides',
    auxiliaryMuscles: ['Trapézio médio', 'Bíceps braquial'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia baixa / Triângulo',
    categoryLabel: 'Composto',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '10-12',
    defaultRestSec: 75,
    defaultCadence: '2-0-2-1',
    defaultWeight: 55,
    shortDescription:
      'Tração horizontal sentado na polia baixa com puxador triângulo, combinando alongamento controlado das escápulas e forte retração dorsal.',
    biomechanicalSubtitle: 'Costas · Tração Horizontal no Cabo',
    angleCue: 'Tronco ereto a ~90°',
    postureCue: 'Adução escapular completa',
    kinematicChainLabel: 'Tração Guiada',
    executionSteps: [
      {
        title: 'Apoio dos pés e coluna ereta',
        description:
          'Sente-se com os pés apoiados na plataforma, joelhos semiflexionados e peitoral estufado.'
      },
      {
        title: 'Puxada para o abdômen inferior',
        description:
          'Puxe o triângulo mantendo os cotovelos próximos às costelas e una as escápulas atrás.'
      },
      {
        title: 'Retorno mantendo a lombar',
        description:
          'Deixe os braços estenderem à frente sem curvar excessivamente a lombar.'
      }
    ],
    safetyNotes: [
      'Não transforme o exercício em um balanço de tronco para a frente e para trás.',
      'Mantenha os ombros baixos durante toda a puxada.'
    ],
    searchAliases: ['remada baixa', 'seated cable row', 'remada triangulo', 'remada polia']
  },
  {
    id: 'e30',
    name: 'Desenvolvimento com Halteres',
    targetGroup: 'ombros',
    muscleFilter: 'ombros',
    primaryMuscleLabel: 'Deltoide anterior e lateral',
    auxiliaryMuscles: ['Tríceps braquial', 'Trapézio superior'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '8-10',
    defaultRestSec: 90,
    defaultCadence: '2-0-1-1',
    defaultWeight: 20,
    shortDescription:
      'Pressão vertical sentado com halteres no plano escapular, fundamental para força e volume tridimensional dos ombros.',
    biomechanicalSubtitle: 'Ombros · Pressão Vertical',
    angleCue: 'Plano escapular (~30° à frente)',
    postureCue: 'Lombar apoiada no banco 75°–80°',
    kinematicChainLabel: 'Empurrar Vertical',
    executionSteps: [
      {
        title: 'Banco ajustado a 75°–80°',
        description:
          'Posicione o encosto levemente inclinado para proteger a coluna e segure os halteres na altura das orelhas.'
      },
      {
        title: 'Empurrada no plano escapular',
        description:
          'Empurre os halteres para cima mantendo os cotovelos discretamente à frente da linha lateral do tronco.'
      },
      {
        title: 'Descida controlada',
        description:
          'Desça até que os halteres se aproximem da linha do queixo/orelhas com controle total.'
      }
    ],
    safetyNotes: [
      'Não abra os cotovelos 100% para trás; o plano escapular (~30° à frente) é mais seguro para o manguito rotador.',
      'Mantenha os pés firmes no chão e evite arquear a lombar.'
    ],
    searchAliases: ['shoulder press', 'desenvolvimento halteres', 'ombro']
  },
  {
    id: 'e31',
    name: 'Elevação Lateral com Halteres',
    targetGroup: 'ombros',
    muscleFilter: 'ombros',
    primaryMuscleLabel: 'Deltoide lateral (médio)',
    auxiliaryMuscles: ['Supraespinhal', 'Trapézio superior'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 4,
    defaultReps: '12-15',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-1',
    defaultWeight: 12,
    shortDescription:
      'Abdução de ombros no plano escapular com halteres, o principal exercício isolador para construir largura de ombros e destacar o formato em V.',
    biomechanicalSubtitle: 'Ombros · Largura de Deltoide Lateral',
    angleCue: 'Elevação até a linha dos ombros',
    postureCue: 'Ombros deprimidos (sem encolher)',
    kinematicChainLabel: 'Abdução Escapular',
    executionSteps: [
      {
        title: 'Braços no plano escapular',
        description:
          'Em pé ou sentado, mantenha leve flexão nos cotovelos e os halteres levemente à frente da linha lateral.'
      },
      {
        title: 'Abdução pensando em afastar as mãos',
        description:
          'Eleve os braços lateralmente até a altura dos ombros sem encolher o trapézio.'
      },
      {
        title: 'Descida resistindo à gravidade',
        description:
          'Desça em 2 segundos mantendo tensão contínua antes de encostar os halteres nas coxas.'
      }
    ],
    safetyNotes: [
      'Não use cargas exageradas que obriguem a dar impulso com os joelhos e quadril.',
      'Evite girar os polegares totalmente para baixo no topo (sinal da lata vazia) para prevenir impacto subacromial.'
    ],
    searchAliases: ['lateral raise', 'elevacao lateral', 'deltoide lateral', 'largura de ombro']
  },
  {
    id: 'e32',
    name: 'Crossover na Polia Alta',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral maior (esternal e inferior)',
    auxiliaryMuscles: ['Deltoide anterior'],
    equipmentCategory: 'cabo',
    equipmentLabel: 'Polia dupla / Crossover',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '12-15',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-1',
    defaultWeight: 20,
    shortDescription:
      'Adução de braços em cabos na polia alta, mantendo tensão mecânica constante inclusive no ponto de máxima aproximação das mãos.',
    biomechanicalSubtitle: 'Peito · Tensão Contínua no Cabo',
    angleCue: 'Passo à frente para estabilidade',
    postureCue: 'Peito alto e escápulas fixas',
    kinematicChainLabel: 'Adução em Cabos',
    executionSteps: [
      {
        title: 'Posição escalonada no centro',
        description:
          'Segure os puxadores das polias altas, dê um passo à frente e incline suavemente o tronco.'
      },
      {
        title: 'Fechamento em arco à frente do peito',
        description:
          'Una as mãos à frente da linha inferior do peitoral mantendo os cotovelos levemente flexionados.'
      },
      {
        title: 'Abertura controlada',
        description:
          'Retorne abrindo os braços até a linha do tronco sentindo o peitoral alongar.'
      }
    ],
    safetyNotes: [
      'Não deixe os cabos puxarem seus braços excessivamente para trás da linha dos ombros.',
      'Mantenha o tronco firme sem balançar.'
    ],
    searchAliases: ['crossover', 'crucifixo polia', 'cable fly', 'peito cabo']
  },
  {
    id: 'e33',
    name: 'Supino Reto com Halteres',
    targetGroup: 'peito',
    muscleFilter: 'peito',
    primaryMuscleLabel: 'Peitoral maior',
    auxiliaryMuscles: ['Tríceps braquial', 'Deltoide anterior'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halteres',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '8-12',
    defaultRestSec: 90,
    defaultCadence: '3-0-1-1',
    defaultWeight: 26,
    shortDescription:
      'Variação com pesos independentes do supino horizontal, permitindo maior amplitude de alongamento e adução natural das mãos no topo.',
    biomechanicalSubtitle: 'Peito · Amplitude e Simetria com Halteres',
    angleCue: 'Punhos e cotovelos alinhados',
    postureCue: 'Escápulas firmes no banco',
    kinematicChainLabel: 'Empurrar Horizontal Livre',
    executionSteps: [
      {
        title: 'Posição inicial segura',
        description:
          'Deite no banco reto trazendo os halteres junto às coxas e estabilize os pés no chão.'
      },
      {
        title: 'Descida ampla e controlada',
        description:
          'Desça os halteres ao lado do peito com os cotovelos a cerca de 60° do tronco.'
      },
      {
        title: 'Subida convergente',
        description:
          'Empurre os halteres para cima aproximando-os sobre a linha do peitoral.'
      }
    ],
    safetyNotes: [
      'Garanta que ambos os braços subam na mesma velocidade para corrigir assimetrias.',
      'Não bata um halter no outro no topo para não perder o controle.'
    ],
    searchAliases: ['dumbbell bench press', 'supino halteres', 'supino reto halter']
  },
  {
    id: 'e34',
    name: 'Elevação Pélvica com Barra (Hip Thrust)',
    targetGroup: 'quadril',
    muscleFilter: 'pernas',
    primaryMuscleLabel: 'Glúteo máximo',
    auxiliaryMuscles: ['Isquiotibiais', 'Core'],
    equipmentCategory: 'barra',
    equipmentLabel: 'Barra olímpica / Banco',
    categoryLabel: 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: 4,
    defaultReps: '8-12',
    defaultRestSec: 90,
    defaultCadence: '2-0-1-2',
    defaultWeight: 80,
    shortDescription:
      'Extensão de quadril com apoio escapular no banco e barra sobre a pelve, proporcionando pico de tensão máxima no glúteo em extensão completa.',
    biomechanicalSubtitle: 'Pernas & Glúteos · Potência de Quadril',
    angleCue: 'Canelas verticais a 90° no topo',
    postureCue: 'Queixo recolhido e olhar à frente',
    kinematicChainLabel: 'Extensão Horizontal de Quadril',
    executionSteps: [
      {
        title: 'Apoio da base das escápulas no banco',
        description:
          'Apoie a região inferior das escápulas na borda do banco e posicione a barra acolchoada sobre a dobra do quadril.'
      },
      {
        title: 'Subida até alinhar tronco e coxas',
        description:
          'Empurre o chão com os calcanhares estendendo o quadril até formar uma linha reta dos ombros aos joelhos, pausando 2s no topo.'
      },
      {
        title: 'Descida em bloco',
        description:
          'Desça o quadril mantendo o tronco e a pelve alinhados.'
      }
    ],
    safetyNotes: [
      'Ajuste a distância dos pés para que as canelas fiquem verticais no topo do movimento.',
      'Não hiperestenda a lombar; o movimento deve vir da contração dos glúteos.'
    ],
    searchAliases: ['hip thrust', 'elevacao pelvica', 'gluteo', 'ponte com barra']
  },
  {
    id: 'e35',
    name: 'Crucifixo Invertido na Máquina (Peck Deck)',
    targetGroup: 'ombros',
    muscleFilter: 'ombros',
    primaryMuscleLabel: 'Deltoide posterior',
    auxiliaryMuscles: ['Romboides', 'Trapézio médio', 'Infraespinhal'],
    equipmentCategory: 'maquinas',
    equipmentLabel: 'Máquina articulada',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Iniciante',
    defaultSets: 3,
    defaultReps: '12-15',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-1',
    defaultWeight: 40,
    shortDescription:
      'Abdução horizontal de ombros na máquina, essencial para preencher a porção posterior do ombro e equilibrar a postura frente aos exercícios de empurrar.',
    biomechanicalSubtitle: 'Ombros · Deltoide Posterior e Postura',
    angleCue: 'Braços paralelos ao solo',
    postureCue: 'Peito apoiado sem encolher ombros',
    kinematicChainLabel: 'Abdução Horizontal Posterior',
    executionSteps: [
      {
        title: 'Ajuste do assento na linha do ombro',
        description:
          'Sente-se de frente para o encosto ajustando o banco para que as alças fiquem exatamente na altura dos ombros.'
      },
      {
        title: 'Abertura conduzida pelos cotovelos',
        description:
          'Leve os braços para trás mantendo os cotovelos quase estendidos e focando na parte posterior do ombro.'
      },
      {
        title: 'Retorno controlado',
        description:
          'Volte devagar até a frente sem deixar os pesos baterem.'
      }
    ],
    safetyNotes: [
      'Evite juntar excessivamente as escápulas no início para não transferir todo o trabalho para o trapézio.',
      'Mantenha o pescoço relaxado e alinhado.'
    ],
    searchAliases: ['reverse fly', 'crucifixo invertido', 'deltoide posterior', 'voador inverso']
  },
  {
    id: 'e36',
    name: 'Tríceps Francês Unilateral com Halter',
    targetGroup: 'braco',
    muscleFilter: 'bracos',
    primaryMuscleLabel: 'Tríceps (cabeça longa)',
    auxiliaryMuscles: ['Ancôneo'],
    equipmentCategory: 'halteres',
    equipmentLabel: 'Halter',
    categoryLabel: 'Isolamento',
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-2-0',
    defaultWeight: 12,
    shortDescription:
      'Extensão de cotovelo acima da cabeça com o ombro em flexão completa, colocando a cabeça longa do tríceps em seu maior grau de alongamento biomecânico.',
    biomechanicalSubtitle: 'Braços · Alongamento da Cabeça Longa',
    angleCue: 'Braço vertical próximo à orelha',
    postureCue: 'Core firme sem arquear a lombar',
    kinematicChainLabel: 'Extensão Overhead',
    executionSteps: [
      {
        title: 'Posição sentada com braço elevado',
        description:
          'Sente-se em um banco com apoio lombar e eleve o halter acima da cabeça mantendo o braço próximo à orelha.'
      },
      {
        title: 'Descida atrás da cabeça',
        description:
          'Flexione apenas o cotovelo descendo o halter atrás da nuca até alongar bem o tríceps.'
      },
      {
        title: 'Extensão vertical',
        description:
          'Estenda o cotovelo levando o halter de volta ao topo sem abrir o braço para o lado.'
      }
    ],
    safetyNotes: [
      'Use a mão livre para estabilizar suavemente o braço que está trabalhando, se necessário.',
      'Mantenha as costelas baixas para não sobrecarregar a lombar.'
    ],
    searchAliases: ['triceps frances', 'overhead triceps extension', 'cabeca longa triceps']
  }
];

function inferEquipmentFromText(text: string): {
  category: ExerciseEquipmentCategory;
  label: string;
} {
  const norm = normalizeSearchText(text);
  if (norm.includes('halter') || norm.includes('dumbbell')) {
    return { category: 'halteres', label: 'Halteres' };
  }
  if (
    norm.includes('polia') ||
    norm.includes('cabo') ||
    norm.includes('pulley') ||
    norm.includes('corda') ||
    norm.includes('crossover') ||
    norm.includes('triangulo')
  ) {
    return { category: 'cabo', label: 'Polia / Cabo' };
  }
  if (
    norm.includes('maquina') ||
    norm.includes('leg press') ||
    norm.includes('cadeira') ||
    norm.includes('mesa') ||
    norm.includes('smith') ||
    norm.includes('esteira') ||
    norm.includes('peck deck')
  ) {
    return { category: 'maquinas', label: 'Máquina articulada' };
  }
  if (
    norm.includes('prancha') ||
    norm.includes('vacuum') ||
    norm.includes('vacuo') ||
    norm.includes('paralela') ||
    norm.includes('dips') ||
    norm.includes('suspenso') ||
    norm.includes('peso corporal') ||
    norm.includes('flexao de braco')
  ) {
    return { category: 'livre', label: 'Peso corporal' };
  }
  if (norm.includes('barra')) {
    return { category: 'barra', label: 'Barra olímpica' };
  }
  return { category: 'halteres', label: 'Peso livre / Halteres' };
}

function inferMuscleFilterFromItem(
  targetGroup: BodyPartKey,
  name: string
): Exclude<ExerciseMuscleFilter, 'all'> {
  const norm = normalizeSearchText(name);
  if (
    norm.includes('puxada') ||
    norm.includes('remada') ||
    norm.includes('dorsal') ||
    norm.includes('barra fixa') ||
    norm.includes('pulley')
  ) {
    return 'costas';
  }
  switch (targetGroup) {
    case 'peito':
      return 'peito';
    case 'ombros':
      return 'ombros';
    case 'braco':
      return 'bracos';
    case 'coxa':
    case 'quadril':
      return 'pernas';
    case 'panturrilha':
      return 'panturrilha';
    case 'cintura':
      return 'abdomen';
    case 'pescoco':
      return 'pescoco';
    default:
      return 'peito';
  }
}

export function synthesizeCatalogEntryFromWorkoutItem(
  item: Pick<
    ExerciseItem,
    'id' | 'name' | 'targetGroup' | 'baseSets' | 'reps' | 'rest' | 'cadence' | 'defaultWeight' | 'tip'
  >,
  isCustom = false
): CatalogExercise {
  const cleanName = cleanDisplayText(item.name);
  const muscleFilter = inferMuscleFilterFromItem(item.targetGroup, cleanName);
  const eq = inferEquipmentFromText(cleanName);
  const primaryMuscleLabel = getPrimaryMuscleDefaultLabel(muscleFilter);

  return {
    id: item.id,
    name: cleanName,
    targetGroup: item.targetGroup,
    muscleFilter,
    primaryMuscleLabel,
    auxiliaryMuscles: ['Estabilizadores sinergistas'],
    equipmentCategory: eq.category,
    equipmentLabel: eq.label,
    categoryLabel:
      eq.category === 'livre' && muscleFilter === 'abdomen'
        ? 'Estabilidade & Core'
        : 'Composto',
    difficultyLabel: 'Intermediário',
    defaultSets: Number(item.baseSets) || 3,
    defaultReps: item.reps || '10-12',
    defaultRestSec: Number(item.rest) || 60,
    defaultCadence: item.cadence || '2-0-1-1',
    defaultWeight: Number(item.defaultWeight) || 20,
    shortDescription:
      item.tip ||
      `Execução controlada de ${cleanName} com foco em estabilidade articular e recrutamento de ${primaryMuscleLabel.toLowerCase()}.`,
    biomechanicalSubtitle: `${primaryMuscleLabel} · ${eq.label}`,
    angleCue: `Cadência: ${item.cadence || '2-0-1-1'}`,
    postureCue: 'Controle excêntrico completo',
    kinematicChainLabel: primaryMuscleLabel,
    executionSteps: [
      {
        title: 'Posicionamento e estabilidade',
        description:
          'Ajuste o equipamento ou sua base corporal garantindo alinhamento articular seguro antes de iniciar a série.'
      },
      {
        title: 'Fase concêntrica controlada',
        description:
          item.tip ||
          `Realize o movimento focando na contração de ${primaryMuscleLabel.toLowerCase()} sem impulsos bruscos.`
      },
      {
        title: 'Fase excêntrica cadenciada',
        description:
          'Retorne à posição inicial controlando a carga por 2 a 3 segundos para maximizar a tensão mecânica.'
      }
    ],
    safetyNotes: [
      'Respeite a amplitude confortável das suas articulações durante toda a série.',
      'Priorize a execução técnica limpa antes de progredir a carga.'
    ],
    searchAliases: [cleanName.toLowerCase()],
    isCustom
  };
}

/**
 * Constrói o catálogo unificado do AURUS GYM mesclando:
 * 1. BASE_EXERCISE_CATALOG (e1..e36)
 * 2. Exercícios personalizados salvos pelo usuário (customExercises)
 * 3. Exercícios presentes nas rotinas atuais (workouts)
 * 4. Exercícios presentes no histórico de treinos (workoutHistory)
 * Sem duplicar identificadores nem nomes equivalentes.
 */
export function buildExerciseCatalog(options?: {
  customExercises?: CatalogExercise[];
  workouts?: WorkoutDay[] | null;
  workoutHistory?: CompletedWorkout[];
}): CatalogExercise[] {
  const byId = new Map<string, CatalogExercise>();
  const byNormName = new Map<string, string>();

  for (const baseEx of BASE_EXERCISE_CATALOG) {
    byId.set(baseEx.id, baseEx);
    byNormName.set(normalizeSearchText(baseEx.name), baseEx.id);
  }

  for (const customEx of options?.customExercises || []) {
    if (!customEx || !customEx.id || !customEx.name) continue;
    const norm = normalizeSearchText(customEx.name);
    const existingId = byId.has(customEx.id) ? customEx.id : byNormName.get(norm);
    if (existingId && BASE_EXERCISE_CATALOG.some((b) => b.id === existingId)) {
      // Nunca sobrescreve exercício oficial do sistema
      continue;
    }
    byId.set(customEx.id, { ...customEx, isCustom: true });
    byNormName.set(norm, customEx.id);
  }

  for (const day of options?.workouts || []) {
    for (const ex of day.exercises || []) {
      if (!ex || !ex.id || !ex.name) continue;
      const norm = normalizeSearchText(ex.name);
      if (byId.has(ex.id) || byNormName.has(norm)) continue;
      const synthesized = synthesizeCatalogEntryFromWorkoutItem(
        ex,
        ex.id.startsWith('ex_custom_') || ex.id.startsWith('custom_ex_')
      );
      byId.set(synthesized.id, synthesized);
      byNormName.set(norm, synthesized.id);
    }
  }

  for (const workout of options?.workoutHistory || []) {
    for (const summary of workout.exercisesSummary || []) {
      if (!summary || !summary.exerciseId || !summary.name) continue;
      const norm = normalizeSearchText(summary.name);
      if (byId.has(summary.exerciseId) || byNormName.has(norm)) continue;
      const synthesized = synthesizeCatalogEntryFromWorkoutItem(
        {
          id: summary.exerciseId,
          name: summary.name,
          targetGroup: summary.targetGroup || 'peito',
          baseSets: summary.totalSets || 3,
          reps: '8-12',
          rest: 60,
          cadence: '2-0-1-1',
          defaultWeight: summary.maxWeight || 20,
          tip: 'Exercício registrado no seu histórico de treinos.'
        },
        summary.exerciseId.startsWith('ex_custom_') ||
          summary.exerciseId.startsWith('custom_ex_')
      );
      byId.set(synthesized.id, synthesized);
      byNormName.set(norm, synthesized.id);
    }
  }

  return Array.from(byId.values());
}

/**
 * Filtra o catálogo combinando busca textual (sem diferenciar maiúsculas/minúsculas ou acentos),
 * filtro de grupo muscular e filtro de equipamento.
 */
export function filterExerciseCatalog(
  catalog: CatalogExercise[],
  filters: {
    query?: string;
    muscleFilter?: ExerciseMuscleFilter;
    equipmentFilter?: ExerciseEquipmentCategory | 'all';
  }
): CatalogExercise[] {
  const normQuery = normalizeSearchText(filters.query || '');
  const muscle = filters.muscleFilter || 'all';
  const equipment = filters.equipmentFilter || 'all';

  return catalog.filter((item) => {
    if (muscle !== 'all' && item.muscleFilter !== muscle) {
      return false;
    }

    if (equipment !== 'all' && item.equipmentCategory !== equipment) {
      return false;
    }

    if (!normQuery) {
      return true;
    }

    const searchableFields = [
      item.name,
      item.primaryMuscleLabel,
      item.equipmentLabel,
      item.categoryLabel,
      item.biomechanicalSubtitle,
      ...(item.auxiliaryMuscles || []),
      ...(item.searchAliases || [])
    ];

    const haystack = normalizeSearchText(searchableFields.join(' '));
    const queryTokens = normQuery.split(' ').filter(Boolean);
    return queryTokens.every((token) => haystack.includes(token));
  });
}

export interface ExercisePersonalHistorySummary {
  hasHistory: boolean;
  resolvedHistoryExerciseId: string | null;
  bestWeightKg: number | null;
  bestReps: number | null;
  bestDateLabel: string | null;
  lastWeightKg: number | null;
  lastReps: number | null;
  lastDateLabel: string | null;
  sessionsCount: number;
  progressionDeltaKg: number | null;
}

/**
 * Obtém o resumo real de histórico pessoal para um exercício do catálogo.
 * Nunca fabrica recordes ou cargas caso o usuário não tenha registrado o exercício.
 */
export function getExercisePersonalHistorySummary(
  exercise: Pick<CatalogExercise, 'id' | 'name'>,
  workoutHistory: CompletedWorkout[],
  lastExerciseWeights: Record<string, number> = {},
  dynamicWorkouts: WorkoutDay[] = []
): ExercisePersonalHistorySummary {
  const registeredList = getRegisteredExercisesList(
    workoutHistory,
    lastExerciseWeights,
    dynamicWorkouts
  );

  const normTargetName = normalizeSearchText(exercise.name);
  const matchedRegistered = registeredList.find(
    (reg) =>
      reg.exerciseId === exercise.id ||
      normalizeSearchText(reg.name) === normTargetName ||
      normalizeSearchText(reg.name).includes(normTargetName) ||
      normTargetName.includes(normalizeSearchText(reg.name))
  );

  if (
    !matchedRegistered ||
    (matchedRegistered.maxWeight <= 0 && matchedRegistered.lastWeight <= 0)
  ) {
    return {
      hasHistory: false,
      resolvedHistoryExerciseId: null,
      bestWeightKg: null,
      bestReps: null,
      bestDateLabel: null,
      lastWeightKg: null,
      lastReps: null,
      lastDateLabel: null,
      sessionsCount: 0,
      progressionDeltaKg: null
    };
  }

  return {
    hasHistory: true,
    resolvedHistoryExerciseId: matchedRegistered.exerciseId,
    bestWeightKg: matchedRegistered.maxWeight > 0 ? matchedRegistered.maxWeight : null,
    bestReps: matchedRegistered.maxWeightReps ?? null,
    bestDateLabel: matchedRegistered.maxWeightDate ?? null,
    lastWeightKg: matchedRegistered.lastWeight > 0 ? matchedRegistered.lastWeight : null,
    lastReps: matchedRegistered.lastWeightReps ?? null,
    lastDateLabel: matchedRegistered.lastSessionDate ?? null,
    sessionsCount: matchedRegistered.sessionsCount,
    progressionDeltaKg: matchedRegistered.weightDeltaKg
  };
}

export interface AddExerciseToRoutineParams {
  currentCustomWorkouts: WorkoutDay[] | null;
  baseTemplate: WorkoutDay[];
  targetDayId: string;
  catalogExercise: CatalogExercise;
  plannedSets: number;
  plannedReps: string;
  plannedRestSec?: number;
  position: 'start' | 'end';
  allowUpdateExisting?: boolean;
  sessionSets?: Record<string, SetLog[]>;
  isSessionActiveOnTargetDay?: boolean;
  lastExerciseWeights?: Record<string, number>;
}

export interface AddExerciseToRoutineResult {
  status: 'added' | 'updated' | 'duplicate_blocked' | 'protected_completed_sets' | 'error';
  message: string;
  updatedWorkouts: WorkoutDay[];
  updatedSessionSets: Record<string, SetLog[]>;
  addedOrUpdatedItem?: ExerciseItem;
}

/**
 * Verifica se um exercício já existe dentro de uma rotina (por ID ou nome normalizado).
 */
export function findExistingExerciseInRoutine(
  workoutDay: WorkoutDay | undefined,
  catalogExercise: Pick<CatalogExercise, 'id' | 'name'>
): ExerciseItem | null {
  if (!workoutDay || !Array.isArray(workoutDay.exercises)) return null;
  const targetNorm = normalizeSearchText(catalogExercise.name);
  return (
    workoutDay.exercises.find(
      (ex) =>
        ex.id === catalogExercise.id ||
        normalizeSearchText(ex.name) === targetNorm
    ) || null
  );
}

/**
 * Adiciona ou atualiza um exercício em uma rotina existente, prevenindo duplicatas acidentais
 * e protegendo integralmente qualquer sessão ativa em andamento na Arena.
 */
export function addOrUpdateExerciseInRoutine(
  params: AddExerciseToRoutineParams
): AddExerciseToRoutineResult {
  const {
    currentCustomWorkouts,
    baseTemplate,
    targetDayId,
    catalogExercise,
    plannedSets,
    plannedReps,
    plannedRestSec,
    position,
    allowUpdateExisting = false,
    sessionSets = {},
    isSessionActiveOnTargetDay = false,
    lastExerciseWeights = {}
  } = params;

  const sourceList = (
    currentCustomWorkouts && currentCustomWorkouts.length > 0
      ? currentCustomWorkouts
      : baseTemplate
  ).map((day) => ({
    ...day,
    exercises: [...(day.exercises || [])]
  }));

  const targetDayIndex = sourceList.findIndex((d) => d.id === targetDayId);
  if (targetDayIndex === -1) {
    return {
      status: 'error',
      message: 'Rotina selecionada não encontrada.',
      updatedWorkouts: sourceList,
      updatedSessionSets: { ...sessionSets }
    };
  }

  const safeSets = Math.max(1, Math.min(10, Math.round(Number(plannedSets) || catalogExercise.defaultSets || 3)));
  const safeReps = String(plannedReps || catalogExercise.defaultReps || '8-10').trim();
  const safeRest = Math.max(15, Number(plannedRestSec ?? catalogExercise.defaultRestSec) || 60);

  const targetDay = sourceList[targetDayIndex];
  const existingItem = findExistingExerciseInRoutine(targetDay, catalogExercise);

  if (existingItem && !allowUpdateExisting) {
    return {
      status: 'duplicate_blocked',
      message: `${catalogExercise.name} já faz parte de ${cleanDisplayText(targetDay.title)}. Você pode atualizar suas séries planejadas.`,
      updatedWorkouts: sourceList,
      updatedSessionSets: { ...sessionSets },
      addedOrUpdatedItem: existingItem
    };
  }

  const nextSessionSets: Record<string, SetLog[]> = { ...sessionSets };

  if (existingItem) {
    // Atualização de exercício já existente na rotina
    const updatedItem: ExerciseItem = {
      ...existingItem,
      baseSets: safeSets,
      totalSets: safeSets,
      reps: safeReps,
      rest: safeRest
    };

    targetDay.exercises = targetDay.exercises.map((ex) =>
      ex.id === existingItem.id ? updatedItem : ex
    );

    const existingLogs = nextSessionSets[existingItem.id] || [];
    const completedLogs = existingLogs.filter((s) => s.completed);

    if (isSessionActiveOnTargetDay && completedLogs.length > 0) {
      // Protege integralmente as séries já concluídas na sessão ativa!
      const targetTotalCount = Math.max(completedLogs.length, safeSets);
      const preservedSets: SetLog[] = [...existingLogs];
      const numReps = parseInt(safeReps.split('-')[1] || safeReps, 10) || 10;
      const lastWeight =
        preservedSets[preservedSets.length - 1]?.weight ??
        lastExerciseWeights[existingItem.id] ??
        existingItem.defaultWeight ??
        20;

      // Atualiza apenas séries ainda não concluídas e adiciona séries faltantes se o total aumentou
      const rebuiltSets: SetLog[] = [];
      for (let i = 0; i < preservedSets.length; i++) {
        const log = preservedSets[i];
        if (log.completed) {
          rebuiltSets.push({ ...log, setNumber: rebuiltSets.length + 1 });
        } else if (rebuiltSets.length < targetTotalCount) {
          rebuiltSets.push({
            ...log,
            setNumber: rebuiltSets.length + 1,
            reps: numReps
          });
        }
      }
      while (rebuiltSets.length < targetTotalCount) {
        rebuiltSets.push({
          setNumber: rebuiltSets.length + 1,
          weight: lastWeight,
          reps: numReps,
          rpe: 8,
          completed: false
        });
      }
      nextSessionSets[existingItem.id] = rebuiltSets;

      return {
        status: 'protected_completed_sets',
        message: `Configuração de ${catalogExercise.name} atualizada preservando suas ${completedLogs.length} série(s) já concluída(s) na sessão ativa.`,
        updatedWorkouts: sourceList,
        updatedSessionSets: nextSessionSets,
        addedOrUpdatedItem: updatedItem
      };
    }

    // Sem séries concluídas: atualiza a grade planejada limpa
    const savedWeight =
      lastExerciseWeights[existingItem.id] ?? existingItem.defaultWeight ?? 20;
    const numReps = parseInt(safeReps.split('-')[1] || safeReps, 10) || 10;
    nextSessionSets[existingItem.id] = Array.from({ length: safeSets }, (_, idx) => ({
      setNumber: idx + 1,
      weight: savedWeight,
      reps: numReps,
      rpe: 8,
      completed: false
    }));

    return {
      status: 'updated',
      message: `${catalogExercise.name} atualizado em ${cleanDisplayText(targetDay.title)} (${safeSets} séries × ${safeReps}).`,
      updatedWorkouts: sourceList,
      updatedSessionSets: nextSessionSets,
      addedOrUpdatedItem: updatedItem
    };
  }

  // Novo exercício sendo adicionado à rotina
  const newItem: ExerciseItem = {
    id: catalogExercise.id,
    name: catalogExercise.name,
    targetGroup: catalogExercise.targetGroup,
    baseSets: safeSets,
    totalSets: safeSets,
    reps: safeReps,
    rest: safeRest,
    cadence: catalogExercise.defaultCadence || '2-0-1-1',
    defaultWeight:
      lastExerciseWeights[catalogExercise.id] ?? catalogExercise.defaultWeight ?? 20,
    tip: catalogExercise.shortDescription
  };

  if (position === 'start') {
    targetDay.exercises = [newItem, ...targetDay.exercises];
  } else {
    targetDay.exercises = [...targetDay.exercises, newItem];
  }

  // Inicializa séries do novo exercício sem tocar nas séries de nenhum outro exercício
  const savedWeight =
    lastExerciseWeights[newItem.id] ?? newItem.defaultWeight ?? 20;
  const numReps = parseInt(safeReps.split('-')[1] || safeReps, 10) || 10;
  if (!nextSessionSets[newItem.id] || nextSessionSets[newItem.id].length === 0) {
    nextSessionSets[newItem.id] = Array.from({ length: safeSets }, (_, idx) => ({
      setNumber: idx + 1,
      weight: savedWeight,
      reps: numReps,
      rpe: 8,
      completed: false
    }));
  }

  return {
    status: 'added',
    message: isSessionActiveOnTargetDay
      ? `${catalogExercise.name} adicionado a ${cleanDisplayText(targetDay.title)} preservando sua sessão em andamento.`
      : `${catalogExercise.name} adicionado a ${cleanDisplayText(targetDay.title)} (${safeSets} séries × ${safeReps}).`,
    updatedWorkouts: sourceList,
    updatedSessionSets: nextSessionSets,
    addedOrUpdatedItem: newItem
  };
}

export interface CreateCustomCatalogExerciseInput {
  name: string;
  muscleFilter: Exclude<ExerciseMuscleFilter, 'all'>;
  equipmentCategory: ExerciseEquipmentCategory;
  categoryLabel?: CatalogExercise['categoryLabel'];
  shortDescription?: string;
  existingCatalog?: CatalogExercise[];
  nowMs?: number;
}

export function createCustomCatalogExercise(
  input: CreateCustomCatalogExerciseInput
): {
  ok: boolean;
  error?: string;
  exercise?: CatalogExercise;
} {
  const cleanName = cleanDisplayText(input.name || '').trim();
  if (cleanName.length < 3) {
    return {
      ok: false,
      error: 'Informe um nome válido com pelo menos 3 caracteres.'
    };
  }

  const normName = normalizeSearchText(cleanName);
  const existing = (input.existingCatalog || BASE_EXERCISE_CATALOG).find(
    (ex) => normalizeSearchText(ex.name) === normName
  );
  if (existing) {
    return {
      ok: false,
      error: `Já existe um exercício cadastrado com o nome "${existing.name}".`,
      exercise: existing
    };
  }

  const slug = normName.replace(/\s+/g, '_').slice(0, 28) || 'exercicio';
  const timestamp = input.nowMs || Date.now();
  const id = `custom_ex_${slug}_${timestamp}`;
  const targetGroup = mapMuscleFilterToBodyPartKey(input.muscleFilter);
  const primaryMuscleLabel = getPrimaryMuscleDefaultLabel(input.muscleFilter);
  const equipmentLabel = getEquipmentLabel(input.equipmentCategory);
  const categoryLabel = input.categoryLabel || 'Composto';

  const exercise: CatalogExercise = {
    id,
    name: cleanName,
    targetGroup,
    muscleFilter: input.muscleFilter,
    primaryMuscleLabel,
    auxiliaryMuscles: ['Sinergistas estabilizadores'],
    equipmentCategory: input.equipmentCategory,
    equipmentLabel,
    categoryLabel,
    difficultyLabel: 'Intermediário',
    defaultSets: 3,
    defaultReps: '10-12',
    defaultRestSec: 60,
    defaultCadence: '2-0-1-1',
    defaultWeight: input.equipmentCategory === 'livre' ? 0 : 20,
    shortDescription:
      (input.shortDescription || '').trim() ||
      `Exercício personalizado cadastrado para desenvolvimento de ${primaryMuscleLabel.toLowerCase()} utilizando ${equipmentLabel.toLowerCase()}.`,
    biomechanicalSubtitle: `${primaryMuscleLabel} · ${equipmentLabel}`,
    angleCue: 'Amplitude completa e controlada',
    postureCue: 'Estabilidade articular ativa',
    kinematicChainLabel: primaryMuscleLabel,
    executionSteps: [
      {
        title: 'Ajuste e posicionamento inicial',
        description: `Prepare o ${equipmentLabel.toLowerCase()} e estabilize as articulações antes de iniciar a primeira repetição.`
      },
      {
        title: 'Contração principal',
        description: `Execute a fase concêntrica priorizando o recrutamento de ${primaryMuscleLabel.toLowerCase()}.`
      },
      {
        title: 'Retorno controlado',
        description:
          'Controle a fase excêntrica por 2 segundos mantendo tensão muscular constante.'
      }
    ],
    safetyNotes: [
      'Mantenha alinhamento articular e evite impulsos bruscos durante a execução.',
      'Progrida a carga de forma gradual conforme sua adaptação.'
    ],
    searchAliases: [normName],
    isCustom: true,
    createdAtMs: timestamp
  };

  return {
    ok: true,
    exercise
  };
}
