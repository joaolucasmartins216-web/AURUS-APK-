import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BackNavigationStateSnapshot,
  isRunningInAndroidWebView,
  resolveAndroidBackAction,
  resolveApiEndpoint
} from './capacitorBridge';
import { getGoogleAuthEnvironmentStatus } from './googleAuth';

const BASE_BACK_STATE: BackNavigationStateSnapshot = {
  activeTab: 'inicio',
  profileSubView: 'profile_home',
  isMobileMenuOpen: false,
  showGuideModal: false,
  showOnboardingModal: false,
  hasCompletedWorkoutSummary: false,
  showDiscardModal: false,
  hasPendingAiReformulation: false,
  hasPendingBackupImport: false,
  isRestModalOpen: false
};

test('resolveApiEndpoint never allows localhost URLs on native Android APK', () => {
  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: true,
      configuredBaseUrl: ''
    }),
    null
  );

  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: true,
      configuredBaseUrl: 'http://localhost:3000'
    }),
    null
  );

  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: true,
      configuredBaseUrl: 'http://127.0.0.1:3000/'
    }),
    null
  );

  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: true,
      configuredBaseUrl: 'https://aurus-backend.run.app/'
    }),
    'https://aurus-backend.run.app/api/gemini/generate'
  );
});

test('resolveApiEndpoint uses relative path on Web when no remote base URL is set', () => {
  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: false,
      configuredBaseUrl: ''
    }),
    '/api/gemini/generate'
  );

  assert.equal(
    resolveApiEndpoint('/api/gemini/generate', {
      isNative: false,
      configuredBaseUrl: 'https://aurus-backend.run.app'
    }),
    'https://aurus-backend.run.app/api/gemini/generate'
  );
});

test('resolveAndroidBackAction closes open modals first, then subviews, then tabs, then minimizes', () => {
  // 1. Rest modal open -> closes rest modal
  assert.deepEqual(
    resolveAndroidBackAction({
      ...BASE_BACK_STATE,
      activeTab: 'executar',
      isRestModalOpen: true
    }),
    { action: 'close_modal', target: 'rest_modal' }
  );

  // 2. Discard modal open -> closes discard modal
  assert.deepEqual(
    resolveAndroidBackAction({
      ...BASE_BACK_STATE,
      activeTab: 'executar',
      showDiscardModal: true
    }),
    { action: 'close_modal', target: 'discard_modal' }
  );

  // 3. Profile subview (e.g., settings or backup) -> resets to profile_home
  assert.deepEqual(
    resolveAndroidBackAction({
      ...BASE_BACK_STATE,
      activeTab: 'perfil',
      profileSubView: 'backup'
    }),
    { action: 'reset_profile_subview' }
  );

  // 4. Secondary tab (e.g., Arena, Evolução, Scanner) -> navigates back to inicio
  assert.deepEqual(
    resolveAndroidBackAction({
      ...BASE_BACK_STATE,
      activeTab: 'executar'
    }),
    { action: 'navigate_home' }
  );

  // 5. Root Dashboard (inicio) with no modals -> minimizes native app
  assert.deepEqual(resolveAndroidBackAction(BASE_BACK_STATE), {
    action: 'minimize_app'
  });
});

test('isRunningInAndroidWebView and getGoogleAuthEnvironmentStatus detect Android WebView user agents', () => {
  const androidWebViewUA =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8 Build/UQ1A.240205.004; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/122.0.6261.64 Mobile Safari/537.36';
  const chromeMobileUA =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.64 Mobile Safari/537.36';

  assert.equal(isRunningInAndroidWebView(androidWebViewUA), true);
  assert.equal(isRunningInAndroidWebView(chromeMobileUA), false);

  const wvStatus = getGoogleAuthEnvironmentStatus(androidWebViewUA);
  assert.equal(wvStatus.isAndroidWebView, true);
  assert.equal(wvStatus.popupSupported, false);
  assert.ok(wvStatus.warningMessage && wvStatus.warningMessage.includes('disallowed_useragent'));

  const webStatus = getGoogleAuthEnvironmentStatus(chromeMobileUA);
  assert.equal(webStatus.isAndroidWebView, false);
  assert.equal(webStatus.popupSupported, true);
});
