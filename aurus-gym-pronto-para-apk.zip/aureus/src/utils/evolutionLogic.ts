import {
  BodyPartKey,
  CheckinRecord,
  CompletedWorkout,
  WorkoutDay
} from '../types';
import {
  HYBRID_WORKOUT_TEMPLATE,
  INITIAL_AI_WORKOUTS
} from './constants';
import {
  cleanDisplayText,
  getCurrentWeekBounds,
  splitCheckinsByOrigin
} from './dashboardLogic';

export type EvolutionPeriod = '7d' | '30d' | '90d' | 'all';

export interface EvolutionOverviewStats {
  sessionsCount: number;
  distinctTrainedDays: number;
  totalDurationSec: number;
  avgDurationMin: number;
  totalVolumeKg: number;
  totalCompletedSets: number;
  weeklyFrequency: number;
  targetWeeklyDays: number;
  durationFormatted: {
    hours: number;
    minutes: number;
    label: string;
  };
  volumeFormatted: {
    value: string;
    unit: 'kg' | 'ton';
    exactKgLabel: string;
  };
}

export interface VolumeChartPoint {
  key: string;
  label: string;
  tooltipTitle: string;
  volumeKg: number;
  sessionsCount: number;
  distinctDaysCount: number;
  timestampMs: number;
}

export interface VolumeChartSeries {
  scaleType: 'day' | 'week' | 'month';
  scaleLabel: string;
  averageLabel: string;
  averageVolumeKg: number;
  points: VolumeChartPoint[];
}

export interface RegisteredExerciseItem {
  exerciseId: string;
  name: string;
  targetGroup: string;
  groupLabel: string;
  maxWeight: number;
  maxWeightReps?: number;
  maxWeightDate?: string;
  lastWeight: number;
  lastWeightReps?: number;
  lastWeightVolumeKg?: number;
  lastSessionDate?: string;
  lastSessionTimestamp: number;
  sessionsCount: number;
  weightDeltaKg: number | null;
  hasHistoricalSessions: boolean;
}

export interface ExerciseSessionRecord {
  workoutId: string;
  workoutTitle: string;
  dayName: string;
  timestamp: number;
  dateShortLabel: string;
  dateFullLabel: string;
  maxWeight: number;
  bestSetReps?: number;
  volumeKg?: number;
  setsCompleted: number;
  totalSets: number;
  isPersonalRecord: boolean;
  hasIndividualSets: boolean;
  setsDetail: Array<{
    setNumber: number;
    weight: number;
    reps: number;
    rpe?: number;
  }>;
}

export interface ExerciseEvolutionDetail {
  exerciseId: string;
  name: string;
  targetGroup: string;
  groupLabel: string;
  allTimeMaxWeight: number;
  allTimeMaxReps?: number;
  allTimeMaxDateLabel?: string;
  allTimeSessionsCount: number;
  lastRecord: ExerciseSessionRecord | null;
  fallbackLastWeight: number | null;
  periodSessions: ExerciseSessionRecord[];
  progressionPoints: ExerciseSessionRecord[];
}

export interface WorkoutMonthGroup {
  monthKey: string;
  monthLabel: string;
  workouts: CompletedWorkout[];
}

const GROUP_DISPLAY_LABELS: Record<string, string> = {
  peito: 'Peito',
  ombros: 'Ombros',
  braco: 'Braços',
  coxa: 'Pernas',
  panturrilha: 'Panturrilha',
  pescoco: 'Pescoço',
  cintura: 'Core / Abdômen',
  quadril: 'Glúteos / Quadril',
  costas: 'Costas',
  dorsais: 'Costas',
  pernas: 'Pernas',
  bracos: 'Braços'
};

export function getMuscleGroupDisplayLabel(groupKey: string | undefined | null): string {
  if (!groupKey) return 'Musculação';
  const normalized = groupKey.toLowerCase().trim();
  if (GROUP_DISPLAY_LABELS[normalized]) {
    return GROUP_DISPLAY_LABELS[normalized];
  }
  if (normalized.includes('peito') || normalized.includes('peitoral')) return 'Peito';
  if (normalized.includes('costa') || normalized.includes('dorsal')) return 'Costas';
  if (normalized.includes('perna') || normalized.includes('coxa') || normalized.includes('quadr'))
    return 'Pernas';
  if (normalized.includes('ombro') || normalized.includes('deltoide')) return 'Ombros';
  if (normalized.includes('braço') || normalized.includes('braco') || normalized.includes('tríceps') || normalized.includes('bíceps'))
    return 'Braços';
  if (normalized.includes('panturrilha')) return 'Panturrilha';
  return groupKey.charAt(0).toUpperCase() + groupKey.slice(1);
}

/**
 * Formata uma chave de data local (YYYY-MM-DD) usando o fuso horário local do usuário.
 */
export function toLocalDateKey(timestampMs: number): string {
  const d = new Date(timestampMs);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/**
 * Formata data curta local (ex: "08 Nov").
 */
export function formatShortLocalDate(timestampMs: number): string {
  const d = new Date(timestampMs);
  const day = String(d.getDate()).padStart(2, '0');
  const months = [
    'Jan',
    'Fev',
    'Mar',
    'Abr',
    'Mai',
    'Jun',
    'Jul',
    'Ago',
    'Set',
    'Out',
    'Nov',
    'Dez'
  ];
  return `${day} ${months[d.getMonth()] || ''}`;
}

/**
 * Formata data completa e amigável em português (ex: "Hoje, 18:30", "Ontem, 19:00" ou "Sáb, 08 de Nov · 18:30").
 */
export function formatSessionFriendlyDate(
  timestampMs: number,
  nowMs: number = Date.now()
): string {
  const d = new Date(timestampMs);
  const todayKey = toLocalDateKey(nowMs);
  const yesterdayDate = new Date(nowMs);
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterdayKey = toLocalDateKey(yesterdayDate.getTime());
  const targetKey = toLocalDateKey(timestampMs);

  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const timePart = `${hh}:${mm}`;

  if (targetKey === todayKey) {
    return `Hoje, ${timePart}`;
  }
  if (targetKey === yesterdayKey) {
    return `Ontem, ${timePart}`;
  }

  const weekdays = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const months = [
    'Jan',
    'Fev',
    'Mar',
    'Abr',
    'Mai',
    'Jun',
    'Jul',
    'Ago',
    'Set',
    'Out',
    'Nov',
    'Dez'
  ];
  const wDay = weekdays[d.getDay()] || '';
  const dayNum = String(d.getDate()).padStart(2, '0');
  const monthName = months[d.getMonth()] || '';

  return `${wDay}, ${dayNum} de ${monthName} · ${timePart}`;
}

/**
 * Remove sessões duplicadas (mesmo sessionId ou id) e ordena cronologicamente.
 * Nunca inclui sessões inválidas ou sem timestamp numérico válido.
 */
export function deduplicateAndSortWorkouts(
  workoutHistory: CompletedWorkout[],
  direction: 'desc' | 'asc' = 'desc'
): CompletedWorkout[] {
  if (!Array.isArray(workoutHistory) || workoutHistory.length === 0) {
    return [];
  }

  const seenKeys = new Set<string>();
  const unique: CompletedWorkout[] = [];

  for (const wk of workoutHistory) {
    if (!wk || typeof wk !== 'object') continue;
    const ts = Number(wk.timestamp);
    if (!Number.isFinite(ts) || ts <= 0) continue;

    const uniqueKey = String(wk.sessionId || wk.id || `${wk.dayId}_${ts}`);
    if (seenKeys.has(uniqueKey)) continue;
    seenKeys.add(uniqueKey);
    unique.push(wk);
  }

  return unique.sort((a, b) =>
    direction === 'desc' ? b.timestamp - a.timestamp : a.timestamp - b.timestamp
  );
}

/**
 * Filtra os treinos concluídos pelo período selecionado (7 dias, 30 dias, 90 dias ou Tudo),
 * respeitando a meia-noite local do dia inicial e prevenindo duplicações.
 */
export function filterWorkoutsByPeriod(
  workoutHistory: CompletedWorkout[],
  period: EvolutionPeriod,
  nowMs: number = Date.now()
): CompletedWorkout[] {
  const deduplicatedDesc = deduplicateAndSortWorkouts(workoutHistory, 'desc');
  if (period === 'all') {
    return deduplicatedDesc;
  }

  const daysMap: Record<Exclude<EvolutionPeriod, 'all'>, number> = {
    '7d': 7,
    '30d': 30,
    '90d': 90
  };
  const days = daysMap[period];
  const now = new Date(nowMs);
  const startBoundaryMs = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() - (days - 1),
    0,
    0,
    0,
    0
  ).getTime();
  const endBoundaryMs = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    23,
    59,
    59,
    999
  ).getTime();

  return deduplicatedDesc.filter(
    (wk) => wk.timestamp >= startBoundaryMs && wk.timestamp <= endBoundaryMs
  );
}

/**
 * Formata duração em segundos para horas e minutos legíveis.
 */
export function formatDurationHoursMinutes(totalSec: number): {
  hours: number;
  minutes: number;
  label: string;
} {
  const safeSec = Math.max(0, Math.round(Number(totalSec) || 0));
  if (safeSec === 0) {
    return { hours: 0, minutes: 0, label: '0 min' };
  }
  const totalMinutes = Math.max(1, Math.round(safeSec / 60));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours === 0) {
    return { hours: 0, minutes: totalMinutes, label: `${totalMinutes} min` };
  }
  if (minutes === 0) {
    return { hours, minutes: 0, label: `${hours}h` };
  }
  return { hours, minutes, label: `${hours}h ${minutes}m` };
}

/**
 * Formata volume total em kg ou toneladas com conversão consistente.
 */
export function formatVolumeMetric(volumeKg: number): {
  value: string;
  unit: 'kg' | 'ton';
  exactKgLabel: string;
} {
  const cleanKg = Math.max(0, Math.round(Number(volumeKg) || 0));
  const exactKgLabel = `${cleanKg.toLocaleString('pt-BR')} kg`;

  if (cleanKg >= 10000) {
    const tons = cleanKg / 1000;
    const formattedTons = tons.toLocaleString('pt-BR', {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1
    });
    return {
      value: formattedTons,
      unit: 'ton',
      exactKgLabel
    };
  }

  return {
    value: cleanKg.toLocaleString('pt-BR'),
    unit: 'kg',
    exactKgLabel
  };
}

/**
 * Calcula todos os indicadores principais da Visão Geral da Evolução
 * a partir do histórico real de sessões concluídas no período selecionado.
 * Diferencia quantidade de sessões e quantidade de dias distintos com treinamento.
 */
export function calculateEvolutionOverviewStats(
  filteredWorkouts: CompletedWorkout[],
  targetWeeklyDaysInput: number = 5
): EvolutionOverviewStats {
  const uniqueWorkouts = deduplicateAndSortWorkouts(filteredWorkouts, 'desc');
  const sessionsCount = uniqueWorkouts.length;

  const distinctDayKeys = new Set<string>();
  let totalDurationSec = 0;
  let totalVolumeKg = 0;
  let totalCompletedSets = 0;

  for (const wk of uniqueWorkouts) {
    distinctDayKeys.add(toLocalDateKey(wk.timestamp));
    totalDurationSec += Math.max(0, Number(wk.durationSec) || 0);
    totalVolumeKg += Math.max(0, Number(wk.tonnage) || 0);
    totalCompletedSets += Math.max(0, Number(wk.completedSets) || 0);
  }

  const distinctTrainedDays = distinctDayKeys.size;
  const avgDurationMin =
    sessionsCount > 0 ? Math.max(1, Math.round(totalDurationSec / 60 / sessionsCount)) : 0;

  // Calcular frequência semanal real baseada nos dias distintos treinados dentro das semanas ativas
  let weeklyFrequency = 0;
  if (distinctTrainedDays > 0) {
    const distinctWeekKeys = new Set<string>();
    for (const wk of uniqueWorkouts) {
      const bounds = getCurrentWeekBounds(wk.timestamp);
      distinctWeekKeys.add(toLocalDateKey(bounds.mondayStartMs));
    }
    const activeWeeksCount = Math.max(1, distinctWeekKeys.size);
    weeklyFrequency = Math.round((distinctTrainedDays / activeWeeksCount) * 10) / 10;
  }

  const targetWeeklyDays = Math.max(1, Number(targetWeeklyDaysInput) || 5);

  return {
    sessionsCount,
    distinctTrainedDays,
    totalDurationSec,
    avgDurationMin,
    totalVolumeKg: Math.round(totalVolumeKg * 10) / 10,
    totalCompletedSets,
    weeklyFrequency,
    targetWeeklyDays,
    durationFormatted: formatDurationHoursMinutes(totalDurationSec),
    volumeFormatted: formatVolumeMetric(totalVolumeKg)
  };
}

/**
 * Agrupa o volume real registrado em intervalos apropriados à escala selecionada
 * (Diário, Semanal ou Mensal), sem inventar pontos intermediários e sem tratar
 * ausência de registros como volume zero executado.
 */
export function groupVolumeByInterval(
  filteredWorkouts: CompletedWorkout[],
  period: EvolutionPeriod
): VolumeChartSeries {
  const chronological = deduplicateAndSortWorkouts(filteredWorkouts, 'asc');

  if (chronological.length === 0) {
    return {
      scaleType: period === '7d' ? 'day' : 'week',
      scaleLabel: period === '7d' ? 'Diário (kg)' : 'Semanal (kg)',
      averageLabel: period === '7d' ? 'Média por dia treinado:' : 'Média semanal calculada:',
      averageVolumeKg: 0,
      points: []
    };
  }

  // Determinar escala apropriada
  let scaleType: 'day' | 'week' | 'month' = 'week';
  if (period === '7d') {
    scaleType = 'day';
  } else if (period === '30d' || period === '90d') {
    // Verificar quantas semanas distintas possuem registros; se todas as sessões estão na mesma semana
    // e há mais de 1 dia distinto, exibir por dia para mostrar a progressão real sem colapsar em 1 ponto.
    const weekSet = new Set<string>();
    const daySet = new Set<string>();
    chronological.forEach((wk) => {
      weekSet.add(toLocalDateKey(getCurrentWeekBounds(wk.timestamp).mondayStartMs));
      daySet.add(toLocalDateKey(wk.timestamp));
    });
    scaleType = weekSet.size === 1 && daySet.size > 1 ? 'day' : 'week';
  } else {
    // 'all'
    const firstTs = chronological[0].timestamp;
    const lastTs = chronological[chronological.length - 1].timestamp;
    const spanDays = (lastTs - firstTs) / (1000 * 60 * 60 * 24);
    const monthSet = new Set<string>();
    const weekSet = new Set<string>();
    const daySet = new Set<string>();
    chronological.forEach((wk) => {
      const d = new Date(wk.timestamp);
      monthSet.add(`${d.getFullYear()}-${d.getMonth()}`);
      weekSet.add(toLocalDateKey(getCurrentWeekBounds(wk.timestamp).mondayStartMs));
      daySet.add(toLocalDateKey(wk.timestamp));
    });

    if (spanDays > 90 && monthSet.size >= 2) {
      scaleType = 'month';
    } else if (weekSet.size >= 2) {
      scaleType = 'week';
    } else {
      scaleType = 'day';
    }
  }

  const buckets = new Map<
    string,
    {
      key: string;
      label: string;
      tooltipTitle: string;
      volumeKg: number;
      sessionsCount: number;
      dayKeys: Set<string>;
      timestampMs: number;
    }
  >();

  const monthsShort = [
    'Jan',
    'Fev',
    'Mar',
    'Abr',
    'Mai',
    'Jun',
    'Jul',
    'Ago',
    'Set',
    'Out',
    'Nov',
    'Dez'
  ];

  chronological.forEach((wk) => {
    const vol = Math.max(0, Number(wk.tonnage) || 0);
    const dayKey = toLocalDateKey(wk.timestamp);
    const d = new Date(wk.timestamp);

    let bucketKey = '';
    let label = '';
    let tooltipTitle = '';
    let bucketTs = wk.timestamp;

    if (scaleType === 'day') {
      bucketKey = dayKey;
      label = formatShortLocalDate(wk.timestamp);
      tooltipTitle = `${label}`;
      bucketTs = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    } else if (scaleType === 'week') {
      const bounds = getCurrentWeekBounds(wk.timestamp);
      bucketKey = toLocalDateKey(bounds.mondayStartMs);
      const mon = new Date(bounds.mondayStartMs);
      const dayNum = String(mon.getDate()).padStart(2, '0');
      const monName = monthsShort[mon.getMonth()] || '';
      label = `${dayNum} ${monName}`;
      tooltipTitle = `Sem. ${bounds.weekLabel}`;
      bucketTs = bounds.mondayStartMs;
    } else {
      bucketKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      label = `${monthsShort[d.getMonth()]} ${String(d.getFullYear()).slice(-2)}`;
      tooltipTitle = `${monthsShort[d.getMonth()]} de ${d.getFullYear()}`;
      bucketTs = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
    }

    const existing = buckets.get(bucketKey);
    if (existing) {
      existing.volumeKg = Math.round((existing.volumeKg + vol) * 10) / 10;
      existing.sessionsCount += 1;
      existing.dayKeys.add(dayKey);
    } else {
      buckets.set(bucketKey, {
        key: bucketKey,
        label,
        tooltipTitle,
        volumeKg: Math.round(vol * 10) / 10,
        sessionsCount: 1,
        dayKeys: new Set([dayKey]),
        timestampMs: bucketTs
      });
    }
  });

  const points: VolumeChartPoint[] = Array.from(buckets.values()).map((b) => ({
    key: b.key,
    label: b.label,
    tooltipTitle: b.tooltipTitle,
    volumeKg: b.volumeKg,
    sessionsCount: b.sessionsCount,
    distinctDaysCount: b.dayKeys.size,
    timestampMs: b.timestampMs
  }));

  const totalVol = points.reduce((acc, p) => acc + p.volumeKg, 0);
  const averageVolumeKg = points.length > 0 ? Math.round(totalVol / points.length) : 0;

  const scaleLabel =
    scaleType === 'day'
      ? 'Diário (kg)'
      : scaleType === 'week'
      ? 'Semanal (kg)'
      : 'Mensal (kg)';

  const averageLabel =
    scaleType === 'day'
      ? 'Média por dia treinado:'
      : scaleType === 'week'
      ? 'Média semanal calculada:'
      : 'Média mensal calculada:';

  return {
    scaleType,
    scaleLabel,
    averageLabel,
    averageVolumeKg,
    points
  };
}

/**
 * Constrói o índice de metadados de exercícios conhecidos nos templates e rotinas.
 */
function buildKnownExerciseLookup(
  dynamicWorkouts: WorkoutDay[] = []
): Record<string, { name: string; targetGroup: string }> {
  const lookup: Record<string, { name: string; targetGroup: string }> = {};
  const lists = [
    ...(INITIAL_AI_WORKOUTS || []),
    ...(HYBRID_WORKOUT_TEMPLATE || []),
    ...(dynamicWorkouts || [])
  ];

  lists.forEach((day) => {
    (day?.exercises || []).forEach((ex) => {
      if (ex && ex.id) {
        lookup[ex.id] = {
          name: ex.name,
          targetGroup: ex.targetGroup || ex.partLabel || 'peito'
        };
      }
    });
  });

  return lookup;
}

/**
 * Obtém todos os exercícios presentes no histórico de sessões concluídas
 * (e reconcilia com lastExerciseWeights quando aplicável),
 * exibindo apenas cargas e estatísticas realmente registradas.
 */
export function getRegisteredExercisesList(
  workoutHistory: CompletedWorkout[],
  lastExerciseWeights: Record<string, number> = {},
  dynamicWorkouts: WorkoutDay[] = []
): RegisteredExerciseItem[] {
  const chronological = deduplicateAndSortWorkouts(workoutHistory, 'asc');
  const lookup = buildKnownExerciseLookup(dynamicWorkouts);

  const map = new Map<
    string,
    {
      exerciseId: string;
      name: string;
      targetGroup: string;
      firstWeight: number;
      maxWeight: number;
      maxWeightReps?: number;
      maxWeightDate?: string;
      lastWeight: number;
      lastWeightReps?: number;
      lastWeightVolumeKg?: number;
      lastSessionDate?: string;
      lastSessionTimestamp: number;
      sessionsCount: number;
      hasHistoricalSessions: boolean;
    }
  >();

  chronological.forEach((wk) => {
    (wk.exercisesSummary || []).forEach((exSum) => {
      if (!exSum || !exSum.exerciseId) return;
      const weight = Math.max(0, Number(exSum.maxWeight) || 0);
      const setsDone = Math.max(0, Number(exSum.setsCompleted) || 0);
      if (weight <= 0 && setsDone <= 0) return;

      const prev = map.get(exSum.exerciseId);
      const known = lookup[exSum.exerciseId];
      const name = exSum.name || known?.name || exSum.exerciseId;
      const targetGroup = exSum.targetGroup || known?.targetGroup || 'peito';
      const dateShort = formatShortLocalDate(wk.timestamp);

      if (!prev) {
        map.set(exSum.exerciseId, {
          exerciseId: exSum.exerciseId,
          name,
          targetGroup,
          firstWeight: weight,
          maxWeight: weight,
          maxWeightReps: exSum.bestSetReps,
          maxWeightDate: dateShort,
          lastWeight: weight,
          lastWeightReps: exSum.bestSetReps,
          lastWeightVolumeKg: exSum.volumeKg,
          lastSessionDate: dateShort,
          lastSessionTimestamp: wk.timestamp,
          sessionsCount: 1,
          hasHistoricalSessions: true
        });
      } else {
        const isNewMax = weight > prev.maxWeight;
        const isSameMaxMoreReps =
          weight === prev.maxWeight &&
          (exSum.bestSetReps || 0) > (prev.maxWeightReps || 0);

        map.set(exSum.exerciseId, {
          ...prev,
          name: exSum.name || prev.name,
          firstWeight: prev.firstWeight > 0 ? prev.firstWeight : weight,
          maxWeight: isNewMax ? weight : prev.maxWeight,
          maxWeightReps:
            isNewMax || isSameMaxMoreReps ? exSum.bestSetReps : prev.maxWeightReps,
          maxWeightDate: isNewMax ? dateShort : prev.maxWeightDate,
          lastWeight: weight > 0 ? weight : prev.lastWeight,
          lastWeightReps: exSum.bestSetReps ?? prev.lastWeightReps,
          lastWeightVolumeKg: exSum.volumeKg ?? prev.lastWeightVolumeKg,
          lastSessionDate: dateShort,
          lastSessionTimestamp: wk.timestamp,
          sessionsCount: prev.sessionsCount + 1,
          hasHistoricalSessions: true
        });
      }
    });
  });

  // Incluir pesos salvos em lastExerciseWeights caso ainda não estejam no histórico de sessões
  Object.entries(lastExerciseWeights || {}).forEach(([exId, rawWeight]) => {
    const weight = Math.max(0, Number(rawWeight) || 0);
    if (weight <= 0) return;

    const existing = map.get(exId);
    const known = lookup[exId];
    if (!existing) {
      map.set(exId, {
        exerciseId: exId,
        name: known?.name || exId,
        targetGroup: known?.targetGroup || 'peito',
        firstWeight: weight,
        maxWeight: weight,
        lastWeight: weight,
        lastSessionTimestamp: 0,
        sessionsCount: 0,
        hasHistoricalSessions: false
      });
    } else if (weight > existing.maxWeight) {
      map.set(exId, {
        ...existing,
        maxWeight: weight
      });
    }
  });

  return Array.from(map.values())
    .map((item) => {
      const weightDeltaKg =
        item.sessionsCount >= 2 && item.firstWeight > 0 && item.lastWeight > 0
          ? Math.round((item.lastWeight - item.firstWeight) * 10) / 10
          : null;

      return {
        exerciseId: item.exerciseId,
        name: item.name,
        targetGroup: item.targetGroup,
        groupLabel: getMuscleGroupDisplayLabel(item.targetGroup),
        maxWeight: item.maxWeight,
        maxWeightReps: item.maxWeightReps,
        maxWeightDate: item.maxWeightDate,
        lastWeight: item.lastWeight,
        lastWeightReps: item.lastWeightReps,
        lastWeightVolumeKg: item.lastWeightVolumeKg,
        lastSessionDate: item.lastSessionDate,
        lastSessionTimestamp: item.lastSessionTimestamp,
        sessionsCount: item.sessionsCount,
        weightDeltaKg,
        hasHistoricalSessions: item.hasHistoricalSessions
      };
    })
    .sort((a, b) => {
      if (b.sessionsCount !== a.sessionsCount) {
        return b.sessionsCount - a.sessionsCount;
      }
      if (b.lastSessionTimestamp !== a.lastSessionTimestamp) {
        return b.lastSessionTimestamp - a.lastSessionTimestamp;
      }
      return b.maxWeight - a.maxWeight;
    });
}

/**
 * Obtém o detalhamento completo de evolução de um exercício específico.
 * Respeita rigorosamente a integridade dos dados:
 * - Nunca reconstrói séries individuais fictícias quando o histórico antigo contém apenas dados agregados.
 * - Preserva séries individuais reais quando setsDetail está presente.
 */
export function getExerciseEvolutionDetail(params: {
  exerciseId: string;
  workoutHistory: CompletedWorkout[];
  period: EvolutionPeriod;
  lastExerciseWeights?: Record<string, number>;
  dynamicWorkouts?: WorkoutDay[];
  nowMs?: number;
}): ExerciseEvolutionDetail {
  const {
    exerciseId,
    workoutHistory,
    period,
    lastExerciseWeights = {},
    dynamicWorkouts = [],
    nowMs = Date.now()
  } = params;

  const lookup = buildKnownExerciseLookup(dynamicWorkouts);
  const known = lookup[exerciseId];

  const allChronological = deduplicateAndSortWorkouts(workoutHistory, 'asc');
  let resolvedName = known?.name || exerciseId;
  let resolvedGroup: string = known?.targetGroup || 'peito';

  let allTimeMaxWeight = 0;
  let allTimeMaxReps: number | undefined = undefined;
  let allTimeMaxDateLabel: string | undefined = undefined;
  const allSessionsForExercise: ExerciseSessionRecord[] = [];

  allChronological.forEach((wk) => {
    const exSum = (wk.exercisesSummary || []).find(
      (s) =>
        s.exerciseId === exerciseId ||
        (known?.name && s.name?.toLowerCase() === known.name.toLowerCase())
    );
    if (!exSum) return;

    const maxWeight = Math.max(0, Number(exSum.maxWeight) || 0);
    const setsCompleted = Math.max(0, Number(exSum.setsCompleted) || 0);
    if (maxWeight <= 0 && setsCompleted <= 0) return;

    if (exSum.name) resolvedName = exSum.name;
    if (exSum.targetGroup) resolvedGroup = exSum.targetGroup;

    const dateShortLabel = formatShortLocalDate(wk.timestamp);
    const dateFullLabel = formatSessionFriendlyDate(wk.timestamp, nowMs);

    const isStrictNewMax =
      allSessionsForExercise.length > 0 && maxWeight > allTimeMaxWeight && maxWeight > 0;

    if (maxWeight > allTimeMaxWeight) {
      allTimeMaxWeight = maxWeight;
      allTimeMaxReps = exSum.bestSetReps;
      allTimeMaxDateLabel = dateShortLabel;
    } else if (
      maxWeight === allTimeMaxWeight &&
      maxWeight > 0 &&
      (exSum.bestSetReps || 0) > (allTimeMaxReps || 0)
    ) {
      allTimeMaxReps = exSum.bestSetReps;
    }

    const validSetsDetail = Array.isArray(exSum.setsDetail)
      ? exSum.setsDetail.filter(
          (s) =>
            s &&
            typeof s.weight === 'number' &&
            typeof s.reps === 'number' &&
            (s.weight > 0 || s.reps > 0)
        )
      : [];

    allSessionsForExercise.push({
      workoutId: wk.id,
      workoutTitle: cleanDisplayText(wk.title),
      dayName: wk.dayName,
      timestamp: wk.timestamp,
      dateShortLabel,
      dateFullLabel,
      maxWeight,
      bestSetReps:
        typeof exSum.bestSetReps === 'number' && exSum.bestSetReps > 0
          ? exSum.bestSetReps
          : undefined,
      volumeKg:
        typeof exSum.volumeKg === 'number' && exSum.volumeKg > 0
          ? Math.round(exSum.volumeKg * 10) / 10
          : undefined,
      setsCompleted,
      totalSets: Math.max(setsCompleted, Number(exSum.totalSets) || setsCompleted),
      isPersonalRecord: Boolean(exSum.isPersonalRecord || isStrictNewMax),
      hasIndividualSets: validSetsDetail.length > 0,
      setsDetail: validSetsDetail
    });
  });

  const savedFallbackWeight =
    typeof lastExerciseWeights[exerciseId] === 'number' &&
    lastExerciseWeights[exerciseId] > 0
      ? lastExerciseWeights[exerciseId]
      : null;

  if (savedFallbackWeight && savedFallbackWeight > allTimeMaxWeight) {
    allTimeMaxWeight = savedFallbackWeight;
  }

  // Filtrar sessões pelo período selecionado
  const filteredWorkoutIds = new Set(
    filterWorkoutsByPeriod(workoutHistory, period, nowMs).map(
      (wk) => wk.sessionId || wk.id
    )
  );

  const periodChronological = allSessionsForExercise.filter((rec) => {
    if (period === 'all') return true;
    // Verificar pelo timestamp usando o mesmo critério de filterWorkoutsByPeriod
    const matchedWk = workoutHistory.find(
      (w) => w.id === rec.workoutId && filteredWorkoutIds.has(w.sessionId || w.id)
    );
    return Boolean(matchedWk);
  });

  const periodSessionsDesc = [...periodChronological].sort(
    (a, b) => b.timestamp - a.timestamp
  );

  const lastRecord =
    allSessionsForExercise.length > 0
      ? allSessionsForExercise[allSessionsForExercise.length - 1]
      : null;

  return {
    exerciseId,
    name: resolvedName,
    targetGroup: resolvedGroup as BodyPartKey,
    groupLabel: getMuscleGroupDisplayLabel(resolvedGroup),
    allTimeMaxWeight,
    allTimeMaxReps,
    allTimeMaxDateLabel,
    allTimeSessionsCount: allSessionsForExercise.length,
    lastRecord,
    fallbackLastWeight: savedFallbackWeight,
    periodSessions: periodSessionsDesc,
    progressionPoints: periodChronological.filter((p) => p.maxWeight > 0)
  };
}

/**
 * Filtra o histórico completo por período, busca textual e filtro de categoria/treino.
 */
export function filterWorkoutHistoryFeed(params: {
  workoutHistory: CompletedWorkout[];
  period: EvolutionPeriod;
  searchQuery: string;
  categoryFilter: string;
  nowMs?: number;
}): CompletedWorkout[] {
  const {
    workoutHistory,
    period,
    searchQuery,
    categoryFilter,
    nowMs = Date.now()
  } = params;

  const periodFiltered = filterWorkoutsByPeriod(workoutHistory, period, nowMs);
  const query = (searchQuery || '').trim().toLowerCase();
  const cat = (categoryFilter || 'all').trim().toLowerCase();

  return periodFiltered.filter((wk) => {
    // 1. Filtro por categoria / treino
    if (cat !== 'all') {
      const titleLower = `${wk.title || ''} ${wk.dayName || ''}`.toLowerCase();
      const hasMatchingGroup = (wk.exercisesSummary || []).some(
        (ex) =>
          getMuscleGroupDisplayLabel(ex.targetGroup).toLowerCase() === cat ||
          (ex.targetGroup || '').toLowerCase() === cat
      );
      const matchesDayId = (wk.dayId || '').toLowerCase() === cat;
      const matchesTitle = titleLower.includes(cat);

      if (!hasMatchingGroup && !matchesDayId && !matchesTitle) {
        return false;
      }
    }

    // 2. Busca textual
    if (!query) return true;

    const titleMatch = (wk.title || '').toLowerCase().includes(query);
    const dayMatch = (wk.dayName || '').toLowerCase().includes(query);
    const notesMatch = (wk.sessionNotes || '').toLowerCase().includes(query);
    const exerciseMatch = (wk.exercisesSummary || []).some((ex) =>
      (ex.name || '').toLowerCase().includes(query)
    );

    return titleMatch || dayMatch || notesMatch || exerciseMatch;
  });
}

/**
 * Agrupa sessões de treino ordenadas (da mais recente para a mais antiga) por Mês e Ano local.
 */
export function groupWorkoutsByMonth(workouts: CompletedWorkout[]): WorkoutMonthGroup[] {
  const sortedDesc = deduplicateAndSortWorkouts(workouts, 'desc');
  const groups = new Map<string, WorkoutMonthGroup>();

  const monthNames = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro'
  ];

  sortedDesc.forEach((wk) => {
    const d = new Date(wk.timestamp);
    const year = d.getFullYear();
    const monthIdx = d.getMonth();
    const monthKey = `${year}-${String(monthIdx + 1).padStart(2, '0')}`;
    const monthLabel = `${monthNames[monthIdx] || 'Mês'} ${year}`;

    const existing = groups.get(monthKey);
    if (existing) {
      existing.workouts.push(wk);
    } else {
      groups.set(monthKey, {
        monthKey,
        monthLabel,
        workouts: [wk]
      });
    }
  });

  return Array.from(groups.values());
}

/**
 * Extrai as categorias de filtro disponíveis reais a partir do histórico do usuário.
 */
export function getAvailableHistoryCategories(
  workoutHistory: CompletedWorkout[]
): Array<{ id: string; label: string }> {
  const unique = deduplicateAndSortWorkouts(workoutHistory, 'desc');
  const categories = new Set<string>();

  unique.forEach((wk) => {
    (wk.exercisesSummary || []).forEach((ex) => {
      if (ex && ex.targetGroup) {
        categories.add(getMuscleGroupDisplayLabel(ex.targetGroup));
      }
    });
  });

  const result: Array<{ id: string; label: string }> = [{ id: 'all', label: 'Todos' }];
  Array.from(categories).forEach((label) => {
    result.push({ id: label.toLowerCase(), label });
  });

  return result;
}

export { splitCheckinsByOrigin };
