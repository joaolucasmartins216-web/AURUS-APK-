import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEvolutionOverviewStats,
  deduplicateAndSortWorkouts,
  filterWorkoutHistoryFeed,
  filterWorkoutsByPeriod,
  getExerciseEvolutionDetail,
  getRegisteredExercisesList,
  groupVolumeByInterval,
  groupWorkoutsByMonth,
  splitCheckinsByOrigin
} from './evolutionLogic';
import { CheckinRecord, CompletedWorkout } from '../types';

const BASE_NOW_MS = new Date(2026, 10, 8, 19, 30, 0, 0).getTime(); // 08 Nov 2026 19:30 local
const ONE_DAY_MS = 24 * 60 * 60 * 1000;

function makeWorkout(overrides: Partial<CompletedWorkout> & { id: string; timestamp: number }): CompletedWorkout {
  return {
    id: overrides.id,
    sessionId: overrides.sessionId ?? overrides.id,
    dayId: overrides.dayId ?? 'seg',
    dayName: overrides.dayName ?? 'Segunda-feira',
    title: overrides.title ?? 'Treino A · Peito e Tríceps',
    tonnage: overrides.tonnage ?? 5000,
    durationSec: overrides.durationSec ?? 3300, // 55 min
    completedSets: overrides.completedSets ?? 15,
    totalSets: overrides.totalSets ?? 17,
    cardioCompleted: overrides.cardioCompleted ?? false,
    dateFormatted: overrides.dateFormatted ?? '08 de nov. de 2026',
    timestamp: overrides.timestamp,
    sessionRpe: overrides.sessionRpe,
    sessionNotes: overrides.sessionNotes,
    exercisesSummary: overrides.exercisesSummary ?? [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 4,
        totalSets: 4,
        maxWeight: 100,
        bestSetReps: 8,
        volumeKg: 3200
      }
    ]
  };
}

test('1. Histórico vazio: retorna indicadores zerados e séries de gráfico vazias sem dados fictícios', () => {
  const filtered = filterWorkoutsByPeriod([], '30d', BASE_NOW_MS);
  assert.equal(filtered.length, 0);

  const stats = calculateEvolutionOverviewStats(filtered, 5);
  assert.equal(stats.sessionsCount, 0);
  assert.equal(stats.distinctTrainedDays, 0);
  assert.equal(stats.totalDurationSec, 0);
  assert.equal(stats.totalVolumeKg, 0);
  assert.equal(stats.weeklyFrequency, 0);
  assert.equal(stats.durationFormatted.label, '0 min');
  assert.equal(stats.volumeFormatted.value, '0');
  assert.equal(stats.volumeFormatted.unit, 'kg');

  const chart = groupVolumeByInterval(filtered, '30d');
  assert.equal(chart.points.length, 0);
  assert.equal(chart.averageVolumeKg, 0);

  const exercises = getRegisteredExercisesList([], {}, []);
  assert.equal(exercises.length, 0);
});

test('2. Histórico com apenas um treino: calcula indicadores reais sem fabricar delta de progressão', () => {
  const singleWorkout = [
    makeWorkout({
      id: 'wk_single',
      timestamp: BASE_NOW_MS - ONE_DAY_MS,
      tonnage: 6420,
      durationSec: 3300, // 55m
      completedSets: 17
    })
  ];

  const stats = calculateEvolutionOverviewStats(singleWorkout, 5);
  assert.equal(stats.sessionsCount, 1);
  assert.equal(stats.distinctTrainedDays, 1);
  assert.equal(stats.totalDurationSec, 3300);
  assert.equal(stats.avgDurationMin, 55);
  assert.equal(stats.totalVolumeKg, 6420);
  assert.equal(stats.volumeFormatted.value, '6.420');
  assert.equal(stats.volumeFormatted.unit, 'kg');

  const exercises = getRegisteredExercisesList(singleWorkout, {}, []);
  assert.equal(exercises.length, 1);
  assert.equal(exercises[0].maxWeight, 100);
  assert.equal(exercises[0].lastWeight, 100);
  assert.equal(exercises[0].sessionsCount, 1);
  // Com apenas 1 sessão, weightDeltaKg deve ser null (não inventa ganho)
  assert.equal(exercises[0].weightDeltaKg, null);
});

test('3, 4 & 5. Histórico com múltiplas sessões e filtros de 7, 30, 90 dias e Tudo', () => {
  const wToday = makeWorkout({ id: 'w1', timestamp: BASE_NOW_MS - 2 * 3600 * 1000, tonnage: 4000 });
  const w5DaysAgo = makeWorkout({ id: 'w2', timestamp: BASE_NOW_MS - 5 * ONE_DAY_MS, tonnage: 5000 });
  const w20DaysAgo = makeWorkout({ id: 'w3', timestamp: BASE_NOW_MS - 20 * ONE_DAY_MS, tonnage: 6000 });
  const w60DaysAgo = makeWorkout({ id: 'w4', timestamp: BASE_NOW_MS - 60 * ONE_DAY_MS, tonnage: 7000 });
  const w120DaysAgo = makeWorkout({ id: 'w5', timestamp: BASE_NOW_MS - 120 * ONE_DAY_MS, tonnage: 8000 });

  const history = [wToday, w5DaysAgo, w20DaysAgo, w60DaysAgo, w120DaysAgo];

  const f7d = filterWorkoutsByPeriod(history, '7d', BASE_NOW_MS);
  assert.equal(f7d.length, 2); // wToday, w5DaysAgo

  const f30d = filterWorkoutsByPeriod(history, '30d', BASE_NOW_MS);
  assert.equal(f30d.length, 3); // wToday, w5DaysAgo, w20DaysAgo

  const f90d = filterWorkoutsByPeriod(history, '90d', BASE_NOW_MS);
  assert.equal(f90d.length, 4); // wToday, w5DaysAgo, w20DaysAgo, w60DaysAgo

  const fAll = filterWorkoutsByPeriod(history, 'all', BASE_NOW_MS);
  assert.equal(fAll.length, 5); // Todos os 5 treinos
});

test('6, 7 & 8. Cálculo de volume (kg e ton), duração (h/min) e frequência por dias distintos', () => {
  // Duas sessões no mesmo dia (08 Nov) e uma sessão ontem (07 Nov) -> 3 sessões, mas 2 dias distintos!
  const sameDayMorning = new Date(2026, 10, 8, 9, 0, 0).getTime();
  const sameDayEvening = new Date(2026, 10, 8, 18, 0, 0).getTime();
  const yesterdayEvening = new Date(2026, 10, 7, 18, 0, 0).getTime();

  const workouts = [
    makeWorkout({ id: 's1', timestamp: sameDayMorning, tonnage: 4500, durationSec: 2700 }), // 45m
    makeWorkout({ id: 's2', timestamp: sameDayEvening, tonnage: 5500, durationSec: 3600 }), // 60m
    makeWorkout({ id: 's3', timestamp: yesterdayEvening, tonnage: 6200, durationSec: 3900 }) // 65m
  ];

  const stats = calculateEvolutionOverviewStats(workouts, 5);
  assert.equal(stats.sessionsCount, 3);
  assert.equal(stats.distinctTrainedDays, 2); // Diferencia 3 sessões de 2 dias distintos
  assert.equal(stats.totalVolumeKg, 16200);
  assert.equal(stats.volumeFormatted.unit, 'ton');
  assert.equal(stats.volumeFormatted.value, '16,2');
  assert.equal(stats.volumeFormatted.exactKgLabel, '16.200 kg');
  assert.equal(stats.totalDurationSec, 10200); // 170 min = 2h 50m
  assert.equal(stats.durationFormatted.hours, 2);
  assert.equal(stats.durationFormatted.minutes, 50);
  assert.equal(stats.durationFormatted.label, '2h 50m');
  assert.equal(stats.weeklyFrequency, 2); // 2 dias distintos na semana ativa
});

test('9. Ordenação cronológica e agrupamento mensal do histórico', () => {
  const octWorkout = makeWorkout({
    id: 'oct_1',
    timestamp: new Date(2026, 9, 25, 18, 0).getTime(),
    title: 'Treino Outubro'
  });
  const novWorkout1 = makeWorkout({
    id: 'nov_1',
    timestamp: new Date(2026, 10, 2, 18, 0).getTime(),
    title: 'Treino Início Novembro'
  });
  const novWorkout2 = makeWorkout({
    id: 'nov_2',
    timestamp: new Date(2026, 10, 8, 18, 0).getTime(),
    title: 'Treino Mais Recente'
  });

  // Passando fora de ordem
  const sortedDesc = deduplicateAndSortWorkouts([octWorkout, novWorkout2, novWorkout1], 'desc');
  assert.deepEqual(
    sortedDesc.map((w) => w.id),
    ['nov_2', 'nov_1', 'oct_1']
  );

  const monthGroups = groupWorkoutsByMonth([octWorkout, novWorkout2, novWorkout1]);
  assert.equal(monthGroups.length, 2);
  assert.equal(monthGroups[0].monthLabel, 'Novembro 2026');
  assert.equal(monthGroups[0].workouts.length, 2);
  assert.equal(monthGroups[1].monthLabel, 'Outubro 2026');
  assert.equal(monthGroups[1].workouts.length, 1);
});

test('10 & 11. Progressão de carga por exercício e Maior carga registrada real', () => {
  const s1 = makeWorkout({
    id: 's1',
    timestamp: BASE_NOW_MS - 20 * ONE_DAY_MS,
    exercisesSummary: [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 4,
        totalSets: 4,
        maxWeight: 95,
        bestSetReps: 8,
        volumeKg: 2800
      }
    ]
  });
  const s2 = makeWorkout({
    id: 's2',
    timestamp: BASE_NOW_MS - 10 * ONE_DAY_MS,
    exercisesSummary: [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 4,
        totalSets: 4,
        maxWeight: 110, // Maior carga histórica (PR)
        bestSetReps: 6,
        volumeKg: 3120,
        isPersonalRecord: true
      }
    ]
  });
  const s3 = makeWorkout({
    id: 's3',
    timestamp: BASE_NOW_MS - 1 * ONE_DAY_MS,
    exercisesSummary: [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 4,
        totalSets: 4,
        maxWeight: 105, // Última carga registrada (menor que o pico de 110kg)
        bestSetReps: 8,
        volumeKg: 3050
      }
    ]
  });

  const detail = getExerciseEvolutionDetail({
    exerciseId: 'supino_reto',
    workoutHistory: [s3, s1, s2],
    period: '90d',
    nowMs: BASE_NOW_MS
  });

  assert.equal(detail.allTimeMaxWeight, 110); // Maior carga histórica
  assert.equal(detail.allTimeMaxReps, 6);
  assert.equal(detail.lastRecord?.maxWeight, 105); // Última carga registrada
  assert.equal(detail.lastRecord?.bestSetReps, 8);
  assert.equal(detail.progressionPoints.length, 3);
  assert.deepEqual(
    detail.progressionPoints.map((p) => p.maxWeight),
    [95, 110, 105] // Ordem cronológica no gráfico
  );
  assert.equal(detail.periodSessions[0].workoutId, 's3'); // Ordem mais recente primeiro na lista
});

test('12. Distinção de registros reais e simulados (check-ins demonstrativos nunca entram como reais)', () => {
  const checkins: CheckinRecord[] = [
    {
      id: 'chk_real_1',
      note: 'Avaliação Mensal Real',
      peso: 94.2,
      ombros: 129,
      cintura: 83,
      peito: 112,
      braco: 42,
      coxa: 61,
      panturrilha: 40,
      indiceAdonis: 1.554,
      overallScore: 91,
      dateFormatted: '08/11/2026',
      timestamp: BASE_NOW_MS
    },
    {
      id: 'chk_demo_1',
      note: 'Mês 1 // Ponto de Partida',
      peso: 96,
      ombros: 126,
      cintura: 86,
      peito: 109,
      braco: 40,
      coxa: 59,
      panturrilha: 39,
      indiceAdonis: 1.465,
      overallScore: 84,
      dateFormatted: 'Setembro',
      timestamp: BASE_NOW_MS - 60 * ONE_DAY_MS
    }
  ];

  const { realCheckins, demoCheckins } = splitCheckinsByOrigin(checkins);
  assert.equal(realCheckins.length, 1);
  assert.equal(realCheckins[0].id, 'chk_real_1');
  assert.equal(demoCheckins.length, 1);
  assert.equal(demoCheckins[0].id, 'chk_demo_1');
});

test('13 & 14. Compatibilidade com históricos antigos (sem setsDetail) e registros sem informações opcionais (RPE, notas, volumeKg)', () => {
  const legacyWorkout: CompletedWorkout = {
    id: 'legacy_wk_1',
    dayId: 'seg',
    dayName: 'Segunda-feira',
    title: 'Treino A Antigo',
    tonnage: 4200,
    durationSec: 2400,
    completedSets: 12,
    totalSets: 12,
    cardioCompleted: false,
    dateFormatted: '10 de out. de 2026',
    timestamp: BASE_NOW_MS - 15 * ONE_DAY_MS,
    // Sem sessionRpe e sem sessionNotes
    exercisesSummary: [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 4,
        totalSets: 4,
        maxWeight: 90
        // Sem bestSetReps, sem volumeKg e sem setsDetail
      }
    ]
  };

  const modernWorkout: CompletedWorkout = {
    id: 'modern_wk_2',
    dayId: 'seg',
    dayName: 'Segunda-feira',
    title: 'Treino A Novo',
    tonnage: 5000,
    durationSec: 2700,
    completedSets: 12,
    totalSets: 12,
    cardioCompleted: true,
    dateFormatted: '08 de nov. de 2026',
    timestamp: BASE_NOW_MS - ONE_DAY_MS,
    sessionRpe: 8.5,
    sessionNotes: 'Ótima execução',
    exercisesSummary: [
      {
        exerciseId: 'supino_reto',
        name: 'Supino reto com barra',
        targetGroup: 'peito',
        setsCompleted: 2,
        totalSets: 2,
        maxWeight: 100,
        bestSetReps: 8,
        volumeKg: 1700,
        setsDetail: [
          { setNumber: 1, weight: 90, reps: 10, rpe: 8 },
          { setNumber: 2, weight: 100, reps: 8, rpe: 8.5 }
        ]
      }
    ]
  };

  const detail = getExerciseEvolutionDetail({
    exerciseId: 'supino_reto',
    workoutHistory: [modernWorkout, legacyWorkout],
    period: '30d',
    nowMs: BASE_NOW_MS
  });

  // Sessão moderna possui setsDetail reais
  const modernRec = detail.periodSessions.find((s) => s.workoutId === 'modern_wk_2');
  assert.equal(modernRec?.hasIndividualSets, true);
  assert.equal(modernRec?.setsDetail.length, 2);

  // Sessão antiga NÃO possui setsDetail e NÃO deve ter séries fictícias reconstruídas
  const legacyRec = detail.periodSessions.find((s) => s.workoutId === 'legacy_wk_1');
  assert.equal(legacyRec?.hasIndividualSets, false);
  assert.equal(legacyRec?.setsDetail.length, 0);
  assert.equal(legacyRec?.maxWeight, 90);
  assert.equal(legacyRec?.bestSetReps, undefined);
  assert.equal(legacyRec?.volumeKg, undefined);
});

test('15. Prevenção de duplicação nas estatísticas quando há identificadores duplicados no array', () => {
  const wk = makeWorkout({
    id: 'sess_dup_123',
    sessionId: 'sess_dup_123',
    timestamp: BASE_NOW_MS - ONE_DAY_MS,
    tonnage: 5000,
    durationSec: 3000,
    completedSets: 15
  });

  // Passando o mesmo registro duplicado 3 vezes
  const duplicatedArray = [wk, { ...wk }, { ...wk }];

  const stats = calculateEvolutionOverviewStats(duplicatedArray, 5);
  assert.equal(stats.sessionsCount, 1); // Contado apenas 1 vez!
  assert.equal(stats.totalVolumeKg, 5000);
  assert.equal(stats.totalDurationSec, 3000);

  const feed = filterWorkoutHistoryFeed({
    workoutHistory: duplicatedArray,
    period: 'all',
    searchQuery: 'supino',
    categoryFilter: 'peito',
    nowMs: BASE_NOW_MS
  });
  assert.equal(feed.length, 1);
});
