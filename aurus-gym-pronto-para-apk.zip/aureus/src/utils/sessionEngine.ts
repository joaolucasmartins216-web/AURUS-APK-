import {
  ActiveWorkoutSession,
  CompletedWorkout,
  ExerciseItem,
  RestTimerState,
  SetLog,
  StopwatchState,
  WorkoutDay
} from '../types';

export function createInitialStopwatchState(): StopwatchState {
  return {
    status: 'not_started',
    startedAtMs: null,
    accumulatedElapsedMs: 0,
    lastResumedAtMs: null
  };
}

export function startStopwatchState(prev: StopwatchState, nowMs: number): StopwatchState {
  if (prev.status === 'running' && prev.lastResumedAtMs !== null) {
    return prev;
  }
  return {
    status: 'running',
    startedAtMs: prev.startedAtMs ?? nowMs,
    accumulatedElapsedMs: prev.accumulatedElapsedMs,
    lastResumedAtMs: nowMs
  };
}

export function pauseStopwatchState(prev: StopwatchState, nowMs: number): StopwatchState {
  if (prev.status !== 'running' || prev.lastResumedAtMs === null) {
    return prev;
  }
  const activeDeltaMs = Math.max(0, nowMs - prev.lastResumedAtMs);
  return {
    status: 'paused',
    startedAtMs: prev.startedAtMs ?? prev.lastResumedAtMs,
    accumulatedElapsedMs: prev.accumulatedElapsedMs + activeDeltaMs,
    lastResumedAtMs: null
  };
}

export function resumeStopwatchState(prev: StopwatchState, nowMs: number): StopwatchState {
  if (prev.status === 'running') return prev;
  return {
    status: 'running',
    startedAtMs: prev.startedAtMs ?? nowMs,
    accumulatedElapsedMs: prev.accumulatedElapsedMs,
    lastResumedAtMs: nowMs
  };
}

export function toggleStopwatchState(prev: StopwatchState, nowMs: number): StopwatchState {
  if (prev.status === 'running') {
    return pauseStopwatchState(prev, nowMs);
  }
  return resumeStopwatchState(prev, nowMs);
}

export function computeMainElapsedSec(stopwatch: StopwatchState, nowMs: number): number {
  if (!stopwatch || stopwatch.status === 'not_started') {
    return 0;
  }
  let totalMs = Math.max(0, Number(stopwatch.accumulatedElapsedMs) || 0);
  if (stopwatch.status === 'running' && typeof stopwatch.lastResumedAtMs === 'number') {
    totalMs += Math.max(0, nowMs - stopwatch.lastResumedAtMs);
  }
  return Math.floor(totalMs / 1000);
}

export function createInitialRestTimerState(defaultTargetSec = 60): RestTimerState {
  return {
    status: 'idle',
    targetSec: defaultTargetSec,
    endTimeMs: null,
    pausedRemainingMs: 0,
    contextExerciseId: null,
    contextExerciseName: null,
    completedSetNumber: null,
    nextSetNumber: null,
    nextSetWeight: null,
    nextSetReps: null,
    isModalOpen: false
  };
}

export interface RestContextMeta {
  exerciseId?: string | null;
  exerciseName?: string | null;
  completedSetNumber?: number | null;
  nextSetNumber?: number | null;
  nextSetWeight?: number | null;
  nextSetReps?: number | null;
  openModal?: boolean;
}

export function startRestTimerState(
  targetSec: number,
  nowMs: number,
  meta: RestContextMeta = {}
): RestTimerState {
  const cleanTarget = Math.max(5, Math.round(Number(targetSec) || 60));
  const durationMs = cleanTarget * 1000;
  return {
    status: 'running',
    targetSec: cleanTarget,
    endTimeMs: nowMs + durationMs,
    pausedRemainingMs: durationMs,
    contextExerciseId: meta.exerciseId ?? null,
    contextExerciseName: meta.exerciseName ?? null,
    completedSetNumber: meta.completedSetNumber ?? null,
    nextSetNumber: meta.nextSetNumber ?? null,
    nextSetWeight: meta.nextSetWeight ?? null,
    nextSetReps: meta.nextSetReps ?? null,
    isModalOpen: meta.openModal !== undefined ? meta.openModal : true
  };
}

export function computeRestRemainingSec(restTimer: RestTimerState, nowMs: number): number {
  if (!restTimer || restTimer.status === 'idle' || restTimer.status === 'completed') {
    return 0;
  }
  if (restTimer.status === 'paused') {
    return Math.max(0, Math.ceil((Number(restTimer.pausedRemainingMs) || 0) / 1000));
  }
  if (restTimer.status === 'running' && typeof restTimer.endTimeMs === 'number') {
    const remMs = restTimer.endTimeMs - nowMs;
    if (remMs <= 0) return 0;
    return Math.ceil(remMs / 1000);
  }
  return 0;
}

export function syncRestTimerState(
  restTimer: RestTimerState,
  nowMs: number
): { nextState: RestTimerState; justCompleted: boolean } {
  if (restTimer.status === 'running' && typeof restTimer.endTimeMs === 'number') {
    if (nowMs >= restTimer.endTimeMs) {
      return {
        nextState: {
          ...restTimer,
          status: 'completed',
          endTimeMs: null,
          pausedRemainingMs: 0
        },
        justCompleted: true
      };
    }
  }
  return { nextState: restTimer, justCompleted: false };
}

export function pauseRestTimerState(restTimer: RestTimerState, nowMs: number): RestTimerState {
  if (restTimer.status !== 'running' || typeof restTimer.endTimeMs !== 'number') {
    return restTimer;
  }
  const remMs = Math.max(0, restTimer.endTimeMs - nowMs);
  if (remMs <= 0) {
    return {
      ...restTimer,
      status: 'completed',
      endTimeMs: null,
      pausedRemainingMs: 0
    };
  }
  return {
    ...restTimer,
    status: 'paused',
    endTimeMs: null,
    pausedRemainingMs: remMs
  };
}

export function resumeRestTimerState(restTimer: RestTimerState, nowMs: number): RestTimerState {
  if (restTimer.status !== 'paused') {
    return restTimer;
  }
  const remMs = Math.max(0, Number(restTimer.pausedRemainingMs) || 0);
  if (remMs <= 0) {
    return {
      ...restTimer,
      status: 'completed',
      endTimeMs: null,
      pausedRemainingMs: 0
    };
  }
  return {
    ...restTimer,
    status: 'running',
    endTimeMs: nowMs + remMs
  };
}

export function togglePauseRestTimerState(
  restTimer: RestTimerState,
  nowMs: number
): RestTimerState {
  if (restTimer.status === 'running') {
    return pauseRestTimerState(restTimer, nowMs);
  }
  if (restTimer.status === 'paused') {
    return resumeRestTimerState(restTimer, nowMs);
  }
  return restTimer;
}

export function adjustRestTimerState(
  restTimer: RestTimerState,
  deltaSec: number,
  nowMs: number
): RestTimerState {
  const deltaMs = deltaSec * 1000;

  if (restTimer.status === 'running' && typeof restTimer.endTimeMs === 'number') {
    const currentRemMs = Math.max(0, restTimer.endTimeMs - nowMs);
    const nextRemMs = Math.max(0, currentRemMs + deltaMs);
    const nextRemSec = Math.ceil(nextRemMs / 1000);
    if (nextRemMs <= 0) {
      return {
        ...restTimer,
        status: 'completed',
        endTimeMs: null,
        pausedRemainingMs: 0
      };
    }
    return {
      ...restTimer,
      targetSec: Math.max(restTimer.targetSec, nextRemSec),
      endTimeMs: nowMs + nextRemMs,
      pausedRemainingMs: nextRemMs
    };
  }

  if (restTimer.status === 'paused') {
    const nextRemMs = Math.max(0, (Number(restTimer.pausedRemainingMs) || 0) + deltaMs);
    const nextRemSec = Math.ceil(nextRemMs / 1000);
    if (nextRemMs <= 0) {
      return {
        ...restTimer,
        status: 'completed',
        endTimeMs: null,
        pausedRemainingMs: 0
      };
    }
    return {
      ...restTimer,
      targetSec: Math.max(restTimer.targetSec, nextRemSec),
      pausedRemainingMs: nextRemMs
    };
  }

  // If completed or idle and user adds positive time (+15s, +30s, +60s), start running
  if (deltaSec > 0) {
    return startRestTimerState(deltaSec, nowMs, {
      exerciseId: restTimer.contextExerciseId,
      exerciseName: restTimer.contextExerciseName,
      completedSetNumber: restTimer.completedSetNumber,
      nextSetNumber: restTimer.nextSetNumber,
      nextSetWeight: restTimer.nextSetWeight,
      nextSetReps: restTimer.nextSetReps,
      openModal: restTimer.isModalOpen
    });
  }

  return restTimer;
}

export function skipRestTimerState(restTimer: RestTimerState): RestTimerState {
  return {
    ...restTimer,
    status: 'idle',
    endTimeMs: null,
    pausedRemainingMs: 0,
    isModalOpen: false
  };
}

let sessionSequenceCounter = 0;

export function createSessionId(nowMs: number, dayId: string): string {
  sessionSequenceCounter = (sessionSequenceCounter + 1) % 1000000;
  return `sess_${nowMs}_${sessionSequenceCounter}_${dayId}`;
}

export interface ToggleSetCompletionResult {
  updatedSessionSets: Record<string, SetLog[]>;
  updatedExerciseSets: SetLog[];
  toggledSet: SetLog | null;
  shouldStartRest: boolean;
  restDurationSec: number;
}

/**
 * Purely toggles a set's completion state without side effects.
 * Returns shouldStartRest = true ONLY when a set transitions from uncompleted to completed.
 * Reverting a completed set returns shouldStartRest = false.
 */
export function toggleSetCompletionPure(
  sessionSets: Record<string, SetLog[]>,
  exercise: ExerciseItem,
  setIndex: number
): ToggleSetCompletionResult {
  const currentList = sessionSets[exercise.id] || [];
  if (setIndex < 0 || setIndex >= currentList.length) {
    return {
      updatedSessionSets: sessionSets,
      updatedExerciseSets: currentList,
      toggledSet: null,
      shouldStartRest: false,
      restDurationSec: exercise.rest || 60
    };
  }

  const nextList = [...currentList];
  const prevSet = nextList[setIndex];
  const nextCompleted = !prevSet.completed;
  const toggledSet: SetLog = {
    ...prevSet,
    completed: nextCompleted
  };
  nextList[setIndex] = toggledSet;

  return {
    updatedSessionSets: {
      ...sessionSets,
      [exercise.id]: nextList
    },
    updatedExerciseSets: nextList,
    toggledSet,
    shouldStartRest: nextCompleted === true,
    restDurationSec: exercise.rest || 60
  };
}

export interface ExerciseSwapPermission {
  allowed: boolean;
  completedSetsCount: number;
  reason?: string;
}

/**
 * Prevents replacing an exercise that already has completed sets in the active session.
 */
export function canSwapExerciseInSession(
  exerciseId: string,
  sessionSets: Record<string, SetLog[]>
): ExerciseSwapPermission {
  const sets = sessionSets[exerciseId] || [];
  const completedSetsCount = sets.filter((s) => s.completed).length;
  if (completedSetsCount > 0) {
    return {
      allowed: false,
      completedSetsCount,
      reason: `Este exercício já possui ${completedSetsCount} ${
        completedSetsCount === 1 ? 'série concluída' : 'séries concluídas'
      } nesta sessão e não pode ser substituído para preservar seus registros.`
    };
  }
  return {
    allowed: true,
    completedSetsCount: 0
  };
}

export interface ApplyAiReformulationInput {
  currentCustomWorkouts: WorkoutDay[] | null;
  baseTemplate: WorkoutDay[];
  generatedWorkouts: WorkoutDay[];
  scope: 'week' | 'day';
  currentDayWorkout: WorkoutDay;
  sessionSets: Record<string, SetLog[]>;
  isSessionActive: boolean;
  resolution: 'preserve_active' | 'replace_active';
}

export interface ApplyAiReformulationResult {
  updatedCustomWorkouts: WorkoutDay[];
  updatedSessionSets: Record<string, SetLog[]>;
  shouldResetActiveSession: boolean;
  preservedCompletedExercisesCount: number;
}

/**
 * Safely applies AI workout reformulations.
 * When resolution === 'preserve_active' and a session is active (or has completed sets),
 * any exercise in currentDayWorkout that has completed sets is preserved with its ID and SetLogs,
 * and the active session is NOT reset.
 */
export function applyAiReformulationWithSessionProtection(
  input: ApplyAiReformulationInput
): ApplyAiReformulationResult {
  const {
    currentCustomWorkouts,
    baseTemplate,
    generatedWorkouts,
    scope,
    currentDayWorkout,
    sessionSets,
    isSessionActive,
    resolution
  } = input;

  const { completedSets } = countCompletedSetsInSession(
    currentDayWorkout?.exercises || [],
    sessionSets
  );
  const hasActiveProgress = isSessionActive || completedSets > 0;

  if (!hasActiveProgress || resolution === 'replace_active') {
    if (scope === 'day') {
      const updatedDay: WorkoutDay = {
        ...generatedWorkouts[0],
        id: currentDayWorkout.id,
        dayName: currentDayWorkout.dayName,
        shortDay: currentDayWorkout.shortDay
      };
      const baseList = currentCustomWorkouts
        ? [...currentCustomWorkouts]
        : [...baseTemplate];
      const existsIdx = baseList.findIndex((d) => d.id === currentDayWorkout.id);
      if (existsIdx >= 0) {
        baseList[existsIdx] = updatedDay;
      } else {
        baseList.push(updatedDay);
      }
      return {
        updatedCustomWorkouts: baseList,
        updatedSessionSets: {},
        shouldResetActiveSession: true,
        preservedCompletedExercisesCount: 0
      };
    }

    return {
      updatedCustomWorkouts: generatedWorkouts,
      updatedSessionSets: {},
      shouldResetActiveSession: true,
      preservedCompletedExercisesCount: 0
    };
  }

  // resolution === 'preserve_active' with active session or completed sets:
  // Identify exercises in currentDayWorkout that already have completed sets
  const completedExercises = (currentDayWorkout.exercises || []).filter((ex) =>
    (sessionSets[ex.id] || []).some((s) => s.completed)
  );
  const completedExIds = new Set(completedExercises.map((ex) => ex.id));

  const candidateDayFromAi =
    scope === 'day'
      ? generatedWorkouts[0]
      : generatedWorkouts.find((d) => d.id === currentDayWorkout.id) || generatedWorkouts[0];

  // Keep all exercises with completed sets in their original order at the start,
  // and fill remaining slots with non-colliding AI exercises (or keep uncompleted exercises if none)
  const newAiExercises = (candidateDayFromAi?.exercises || []).filter(
    (ex) => !completedExIds.has(ex.id)
  );
  const targetExerciseCount = Math.max(
    completedExercises.length,
    (candidateDayFromAi?.exercises || currentDayWorkout.exercises).length
  );
  const mergedDayExercises: ExerciseItem[] = [
    ...completedExercises,
    ...newAiExercises.slice(0, Math.max(0, targetExerciseCount - completedExercises.length))
  ];

  // If no completed exercises existed yet (session just started with 0 sets done),
  // keep currentDayWorkout exercises intact if scope === 'week', or use mergedDayExercises
  const safeDayExercises =
    completedExercises.length > 0
      ? mergedDayExercises
      : scope === 'week'
      ? currentDayWorkout.exercises
      : mergedDayExercises.length > 0
      ? mergedDayExercises
      : currentDayWorkout.exercises;

  const protectedCurrentDay: WorkoutDay = {
    ...(candidateDayFromAi || currentDayWorkout),
    id: currentDayWorkout.id,
    dayName: currentDayWorkout.dayName,
    shortDay: currentDayWorkout.shortDay,
    title: currentDayWorkout.title,
    exercises: safeDayExercises
  };

  let updatedCustomWorkouts: WorkoutDay[];
  if (scope === 'day') {
    const baseList = currentCustomWorkouts
      ? [...currentCustomWorkouts]
      : [...baseTemplate];
    const existsIdx = baseList.findIndex((d) => d.id === currentDayWorkout.id);
    if (existsIdx >= 0) {
      baseList[existsIdx] = protectedCurrentDay;
    } else {
      baseList.push(protectedCurrentDay);
    }
    updatedCustomWorkouts = baseList;
  } else {
    const hasCurrentInGenerated = generatedWorkouts.some((d) => d.id === currentDayWorkout.id);
    updatedCustomWorkouts = hasCurrentInGenerated
      ? generatedWorkouts.map((d) =>
          d.id === currentDayWorkout.id ? protectedCurrentDay : d
        )
      : [protectedCurrentDay, ...generatedWorkouts];
  }

  // Preserve sessionSets for all kept exercises and initialize defaults for any new exercises
  const preservedSets: Record<string, SetLog[]> = {};
  safeDayExercises.forEach((ex) => {
    if (sessionSets[ex.id] && sessionSets[ex.id].length > 0) {
      preservedSets[ex.id] = sessionSets[ex.id];
    } else {
      const targetReps = parseInt(String(ex.reps).split('-')[1] || ex.reps, 10) || 10;
      const totalSets = ex.totalSets || ex.baseSets || 3;
      preservedSets[ex.id] = Array.from({ length: totalSets }, (_, idx) => ({
        setNumber: idx + 1,
        weight: ex.defaultWeight ?? 20,
        reps: targetReps,
        rpe: 8,
        completed: false
      }));
    }
  });

  return {
    updatedCustomWorkouts,
    updatedSessionSets: preservedSets,
    shouldResetActiveSession: false,
    preservedCompletedExercisesCount: completedExercises.length
  };
}

export function buildDefaultSessionSetsForDay(
  dayWorkout: WorkoutDay,
  lastExerciseWeights: Record<string, number>,
  existingSets: Record<string, SetLog[]> = {}
): Record<string, SetLog[]> {
  const updated: Record<string, SetLog[]> = { ...existingSets };
  (dayWorkout.exercises || []).forEach((ex) => {
    const savedWeight = lastExerciseWeights[ex.id] ?? ex.defaultWeight ?? 20;
    const targetReps = parseInt(String(ex.reps).split('-')[1] || ex.reps, 10) || 10;
    const totalSets = ex.totalSets || ex.baseSets || 3;

    if (!updated[ex.id] || updated[ex.id].length === 0) {
      updated[ex.id] = Array.from({ length: totalSets }, (_, idx) => ({
        setNumber: idx + 1,
        weight: savedWeight,
        reps: targetReps,
        rpe: 8,
        completed: false
      }));
    }
  });
  return updated;
}

export function createActiveWorkoutSession(
  dayWorkout: WorkoutDay,
  sessionSets: Record<string, SetLog[]>,
  nowMs: number
): ActiveWorkoutSession {
  return {
    sessionId: createSessionId(nowMs, dayWorkout.id),
    dayId: dayWorkout.id,
    dayTitle: dayWorkout.title,
    status: 'running',
    startedAtMs: nowMs,
    updatedAtMs: nowMs,
    activeExerciseIndex: 0,
    arenaPhase: 'hipertrofia',
    mobilityChecked: {},
    cardioCompleted: false,
    sessionSets,
    customExercisesAdded: [],
    stopwatch: {
      status: 'running',
      startedAtMs: nowMs,
      accumulatedElapsedMs: 0,
      lastResumedAtMs: nowMs
    },
    restTimer: createInitialRestTimerState(60),
    sessionRpe: undefined,
    sessionNotes: ''
  };
}

export function countCompletedSetsInSession(
  exercises: ExerciseItem[],
  sessionSets: Record<string, SetLog[]>
): { completedSets: number; totalSets: number; tonnage: number } {
  let completedSets = 0;
  let totalSets = 0;
  let tonnage = 0;

  exercises.forEach((ex) => {
    const sets = sessionSets[ex.id] || [];
    sets.forEach((s) => {
      totalSets += 1;
      if (s.completed) {
        completedSets += 1;
        tonnage += (Math.max(0, Number(s.weight) || 0)) * (Math.max(0, Number(s.reps) || 0));
      }
    });
  });

  return {
    completedSets,
    totalSets,
    tonnage: Math.round(tonnage * 10) / 10
  };
}

export function isSessionAlreadyRecorded(
  workoutHistory: CompletedWorkout[],
  sessionId: string | null | undefined
): CompletedWorkout | null {
  if (!sessionId || !Array.isArray(workoutHistory)) return null;
  return (
    workoutHistory.find((wk) => wk.id === sessionId || wk.sessionId === sessionId) || null
  );
}

export interface FinalizeWorkoutInput {
  sessionId: string;
  startedAtMs: number;
  durationSec: number;
  dayWorkout: WorkoutDay;
  sessionSets: Record<string, SetLog[]>;
  cardioCompleted: boolean;
  workoutHistory: CompletedWorkout[];
  lastExerciseWeights: Record<string, number>;
  nowMs: number;
  sessionRpe?: number;
  sessionNotes?: string;
}

export interface FinalizeWorkoutResult {
  alreadyRecorded: boolean;
  completedWorkout: CompletedWorkout;
  updatedHistory: CompletedWorkout[];
  updatedLastWeights: Record<string, number>;
}

/**
 * Idempotently finalizes a workout session.
 * Repeated calls with the same sessionId will never create duplicate history entries.
 * Never fabricates sessionRpe when not provided by the user.
 */
export function finalizeWorkoutSessionIdempotent(
  input: FinalizeWorkoutInput
): FinalizeWorkoutResult {
  const existing = isSessionAlreadyRecorded(input.workoutHistory, input.sessionId);
  if (existing) {
    return {
      alreadyRecorded: true,
      completedWorkout: existing,
      updatedHistory: input.workoutHistory,
      updatedLastWeights: input.lastExerciseWeights
    };
  }

  const { completedSets, totalSets, tonnage } = countCompletedSetsInSession(
    input.dayWorkout.exercises,
    input.sessionSets
  );

  const updatedLastWeights = { ...input.lastExerciseWeights };

  const exercisesSummary = input.dayWorkout.exercises.map((ex) => {
    const sets = input.sessionSets[ex.id] || [];
    const completed = sets.filter((s) => s.completed);

    // Find historical best weight before this session
    let previousBestWeight =
      typeof input.lastExerciseWeights[ex.id] === 'number' && input.lastExerciseWeights[ex.id] > 0
        ? input.lastExerciseWeights[ex.id]
        : 0;

    for (const wk of input.workoutHistory) {
      const found = wk.exercisesSummary?.find(
        (s) => s.exerciseId === ex.id || s.name.toLowerCase() === ex.name.toLowerCase()
      );
      if (found && found.maxWeight > previousBestWeight) {
        previousBestWeight = found.maxWeight;
      }
    }

    let maxWeight = 0;
    let bestSetReps = 0;
    let volumeKg = 0;

    completed.forEach((s) => {
      const w = Math.max(0, Number(s.weight) || 0);
      const r = Math.max(0, Number(s.reps) || 0);
      volumeKg += w * r;
      if (w > maxWeight || (w === maxWeight && r > bestSetReps)) {
        maxWeight = w;
        bestSetReps = r;
      }
    });

    if (maxWeight > 0) {
      updatedLastWeights[ex.id] = maxWeight;
    }

    const isPersonalRecord = previousBestWeight > 0 && maxWeight > previousBestWeight;

    const setsDetail = completed.map((s, idx) => ({
      setNumber: Number(s.setNumber) || idx + 1,
      weight: Math.max(0, Number(s.weight) || 0),
      reps: Math.max(0, Number(s.reps) || 0),
      ...(typeof s.rpe === 'number' && !Number.isNaN(s.rpe) ? { rpe: s.rpe } : {})
    }));

    return {
      exerciseId: ex.id,
      name: ex.name,
      targetGroup: ex.targetGroup,
      setsCompleted: completed.length,
      totalSets: sets.length,
      maxWeight,
      bestSetReps,
      volumeKg: Math.round(volumeKg * 10) / 10,
      isPersonalRecord,
      previousBestWeight: previousBestWeight > 0 ? previousBestWeight : undefined,
      setsDetail
    };
  });

  const dateFormatted = new Date(input.nowMs).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const normalizedRpe =
    typeof input.sessionRpe === 'number' && !Number.isNaN(input.sessionRpe)
      ? input.sessionRpe
      : undefined;

  const completedWorkout: CompletedWorkout = {
    id: input.sessionId,
    sessionId: input.sessionId,
    dayId: input.dayWorkout.id,
    dayName: input.dayWorkout.dayName,
    title: input.dayWorkout.title,
    tonnage,
    durationSec: Math.max(1, Math.round(input.durationSec)),
    completedSets,
    totalSets,
    cardioCompleted: input.cardioCompleted,
    dateFormatted,
    timestamp: input.nowMs,
    startedAtTimestamp: input.startedAtMs,
    sessionRpe: normalizedRpe,
    sessionNotes: input.sessionNotes ?? '',
    exercisesSummary
  };

  return {
    alreadyRecorded: false,
    completedWorkout,
    updatedHistory: [completedWorkout, ...input.workoutHistory],
    updatedLastWeights
  };
}
