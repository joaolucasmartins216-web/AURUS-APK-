import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateArenaSessionStats,
  formatArenaTimer,
  getExercisePreviousReference,
  resolveFocusedSetIndex
} from './arenaLogic';
import { CompletedWorkout, ExerciseItem, SetLog } from '../types';

const mockExercise: ExerciseItem = {
  id: 'supino_reto',
  name: 'Supino Reto com Barra',
  targetGroup: 'peito',
  baseSets: 4,
  reps: '8-10',
  rest: 90,
  cadence: '2-0-1-0',
  defaultWeight: 60,
  tip: 'Escápulas retraídas.'
};

test('calculateArenaSessionStats counts only completed sets for tonnage and progress', () => {
  const sets: Record<string, SetLog[]> = {
    supino_reto: [
      { setNumber: 1, weight: 90, reps: 10, rpe: 8, completed: true },
      { setNumber: 2, weight: 100, reps: 8, rpe: 8.5, completed: true },
      { setNumber: 3, weight: 105, reps: 8, rpe: 9, completed: false },
      { setNumber: 4, weight: 105, reps: 8, rpe: 9, completed: false }
    ]
  };

  const stats = calculateArenaSessionStats([mockExercise], sets);
  assert.equal(stats.totalSets, 4);
  assert.equal(stats.completedSets, 2);
  assert.equal(stats.tonnage, 90 * 10 + 100 * 8); // 1700
  assert.equal(stats.progressPct, 50);
});

test('formatArenaTimer formats rest timer and session stopwatch accurately', () => {
  assert.equal(formatArenaTimer(0, false), '00:00');
  assert.equal(formatArenaTimer(90, false), '01:30');
  assert.equal(formatArenaTimer(1590, true), '00:26:30');
  assert.equal(formatArenaTimer(3665, false), '01:01:05');
});

test('getExercisePreviousReference never fabricates PRs when no history exists', () => {
  const emptyRef = getExercisePreviousReference(mockExercise, {}, []);
  assert.equal(emptyRef.hasHistory, false);
  assert.equal(emptyRef.lastWeightKg, null);
  assert.equal(emptyRef.tableCellText, 'Sem registro');
  assert.ok(emptyRef.summaryText.includes('Sem histórico anterior'));

  const history: CompletedWorkout[] = [
    {
      id: 'wk_1',
      dayId: 'seg',
      dayName: 'Segunda-feira',
      title: 'Treino A',
      tonnage: 3200,
      durationSec: 2400,
      completedSets: 4,
      totalSets: 4,
      cardioCompleted: true,
      dateFormatted: '05 de nov. de 2026, 18:30',
      timestamp: 1762367400000,
      exercisesSummary: [
        {
          exerciseId: 'supino_reto',
          name: 'Supino Reto com Barra',
          targetGroup: 'peito',
          setsCompleted: 4,
          totalSets: 4,
          maxWeight: 105
        }
      ]
    }
  ];

  const realRef = getExercisePreviousReference(mockExercise, { supino_reto: 100 }, history);
  assert.equal(realRef.hasHistory, true);
  assert.equal(realRef.lastWeightKg, 100);
  assert.equal(realRef.bestWeightKg, 105);
  assert.equal(realRef.tableCellText, '100 kg × 8');
});

test('resolveFocusedSetIndex defaults to first uncompleted set and respects manual selection', () => {
  const sets: SetLog[] = [
    { setNumber: 1, weight: 80, reps: 10, rpe: 8, completed: true },
    { setNumber: 2, weight: 85, reps: 8, rpe: 8, completed: false },
    { setNumber: 3, weight: 85, reps: 8, rpe: 9, completed: false }
  ];

  assert.equal(resolveFocusedSetIndex(sets, null), 1);
  assert.equal(resolveFocusedSetIndex(sets, 0), 0); // user clicked completed set #1 to edit
  assert.equal(resolveFocusedSetIndex(sets, 2), 2);
});
