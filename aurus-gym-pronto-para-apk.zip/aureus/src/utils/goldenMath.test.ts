import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateGoldenAnalysis, PHI } from './goldenMath.ts';
import { BiometricMetrics } from '../types/index.ts';

test('Golden ratio constant is 1.618', () => {
  assert.equal(PHI, 1.618);
});

test('calculateGoldenAnalysis correctly calculates Adonis Index and McCallum targets', () => {
  const metrics: BiometricMetrics = {
    idade: 24,
    peso: 95,
    altura: 176,
    pulso: 20,
    ombros: 129,
    peito: 97,
    cintura: 96,
    quadril: 106,
    braco: 38,
    coxa: 58,
    panturrilha: 43,
    pescoco: 40
  };

  const analysis = calculateGoldenAnalysis(metrics);

  // Height = 176 => Waist target = 176 * 0.45 = 79.2
  assert.equal(analysis.cinturaIdeal, 79.2);

  // Shoulder target = 79.2 * 1.618 = 128.1
  assert.equal(analysis.ombrosIdeais, 128.1);

  // Wrist = 20 => Chest target = 20 * 6.5 = 130
  assert.equal(analysis.peitoIdeal, 130);

  // Arm target = 130 * 0.36 = 46.8
  assert.equal(analysis.bracoIdeal, 46.8);

  // Thigh target = 130 * 0.53 = 68.9
  assert.equal(analysis.coxaIdeal, 68.9);

  // Calf target = 130 * 0.34 = 44.2
  assert.equal(analysis.panturrilhaIdeal, 44.2);

  // Adonis index = 129 / 96 = 1.344
  assert.equal(analysis.indiceAdonisAtual, 1.344);

  // Check red zones are identified (peito 97 vs 130 is delta 33cm => RED)
  assert.equal(analysis.parts.peito.colorZone, 'red');

  // Cintura 96 vs 79.2 has excess > 2cm => RED reduction target
  assert.equal(analysis.parts.cintura.colorZone, 'red');
  assert.equal(analysis.needsFatLossProtocol, true);
});

test('calculateGoldenAnalysis classifies green zones when delta <= 1.0', () => {
  const balancedMetrics: BiometricMetrics = {
    idade: 26,
    peso: 78,
    altura: 178,
    pulso: 17.5,
    ombros: 129.5, // Target 129.6 => delta 0.1 => green
    peito: 113.5,  // Target 113.8 => delta 0.3 => green
    cintura: 80.2, // Target 80.1 => delta 0.1 => green
    quadril: 96.5, // Target 96.7 => delta 0.2 => green
    braco: 41.0,   // Target 41.0 => delta 0 => green
    coxa: 60.0,    // Target 60.3 => delta 0.3 => green
    panturrilha: 38.6,
    pescoco: 42.0
  };

  const analysis = calculateGoldenAnalysis(balancedMetrics);
  assert.equal(analysis.parts.ombros.colorZone, 'green');
  assert.equal(analysis.parts.peito.colorZone, 'green');
  assert.equal(analysis.parts.cintura.colorZone, 'green');
  assert.ok(analysis.overallScore > 98);
});
