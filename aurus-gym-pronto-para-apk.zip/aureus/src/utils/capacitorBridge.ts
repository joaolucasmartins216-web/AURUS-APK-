import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import { Preferences } from '@capacitor/preferences';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Keyboard } from '@capacitor/keyboard';
import { SplashScreen } from '@capacitor/splash-screen';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { ProfileSubView } from '../components/ProfileSettingsView';

/**
 * Detecta se o aplicativo está rodando dentro do container nativo Capacitor (Android/iOS).
 */
export function isNativePlatform(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/**
 * Detecta se o aplicativo está rodando especificamente no Android nativo via Capacitor.
 */
export function isNativeAndroid(): boolean {
  try {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

/**
 * Detecta se o ambiente atual é uma Android WebView (seja via Capacitor ou WebView embutida).
 * Útil para adaptar fluxos como Google OAuth por popup que são bloqueados pela política
 * `disallowed_useragent` do Google em WebViews embutidas.
 */
export function isRunningInAndroidWebView(customUserAgent?: string): boolean {
  if (isNativeAndroid()) return true;
  const ua =
    customUserAgent !== undefined
      ? customUserAgent
      : typeof navigator !== 'undefined'
      ? navigator.userAgent || ''
      : '';
  if (!ua) return false;
  const isAndroid = /Android/i.test(ua);
  const hasWvToken = /;\s*wv\)/i.test(ua) || /\bwv\b/i.test(ua);
  const isCapacitorBridge =
    typeof window !== 'undefined' &&
    Boolean((window as unknown as Record<string, unknown>).Capacitor);
  return isAndroid && (hasWvToken || isCapacitorBridge);
}

/**
 * Resolve a URL de endpoint de API garantindo que no APK Android nunca seja utilizada
 * uma URL `localhost` ou `127.0.0.1` para serviços externos (como o backend Express do Coach IA).
 *
 * - Se `configuredBaseUrl` for uma URL HTTPS válida (ex.: Cloud Run publicado), concatena com `path`.
 * - Se estiver no APK nativo (`isNative = true`) e não houver `VITE_API_BASE_URL` remota (ou se for localhost),
 *   retorna `null` para acionar imediatamente o motor biomecânico offline sem tentar conexão local inválida.
 * - Na Web normal sem `VITE_API_BASE_URL`, retorna o caminho relativo `path` (`/api/gemini/generate`).
 */
export function resolveApiEndpoint(
  path: string,
  options?: {
    configuredBaseUrl?: string;
    isNative?: boolean;
  }
): string | null {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const isNative = options?.isNative ?? isNativePlatform();

  let rawBase =
    options?.configuredBaseUrl !== undefined
      ? options.configuredBaseUrl
      : typeof import.meta !== 'undefined' && import.meta.env
      ? (import.meta.env.VITE_API_BASE_URL as string | undefined) || ''
      : '';

  rawBase = rawBase.trim().replace(/\/+$/, '');

  const isLocalhostUrl = (urlStr: string): boolean => {
    return /^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?(\/|$)/i.test(urlStr);
  };

  if (isNative) {
    if (!rawBase || isLocalhostUrl(rawBase)) {
      return null;
    }
    return `${rawBase}${normalizedPath}`;
  }

  if (rawBase && !isLocalhostUrl(rawBase)) {
    return `${rawBase}${normalizedPath}`;
  }

  return normalizedPath;
}

/**
 * espelha assincronamente uma chave do localStorage no armazenamento nativo
 * SharedPreferences do Android (`@capacitor/preferences`), prevenindo perda de dados
 * caso o sistema Android limpe o cache da WebView.
 */
export async function mirrorKeyToNativePreferences(
  key: string,
  value: string | null
): Promise<void> {
  try {
    if (value === null) {
      await Preferences.remove({ key });
    } else {
      await Preferences.set({ key, value });
    }
  } catch {
    // Ignora silenciosamente em ambientes de teste Node sem DOM/Capacitor
  }
}

/**
 * Sincroniza bidirecionalmente o `localStorage` com o `@capacitor/preferences` na inicialização:
 * 1. Se uma chave existir no `Preferences` nativo mas tiver sido limpa do `localStorage` da WebView,
 *    restaura imediatamente para o `localStorage`.
 * 2. Se uma chave existir no `localStorage`, garante que esteja salva no `Preferences` nativo.
 */
export async function hydrateLocalStorageFromNativePreferences(
  keys: string[]
): Promise<{ restoredKeys: string[]; backedUpKeys: string[] }> {
  const restoredKeys: string[] = [];
  const backedUpKeys: string[] = [];

  if (typeof localStorage === 'undefined') {
    return { restoredKeys, backedUpKeys };
  }

  for (const key of keys) {
    try {
      const localVal = localStorage.getItem(key);
      const { value: nativeVal } = await Preferences.get({ key });

      if ((localVal === null || localVal === '') && nativeVal !== null && nativeVal !== '') {
        localStorage.setItem(key, nativeVal);
        restoredKeys.push(key);
      } else if (localVal !== null && localVal !== '' && localVal !== nativeVal) {
        await Preferences.set({ key, value: localVal });
        backedUpKeys.push(key);
      }
    } catch {
      // Continua para as demais chaves se o plugin não estiver disponível
    }
  }

  return { restoredKeys, backedUpKeys };
}

/**
 * Exporta um arquivo (`.json` ou `.csv`) de forma compatível tanto com navegadores Web
 * quanto com o APK Android nativo (usando `@capacitor/filesystem` + `@capacitor/share`
 * quando em plataforma nativa, pois links `blob:` com `<a download>` podem ser ignorados na WebView).
 */
export async function exportFileCompat(params: {
  filename: string;
  content: string;
  mimeType: string;
  shareTitle?: string;
}): Promise<'shared_native' | 'downloaded_web' | 'noop'> {
  const { filename, content, mimeType, shareTitle } = params;

  if (isNativePlatform()) {
    try {
      const writeResult = await Filesystem.writeFile({
        path: filename,
        data: content,
        directory: Directory.Cache,
        encoding: Encoding.UTF8
      });

      await Share.share({
        title: shareTitle || filename,
        text: `Arquivo exportado pelo AURUS GYM: ${filename}`,
        url: writeResult.uri,
        dialogTitle: shareTitle || 'Salvar ou compartilhar arquivo'
      });

      return 'shared_native';
    } catch (err) {
      console.warn('Fallback para download web após falha no compartilhamento nativo:', err);
    }
  }

  if (typeof window !== 'undefined' && typeof Blob !== 'undefined' && typeof document !== 'undefined') {
    const blobContent =
      mimeType.includes('csv') && !content.startsWith('\uFEFF') ? '\uFEFF' + content : content;
    const blob = new Blob([blobContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return 'downloaded_web';
  }

  return 'noop';
}

export interface BackNavigationStateSnapshot {
  activeTab: string;
  profileSubView: ProfileSubView;
  isMobileMenuOpen: boolean;
  showGuideModal: boolean;
  showOnboardingModal: boolean;
  hasCompletedWorkoutSummary: boolean;
  showDiscardModal: boolean;
  hasPendingAiReformulation: boolean;
  hasPendingBackupImport: boolean;
  isRestModalOpen: boolean;
}

export type BackNavigationResolution =
  | { action: 'close_modal'; target: string }
  | { action: 'reset_profile_subview' }
  | { action: 'navigate_home' }
  | { action: 'minimize_app' };

/**
 * Máquina de estados pura para o botão Voltar físico/gestual do Android.
 * Garante que modais e subtelas sejam fechados na ordem correta antes de minimizar o app.
 */
export function resolveAndroidBackAction(
  state: BackNavigationStateSnapshot
): BackNavigationResolution {
  if (state.isRestModalOpen) {
    return { action: 'close_modal', target: 'rest_modal' };
  }
  if (state.showDiscardModal) {
    return { action: 'close_modal', target: 'discard_modal' };
  }
  if (state.hasPendingAiReformulation) {
    return { action: 'close_modal', target: 'ai_reformulation_modal' };
  }
  if (state.hasPendingBackupImport) {
    return { action: 'close_modal', target: 'backup_import_modal' };
  }
  if (state.hasCompletedWorkoutSummary) {
    return { action: 'close_modal', target: 'workout_summary_modal' };
  }
  if (state.showGuideModal) {
    return { action: 'close_modal', target: 'guide_modal' };
  }
  if (state.showOnboardingModal) {
    return { action: 'close_modal', target: 'onboarding_modal' };
  }
  if (state.isMobileMenuOpen) {
    return { action: 'close_modal', target: 'mobile_menu' };
  }

  if (state.activeTab === 'perfil' && state.profileSubView !== 'profile_home') {
    return { action: 'reset_profile_subview' };
  }

  if (state.activeTab !== 'inicio') {
    return { action: 'navigate_home' };
  }

  return { action: 'minimize_app' };
}

/**
 * Inicializa os recursos nativos do Capacitor no Android:
 * - StatusBar escura (#08090C)
 * - SplashScreen auto-hide seguro
 * - Ajuste automático de scroll para inputs quando o teclado virtual abre
 * - Listeners de botão Voltar do Android e ciclo de vida (background/resume)
 */
export function initCapacitorNativeShell(callbacks: {
  onHardwareBack: () => void;
  onAppBackground?: () => void;
  onAppResume?: () => void;
}): () => void {
  const cleanups: Array<() => void> = [];

  // Configuração de StatusBar e SplashScreen quando em dispositivo nativo
  if (isNativePlatform()) {
    StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#08090C' }).catch(() => {});
    SplashScreen.hide().catch(() => {});
  }

  // Tratamento de foco e scroll suave quando o teclado virtual abre no Android/Mobile
  const handleFocusIn = (event: FocusEvent) => {
    const target = event.target as HTMLElement | null;
    if (!target) return;
    const tag = target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') {
      setTimeout(() => {
        try {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch {
          // ignore
        }
      }, 220);
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('focusin', handleFocusIn, { passive: true });
    cleanups.push(() => window.removeEventListener('focusin', handleFocusIn));
  }

  if (isNativePlatform()) {
    const kbShowPromise = Keyboard.addListener('keyboardWillShow', () => {
      if (typeof document !== 'undefined') {
        document.body.setAttribute('data-keyboard-open', 'true');
        const activeEl = document.activeElement as HTMLElement | null;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
          setTimeout(() => {
            try {
              activeEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } catch {
              // ignore
            }
          }, 120);
        }
      }
    });

    const kbHidePromise = Keyboard.addListener('keyboardWillHide', () => {
      if (typeof document !== 'undefined') {
        document.body.removeAttribute('data-keyboard-open');
      }
    });

    const backPromise = CapacitorApp.addListener('backButton', () => {
      callbacks.onHardwareBack();
    });

    const statePromise = CapacitorApp.addListener('appStateChange', ({ isActive }) => {
      if (isActive) {
        callbacks.onAppResume?.();
      } else {
        callbacks.onAppBackground?.();
      }
    });

    cleanups.push(() => {
      kbShowPromise.then((h) => h.remove()).catch(() => {});
      kbHidePromise.then((h) => h.remove()).catch(() => {});
      backPromise.then((h) => h.remove()).catch(() => {});
      statePromise.then((h) => h.remove()).catch(() => {});
    });
  }

  return () => {
    for (const fn of cleanups) {
      try {
        fn();
      } catch {
        // ignore
      }
    }
  };
}

export function minimizeNativeApp(): void {
  if (isNativePlatform()) {
    CapacitorApp.minimizeApp().catch(() => {});
  }
}
