import { BiometricMetrics, BodyPartAnalysis, BodyPartKey, GoldenAnalysis } from '../types';

export const PHI = 1.618;

export function buildHypertrophyItem(
  key: BodyPartKey,
  shortLabel: string,
  label: string,
  formulaDesc: string,
  current: number,
  ideal: number
): BodyPartAnalysis {
  const currVal = Number(current) || 0;
  const delta = +(ideal - currVal).toFixed(1); // Positive = needs to gain X cm
  const accuracy = ideal > 0 ? Math.max(0, 100 - (Math.abs(delta) / ideal) * 100) : 0;

  // Semaphoric criteria for Avatar 3D:
  // RED: Needs hypertrophy > 2.0 cm
  // AMBER: Needs between 1.1 and 2.0 cm
  // GREEN: Within <= 1.0 cm (or exceeded) -> Maintain!
  let colorZone: 'red' | 'amber' | 'green' = 'green';
  let statusLabel = 'VERDE // MEDIDA OK (MANUTENÇÃO)';
  let extraSets = 0;
  let recommendedWeeklySets = 10;

  if (delta > 2.0) {
    colorZone = 'red';
    statusLabel = 'VERMELHO // PRIORIDADE DE HIPERTROFIA';
    extraSets = delta > 5.0 ? 2 : 1;
    recommendedWeeklySets = delta > 5.0 ? 18 : 15;
  } else if (delta > 1.0) {
    colorZone = 'amber';
    statusLabel = 'ÂMBAR // REFINAMENTO PRÓXIMO À META';
    extraSets = 1;
    recommendedWeeklySets = 12;
  }

  return {
    key,
    shortLabel,
    label,
    formulaDesc,
    current: currVal,
    ideal,
    delta,
    accuracy: +accuracy.toFixed(1),
    colorZone,
    statusLabel,
    extraSets,
    recommendedWeeklySets,
    isReductionTarget: false
  };
}

export function buildReductionItem(
  key: BodyPartKey,
  shortLabel: string,
  label: string,
  formulaDesc: string,
  current: number,
  ideal: number
): BodyPartAnalysis {
  const currVal = Number(current) || 0;
  const delta = +(ideal - currVal).toFixed(1); // Negative = needs to trim waist/hips
  const excess = +(currVal - ideal).toFixed(1);
  const accuracy = ideal > 0 ? Math.max(0, 100 - (Math.abs(delta) / ideal) * 100) : 0;

  let colorZone: 'red' | 'amber' | 'green' = 'green';
  let statusLabel = 'VERDE // LINHA ATLÉTICA OK (MANTER)';
  let needsCardioBoost = false;
  let recommendedWeeklySets = 8;

  if (excess > 2.0) {
    colorZone = 'red';
    statusLabel = 'VERMELHO // REDUZIR MEDIDA (CARDIO + VACUUM)';
    needsCardioBoost = true;
    recommendedWeeklySets = 14;
  } else if (excess > 1.0) {
    colorZone = 'amber';
    statusLabel = 'ÂMBAR // AJUSTE FINO DE DEFINIÇÃO';
    needsCardioBoost = true;
    recommendedWeeklySets = 10;
  }

  return {
    key,
    shortLabel,
    label,
    formulaDesc,
    current: currVal,
    ideal,
    delta,
    accuracy: +accuracy.toFixed(1),
    colorZone,
    statusLabel,
    extraSets: needsCardioBoost ? 1 : 0,
    recommendedWeeklySets,
    needsCardioBoost,
    isReductionTarget: true
  };
}

export function calculateGoldenAnalysis(metrics: BiometricMetrics): GoldenAnalysis {
  const altura = Number(metrics.altura) || 178;
  const pulso = Number(metrics.pulso) || 17.5;

  // 1. Adonis Index (Height and Golden Ratio Phi = 1.618)
  const cinturaIdeal = +(altura * 0.45).toFixed(1);
  const ombrosIdeais = +(cinturaIdeal * PHI).toFixed(1);
  const indiceAdonisAtual =
    metrics.cintura > 0 ? +(metrics.ombros / metrics.cintura).toFixed(3) : 0;

  // 2. McCallum Formula (Anchored on Wrist Bone Circumference)
  const peitoIdeal = +(pulso * 6.5).toFixed(1);
  const bracoIdeal = +(peitoIdeal * 0.36).toFixed(1);
  const coxaIdeal = +(peitoIdeal * 0.53).toFixed(1);
  const panturrilhaIdeal = +(peitoIdeal * 0.34).toFixed(1);
  const pescocoIdeal = +(peitoIdeal * 0.37).toFixed(1);
  const quadrilIdeal = +(peitoIdeal * 0.85).toFixed(1);

  const parts: Record<BodyPartKey, BodyPartAnalysis> = {
    ombros: buildHypertrophyItem(
      'ombros',
      'Ombros',
      'Ombros (Deltoides & Dorsal)',
      'Cintura Ideal × 1.618 (Adônis)',
      metrics.ombros,
      ombrosIdeais
    ),
    peito: buildHypertrophyItem(
      'peito',
      'Peitoral',
      'Peitoral / Caixa Torácica',
      'Pulso × 6.5 (100% McCallum)',
      metrics.peito,
      peitoIdeal
    ),
    braco: buildHypertrophyItem(
      'braco',
      'Braços',
      'Braços Contraídos',
      'Peito Ideal × 0.36 (36%)',
      metrics.braco,
      bracoIdeal
    ),
    coxa: buildHypertrophyItem(
      'coxa',
      'Coxas',
      'Coxas (Quadríceps/Post.)',
      'Peito Ideal × 0.53 (53%)',
      metrics.coxa,
      coxaIdeal
    ),
    panturrilha: buildHypertrophyItem(
      'panturrilha',
      'Panturrilhas',
      'Panturrilhas',
      'Peito Ideal × 0.34 (34%)',
      metrics.panturrilha,
      panturrilhaIdeal
    ),
    pescoco: buildHypertrophyItem(
      'pescoco',
      'Pescoço',
      'Pescoço',
      'Peito Ideal × 0.37 (37%)',
      metrics.pescoco,
      pescocoIdeal
    ),
    cintura: buildReductionItem(
      'cintura',
      'Cintura',
      'Cintura (Linha Abdominal)',
      'Altura × 0.45 (Adônis)',
      metrics.cintura,
      cinturaIdeal
    ),
    quadril: buildReductionItem(
      'quadril',
      'Quadril',
      'Quadril / Pelve',
      'Peito Ideal × 0.85 (85%)',
      metrics.quadril,
      quadrilIdeal
    )
  };

  const partsArray = Object.values(parts);
  const overallScore = +(
    partsArray.reduce((acc, item) => acc + item.accuracy, 0) / partsArray.length
  ).toFixed(1);

  const redZones = partsArray.filter((p) => p.colorZone === 'red');
  const greenZones = partsArray.filter((p) => p.colorZone === 'green');

  return {
    cinturaIdeal,
    ombrosIdeais,
    indiceAdonisAtual,
    peitoIdeal,
    bracoIdeal,
    coxaIdeal,
    panturrilhaIdeal,
    pescocoIdeal,
    quadrilIdeal,
    parts,
    partsArray,
    overallScore,
    redZones,
    greenZones,
    needsFatLossProtocol: parts.cintura.needsCardioBoost || parts.quadril.needsCardioBoost || false
  };
}
