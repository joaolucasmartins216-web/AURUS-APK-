import {
  BiometricMetrics,
  CheckinRecord,
  CompletedWorkout,
  UserProfile,
  WorkoutDay
} from '../types';
import {
  ALL_WEEK_DAYS,
  DEFAULT_METRICS,
  DEFAULT_PROFILE,
  HYBRID_WORKOUT_TEMPLATE,
  INITIAL_AI_WORKOUTS
} from './constants';

const JS_DAY_TO_WEEKDAY_ID = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'] as const;

export type WeekdayId = (typeof JS_DAY_TO_WEEKDAY_ID)[number];

/**
 * Identifica se um check-in foi gerado pela função de simulação trimestral (handleSeedDemoEvolution).
 * Preserva total compatibilidade com o formato salvo no localStorage e backups JSON.
 */
export function isDemoCheckin(chk: CheckinRecord): boolean {
  if (!chk || typeof chk.id !== 'string') return false;
  if (chk.id.startsWith('chk_demo_')) return true;
  if (
    typeof chk.note === 'string' &&
    (chk.note.includes('Mês 1 // Ponto de Partida') ||
      chk.note.includes('Mês 2 // Recalibração Híbrida') ||
      (chk.note.includes('Mês 3 // Medição Atual') && chk.dateFormatted === 'Hoje'))
  ) {
    return true;
  }
  return false;
}

/**
 * Separa check-ins reais de check-ins demonstrativos (simulação).
 */
export function splitCheckinsByOrigin(checkins: CheckinRecord[]): {
  realCheckins: CheckinRecord[];
  demoCheckins: CheckinRecord[];
} {
  const realCheckins: CheckinRecord[] = [];
  const demoCheckins: CheckinRecord[] = [];

  (checkins || []).forEach((chk) => {
    if (isDemoCheckin(chk)) {
      demoCheckins.push(chk);
    } else {
      realCheckins.push(chk);
    }
  });

  return { realCheckins, demoCheckins };
}

/**
 * Verifica se o perfil e as medidas correspondem a dados confirmados pelo usuário
 * ou se ainda são os valores padrão demonstrativos (DEFAULT_PROFILE / DEFAULT_METRICS).
 */
export function isUserDataConfirmed(params: {
  onboardingCompleted: boolean;
  profile: UserProfile;
  metrics: BiometricMetrics;
}): boolean {
  const { onboardingCompleted, profile, metrics } = params;

  if (onboardingCompleted) return true;

  // Verificar se o usuário alterou algum campo do perfil em relação ao DEFAULT_PROFILE
  const profileChanged =
    profile.nome !== DEFAULT_PROFILE.nome ||
    profile.experiencia !== DEFAULT_PROFILE.experiencia ||
    profile.diasSemana !== DEFAULT_PROFILE.diasSemana ||
    profile.esporteComplementar !== DEFAULT_PROFILE.esporteComplementar ||
    profile.objetivoPrincipal !== DEFAULT_PROFILE.objetivoPrincipal ||
    JSON.stringify(profile.diasSelecionados) !== JSON.stringify(DEFAULT_PROFILE.diasSelecionados);

  if (profileChanged) return true;

  // Verificar se o usuário alterou alguma medida biométrica em relação ao DEFAULT_METRICS
  const metricKeys = Object.keys(DEFAULT_METRICS) as Array<keyof BiometricMetrics>;
  const metricsChanged = metricKeys.some(
    (key) => Number(metrics[key]) !== Number(DEFAULT_METRICS[key])
  );

  return metricsChanged;
}

/**
 * Retorna o identificador do dia da semana ('seg' .. 'dom') no fuso horário local
 * a partir de um timestamp real em milissegundos.
 */
export function getWeekdayIdFromTimestamp(timestampMs: number): WeekdayId {
  const date = new Date(timestampMs);
  const jsDay = date.getDay(); // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado
  return JS_DAY_TO_WEEKDAY_ID[jsDay] || 'seg';
}

/**
 * Calcula o intervalo exato da semana atual (Segunda-feira 00:00:00.000 até Domingo 23:59:59.999)
 * no horário local do dispositivo.
 */
export function getCurrentWeekBounds(nowMs: number = Date.now()): {
  mondayStartMs: number;
  sundayEndMs: number;
  weekLabel: string;
} {
  const now = new Date(nowMs);
  const jsDay = now.getDay(); // 0 (Dom) .. 6 (Sáb)
  const diffToMonday = jsDay === 0 ? -6 : 1 - jsDay;

  const mondayStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + diffToMonday,
    0,
    0,
    0,
    0
  );
  const sundayEnd = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + diffToMonday + 6,
    23,
    59,
    59,
    999
  );

  const fmt = (d: Date) =>
    d.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit'
    });

  return {
    mondayStartMs: mondayStart.getTime(),
    sundayEndMs: sundayEnd.getTime(),
    weekLabel: `${fmt(mondayStart)} a ${fmt(sundayEnd)}`
  };
}

export interface CurrentWeekStats {
  weekLabel: string;
  mondayStartMs: number;
  sundayEndMs: number;
  totalSessionsAllTime: number;
  weeklySessionsCount: number;
  trainedDaysCount: number;
  trainedWeekdayIds: Set<string>;
  sessionsPerWeekday: Record<string, number>;
  completedRoutineDayIdsThisWeek: Set<string>;
  weeklyDurationSec: number;
  totalDurationSecAllTime: number;
  weeklyTonnage: number;
  weeklyCompletedSets: number;
  targetWeeklyDays: number;
  weeklyFrequencyPct: number;
  lastWorkout: CompletedWorkout | null;
}

/**
 * Calcula estimativa realista de duração (em minutos) para uma ficha de treino
 * com base nas séries, tempo médio de execução por série (~45s) e descanso configurado.
 */
export function estimateWorkoutDurationMin(workout: WorkoutDay | null | undefined): number {
  if (!workout || !Array.isArray(workout.exercises) || workout.exercises.length === 0) {
    return 0;
  }
  const totalSec = workout.exercises.reduce((acc, ex) => {
    const sets = Number(ex.totalSets || ex.baseSets) || 3;
    const restSec = Number(ex.rest) || 60;
    return acc + sets * (45 + restSec);
  }, 0);
  const mobilityMin = Array.isArray(workout.mobility) ? workout.mobility.length * 3 : 0;
  return Math.max(15, Math.round(totalSec / 60) + mobilityMin);
}

/**
 * Remove separadores técnicos artificiais ("//", "•••") para exibição em linguagem natural,
 * sem modificar os dados originais persistidos.
 */
export function cleanDisplayText(raw: string | null | undefined): string {
  if (!raw) return '';
  return raw
    .replace(/\s*\/\/\s*/g, ' · ')
    .replace(/\s*•••\s*/g, ' · ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extrai um rótulo curto e natural do grupamento muscular principal da ficha
 * para exibição nas colunas da Semana Atual (ex.: "Peito", "Costas", "Pernas", "Ombro").
 */
export function getShortMuscleLabel(workout: WorkoutDay | null | undefined): string {
  if (!workout) return 'Off';
  const text = `${workout.title || ''} ${workout.subtitle || ''}`.toLowerCase();
  if (text.includes('peito') || text.includes('peitoral')) return 'Peito';
  if (
    text.includes('costas') ||
    text.includes('dorsal') ||
    text.includes('dorsais') ||
    text.includes('v-taper')
  ) {
    return 'Costas';
  }
  if (
    text.includes('perna') ||
    text.includes('coxa') ||
    text.includes('quadríceps') ||
    text.includes('posterior') ||
    text.includes('inferior')
  ) {
    return 'Pernas';
  }
  if (text.includes('ombro') || text.includes('deltoide')) return 'Ombro';
  if (text.includes('braço') || text.includes('bíceps') || text.includes('tríceps')) return 'Braços';
  if (text.includes('glúteo')) return 'Glúteo';
  return 'Treino';
}

/**
 * Calcula a carga prevista real de uma ficha de treino exclusivamente quando
 * existem cargas salvas em lastExerciseWeights para os exercícios da ficha.
 * Retorna 0 quando ainda não há cargas registradas pelo usuário.
 */
export function calculatePredictedWorkoutLoad(
  workout: WorkoutDay | null | undefined,
  lastExerciseWeights: Record<string, number>
): { predictedLoadKg: number; exercisesWithLoadCount: number } {
  if (!workout || !Array.isArray(workout.exercises) || !lastExerciseWeights) {
    return { predictedLoadKg: 0, exercisesWithLoadCount: 0 };
  }

  let predictedLoadKg = 0;
  let exercisesWithLoadCount = 0;

  workout.exercises.forEach((ex) => {
    const savedWeight = Number(lastExerciseWeights[ex.id]) || 0;
    if (savedWeight <= 0) return;

    exercisesWithLoadCount += 1;
    const sets = Number(ex.totalSets || ex.baseSets) || 3;
    const repsMatch = String(ex.reps || '10').match(/\d+/);
    const baseReps = repsMatch ? Math.max(1, parseInt(repsMatch[0], 10)) : 10;
    predictedLoadKg += Math.round(sets * baseReps * savedWeight);
  });

  return { predictedLoadKg, exercisesWithLoadCount };
}

/**
 * Calcula as estatísticas semanais reais considerando a semana atual de Segunda a Domingo (horário local),
 * determinando o dia em que cada treino ocorreu pelo seu timestamp real e diferenciando
 * quantidade de sessões realizadas de quantidade de dias treinados.
 */
export function calculateCurrentWeekStats(
  workoutHistory: CompletedWorkout[],
  targetWeeklyDaysInput: number,
  nowMs: number = Date.now()
): CurrentWeekStats {
  const history = Array.isArray(workoutHistory) ? workoutHistory : [];
  const { mondayStartMs, sundayEndMs, weekLabel } = getCurrentWeekBounds(nowMs);

  const weeklySessions = history.filter(
    (wk) =>
      typeof wk.timestamp === 'number' &&
      wk.timestamp >= mondayStartMs &&
      wk.timestamp <= sundayEndMs
  );

  const trainedWeekdayIds = new Set<string>();
  const sessionsPerWeekday: Record<string, number> = {};
  const completedRoutineDayIdsThisWeek = new Set<string>();

  weeklySessions.forEach((wk) => {
    const realWeekdayId = getWeekdayIdFromTimestamp(wk.timestamp);
    trainedWeekdayIds.add(realWeekdayId);
    sessionsPerWeekday[realWeekdayId] = (sessionsPerWeekday[realWeekdayId] || 0) + 1;
    if (wk.dayId) {
      completedRoutineDayIdsThisWeek.add(wk.dayId);
    }
  });

  const weeklySessionsCount = weeklySessions.length;
  const trainedDaysCount = trainedWeekdayIds.size;

  const weeklyDurationSec = weeklySessions.reduce(
    (acc, wk) => acc + (Number(wk.durationSec) || 0),
    0
  );
  const totalDurationSecAllTime = history.reduce(
    (acc, wk) => acc + (Number(wk.durationSec) || 0),
    0
  );
  const weeklyTonnage = weeklySessions.reduce(
    (acc, wk) => acc + (Number(wk.tonnage) || 0),
    0
  );
  const weeklyCompletedSets = weeklySessions.reduce(
    (acc, wk) => acc + (Number(wk.completedSets) || 0),
    0
  );

  const targetWeeklyDays = Math.max(1, Number(targetWeeklyDaysInput) || 1);
  // Frequência semanal baseada nos dias distintos efetivamente treinados frente à meta de dias da semana
  const weeklyFrequencyPct = Math.min(
    100,
    Math.round((trainedDaysCount / targetWeeklyDays) * 100)
  );

  return {
    weekLabel,
    mondayStartMs,
    sundayEndMs,
    totalSessionsAllTime: history.length,
    weeklySessionsCount,
    trainedDaysCount,
    trainedWeekdayIds,
    sessionsPerWeekday,
    completedRoutineDayIdsThisWeek,
    weeklyDurationSec,
    totalDurationSecAllTime,
    weeklyTonnage,
    weeklyCompletedSets,
    targetWeeklyDays,
    weeklyFrequencyPct,
    lastWorkout: history.length > 0 ? history[0] : null
  };
}

export interface WorkoutScheduleResolution {
  todayWeekdayId: WeekdayId;
  recommendedWorkout: WorkoutDay | null;
  displayedWorkout: WorkoutDay | null;
  statusKind: 'today_scheduled' | 'next_scheduled' | 'manual_selection' | 'none';
  badgeLabel: string;
  helperText: string;
  isManualSelection: boolean;
}

/**
 * Identifica o treino programado para hoje (ou o próximo dia configurado na semana)
 * e diferencia claramente quando o usuário selecionou manualmente outra ficha.
 */
export function resolveWorkoutSchedule(
  dynamicWorkouts: WorkoutDay[],
  selectedDayId: string,
  trainedWeekdayIds: Set<string>,
  nowMs: number = Date.now()
): WorkoutScheduleResolution {
  const workouts = Array.isArray(dynamicWorkouts) ? dynamicWorkouts : [];
  const todayWeekdayId = getWeekdayIdFromTimestamp(nowMs);

  if (workouts.length === 0) {
    return {
      todayWeekdayId,
      recommendedWorkout: null,
      displayedWorkout: null,
      statusKind: 'none',
      badgeLabel: 'Sem programação ativa',
      helperText: 'Configure seus dias de treino no Perfil Biométrico.',
      isManualSelection: false
    };
  }

  const orderedIds = ALL_WEEK_DAYS.map((d) => d.id);
  const todayIndex = orderedIds.indexOf(todayWeekdayId);

  const todayWorkout = workouts.find((w) => w.id === todayWeekdayId) || null;
  const trainedToday = trainedWeekdayIds.has(todayWeekdayId);

  // Encontrar o próximo dia configurado na semana após hoje
  let nextWorkoutInWeek: WorkoutDay | null = null;
  for (let offset = 1; offset <= 7; offset++) {
    const candidateId = orderedIds[(todayIndex + offset) % 7];
    const found = workouts.find((w) => w.id === candidateId);
    if (found) {
      nextWorkoutInWeek = found;
      break;
    }
  }

  let recommendedWorkout: WorkoutDay;
  let recommendedKind: 'today_scheduled' | 'next_scheduled';

  if (todayWorkout && !trainedToday) {
    recommendedWorkout = todayWorkout;
    recommendedKind = 'today_scheduled';
  } else if (todayWorkout && trainedToday && nextWorkoutInWeek) {
    recommendedWorkout = nextWorkoutInWeek;
    recommendedKind = 'next_scheduled';
  } else if (todayWorkout) {
    recommendedWorkout = todayWorkout;
    recommendedKind = 'today_scheduled';
  } else {
    recommendedWorkout = nextWorkoutInWeek || workouts[0];
    recommendedKind = 'next_scheduled';
  }

  const displayedWorkout =
    workouts.find((w) => w.id === selectedDayId) || recommendedWorkout;

  const isManualSelection = displayedWorkout.id !== recommendedWorkout.id;

  if (isManualSelection) {
    return {
      todayWeekdayId,
      recommendedWorkout,
      displayedWorkout,
      statusKind: 'manual_selection',
      badgeLabel: 'Treino selecionado',
      helperText: displayedWorkout.dayName,
      isManualSelection: true
    };
  }

  if (recommendedKind === 'today_scheduled') {
    return {
      todayWeekdayId,
      recommendedWorkout,
      displayedWorkout,
      statusKind: 'today_scheduled',
      badgeLabel: 'Treino de hoje',
      helperText: displayedWorkout.dayName,
      isManualSelection: false
    };
  }

  return {
    todayWeekdayId,
    recommendedWorkout,
    displayedWorkout,
    statusKind: 'next_scheduled',
    badgeLabel: 'Próximo treino',
    helperText: trainedToday
      ? `Concluído hoje · ${displayedWorkout.dayName}`
      : displayedWorkout.dayName,
    isManualSelection: false
  };
}

export interface RecordedLoadItem {
  id: string;
  name: string;
  targetGroup: string;
  lastWeight: number;
  maxWeight: number;
  sessionsCount: number;
  hasProgressionHistory: boolean;
  statusLabel: string;
}

/**
 * Reconcilia cargas salvas tanto em workoutHistory quanto em lastExerciseWeights.
 * Não rotula um único peso salvo como recorde sem evidência de múltiplas sessões.
 */
export function buildRecordedLoadsList(
  workoutHistory: CompletedWorkout[],
  lastExerciseWeights: Record<string, number>,
  dynamicWorkouts: WorkoutDay[]
): RecordedLoadItem[] {
  const nameLookup: Record<string, { name: string; group: string }> = {};

  // Indexar exercícios dos templates conhecidos e dos treinos ativos
  const allKnownWorkoutLists = [
    ...(INITIAL_AI_WORKOUTS || []),
    ...(HYBRID_WORKOUT_TEMPLATE || []),
    ...(dynamicWorkouts || [])
  ];

  allKnownWorkoutLists.forEach((day) => {
    (day?.exercises || []).forEach((ex) => {
      if (ex && ex.id) {
        nameLookup[ex.id] = {
          name: ex.name,
          group: ex.partLabel || ex.targetGroup
        };
      }
    });
  });

  const map = new Map<
    string,
    {
      id: string;
      name: string;
      targetGroup: string;
      lastWeight: number;
      maxWeight: number;
      sessionsCount: number;
    }
  >();

  // 1. Processar workoutHistory do mais antigo para o mais recente
  const chronologicalHistory = [...(workoutHistory || [])].sort(
    (a, b) => (a.timestamp || 0) - (b.timestamp || 0)
  );

  chronologicalHistory.forEach((wk) => {
    (wk.exercisesSummary || []).forEach((exSum) => {
      const weight = Number(exSum.maxWeight) || 0;
      if (weight <= 0) return;

      const prev = map.get(exSum.exerciseId);
      const lookup = nameLookup[exSum.exerciseId];
      const name = exSum.name || lookup?.name || `Exercício (${exSum.exerciseId})`;
      const targetGroup = exSum.targetGroup || lookup?.group || 'geral';

      map.set(exSum.exerciseId, {
        id: exSum.exerciseId,
        name,
        targetGroup,
        lastWeight: weight,
        maxWeight: Math.max(prev?.maxWeight || 0, weight),
        sessionsCount: (prev?.sessionsCount || 0) + 1
      });
    });
  });

  // 2. Reconciliar com lastExerciseWeights (inclui pesos salvos/importados mesmo sem histórico detalhado)
  Object.entries(lastExerciseWeights || {}).forEach(([exId, rawWeight]) => {
    const weight = Number(rawWeight) || 0;
    if (weight <= 0) return;

    const existing = map.get(exId);
    const lookup = nameLookup[exId];

    if (existing) {
      map.set(exId, {
        ...existing,
        lastWeight: weight,
        maxWeight: Math.max(existing.maxWeight, weight)
      });
    } else {
      map.set(exId, {
        id: exId,
        name: lookup?.name || `Exercício (${exId})`,
        targetGroup: lookup?.group || 'musculação',
        lastWeight: weight,
        maxWeight: weight,
        sessionsCount: 0
      });
    }
  });

  return Array.from(map.values())
    .map((item) => {
      const hasProgressionHistory = item.sessionsCount >= 2;
      let statusLabel = 'Última carga salva';
      if (item.sessionsCount >= 2) {
        statusLabel = `${item.sessionsCount} sessões • Pico: ${item.maxWeight} kg`;
      } else if (item.sessionsCount === 1) {
        statusLabel = 'Carga registrada (1 sessão)';
      }

      return {
        ...item,
        hasProgressionHistory,
        statusLabel
      };
    })
    .slice(0, 6);
}
