import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
  signOut
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { isNativeAndroid, isRunningInAndroidWebView } from './capacitorBridge';

// Reuse initialized Firebase app if present, or initialize once
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const WORKSPACE_SCOPES = [
  'https://mail.google.com/',
  'https://www.googleapis.com/auth/gmail.addons.current.action.compose',
  'https://www.googleapis.com/auth/gmail.addons.current.message.action',
  'https://www.googleapis.com/auth/gmail.addons.current.message.metadata',
  'https://www.googleapis.com/auth/gmail.addons.current.message.readonly',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/gmail.insert',
  'https://www.googleapis.com/auth/gmail.labels',
  'https://www.googleapis.com/auth/gmail.metadata',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.settings.basic',
  'https://www.googleapis.com/auth/gmail.settings.sharing',
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/calendar.acls',
  'https://www.googleapis.com/auth/calendar.acls.readonly',
  'https://www.googleapis.com/auth/calendar.app.created',
  'https://www.googleapis.com/auth/calendar.calendarlist',
  'https://www.googleapis.com/auth/calendar.calendarlist.readonly',
  'https://www.googleapis.com/auth/calendar.calendars',
  'https://www.googleapis.com/auth/calendar.calendars.readonly',
  'https://www.googleapis.com/auth/calendar.events',
  'https://www.googleapis.com/auth/calendar.events.freebusy',
  'https://www.googleapis.com/auth/calendar.events.owned',
  'https://www.googleapis.com/auth/calendar.events.owned.readonly',
  'https://www.googleapis.com/auth/calendar.events.public.readonly',
  'https://www.googleapis.com/auth/calendar.events.readonly',
  'https://www.googleapis.com/auth/calendar.freebusy',
  'https://www.googleapis.com/auth/calendar.readonly',
  'https://www.googleapis.com/auth/calendar.settings.readonly'
];

const provider = new GoogleAuthProvider();
// Add Google Workspace scopes
WORKSPACE_SCOPES.forEach((scope) => {
  provider.addScope(scope);
});

// Flag to indicate if we are in the middle of a sign-in flow.
let isSigningIn = false;
// Cache the access token in memory (never localStorage per guidelines)
let cachedAccessToken: string | null = null;

export interface GoogleAuthEnvironmentInfo {
  isAndroidWebView: boolean;
  isNativeAndroidApk: boolean;
  popupSupported: boolean;
  warningMessage: string | null;
}

export function getGoogleAuthEnvironmentStatus(
  customUserAgent?: string
): GoogleAuthEnvironmentInfo {
  const inWebView = isRunningInAndroidWebView(customUserAgent);
  const nativeApk = isNativeAndroid();

  if (inWebView || nativeApk) {
    return {
      isAndroidWebView: true,
      isNativeAndroidApk: nativeApk,
      popupSupported: false,
      warningMessage:
        'No APK Android (WebView), o login Google por popup é bloqueado pela política de segurança do Google OAuth 2.0 (disallowed_useragent). Para usar no Android nativo, é necessário registrar o pacote com.aurusgym.app e a impressão digital SHA-1 no Google Cloud Console / Firebase e usar Custom Chrome Tabs.'
    };
  }

  return {
    isAndroidWebView: false,
    isNativeAndroidApk: false,
    popupSupported: true,
    warningMessage: null
  };
}

export const initAuth = (
  onAuthSuccess?: (user: User, token: string | null) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string }> => {
  const envStatus = getGoogleAuthEnvironmentStatus();
  if (envStatus.isAndroidWebView) {
    throw new Error(
      envStatus.warningMessage ||
        'Autenticação Google por popup não é suportada dentro da Android WebView sem configuração nativa SHA-1.'
    );
  }

  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Falha ao obter token de acesso Google Workspace');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign In error:', error);
    const code = String(error?.code || '');
    const msg = String(error?.message || '');
    if (
      code.includes('popup-blocked') ||
      code.includes('operation-not-supported') ||
      code.includes('unauthorized-domain') ||
      msg.includes('disallowed_useragent')
    ) {
      throw new Error(
        'O ambiente atual bloqueou a janela popup do Google OAuth (WebView / domínio não autorizado). No APK Android, configure o cliente OAuth Android com SHA-1 no Google Cloud Console.'
      );
    }
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const setAccessTokenInMemory = (token: string | null) => {
  cachedAccessToken = token;
};

export const logoutGoogle = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};
