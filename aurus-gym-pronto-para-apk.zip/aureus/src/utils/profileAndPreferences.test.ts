import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  buildFullBackupPayload,
  buildWorkoutHistoryCSV,
  DEFAULT_PREFERENCES,
  validateBackupPayload
} from './storage';
import { DEFAULT_METRICS, DEFAULT_PROFILE, INITIAL_AI_WORKOUTS } from './constants';
import { CheckinRecord, CompletedWorkout } from '../types';

describe('AURUS GYM — Etapa Final (Perfil, Preferências, CSV & Backup)', () => {
  it('buildFullBackupPayload inclui preferências e exercícios personalizados e passa na validação', () => {
    const customPrefs = {
      ...DEFAULT_PREFERENCES,
      enhancedContrast: true,
      weightUnit: 'lbs' as const,
      preferredWorkoutTime: '19:30'
    };

    const backup = buildFullBackupPayload(
      {
        ...DEFAULT_PROFILE,
        nome: 'João Silva',
        duracaoMediaMin: 75,
        modalidadesExtras: ['Musculação', 'Futsal / Esportes']
      },
      DEFAULT_METRICS,
      INITIAL_AI_WORKOUTS,
      { e1: 90 },
      [],
      [],
      null,
      [],
      customPrefs
    );

    assert.equal(backup.profile.nome, 'João Silva');
    assert.equal(backup.profile.duracaoMediaMin, 75);
    assert.equal(backup.preferences?.weightUnit, 'lbs');
    assert.equal(backup.preferences?.preferredWorkoutTime, '19:30');

    const validation = validateBackupPayload(backup);
    assert.equal(validation.valid, true);
    assert.equal(validation.data?.preferences?.enhancedContrast, true);
    assert.equal(validation.data?.preferences?.weightUnit, 'lbs');
    assert.equal(validation.data?.profile?.duracaoMediaMin, 75);
  });

  it('buildWorkoutHistoryCSV exporta sessões reais e diferencia check-ins reais de simulações', () => {
    const history: CompletedWorkout[] = [
      {
        id: 'w_real_1',
        dayId: 'seg',
        dayName: 'Segunda-feira',
        title: 'Treino A • Peito e Tríceps',
        tonnage: 4200,
        durationSec: 3120,
        completedSets: 12,
        totalSets: 15,
        cardioCompleted: true,
        dateFormatted: '10/11/2026',
        timestamp: 1762800000000,
        sessionRpe: 8.5,
        exercisesSummary: [
          {
            exerciseId: 'e1',
            name: 'Supino reto com barra',
            targetGroup: 'peito',
            setsCompleted: 4,
            totalSets: 4,
            maxWeight: 100
          }
        ]
      }
    ];

    const checkins: CheckinRecord[] = [
      {
        id: 'chk_real_100',
        note: 'Avaliação Real',
        peso: 94.2,
        ombros: 129,
        cintura: 92,
        peito: 108,
        braco: 40,
        coxa: 60,
        panturrilha: 42,
        indiceAdonis: 1.402,
        overallScore: 91.2,
        dateFormatted: '10/11/2026',
        timestamp: 1762800000000
      },
      {
        id: 'chk_demo_1',
        note: 'Mês 1 // Simulação',
        peso: 98.4,
        ombros: 125.5,
        cintura: 101,
        peito: 94,
        braco: 36.8,
        coxa: 56,
        panturrilha: 42,
        indiceAdonis: 1.243,
        overallScore: 84.1,
        dateFormatted: '90 dias atrás',
        timestamp: 1755000000000
      }
    ];

    const csv = buildWorkoutHistoryCSV(history, checkins);
    assert.ok(csv.includes('TREINO,w_real_1'));
    assert.ok(csv.includes('Supino reto com barra: 100kg (4/4)'));
    assert.ok(csv.includes('CHECKIN_REAL,chk_real_100'));
    assert.ok(csv.includes('CHECKIN_SIMULACAO,chk_demo_1'));
  });
});
