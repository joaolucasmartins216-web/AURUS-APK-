import React, { useState, useEffect, useMemo, useRef, useCallback, ChangeEvent } from 'react';
import { Flame, Sparkles } from 'lucide-react';
import {
  ActiveWorkoutSession,
  AppPreferences,
  BackupData,
  BiometricMetrics,
  BodyPartKey,
  CatalogExercise,
  CheckinRecord,
  CompletedWorkout,
  ExerciseItem,
  RestTimerState,
  SetLog,
  StopwatchState,
  UserProfile,
  WorkoutDay
} from './types';
import { calculateGoldenAnalysis } from './utils/goldenMath';
import { ALL_WEEK_DAYS, DEFAULT_PROFILE, DEFAULT_METRICS, INITIAL_AI_WORKOUTS, HYBRID_WORKOUT_TEMPLATE } from './utils/constants';
import {
  clearActiveSession,
  exportFullBackupJSON,
  loadActiveSession,
  loadCheckins,
  loadCustomExercises,
  loadCustomWorkouts,
  loadLastWeights,
  loadMetrics,
  loadOnboardingCompleted,
  loadPreferences,
  loadProfile,
  loadWorkoutHistory,
  saveActiveSession,
  saveCheckins,
  saveCustomExercises,
  saveCustomWorkouts,
  saveLastWeights,
  saveMetrics,
  saveOnboardingCompleted,
  savePreferences,
  saveProfile,
  saveWorkoutHistory,
  syncAllStorageWithNativePreferences,
  validateBackupPayload
} from './utils/storage';
import {
  BackNavigationStateSnapshot,
  initCapacitorNativeShell,
  minimizeNativeApp,
  resolveAndroidBackAction
} from './utils/capacitorBridge';
import {
  buildExerciseCatalog,
  synthesizeCatalogEntryFromWorkoutItem
} from './utils/exerciseCatalog';
import {
  generateAlgorithmicCoachReply,
  generateAlgorithmicExerciseSwap,
  generateAlgorithmicWorkoutPlan,
  requestGeminiApi
} from './utils/geminiService';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { BiometricsWizard } from './components/BiometricsWizard';
import { Scanner3DView } from './components/Scanner3DView';
import { ArenaView } from './components/ArenaView';
import { ExercisesLibraryView } from './components/ExercisesLibraryView';
import { EvolutionView } from './components/EvolutionView';
import { DailyGuideModal } from './components/DailyGuideModal';
import { GoogleWorkspaceView } from './components/GoogleWorkspaceView';
import { BottomNav } from './components/BottomNav';
import { DashboardHomeView } from './components/DashboardHomeView';
import { WorkoutSummaryModal } from './components/WorkoutSummaryModal';
import {
  ProfileSettingsView,
  ProfileSubView
} from './components/ProfileSettingsView';
import { OnboardingFlowModal } from './components/OnboardingFlowModal';
import {
  AiReformulateProtectionModal,
  BackupImportConfirmModal
} from './components/ResumeSessionModal';
import type { User } from 'firebase/auth';
import { initAuth, logoutGoogle } from './utils/googleAuth';
import { getWeekdayIdFromTimestamp, isDemoCheckin } from './utils/dashboardLogic';
import {
  adjustRestTimerState,
  applyAiReformulationWithSessionProtection,
  canSwapExerciseInSession,
  computeMainElapsedSec,
  computeRestRemainingSec,
  countCompletedSetsInSession,
  createInitialRestTimerState,
  createInitialStopwatchState,
  createSessionId,
  finalizeWorkoutSessionIdempotent,
  skipRestTimerState,
  startRestTimerState,
  startStopwatchState,
  syncRestTimerState,
  togglePauseRestTimerState,
  toggleSetCompletionPure,
  toggleStopwatchState
} from './utils/sessionEngine';

export default function App() {
  // Load persisted incomplete session once on boot
  const [initialPersistedSession] = useState<ActiveWorkoutSession | null>(() => loadActiveSession());

  // Navigation & UI States
  const [activeTab, setActiveTab] = useState<string>(() =>
    initialPersistedSession ? 'executar' : 'inicio'
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: 'emerald' | 'rose' | 'gold' } | null>(null);
  const [showDailyGuideModal, setShowDailyGuideModal] = useState(false);

  // Google Workspace Auth State (In-Memory Only, never stored in localStorage)
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);

  // Listen for Google Auth state changes
  useEffect(() => {
    const unsubscribe = initAuth((user, token) => {
      setGoogleUser(user);
      setGoogleAccessToken(token);
    });
    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, []);

  // Profile & Biometrics
  const [profile, setProfile] = useState<UserProfile>(loadProfile);
  const [metrics, setMetrics] = useState<BiometricMetrics>(loadMetrics);
  const [wizardStep, setWizardStep] = useState(1);
  const [onboardingCompleted, setOnboardingCompleted] = useState<boolean>(loadOnboardingCompleted);
  const [isSavingMetrics, setIsSavingMetrics] = useState(false);

  // 3D Scanner Selected Part
  const [selectedPartKey, setSelectedPartKey] = useState<BodyPartKey>('ombros');

  // Workouts & Arena
  const [customAiWorkouts, setCustomAiWorkouts] = useState<WorkoutDay[] | null>(loadCustomWorkouts);
  const [selectedDayId, setSelectedDayId] = useState<string>(() => {
    if (initialPersistedSession?.dayId) {
      return initialPersistedSession.dayId;
    }
    const savedProfile = loadProfile();
    const activeDays =
      Array.isArray(savedProfile.diasSelecionados) && savedProfile.diasSelecionados.length > 0
        ? savedProfile.diasSelecionados
        : ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'];
    const todayId = getWeekdayIdFromTimestamp(Date.now());
    if (activeDays.includes(todayId)) return todayId;
    const order = ALL_WEEK_DAYS.map((d) => d.id);
    const todayIdx = order.indexOf(todayId);
    for (let offset = 1; offset <= 7; offset++) {
      const candidate = order[(todayIdx + offset) % 7];
      if (activeDays.includes(candidate)) return candidate;
    }
    return activeDays[0] || 'seg';
  });
  const [activeExerciseIndex, setActiveExerciseIndex] = useState<number>(
    () => initialPersistedSession?.activeExerciseIndex ?? 0
  );
  const [arenaPhase, setArenaPhase] = useState<'mobilidade' | 'hipertrofia' | 'cardio'>(
    () => initialPersistedSession?.arenaPhase ?? 'hipertrofia'
  );

  // Arena session state
  const [activeSessionId, setActiveSessionId] = useState<string | null>(
    () => initialPersistedSession?.sessionId ?? null
  );
  const [sessionStartedAtMs, setSessionStartedAtMs] = useState<number | null>(
    () => initialPersistedSession?.startedAtMs ?? null
  );
  const [mobilityChecked, setMobilityChecked] = useState<Record<string, boolean>>(
    () => initialPersistedSession?.mobilityChecked ?? {}
  );
  const [cardioCompleted, setCardioCompleted] = useState<boolean>(
    () => initialPersistedSession?.cardioCompleted ?? false
  );
  const [sessionSets, setSessionSets] = useState<Record<string, SetLog[]>>(
    () => initialPersistedSession?.sessionSets ?? {}
  );
  const [lastExerciseWeights, setLastExerciseWeights] = useState<Record<string, number>>(loadLastWeights);
  const [isSavingWorkout, setIsSavingWorkout] = useState(false);
  const [swappingExerciseId, setSwappingExerciseId] = useState<string | null>(null);

  // Resume, Discard & Summary Modals
  const [showResumeBanner, setShowResumeBanner] = useState<boolean>(
    () => !!initialPersistedSession
  );
  const [showDiscardModal, setShowDiscardModal] = useState<boolean>(false);
  const [pendingSwitchDayId, setPendingSwitchDayId] = useState<string | null>(null);
  const [pendingAiReformulation, setPendingAiReformulation] = useState<{
    scope: 'week' | 'day';
    customPrompt?: string;
  } | null>(null);
  const [pendingBackupImport, setPendingBackupImport] = useState<{
    data: Partial<BackupData>;
    hasActiveSessionInBackup: boolean;
  } | null>(null);
  const [completedWorkoutSummary, setCompletedWorkoutSummary] = useState<CompletedWorkout | null>(
    null
  );
  const isFinishingRef = useRef<boolean>(false);

  // Timestamp-driven Stopwatch & Rest Timer
  const [stopwatch, setStopwatch] = useState<StopwatchState>(
    () => initialPersistedSession?.stopwatch ?? createInitialStopwatchState()
  );
  const [restTimer, setRestTimer] = useState<RestTimerState>(
    () => initialPersistedSession?.restTimer ?? createInitialRestTimerState(60)
  );
  const prevRestStatusRef = useRef<RestTimerState['status']>(
    initialPersistedSession?.restTimer.status ?? 'idle'
  );
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [timerFinishedAlert, setTimerFinishedAlert] = useState(false);

  // AI & Coach
  const [isGeneratingAiWorkout, setIsGeneratingAiWorkout] = useState(false);
  const [isAskingCoach, setIsAskingCoach] = useState(false);
  const [aiCoachMessages, setAiCoachMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: 'Olá! Sou o Arquiteto Biomecânico IA do AURUS GYM. Analisei suas medidas corporais pela Proporção Áurea (Φ = 1.618) e Fórmula de McCallum. Posso recalibrar toda a sua semana de treinos focando nas regiões prioritárias do seu Avatar 3D ou ajustar exercícios para o seu esporte!'
    }
  ]);

  // History, Checkins & Custom Exercises Catalog
  const [checkins, setCheckins] = useState<CheckinRecord[]>(loadCheckins);
  const [workoutHistory, setWorkoutHistory] = useState<CompletedWorkout[]>(loadWorkoutHistory);
  const [customExercises, setCustomExercises] = useState<CatalogExercise[]>(loadCustomExercises);
  const [preferences, setPreferences] = useState<AppPreferences>(loadPreferences);
  const [profileSubView, setProfileSubView] = useState<ProfileSubView>('profile_home');
  const [initialEvolutionExerciseId, setInitialEvolutionExerciseId] = useState<string | null>(null);
  const [initialEvolutionSubView, setInitialEvolutionSubView] = useState<
    'overview' | 'exercise' | 'history' | 'measures' | null
  >(null);
  const [initialExercisesSubView, setInitialExercisesSubView] = useState<
    'library' | 'routine' | 'ai' | null
  >(null);
  const [showOnboardingModal, setShowOnboardingModal] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('onboarding') === '1') return true;
    }
    return false;
  });
  const [isSavingCheckin, setIsSavingCheckin] = useState(false);

  // Toast Helper
  const showToast = useCallback((message: string, type: 'emerald' | 'rose' | 'gold' = 'gold') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveProfile(profile);
  }, [profile]);

  useEffect(() => {
    saveMetrics(metrics);
  }, [metrics]);

  useEffect(() => {
    saveCustomWorkouts(customAiWorkouts);
  }, [customAiWorkouts]);

  useEffect(() => {
    saveLastWeights(lastExerciseWeights);
  }, [lastExerciseWeights]);

  useEffect(() => {
    saveCheckins(checkins);
  }, [checkins]);

  useEffect(() => {
    saveWorkoutHistory(workoutHistory);
  }, [workoutHistory]);

  useEffect(() => {
    saveCustomExercises(customExercises);
  }, [customExercises]);

  useEffect(() => {
    savePreferences(preferences);
  }, [preferences]);

  // Pure Golden Ratio calculation
  const goldenAnalysis = useMemo(() => {
    return calculateGoldenAnalysis(metrics);
  }, [metrics]);

  // Active training days
  const activeSelectedDays = useMemo(() => {
    const list = profile.diasSelecionados;
    if (Array.isArray(list) && list.length > 0) return list;
    return ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'];
  }, [profile.diasSelecionados]);

  // Dynamic Workouts
  const dynamicWorkouts = useMemo(() => {
    const baseSource = customAiWorkouts || HYBRID_WORKOUT_TEMPLATE;
    const { parts, needsFatLossProtocol } = goldenAnalysis;

    const mergedDays = ALL_WEEK_DAYS.filter((d) => activeSelectedDays.includes(d.id)).map((dayMeta) => {
      const foundInCustom = (baseSource || []).find((item) => item.id === dayMeta.id);
      const foundInTemplate =
        HYBRID_WORKOUT_TEMPLATE.find((item) => item.id === dayMeta.id) || HYBRID_WORKOUT_TEMPLATE[0];
      return foundInCustom || foundInTemplate;
    });

    const activeSource = mergedDays.length > 0 ? mergedDays : baseSource;

    return activeSource.map((day) => {
      const adjustedExercises = (day.exercises || []).map((ex) => {
        const partData = parts[ex.targetGroup] || parts.ombros;
        const extraSets = customAiWorkouts ? 0 : partData.extraSets;
        const totalSets = (Number(ex.baseSets) || 3) + extraSets;

        return {
          ...ex,
          extraSets,
          totalSets,
          colorZone: partData.colorZone,
          statusLabel: partData.statusLabel,
          deltaValue: partData.delta,
          partLabel: partData.shortLabel
        };
      });

      const cardioBlock =
        day.cardioBlock ||
        (needsFatLossProtocol
          ? {
              mode: 'PROTOCOLO DEFINIÇÃO ÁUREA (ZONA VERMELHA CINTURA)',
              badgeColor: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
              protocol:
                day.id === 'ter' || day.id === 'qui'
                  ? '15 min Caminhada Inclinada (12% inclinação, 5.5 km/h - Zona 2 Lipolítica)'
                  : '12 min HIIT Metabólico (Bike/Esteira: 30s Sprint Forte / 60s Recuperação Ativa)',
              caloriesEst: '190 - 250 kcal',
              stretching:
                '8 min Descompressão Lombar + Alongamento de Psoas e Cadeia Posterior + 4 séries de Stomach Vacuum.'
            }
          : {
              mode: 'CONDICIONAMENTO ATLÉTICO & PERFORMANCE HÍBRIDA',
              badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
              protocol:
                day.id === 'ter' || day.id === 'qui'
                  ? `12 min Mobilidade Ativa + Agilidade/Pliometria preventiva (${profile.esporteComplementar})`
                  : '15 min Cardio Zona 2 Contínuo (Remo, Bike ou Corrida leve para VO2 Máx e recuperação)',
              caloriesEst: '140 - 180 kcal',
              stretching:
                '8 min Alongamento Miofascial Global (Foco em Dorsiflexão, Isquiotibiais e Cápsula do Ombro).'
            });

      const totalDaySets = adjustedExercises.reduce((acc, e) => acc + (e.totalSets || 3), 0);

      return {
        ...day,
        exercises: adjustedExercises,
        cardioBlock,
        totalDaySets
      };
    });
  }, [customAiWorkouts, goldenAnalysis, profile.esporteComplementar, activeSelectedDays]);

  const currentDayWorkout = useMemo(() => {
    return dynamicWorkouts.find((d) => d.id === selectedDayId) || dynamicWorkouts[0];
  }, [dynamicWorkouts, selectedDayId]);

  useEffect(() => {
    if (dynamicWorkouts.length > 0 && !dynamicWorkouts.some((d) => d.id === selectedDayId)) {
      setSelectedDayId(dynamicWorkouts[0].id);
    }
  }, [dynamicWorkouts, selectedDayId]);

  // Initialize sets for current day workout (preserving any existing or extra sets)
  useEffect(() => {
    if (!currentDayWorkout) return;
    setSessionSets((prev) => {
      let changed = false;
      const updated = { ...prev };
      currentDayWorkout.exercises.forEach((ex) => {
        const savedWeight = lastExerciseWeights[ex.id] ?? ex.defaultWeight ?? 20;
        const targetReps = parseInt(String(ex.reps).split('-')[1] || ex.reps, 10) || 10;
        const totalSets = ex.totalSets || ex.baseSets || 3;

        if (!updated[ex.id] || updated[ex.id].length === 0) {
          changed = true;
          updated[ex.id] = Array.from({ length: totalSets }, (_, idx) => ({
            setNumber: idx + 1,
            weight: savedWeight,
            reps: targetReps,
            rpe: 8,
            completed: false
          }));
        }
      });
      return changed ? updated : prev;
    });
  }, [currentDayWorkout, lastExerciseWeights]);

  // Pure effect to trigger finished alert, sound beep, and vibration when restTimer transitions from running to completed
  useEffect(() => {
    if (prevRestStatusRef.current === 'running' && restTimer.status === 'completed') {
      setTimerFinishedAlert(true);
      if (preferences.vibrationEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([120, 60, 120]);
        } catch {
          // ignore
        }
      }
      if (preferences.restSoundEnabled && typeof window !== 'undefined') {
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.value = 880;
            gain.gain.value = 0.08;
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.18);
          }
        } catch {
          // ignore
        }
      }
    }
    prevRestStatusRef.current = restTimer.status;
  }, [restTimer.status, preferences.restSoundEnabled, preferences.vibrationEnabled]);

  // Screen Wake Lock when Arena session is running and keepScreenAwake is enabled
  useEffect(() => {
    let wakeLockSentinel: any = null;
    const isRunning = stopwatch.status === 'running' && activeTab === 'executar';
    if (
      preferences.keepScreenAwake &&
      isRunning &&
      typeof navigator !== 'undefined' &&
      'wakeLock' in navigator
    ) {
      (navigator as any).wakeLock
        .request('screen')
        .then((sentinel: any) => {
          wakeLockSentinel = sentinel;
        })
        .catch(() => {
          // ignore if wakeLock permission not granted in iframe
        });
    }
    return () => {
      if (wakeLockSentinel && typeof wakeLockSentinel.release === 'function') {
        wakeLockSentinel.release().catch(() => {});
      }
    };
  }, [preferences.keepScreenAwake, stopwatch.status, activeTab]);

  // Timestamp-driven ticker + visibilitychange / focus resync
  useEffect(() => {
    const syncClocks = () => {
      const currentNow = Date.now();
      setNowMs(currentNow);
      setRestTimer((prev) => syncRestTimerState(prev, currentNow).nextState);
    };

    syncClocks();

    const isAnyTimerRunning =
      stopwatch.status === 'running' || restTimer.status === 'running';

    let intervalId: any = null;
    if (isAnyTimerRunning) {
      intervalId = setInterval(syncClocks, 500);
    }

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncClocks();
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('focus', syncClocks);

    return () => {
      if (intervalId) clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('focus', syncClocks);
    };
  }, [stopwatch.status, restTimer.status, restTimer.endTimeMs]);

  // Expose deterministic time-advance hook on window for automated background/pause tests
  useEffect(() => {
    (window as any).__AURUS_SIMULATE_TIME_ADVANCE_MS__ = (deltaMs: number) => {
      const shift = Math.max(0, Number(deltaMs) || 0);
      const currentNow = Date.now();
      setStopwatch((prev) => ({
        ...prev,
        startedAtMs: prev.startedAtMs !== null ? prev.startedAtMs - shift : null,
        lastResumedAtMs:
          prev.status === 'running' && prev.lastResumedAtMs !== null
            ? prev.lastResumedAtMs - shift
            : prev.lastResumedAtMs
      }));
      setRestTimer((prev) => {
        if (prev.status === 'running' && prev.endTimeMs !== null) {
          const shiftedEnd = prev.endTimeMs - shift;
          return syncRestTimerState({ ...prev, endTimeMs: shiftedEnd }, currentNow).nextState;
        }
        return prev;
      });
      setNowMs(currentNow);
    };
    return () => {
      delete (window as any).__AURUS_SIMULATE_TIME_ADVANCE_MS__;
    };
  }, []);

  // Compute live display values from timestamps
  const workoutElapsedSec = useMemo(
    () => computeMainElapsedSec(stopwatch, nowMs),
    [stopwatch, nowMs]
  );
  const workoutStopwatchRunning = stopwatch.status === 'running';

  const timerSeconds = useMemo(
    () => computeRestRemainingSec(restTimer, nowMs),
    [restTimer, nowMs]
  );
  const timerTarget = restTimer.targetSec;
  const timerRunning = restTimer.status === 'running';

  // Build current ActiveWorkoutSession snapshot and auto-save whenever session is running/paused
  const activeSessionSnapshot = useMemo<ActiveWorkoutSession | null>(() => {
    if (stopwatch.status === 'not_started') {
      return null;
    }
    const sid = activeSessionId || `sess_${sessionStartedAtMs || Date.now()}_${selectedDayId}`;
    return {
      sessionId: sid,
      dayId: selectedDayId,
      dayTitle: currentDayWorkout?.title || 'Treino',
      status: stopwatch.status,
      startedAtMs: sessionStartedAtMs || stopwatch.startedAtMs || Date.now(),
      updatedAtMs: Date.now(),
      activeExerciseIndex,
      arenaPhase,
      mobilityChecked,
      cardioCompleted,
      sessionSets,
      customExercisesAdded: [],
      stopwatch,
      restTimer
    };
  }, [
    stopwatch,
    activeSessionId,
    sessionStartedAtMs,
    selectedDayId,
    currentDayWorkout?.title,
    activeExerciseIndex,
    arenaPhase,
    mobilityChecked,
    cardioCompleted,
    sessionSets,
    restTimer
  ]);

  useEffect(() => {
    if (activeSessionSnapshot) {
      saveActiveSession(activeSessionSnapshot);
    }
  }, [activeSessionSnapshot]);

  // Hidratação e espelhamento nativo Android (@capacitor/preferences) na inicialização
  useEffect(() => {
    let mounted = true;
    syncAllStorageWithNativePreferences()
      .then(({ restoredKeys }) => {
        if (!mounted || restoredKeys.length === 0) return;
        setProfile(loadProfile());
        setMetrics(loadMetrics());
        setCustomAiWorkouts(loadCustomWorkouts());
        setLastExerciseWeights(loadLastWeights());
        setCheckins(loadCheckins());
        setWorkoutHistory(loadWorkoutHistory());
        setCustomExercises(loadCustomExercises());
        setPreferences(loadPreferences());
        setOnboardingCompleted(loadOnboardingCompleted());
        const restoredSession = loadActiveSession();
        if (restoredSession && stopwatch.status === 'not_started') {
          setSelectedDayId(restoredSession.dayId);
          setActiveExerciseIndex(restoredSession.activeExerciseIndex);
          setArenaPhase(restoredSession.arenaPhase);
          setMobilityChecked(restoredSession.mobilityChecked);
          setCardioCompleted(restoredSession.cardioCompleted);
          setSessionSets(restoredSession.sessionSets);
          setStopwatch(restoredSession.stopwatch);
          setRestTimer(restoredSession.restTimer);
          setActiveSessionId(restoredSession.sessionId);
          setSessionStartedAtMs(restoredSession.startedAtMs);
          setShowResumeBanner(true);
          setActiveTab('executar');
        }
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, []);

  // Referência atualizada para navegação pelo botão Voltar do Android e ciclo de vida nativo
  const backNavStateRef = useRef<BackNavigationStateSnapshot>({
    activeTab,
    profileSubView,
    isMobileMenuOpen: mobileMenuOpen,
    showGuideModal: showDailyGuideModal,
    showOnboardingModal,
    hasCompletedWorkoutSummary: Boolean(completedWorkoutSummary),
    showDiscardModal,
    hasPendingAiReformulation: Boolean(pendingAiReformulation),
    hasPendingBackupImport: Boolean(pendingBackupImport),
    isRestModalOpen: Boolean(restTimer.isModalOpen && restTimer.status !== 'idle')
  });

  useEffect(() => {
    backNavStateRef.current = {
      activeTab,
      profileSubView,
      isMobileMenuOpen: mobileMenuOpen,
      showGuideModal: showDailyGuideModal,
      showOnboardingModal,
      hasCompletedWorkoutSummary: Boolean(completedWorkoutSummary),
      showDiscardModal,
      hasPendingAiReformulation: Boolean(pendingAiReformulation),
      hasPendingBackupImport: Boolean(pendingBackupImport),
      isRestModalOpen: Boolean(restTimer.isModalOpen && restTimer.status !== 'idle')
    };
  }, [
    activeTab,
    profileSubView,
    mobileMenuOpen,
    showDailyGuideModal,
    showOnboardingModal,
    completedWorkoutSummary,
    showDiscardModal,
    pendingAiReformulation,
    pendingBackupImport,
    restTimer.isModalOpen,
    restTimer.status
  ]);

  const activeSessionRef = useRef<ActiveWorkoutSession | null>(activeSessionSnapshot);
  useEffect(() => {
    activeSessionRef.current = activeSessionSnapshot;
  }, [activeSessionSnapshot]);

  useEffect(() => {
    const handleHardwareBack = () => {
      const decision = resolveAndroidBackAction(backNavStateRef.current);
      if (decision.action === 'close_modal') {
        switch (decision.target) {
          case 'rest_modal':
            setRestTimer((prev) => ({ ...prev, isModalOpen: false }));
            break;
          case 'discard_modal':
            setShowDiscardModal(false);
            setPendingSwitchDayId(null);
            break;
          case 'ai_reformulation_modal':
            setPendingAiReformulation(null);
            break;
          case 'backup_import_modal':
            setPendingBackupImport(null);
            break;
          case 'workout_summary_modal':
            setCompletedWorkoutSummary(null);
            break;
          case 'guide_modal':
            setShowDailyGuideModal(false);
            break;
          case 'onboarding_modal':
            setShowOnboardingModal(false);
            break;
          case 'mobile_menu':
            setMobileMenuOpen(false);
            break;
        }
        return decision;
      }

      if (decision.action === 'reset_profile_subview') {
        setProfileSubView('profile_home');
        return decision;
      }

      if (decision.action === 'navigate_home') {
        setActiveTab('inicio');
        return decision;
      }

      minimizeNativeApp();
      return decision;
    };

    // Expõe hook determinístico para testes automatizados do botão Voltar do Android
    (window as any).__AURUS_TRIGGER_ANDROID_BACK__ = handleHardwareBack;

    const cleanupShell = initCapacitorNativeShell({
      onHardwareBack: () => {
        handleHardwareBack();
      },
      onAppBackground: () => {
        if (activeSessionRef.current) {
          saveActiveSession(activeSessionRef.current);
        }
        void syncAllStorageWithNativePreferences();
      },
      onAppResume: () => {
        const currentNow = Date.now();
        setNowMs(currentNow);
        setRestTimer((prev) => syncRestTimerState(prev, currentNow).nextState);
      }
    });

    return () => {
      delete (window as any).__AURUS_TRIGGER_ANDROID_BACK__;
      cleanupShell();
    };
  }, []);

  // Explicit helper to ensure session is started when user initiates workout or logs a set
  const ensureSessionStarted = useCallback(
    (dayIdOverride?: string) => {
      const currentNow = Date.now();
      const targetDay = dayIdOverride || selectedDayId;
      setActiveSessionId((prev) => prev || createSessionId(currentNow, targetDay));
      setSessionStartedAtMs((prev) => prev || currentNow);
      setStopwatch((prev) =>
        prev.status === 'not_started' ? startStopwatchState(prev, currentNow) : prev
      );
      setNowMs(currentNow);
    },
    [selectedDayId]
  );

  const handleStartSessionExplicit = useCallback(() => {
    ensureSessionStarted();
    setShowResumeBanner(false);
    showToast('Sessão de treino iniciada! Bom treino!', 'emerald');
  }, [ensureSessionStarted, showToast]);

  const handleStartWorkoutFromDashboard = useCallback(
    (dayId?: string) => {
      const targetDayId = dayId || selectedDayId;
      // If an active session already exists on another day, navigate to Arena and show Resume Banner
      if (stopwatch.status !== 'not_started' && targetDayId !== selectedDayId) {
        setShowResumeBanner(true);
        setActiveTab('executar');
        return;
      }
      if (targetDayId !== selectedDayId) {
        setSelectedDayId(targetDayId);
        setActiveExerciseIndex(0);
      }
      ensureSessionStarted(targetDayId);
      setActiveTab('executar');
    },
    [selectedDayId, stopwatch.status, ensureSessionStarted]
  );

  const handleSelectDayInArena = useCallback(
    (newDayId: string) => {
      if (newDayId === selectedDayId) return;
      const { completedSets } = countCompletedSetsInSession(
        currentDayWorkout?.exercises || [],
        sessionSets
      );
      if (stopwatch.status !== 'not_started' || completedSets > 0) {
        // Protect active session from accidental loss
        setPendingSwitchDayId(newDayId);
        setShowDiscardModal(true);
        return;
      }
      setSelectedDayId(newDayId);
      setActiveExerciseIndex(0);
    },
    [selectedDayId, currentDayWorkout?.exercises, sessionSets, stopwatch.status]
  );

  const handleSelectDayOnDashboard = useCallback(
    (newDayId: string) => {
      if (newDayId === selectedDayId) return;
      if (stopwatch.status !== 'not_started') {
        showToast(
          'Há um treino em andamento na Arena. Continue ou descarte a sessão atual antes de trocar de dia.',
          'gold'
        );
        setShowResumeBanner(true);
        setActiveTab('executar');
        return;
      }
      setSelectedDayId(newDayId);
      setActiveExerciseIndex(0);
    },
    [selectedDayId, stopwatch.status, showToast]
  );

  const handleToggleStopwatch = useCallback(() => {
    const currentNow = Date.now();
    if (stopwatch.status === 'not_started') {
      ensureSessionStarted();
      return;
    }
    setStopwatch((prev) => toggleStopwatchState(prev, currentNow));
    setNowMs(currentNow);
  }, [stopwatch.status, ensureSessionStarted]);

  const handleStartRestTimer = useCallback(
    (seconds: number, meta?: { exercise?: ExerciseItem; completedSetNumber?: number; updatedSets?: SetLog[] }) => {
      const currentNow = Date.now();
      ensureSessionStarted();
      setTimerFinishedAlert(false);

      const ex = meta?.exercise || currentDayWorkout?.exercises[activeExerciseIndex];
      const setsForEx = meta?.updatedSets || (ex ? sessionSets[ex.id] || [] : []);
      const nextPending = setsForEx.find((s) => !s.completed);

      setRestTimer(
        startRestTimerState(seconds, currentNow, {
          exerciseId: ex?.id ?? null,
          exerciseName: ex?.name ?? null,
          completedSetNumber: meta?.completedSetNumber ?? null,
          nextSetNumber: nextPending?.setNumber ?? null,
          nextSetWeight: nextPending?.weight ?? null,
          nextSetReps: nextPending?.reps ?? null,
          openModal: true
        })
      );
      setNowMs(currentNow);
    },
    [ensureSessionStarted, currentDayWorkout, activeExerciseIndex, sessionSets]
  );

  const handleAdjustRestTimer = useCallback((deltaSec: number) => {
    const currentNow = Date.now();
    setRestTimer((prev) => adjustRestTimerState(prev, deltaSec, currentNow));
    setNowMs(currentNow);
  }, []);

  const handleTogglePauseRestTimer = useCallback(() => {
    const currentNow = Date.now();
    setRestTimer((prev) => togglePauseRestTimerState(prev, currentNow));
    setNowMs(currentNow);
  }, []);

  const handleResetRestTimer = useCallback(() => {
    setRestTimer((prev) => skipRestTimerState(prev));
  }, []);

  const handleOpenRestModal = useCallback(() => {
    setRestTimer((prev) => {
      if (prev.status === 'idle') {
        const activeEx = currentDayWorkout?.exercises[activeExerciseIndex];
        return startRestTimerState(activeEx?.rest || 60, Date.now(), {
          exerciseId: activeEx?.id ?? null,
          exerciseName: activeEx?.name ?? null,
          openModal: true
        });
      }
      return { ...prev, isModalOpen: true };
    });
  }, [currentDayWorkout, activeExerciseIndex]);

  const handleMinimizeRestModal = useCallback(() => {
    setRestTimer((prev) => ({ ...prev, isModalOpen: false }));
  }, []);

  const resetActiveSessionState = useCallback(
    (targetDayWorkout?: WorkoutDay, weightsMap: Record<string, number> = lastExerciseWeights) => {
      clearActiveSession();
      setActiveSessionId(null);
      setSessionStartedAtMs(null);
      setStopwatch(createInitialStopwatchState());
      setRestTimer(createInitialRestTimerState(60));
      setMobilityChecked({});
      setCardioCompleted(false);
      setActiveExerciseIndex(0);
      setArenaPhase('hipertrofia');
      setShowResumeBanner(false);
      setShowDiscardModal(false);
      setTimerFinishedAlert(false);

      if (targetDayWorkout) {
        const freshSets: Record<string, SetLog[]> = {};
        targetDayWorkout.exercises.forEach((ex) => {
          const savedWeight = weightsMap[ex.id] ?? ex.defaultWeight ?? 20;
          const targetReps = parseInt(String(ex.reps).split('-')[1] || ex.reps, 10) || 10;
          const totalSets = ex.totalSets || ex.baseSets || 3;
          freshSets[ex.id] = Array.from({ length: totalSets }, (_, idx) => ({
            setNumber: idx + 1,
            weight: savedWeight,
            reps: targetReps,
            rpe: 8,
            completed: false
          }));
        });
        setSessionSets(freshSets);
      } else {
        setSessionSets({});
      }
    },
    [lastExerciseWeights]
  );

  const handleConfirmDiscardSession = useCallback(() => {
    const targetDayId = pendingSwitchDayId || selectedDayId;
    setPendingSwitchDayId(null);
    setSelectedDayId(targetDayId);

    const targetDay =
      dynamicWorkouts.find((d) => d.id === targetDayId) || currentDayWorkout;
    resetActiveSessionState(targetDay, lastExerciseWeights);

    showToast('Sessão descartada. Nenhum dado foi salvo no histórico.', 'gold');
  }, [
    pendingSwitchDayId,
    selectedDayId,
    dynamicWorkouts,
    currentDayWorkout,
    lastExerciseWeights,
    resetActiveSessionState,
    showToast
  ]);

  const handleCancelDiscardSession = useCallback(() => {
    setPendingSwitchDayId(null);
    setShowDiscardModal(false);
  }, []);

  const handleMetricChange = (field: keyof BiometricMetrics, value: any) => {
    setMetrics((prev) => ({
      ...prev,
      [field]: value === '' ? '' : parseFloat(value) || 0
    }));
  };

  const handleProfileChange = (field: keyof UserProfile, value: any) => {
    setProfile((prev) => ({
      ...prev,
      [field]: value
    }));
  };

  const handleToggleTrainingDay = (dayId: string) => {
    const currentDays = profile.diasSelecionados || ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'];
    let nextDays: string[];
    if (currentDays.includes(dayId)) {
      if (currentDays.length <= 1) {
        showToast('Mantenha pelo menos 1 dia de treino selecionado na semana!', 'rose');
        return;
      }
      nextDays = currentDays.filter((d) => d !== dayId);
    } else {
      const order = ALL_WEEK_DAYS.map((d) => d.id);
      nextDays = [...currentDays, dayId].sort((a, b) => order.indexOf(a) - order.indexOf(b));
    }
    const updated = {
      ...profile,
      diasSelecionados: nextDays,
      diasSemana: nextDays.length
    };
    setProfile(updated);
  };

  const handleSaveAndFinishWizard = (goToTab = 'scanner') => {
    setIsSavingMetrics(true);
    saveMetrics(metrics);
    saveProfile(profile);
    saveOnboardingCompleted(true);
    setOnboardingCompleted(true);
    setIsSavingMetrics(false);
    showToast('Diagnóstico Biométrico salvo! Avatar 3D calibrado.', 'emerald');
    setActiveTab(goToTab);
  };

  const handleUpdateSetField = (
    exerciseId: string,
    setIndex: number,
    field: keyof SetLog,
    value: any
  ) => {
    setSessionSets((prev) => {
      const list = [...(prev[exerciseId] || [])];
      if (!list[setIndex]) return prev;
      list[setIndex] = {
        ...list[setIndex],
        [field]: value === '' ? '' : Number(value)
      };
      return { ...prev, [exerciseId]: list };
    });
  };

  const handleStepSetWeight = (exerciseId: string, setIndex: number, deltaKg: number) => {
    setSessionSets((prev) => {
      const list = [...(prev[exerciseId] || [])];
      if (!list[setIndex]) return prev;
      const currentW = Number(list[setIndex].weight) || 0;
      list[setIndex] = {
        ...list[setIndex],
        weight: Math.max(0, +(currentW + deltaKg).toFixed(1))
      };
      return { ...prev, [exerciseId]: list };
    });
  };

  const handleStepSetReps = (exerciseId: string, setIndex: number, deltaReps: number) => {
    setSessionSets((prev) => {
      const list = [...(prev[exerciseId] || [])];
      if (!list[setIndex]) return prev;
      const currentR = Number(list[setIndex].reps) || 0;
      list[setIndex] = {
        ...list[setIndex],
        reps: Math.max(1, currentR + deltaReps)
      };
      return { ...prev, [exerciseId]: list };
    });
  };

  const handleAddExtraSet = (exerciseId: string) => {
    ensureSessionStarted();
    setSessionSets((prev) => {
      const list = [...(prev[exerciseId] || [])];
      const lastSet = list[list.length - 1] || { weight: 20, reps: 10, rpe: 8 };
      list.push({
        setNumber: list.length + 1,
        weight: lastSet.weight,
        reps: lastSet.reps,
        rpe: lastSet.rpe,
        completed: false
      });
      return { ...prev, [exerciseId]: list };
    });
    showToast('Série extra adicionada ao exercício!', 'gold');
  };

  const handleToggleSetCompleted = (exercise: ExerciseItem, setIndex: number) => {
    const result = toggleSetCompletionPure(sessionSets, exercise, setIndex);
    if (!result.toggledSet) return;
    ensureSessionStarted();
    setSessionSets(result.updatedSessionSets);
    if (result.shouldStartRest) {
      handleStartRestTimer(result.restDurationSec, {
        exercise,
        completedSetNumber: result.toggledSet.setNumber,
        updatedSets: result.updatedExerciseSets
      });
    }
  };

  const handleAddCustomExercise = (name: string) => {
    ensureSessionStarted();
    const newId = `ex_custom_${Date.now()}`;
    const customEx: ExerciseItem = {
      id: newId,
      name,
      targetGroup: selectedPartKey || 'ombros',
      baseSets: 3,
      reps: '10-12',
      rest: 60,
      cadence: '2-0-1-1',
      defaultWeight: 20,
      tip: 'Exercício adicionado manualmente na sessão da Arena.'
    };

    const currentList = customAiWorkouts ? [...customAiWorkouts] : [...HYBRID_WORKOUT_TEMPLATE];
    const updatedList = currentList.map((d) => {
      if (d.id === selectedDayId) {
        return {
          ...d,
          exercises: [...d.exercises, customEx]
        };
      }
      return d;
    });

    setCustomAiWorkouts(updatedList);
    setCustomExercises((prev) => {
      const synthesized = synthesizeCatalogEntryFromWorkoutItem(customEx, true);
      if (prev.some((item) => item.id === synthesized.id || item.name.toLowerCase() === synthesized.name.toLowerCase())) {
        return prev;
      }
      return [synthesized, ...prev];
    });
    setActiveExerciseIndex(currentDayWorkout.exercises.length);
    showToast('Exercício adicionado à fila de hoje e reconhecido no catálogo!', 'emerald');
  };

  const handleFinishWorkout = () => {
    if (isFinishingRef.current || isSavingWorkout) return;

    const { completedSets } = countCompletedSetsInSession(
      currentDayWorkout.exercises,
      sessionSets
    );

    if (completedSets === 0) {
      showToast('Conclua pelo menos uma série na Arena antes de finalizar!', 'rose');
      return;
    }

    isFinishingRef.current = true;
    setIsSavingWorkout(true);

    try {
      const finishNowMs = Date.now();
      const stableSessionId =
        activeSessionId || createSessionId(sessionStartedAtMs || finishNowMs, currentDayWorkout.id);
      const effectiveDurationSec = Math.max(1, computeMainElapsedSec(stopwatch, finishNowMs));

      const result = finalizeWorkoutSessionIdempotent({
        sessionId: stableSessionId,
        startedAtMs: sessionStartedAtMs || finishNowMs - effectiveDurationSec * 1000,
        durationSec: effectiveDurationSec,
        dayWorkout: currentDayWorkout,
        sessionSets,
        cardioCompleted,
        workoutHistory,
        lastExerciseWeights,
        nowMs: finishNowMs
      });

      // Persist workoutHistory and lastExerciseWeights BEFORE clearing active session
      saveLastWeights(result.updatedLastWeights);
      saveWorkoutHistory(result.updatedHistory);
      setLastExerciseWeights(result.updatedLastWeights);
      setWorkoutHistory(result.updatedHistory);

      // Clear active session state and reset Arena for next session consistently
      resetActiveSessionState(currentDayWorkout, result.updatedLastWeights);

      // Open the Stitch Workout Summary screen
      setCompletedWorkoutSummary(result.completedWorkout);
      showToast(
        `Treino finalizado com sucesso! Tonelagem total: ${result.completedWorkout.tonnage.toLocaleString('pt-BR')} kg.`,
        'emerald'
      );
    } finally {
      setIsSavingWorkout(false);
      setTimeout(() => {
        isFinishingRef.current = false;
      }, 300);
    }
  };

  const handleUpdateSummaryMeta = useCallback(
    (workoutId: string, rpe: number | undefined, notes: string) => {
      setCompletedWorkoutSummary((prev) =>
        prev && prev.id === workoutId
          ? { ...prev, sessionRpe: rpe, sessionNotes: notes }
          : prev
      );
      setWorkoutHistory((prev) => {
        const updated = prev.map((wk) =>
          wk.id === workoutId ? { ...wk, sessionRpe: rpe, sessionNotes: notes } : wk
        );
        saveWorkoutHistory(updated);
        return updated;
      });
    },
    []
  );

  // Execute AI Workout Reformulation with explicit resolution
  const executeReformulateWorkout = async (
    options: { scope: 'week' | 'day'; customPrompt?: string },
    resolution: 'preserve_active' | 'replace_active'
  ) => {
    setPendingAiReformulation(null);
    setIsGeneratingAiWorkout(true);
    showToast(
      options.scope === 'day'
        ? `A IA está reformulando o treino de ${currentDayWorkout?.dayName}...`
        : `A IA está montando sua divisão nos ${activeSelectedDays.length} dias selecionados...`,
      'gold'
    );

    try {
      const prompt = `Reformule o treino do atleta ${profile.nome} (${options.scope === 'day' ? 'apenas hoje' : 'semana toda'}). Pedido: ${options.customPrompt || 'Otimizar divisão biomecânica'}`;
      const systemInstruction = 'Você é o Arquiteto Biomecânico do AUREUS (Proporção Áurea Phi = 1.618 e Fórmula de McCallum). Retorne um array JSON de treinos.';

      const payload = {
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] },
        generationConfig: { responseMimeType: 'application/json' }
      };

      let newWorkouts: WorkoutDay[];
      try {
        const text = await requestGeminiApi(payload);
        newWorkouts = JSON.parse(text);
      } catch {
        newWorkouts = generateAlgorithmicWorkoutPlan(
          profile,
          metrics,
          goldenAnalysis,
          activeSelectedDays,
          options.scope,
          currentDayWorkout?.id,
          options.customPrompt
        );
      }

      const applied = applyAiReformulationWithSessionProtection({
        currentCustomWorkouts: customAiWorkouts,
        baseTemplate: HYBRID_WORKOUT_TEMPLATE,
        generatedWorkouts: newWorkouts,
        scope: options.scope,
        currentDayWorkout,
        sessionSets,
        isSessionActive: stopwatch.status !== 'not_started',
        resolution
      });

      setCustomAiWorkouts(applied.updatedCustomWorkouts);

      if (applied.shouldResetActiveSession) {
        const nextCurrentDay =
          applied.updatedCustomWorkouts.find((d) => d.id === currentDayWorkout.id) ||
          applied.updatedCustomWorkouts[0];
        resetActiveSessionState(nextCurrentDay, lastExerciseWeights);
        showToast(
          options.scope === 'day'
            ? `Treino de ${currentDayWorkout?.dayName} reformulado com sucesso!`
            : `Divisão de ${activeSelectedDays.length} dias reformulada com sucesso!`,
          'emerald'
        );
      } else {
        setSessionSets(applied.updatedSessionSets);
        showToast(
          applied.preservedCompletedExercisesCount > 0
            ? `Rotina atualizada! Seus ${applied.preservedCompletedExercisesCount} exercício(s) com séries concluídas hoje foram preservados.`
            : 'Rotina atualizada preservando sua sessão ativa em andamento!',
          'emerald'
        );
      }
    } catch (e) {
      console.error('Error reformulating workout:', e);
      showToast('A IA aplicou a reformulação algorítmica direta.', 'gold');
    } finally {
      setIsGeneratingAiWorkout(false);
    }
  };

  // AI Workout Reformulation entry point (protects active sessions)
  const handleReformulateWorkout = async (options: {
    scope: 'week' | 'day';
    customPrompt?: string;
  }) => {
    const { completedSets } = countCompletedSetsInSession(
      currentDayWorkout?.exercises || [],
      sessionSets
    );
    if (stopwatch.status !== 'not_started' || completedSets > 0) {
      setPendingAiReformulation(options);
      return;
    }
    await executeReformulateWorkout(options, 'replace_active');
  };

  // Swap Single Exercise via AI (blocks swapping exercises that already have completed sets)
  const handleSwapSingleExercise = async (exercise: ExerciseItem, reason: string) => {
    const swapPermission = canSwapExerciseInSession(exercise.id, sessionSets);
    if (!swapPermission.allowed) {
      showToast(
        swapPermission.reason ||
          'Não é possível substituir um exercício que já possui séries concluídas nesta sessão.',
        'rose'
      );
      return;
    }

    setSwappingExerciseId(exercise.id);
    try {
      const prompt = `Substitua o exercício ${exercise.name} (alvo: ${exercise.targetGroup}) por outro equivalente. Motivo: ${reason}`;
      const payload = {
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: 'application/json' }
      };

      let newEx: ExerciseItem;
      try {
        const text = await requestGeminiApi(payload);
        const data = JSON.parse(text);
        newEx = {
          ...exercise,
          ...data,
          id: `ex_swap_${Date.now()}`,
          targetGroup: exercise.targetGroup
        };
      } catch {
        newEx = generateAlgorithmicExerciseSwap(exercise, reason);
      }

      const baseList = customAiWorkouts ? [...customAiWorkouts] : [...HYBRID_WORKOUT_TEMPLATE];
      const updatedList = baseList.map((day) => {
        if (day.id !== currentDayWorkout.id) return day;
        return {
          ...day,
          exercises: day.exercises.map((ex) => (ex.id === exercise.id ? newEx : ex))
        };
      });

      setCustomAiWorkouts(updatedList);
      setSessionSets((prev) => {
        const next = { ...prev };
        delete next[exercise.id];
        const savedWeight = lastExerciseWeights[newEx.id] ?? newEx.defaultWeight ?? 20;
        const targetReps = parseInt(String(newEx.reps).split('-')[1] || newEx.reps, 10) || 10;
        const totalSets = newEx.totalSets || newEx.baseSets || 3;
        next[newEx.id] = Array.from({ length: totalSets }, (_, idx) => ({
          setNumber: idx + 1,
          weight: savedWeight,
          reps: targetReps,
          rpe: 8,
          completed: false
        }));
        return next;
      });
      showToast(`Exercício substituído por: ${newEx.name}`, 'emerald');
    } catch {
      showToast('Não foi possível trocar no momento.', 'rose');
    } finally {
      setSwappingExerciseId(null);
    }
  };

  // Ask AI Coach
  const handleAskCoach = async (question: string) => {
    const userMsg = { role: 'user' as const, text: question };
    setAiCoachMessages((prev) => [...prev, userMsg]);
    setIsAskingCoach(true);

    try {
      const payload = {
        contents: [{ role: 'user', parts: [{ text: question }] }],
        systemInstruction: {
          parts: [
            {
              text: `Você é o Coach Biomecânico do AUREUS (Proporção Áurea Phi = 1.618 e McCallum). Responda ao atleta ${profile.nome} em até 150 palavras com foco em simetria e técnica.`
            }
          ]
        }
      };

      let reply: string;
      try {
        reply = await requestGeminiApi(payload);
      } catch {
        reply = generateAlgorithmicCoachReply(question, profile, metrics, goldenAnalysis);
      }

      setAiCoachMessages((prev) => [...prev, { role: 'assistant', text: reply }]);
    } catch {
      setAiCoachMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Foque na cadência excêntrica de 3s e mantenha 16 séries semanais nos seus pontos vermelhos!'
        }
      ]);
    } finally {
      setIsAskingCoach(false);
    }
  };

  // Checkins
  const handleAddCheckin = (note: string) => {
    setIsSavingCheckin(true);
    const realCount = checkins.filter((c) => !isDemoCheckin(c)).length;
    const newRecord: CheckinRecord = {
      id: `chk_${Date.now()}`,
      note: note.trim() || `Check-in Biométrico #${realCount + 1}`,
      peso: metrics.peso,
      ombros: metrics.ombros,
      cintura: metrics.cintura,
      peito: metrics.peito,
      braco: metrics.braco,
      coxa: metrics.coxa,
      panturrilha: metrics.panturrilha,
      indiceAdonis: goldenAnalysis.indiceAdonisAtual,
      overallScore: goldenAnalysis.overallScore,
      dateFormatted: new Date().toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }),
      timestamp: Date.now()
    };
    setCheckins((prev) => [newRecord, ...prev]);
    setIsSavingCheckin(false);
    showToast('Check-in biométrico registrado na linha do tempo!', 'emerald');
  };

  const handleDeleteCheckin = (id: string) => {
    setCheckins((prev) => prev.filter((c) => c.id !== id));
    showToast('Check-in removido.', 'gold');
  };

  const handleSeedDemoEvolution = () => {
    const now = Date.now();
    const dayMs = 86400 * 1000;
    const demo: CheckinRecord[] = [
      {
        id: 'chk_demo_1',
        note: 'Mês 1 // Ponto de Partida',
        peso: 98.5,
        ombros: 125.0,
        cintura: 100.5,
        peito: 94.0,
        braco: 36.5,
        coxa: 56.5,
        panturrilha: 42.0,
        indiceAdonis: +(125.0 / 100.5).toFixed(3),
        overallScore: 84.5,
        dateFormatted: '90 dias atrás',
        timestamp: now - 90 * dayMs
      },
      {
        id: 'chk_demo_2',
        note: 'Mês 2 // Recalibração Híbrida',
        peso: 96.8,
        ombros: 127.2,
        cintura: 98.0,
        peito: 95.8,
        braco: 37.4,
        coxa: 57.2,
        panturrilha: 42.6,
        indiceAdonis: +(127.2 / 98.0).toFixed(3),
        overallScore: 87.8,
        dateFormatted: '45 dias atrás',
        timestamp: now - 45 * dayMs
      },
      {
        id: 'chk_demo_3',
        note: 'Mês 3 // Medição Atual',
        peso: metrics.peso,
        ombros: metrics.ombros,
        cintura: metrics.cintura,
        peito: metrics.peito,
        braco: metrics.braco,
        coxa: metrics.coxa,
        panturrilha: metrics.panturrilha,
        indiceAdonis: goldenAnalysis.indiceAdonisAtual,
        overallScore: goldenAnalysis.overallScore,
        dateFormatted: 'Hoje',
        timestamp: now
      }
    ];
    setCheckins((prev) => [...demo, ...prev.filter((c) => !isDemoCheckin(c))]);
    showToast('Simulação trimestral demonstrativa carregada separadamente!', 'gold');
  };

  const handleClearDemoCheckins = () => {
    setCheckins((prev) => prev.filter((c) => !isDemoCheckin(c)));
    showToast('Registros de simulação removidos.', 'gold');
  };

  // Backup Export & Import
  const applyValidatedBackupData = useCallback(
    (
      data: Partial<BackupData>,
      sessionStrategy: 'preserve_current' | 'replace_with_backup'
    ) => {
      if (data.profile) setProfile(data.profile);
      if (data.metrics) setMetrics(data.metrics);
      if (data.profile || data.metrics) {
        saveOnboardingCompleted(true);
        setOnboardingCompleted(true);
      }
      if (data.lastExerciseWeights) setLastExerciseWeights(data.lastExerciseWeights);
      if (data.checkins) setCheckins(data.checkins);
      if (data.workoutHistory) setWorkoutHistory(data.workoutHistory);
      if (Array.isArray(data.customExercises)) {
        setCustomExercises(data.customExercises);
      }
      if (data.preferences) {
        setPreferences(data.preferences);
      }

      if (sessionStrategy === 'preserve_current') {
        if (data.customAiWorkouts !== undefined) {
          if (data.customAiWorkouts === null) {
            setCustomAiWorkouts(null);
          } else {
            const safeApplied = applyAiReformulationWithSessionProtection({
              currentCustomWorkouts: customAiWorkouts,
              baseTemplate: HYBRID_WORKOUT_TEMPLATE,
              generatedWorkouts: data.customAiWorkouts,
              scope: 'week',
              currentDayWorkout,
              sessionSets,
              isSessionActive: true,
              resolution: 'preserve_active'
            });
            setCustomAiWorkouts(safeApplied.updatedCustomWorkouts);
            setSessionSets(safeApplied.updatedSessionSets);
          }
        }
        showToast(
          'Backup importado com sucesso! Sua sessão ativa atual foi preservada.',
          'emerald'
        );
        return;
      }

      // sessionStrategy === 'replace_with_backup'
      if (data.customAiWorkouts !== undefined) {
        setCustomAiWorkouts(data.customAiWorkouts);
      }

      if (data.activeSession) {
        const restored = data.activeSession;
        saveActiveSession(restored);
        setActiveSessionId(restored.sessionId);
        setSessionStartedAtMs(restored.startedAtMs);
        setSelectedDayId(restored.dayId);
        setActiveExerciseIndex(restored.activeExerciseIndex ?? 0);
        setArenaPhase(restored.arenaPhase ?? 'hipertrofia');
        setMobilityChecked(restored.mobilityChecked ?? {});
        setCardioCompleted(restored.cardioCompleted ?? false);
        setSessionSets(restored.sessionSets ?? {});
        setStopwatch(restored.stopwatch);
        setRestTimer(restored.restTimer);
        setShowResumeBanner(true);
        setActiveTab('executar');
        showToast(
          'Backup e rascunho de sessão ativa restaurados com sucesso!',
          'emerald'
        );
      } else {
        resetActiveSessionState(currentDayWorkout, data.lastExerciseWeights || lastExerciseWeights);
        showToast('Backup importado com sucesso! Dados confirmados restaurados.', 'emerald');
      }
    },
    [
      customAiWorkouts,
      currentDayWorkout,
      sessionSets,
      lastExerciseWeights,
      resetActiveSessionState,
      showToast
    ]
  );

  const handleExportBackup = () => {
    exportFullBackupJSON(
      profile,
      metrics,
      customAiWorkouts,
      lastExerciseWeights,
      checkins,
      workoutHistory,
      activeSessionSnapshot,
      customExercises,
      preferences
    );
    showToast(
      activeSessionSnapshot
        ? 'Backup completo (incluindo sessão ativa em andamento) exportado!'
        : 'Backup completo exportado com sucesso!',
      'emerald'
    );
  };

  const handleImportBackup = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        const validation = validateBackupPayload(parsed);
        if (!validation.valid || !validation.data) {
          showToast(validation.error || 'Arquivo de backup inválido.', 'rose');
          return;
        }

        const { completedSets } = countCompletedSetsInSession(
          currentDayWorkout?.exercises || [],
          sessionSets
        );
        const hasCurrentActiveSession =
          stopwatch.status !== 'not_started' || completedSets > 0;

        if (hasCurrentActiveSession) {
          setPendingBackupImport({
            data: validation.data,
            hasActiveSessionInBackup: validation.hasActiveSessionInBackup
          });
          setShowDailyGuideModal(false);
          return;
        }

        applyValidatedBackupData(validation.data, 'replace_with_backup');
        setShowDailyGuideModal(false);
      } catch (err) {
        console.error('Error importing backup:', err);
        showToast('Arquivo de backup inválido.', 'rose');
      } finally {
        event.target.value = '';
      }
    };
    reader.readAsText(file);
  };

  const activeSessionStats = useMemo(
    () => countCompletedSetsInSession(currentDayWorkout?.exercises || [], sessionSets),
    [currentDayWorkout?.exercises, sessionSets]
  );

  const catalogCount = useMemo(
    () =>
      buildExerciseCatalog({
        customExercises,
        workouts: dynamicWorkouts,
        workoutHistory
      }).length,
    [customExercises, dynamicWorkouts, workoutHistory]
  );

  const handleApplyPreviewWorkouts = useCallback(
    (proposedWorkouts: WorkoutDay[], scope: 'week' | 'day') => {
      const isSessionCurrentlyActive =
        stopwatch.status !== 'not_started' || activeSessionStats.completedSets > 0;

      const applied = applyAiReformulationWithSessionProtection({
        currentCustomWorkouts: customAiWorkouts,
        baseTemplate: HYBRID_WORKOUT_TEMPLATE,
        generatedWorkouts: proposedWorkouts,
        scope,
        currentDayWorkout,
        sessionSets,
        isSessionActive: isSessionCurrentlyActive,
        resolution: 'preserve_active'
      });

      setCustomAiWorkouts(applied.updatedCustomWorkouts);
      setSessionSets(applied.updatedSessionSets);
      showToast(
        scope === 'day'
          ? 'Ajuste do treino do dia aplicado com sucesso!'
          : 'Ajuste semanal aplicado à sua rotina!',
        'emerald'
      );
    },
    [
      stopwatch.status,
      activeSessionStats.completedSets,
      customAiWorkouts,
      currentDayWorkout,
      sessionSets,
      showToast
    ]
  );

  return (
    <div
      className={`min-h-screen bg-[#08090C] text-[#F4F5F7] font-sans flex selection:bg-[#D4AF37]/30 selection:text-amber-200 overflow-x-hidden ${
        preferences.enhancedContrast ? 'contrast-125' : ''
      } ${preferences.textScale === 'large' ? 'text-[17px]' : ''} ${
        preferences.reducedMotion ? ' motion-reduce:transition-none' : ''
      }`}
    >
      {/* FLOATING TOAST NOTIFICATION */}
      {notification && (
        <div className="fixed top-4 right-4 z-50 max-w-md">
          <div
            className={`flex items-center gap-3 px-4 py-3 rounded-xl border shadow-2xl backdrop-blur-md ${
              notification.type === 'emerald'
                ? 'bg-emerald-950/95 border-emerald-500/50 text-emerald-200'
                : notification.type === 'rose'
                ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
                : 'bg-[#13151A]/95 border-[#D4AF37]/50 text-amber-200'
            }`}
          >
            <Sparkles className="w-5 h-5 shrink-0 text-[#D4AF37]" />
            <span className="text-sm font-semibold">{notification.message}</span>
          </div>
        </div>
      )}

      {/* ONBOARDING FLOW MODAL (GRUPO 4) */}
      <OnboardingFlowModal
        isOpen={showOnboardingModal}
        initialProfile={profile}
        initialMetrics={metrics}
        onCompleteOnboarding={(updatedProfile, updatedMetrics, destination = 'inicio') => {
          setProfile(updatedProfile);
          setMetrics(updatedMetrics);
          saveOnboardingCompleted(true);
          setOnboardingCompleted(true);
          setShowOnboardingModal(false);
          setActiveTab(destination);
          showToast('Perfil e rotina configurados com sucesso!', 'emerald');
        }}
        onCloseOrSkip={() => setShowOnboardingModal(false)}
      />

      {/* REST TIMER FINISHED ALERT BANNER */}
      {timerFinishedAlert && (
        <div className="fixed inset-x-0 top-0 z-50 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 px-4 py-3 shadow-2xl flex items-center justify-between">
          <div className="flex items-center gap-3 mx-auto">
            <Flame className="w-6 h-6 animate-pulse" />
            <span className="font-black tracking-wide text-xs sm:text-sm uppercase">
              Recuperação Completa! Ataque a próxima série mantendo a cadência biomecânica!
            </span>
            <button
              onClick={() => setTimerFinishedAlert(false)}
              className="ml-3 px-3 py-1 bg-slate-950 text-amber-400 rounded-lg text-xs font-bold hover:bg-slate-900 transition"
            >
              PRONTO
            </button>
          </div>
        </div>
      )}

      {/* SIDEBAR NAVIGATION */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'perfil') setProfileSubView('profile_home');
          setActiveTab(tab);
        }}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        profile={profile}
        goldenAnalysis={goldenAnalysis}
        customAiWorkouts={customAiWorkouts}
        onOpenDailyGuide={() => setShowDailyGuideModal(true)}
        onQuickReformulateWeek={() => handleReformulateWorkout({ scope: 'week' })}
        isGeneratingAi={isGeneratingAiWorkout}
        onOpenWizard={() => {
          setActiveTab('questionario');
          setWizardStep(1);
        }}
        googleUser={googleUser}
      />

      {/* DAILY GUIDE MODAL */}
      <DailyGuideModal
        isOpen={showDailyGuideModal}
        onClose={() => setShowDailyGuideModal(false)}
        onExportBackup={handleExportBackup}
        onImportBackup={handleImportBackup}
      />

      {/* AI REFORMULATE ACTIVE SESSION PROTECTION MODAL (ETAPA 3.1) */}
      <AiReformulateProtectionModal
        isOpen={pendingAiReformulation !== null}
        scope={pendingAiReformulation?.scope || 'week'}
        completedSets={activeSessionStats.completedSets}
        tonnage={activeSessionStats.tonnage}
        workoutTitle={currentDayWorkout?.title || 'Treino'}
        onPreserveAndApply={() => {
          if (pendingAiReformulation) {
            executeReformulateWorkout(pendingAiReformulation, 'preserve_active');
          }
        }}
        onReplaceAndDiscard={() => {
          if (pendingAiReformulation) {
            executeReformulateWorkout(pendingAiReformulation, 'replace_active');
          }
        }}
        onCancel={() => setPendingAiReformulation(null)}
      />

      {/* BACKUP IMPORT ACTIVE SESSION CONFIRMATION MODAL (ETAPA 3.1) */}
      <BackupImportConfirmModal
        isOpen={pendingBackupImport !== null}
        completedSets={activeSessionStats.completedSets}
        tonnage={activeSessionStats.tonnage}
        hasActiveSessionInBackup={pendingBackupImport?.hasActiveSessionInBackup ?? false}
        onImportPreservingCurrentSession={() => {
          if (pendingBackupImport) {
            applyValidatedBackupData(pendingBackupImport.data, 'preserve_current');
            setPendingBackupImport(null);
          }
        }}
        onImportReplacingCurrentSession={() => {
          if (pendingBackupImport) {
            applyValidatedBackupData(pendingBackupImport.data, 'replace_with_backup');
            setPendingBackupImport(null);
          }
        }}
        onCancel={() => setPendingBackupImport(null)}
      />

      {/* WORKOUT SUMMARY MODAL (ETAPA 3) */}
      {completedWorkoutSummary && (
        <WorkoutSummaryModal
          completedWorkout={completedWorkoutSummary}
          workoutHistory={workoutHistory}
          onUpdateSummaryMeta={handleUpdateSummaryMeta}
          onGoHome={() => {
            setCompletedWorkoutSummary(null);
            setActiveTab('inicio');
          }}
          onGoHistory={() => {
            setCompletedWorkoutSummary(null);
            setInitialEvolutionSubView('history');
            setActiveTab('evolucao');
          }}
        />
      )}

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#08090C] text-[#F4F5F7]">
        <Header
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'perfil') setProfileSubView('profile_home');
            setActiveTab(tab);
          }}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenDailyGuide={() => setShowDailyGuideModal(true)}
          userName={profile.nome}
          userPhotoUrl={googleUser?.photoURL}
        />

        <main className="flex-1 px-4 sm:px-6 pt-4 pb-28 lg:pb-8 max-w-7xl w-full mx-auto space-y-5 sm:space-y-6">
          {/* TAB 0: DASHBOARD PRINCIPAL (INÍCIO) */}
          {activeTab === 'inicio' && (
            <DashboardHomeView
              profile={profile}
              metrics={metrics}
              goldenAnalysis={goldenAnalysis}
              onboardingCompleted={onboardingCompleted}
              dynamicWorkouts={dynamicWorkouts}
              currentDayWorkout={currentDayWorkout}
              selectedDayId={selectedDayId}
              onSelectDayId={handleSelectDayOnDashboard}
              workoutHistory={workoutHistory}
              checkins={checkins}
              lastExerciseWeights={lastExerciseWeights}
              onClearDemoCheckins={handleClearDemoCheckins}
              onOpenDailyGuide={() => setShowDailyGuideModal(true)}
              onNavigateTab={(tab) => {
                if (tab === 'ia') {
                  setInitialExercisesSubView(null);
                }
                setActiveTab(tab);
              }}
              onStartWorkoutSession={handleStartWorkoutFromDashboard}
            />
          )}

          {/* TAB PERFIL, CONFIGURAÇÕES E BACKUP (GRUPO 1) */}
          {activeTab === 'perfil' && (
            <ProfileSettingsView
              subView={profileSubView}
              onChangeSubView={setProfileSubView}
              profile={profile}
              metrics={metrics}
              goldenAnalysis={goldenAnalysis}
              onboardingCompleted={onboardingCompleted}
              dynamicWorkouts={dynamicWorkouts}
              workoutHistory={workoutHistory}
              checkins={checkins}
              catalogCount={catalogCount}
              preferences={preferences}
              onUpdatePreferences={(updated) => {
                setPreferences(updated);
                showToast('Preferência atualizada!', 'emerald');
              }}
              onSaveFullProfile={(updatedProfile) => {
                setProfile(updatedProfile);
                saveOnboardingCompleted(true);
                setOnboardingCompleted(true);
                showToast('Perfil e rotina atualizados com sucesso!', 'emerald');
              }}
              onExportBackup={handleExportBackup}
              onImportBackup={handleImportBackup}
              onClearDemoCheckins={handleClearDemoCheckins}
              onResetWorkoutHistory={() => {
                setWorkoutHistory([]);
                setLastExerciseWeights({});
                showToast('Histórico de treinos redefinido.', 'gold');
              }}
              isSessionActive={
                stopwatch.status !== 'not_started' || activeSessionStats.completedSets > 0
              }
              googleUser={
                googleUser
                  ? {
                      name: googleUser.displayName || undefined,
                      email: googleUser.email || undefined,
                      photoURL: googleUser.photoURL || undefined
                    }
                  : null
              }
              onLogoutGoogle={async () => {
                await logoutGoogle();
                setGoogleUser(null);
                setGoogleAccessToken(null);
                showToast('Conta Google desconectada.', 'gold');
              }}
              onNavigateToRoutine={() => {
                setInitialExercisesSubView('routine');
                setActiveTab('ia');
              }}
              onNavigateToCoachIa={() => {
                setInitialExercisesSubView('ai');
                setActiveTab('ia');
              }}
              onNavigateToHistory={() => {
                setInitialEvolutionSubView('history');
                setActiveTab('evolucao');
              }}
              onNavigateToBiometrics={() => {
                setWizardStep(1);
                setActiveTab('questionario');
              }}
              onNavigateToScanner3D={() => {
                setActiveTab('scanner');
              }}
              onNavigateToWorkspace={() => {
                setActiveTab('workspace');
              }}
              onOpenOnboardingTour={() => {
                setShowOnboardingModal(true);
              }}
              onShowToast={showToast}
            />
          )}

          {/* TAB 1: QUESTIONNAIRE (MEDIDAS E BIOMETRIA) */}
          {activeTab === 'questionario' && (
            <BiometricsWizard
              wizardStep={wizardStep}
              setWizardStep={setWizardStep}
              profile={profile}
              metrics={metrics}
              goldenAnalysis={goldenAnalysis}
              onProfileChange={handleProfileChange}
              onMetricChange={handleMetricChange}
              onToggleTrainingDay={handleToggleTrainingDay}
              onSaveAndFinish={handleSaveAndFinishWizard}
              onSaveAndGenerateAi={async () => {
                handleSaveAndFinishWizard('scanner');
                handleReformulateWorkout({ scope: 'week' });
              }}
              isSaving={isSavingMetrics}
              isGeneratingAi={isGeneratingAiWorkout}
              onboardingCompleted={onboardingCompleted}
            />
          )}

          {/* TAB 2: 3D SCANNER (GRUPO 3) */}
          {activeTab === 'scanner' && (
            <Scanner3DView
              goldenAnalysis={goldenAnalysis}
              selectedPartKey={selectedPartKey}
              onSelectPart={setSelectedPartKey}
              onOpenWizard={() => {
                setActiveTab('questionario');
                setWizardStep(1);
              }}
              onGenerateAiWorkout={() => handleReformulateWorkout({ scope: 'week' })}
              isGeneratingAi={isGeneratingAiWorkout}
              profile={profile}
              metrics={metrics}
              onboardingCompleted={onboardingCompleted}
              workoutHistory={workoutHistory}
              checkins={checkins}
              onAddCheckin={handleAddCheckin}
              onDeleteCheckin={handleDeleteCheckin}
              onSeedDemoEvolution={handleSeedDemoEvolution}
              onClearDemoCheckins={handleClearDemoCheckins}
            />
          )}

          {/* TAB 3: LIVE ARENA */}
          {activeTab === 'executar' && currentDayWorkout && (
            <ArenaView
              currentDayWorkout={currentDayWorkout}
              dynamicWorkouts={dynamicWorkouts}
              selectedDayId={selectedDayId}
              onSelectDayId={handleSelectDayInArena}
              activeExerciseIndex={activeExerciseIndex}
              setActiveExerciseIndex={setActiveExerciseIndex}
              arenaPhase={arenaPhase}
              setArenaPhase={setArenaPhase}
              mobilityChecked={mobilityChecked}
              onToggleMobility={(id) =>
                setMobilityChecked((prev) => ({ ...prev, [id]: !prev[id] }))
              }
              cardioCompleted={cardioCompleted}
              onToggleCardio={() => setCardioCompleted((prev) => !prev)}
              sessionSets={sessionSets}
              onUpdateSetField={handleUpdateSetField}
              onStepSetWeight={handleStepSetWeight}
              onStepSetReps={handleStepSetReps}
              onAddExtraSet={handleAddExtraSet}
              onToggleSetCompleted={handleToggleSetCompleted}
              onFinishWorkout={handleFinishWorkout}
              isSavingWorkout={isSavingWorkout}
              activeSelectedDays={activeSelectedDays}
              onToggleTrainingDay={handleToggleTrainingDay}
              onReformulate={handleReformulateWorkout}
              isGeneratingAi={isGeneratingAiWorkout}
              swappingExerciseId={swappingExerciseId}
              onSwapSingleExercise={handleSwapSingleExercise}
              onAddCustomExercise={handleAddCustomExercise}
              timerSeconds={timerSeconds}
              timerTarget={timerTarget}
              timerRunning={timerRunning}
              restTimerState={restTimer}
              onStartRestTimer={handleStartRestTimer}
              onAdjustRestTimer={handleAdjustRestTimer}
              onResetRestTimer={handleResetRestTimer}
              onTogglePauseRestTimer={handleTogglePauseRestTimer}
              onOpenRestModal={handleOpenRestModal}
              onMinimizeRestModal={handleMinimizeRestModal}
              workoutElapsedSec={workoutElapsedSec}
              workoutStopwatchRunning={workoutStopwatchRunning}
              onToggleStopwatch={handleToggleStopwatch}
              sessionStatus={stopwatch.status}
              activeSession={activeSessionSnapshot}
              showResumeBanner={showResumeBanner}
              onStartSession={handleStartSessionExplicit}
              onContinueResumedSession={() => {
                ensureSessionStarted();
                setShowResumeBanner(false);
              }}
              showDiscardModal={showDiscardModal}
              onRequestDiscardSession={() => setShowDiscardModal(true)}
              onCancelDiscardSession={handleCancelDiscardSession}
              onConfirmDiscardSession={handleConfirmDiscardSession}
              lastExerciseWeights={lastExerciseWeights}
              workoutHistory={workoutHistory}
            />
          )}

          {/* TAB 4: BIBLIOTECA DE EXERCÍCIOS, ROTINAS & COACH IA (ETAPA 5 + GRUPO 2) */}
          {(activeTab === 'ia' || activeTab === 'exercicios') && (
            <ExercisesLibraryView
              profile={profile}
              goldenAnalysis={goldenAnalysis}
              dynamicWorkouts={dynamicWorkouts}
              customAiWorkouts={customAiWorkouts}
              baseTemplateWorkouts={HYBRID_WORKOUT_TEMPLATE}
              selectedDayId={selectedDayId}
              onSelectDayId={handleSelectDayOnDashboard}
              currentDayWorkout={currentDayWorkout}
              activeSelectedDays={activeSelectedDays}
              onToggleTrainingDay={handleToggleTrainingDay}
              onReformulate={handleReformulateWorkout}
              isGeneratingAi={isGeneratingAiWorkout}
              onResetToDefault={() => {
                if (stopwatch.status !== 'not_started' || activeSessionStats.completedSets > 0) {
                  showToast('Finalize ou descarte o treino em andamento antes de restaurar o template.', 'gold');
                  setActiveTab('executar');
                  return;
                }
                setCustomAiWorkouts(null);
                showToast('Restaurado para o template inicial.', 'gold');
              }}
              onNavigateToArena={(dayId) => {
                if (dayId && dayId !== selectedDayId) {
                  if (stopwatch.status === 'not_started' && activeSessionStats.completedSets === 0) {
                    setSelectedDayId(dayId);
                    setActiveExerciseIndex(0);
                  }
                }
                setActiveTab('executar');
              }}
              onOpenExerciseEvolution={(exerciseId) => {
                setInitialEvolutionExerciseId(exerciseId);
                setActiveTab('evolucao');
              }}
              onOpenScanner3D={(partKey) => {
                if (partKey) setSelectedPartKey(partKey);
                setActiveTab('scanner');
              }}
              workoutHistory={workoutHistory}
              lastExerciseWeights={lastExerciseWeights}
              customExercises={customExercises}
              onSaveCustomExercises={(updatedList) => {
                setCustomExercises(updatedList);
                showToast('Exercício personalizado salvo no catálogo!', 'emerald');
              }}
              onUpdateWorkoutsAndSessionSets={(
                updatedWorkouts,
                updatedSets,
                toastMsg,
                toastType = 'emerald'
              ) => {
                setCustomAiWorkouts(updatedWorkouts);
                setSessionSets(updatedSets);
                showToast(toastMsg, toastType);
              }}
              sessionSets={sessionSets}
              isSessionActive={stopwatch.status !== 'not_started' || activeSessionStats.completedSets > 0}
              activeSessionDayId={selectedDayId}
              aiCoachMessages={aiCoachMessages}
              onAskCoach={handleAskCoach}
              isAskingCoach={isAskingCoach}
              initialSubView={initialExercisesSubView}
              onClearInitialSubView={() => setInitialExercisesSubView(null)}
              onApplyPreviewWorkouts={handleApplyPreviewWorkouts}
            />
          )}

          {/* TAB: GOOGLE WORKSPACE (CALENDAR & GMAIL) */}
          {activeTab === 'workspace' && (
            <GoogleWorkspaceView
              user={googleUser}
              accessToken={googleAccessToken}
              onAuthSuccess={(user, token) => {
                setGoogleUser(user);
                setGoogleAccessToken(token);
              }}
              onLogout={() => {
                setGoogleUser(null);
                setGoogleAccessToken(null);
              }}
              profile={profile}
              goldenAnalysis={goldenAnalysis}
              dynamicWorkouts={dynamicWorkouts}
              onShowToast={showToast}
              preferences={preferences}
              onUpdatePreferences={setPreferences}
              onBackToProfile={() => {
                setProfileSubView('profile_home');
                setActiveTab('perfil');
              }}
            />
          )}

          {/* TAB 5: EVOLUTION & CHECKINS */}
          {activeTab === 'evolucao' && (
            <EvolutionView
              profile={profile}
              metrics={metrics}
              goldenAnalysis={goldenAnalysis}
              checkins={checkins}
              workoutHistory={workoutHistory}
              lastExerciseWeights={lastExerciseWeights}
              dynamicWorkouts={dynamicWorkouts}
              initialExerciseId={initialEvolutionExerciseId}
              onClearInitialExerciseId={() => setInitialEvolutionExerciseId(null)}
              initialSubView={initialEvolutionSubView}
              onClearInitialSubView={() => setInitialEvolutionSubView(null)}
              onAddCheckin={handleAddCheckin}
              onDeleteCheckin={handleDeleteCheckin}
              onSeedDemoEvolution={handleSeedDemoEvolution}
              onClearDemoCheckins={handleClearDemoCheckins}
              isSavingCheckin={isSavingCheckin}
              onNavigateTab={setActiveTab}
            />
          )}
        </main>

        {/* FIXED BOTTOM NAVIGATION FOR MOBILE */}
        <BottomNav
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'perfil') setProfileSubView('profile_home');
            setActiveTab(tab);
          }}
          redZonesCount={goldenAnalysis.redZones.length}
        />
      </div>
    </div>
  );
}
