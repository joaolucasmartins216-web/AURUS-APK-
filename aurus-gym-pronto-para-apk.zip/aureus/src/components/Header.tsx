import React from 'react';
import { Bell, Eye, Menu, Play } from 'lucide-react';
import { AurusLogo } from './AurusLogo';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenMobileMenu: () => void;
  onOpenDailyGuide?: () => void;
  userName?: string;
  userPhotoUrl?: string | null;
}

export function Header({
  activeTab,
  setActiveTab,
  onOpenMobileMenu,
  onOpenDailyGuide,
  userName = 'Atleta',
  userPhotoUrl
}: HeaderProps) {
  const sectionLabels: Record<string, string> = {
    inicio: 'Início',
    executar: 'Treinar',
    evolucao: 'Evolução',
    ia: 'Exercícios',
    scanner: 'Scanner 3D',
    workspace: 'Agenda',
    perfil: 'Perfil',
    questionario: 'Medidas & Biometria'
  };

  const initials =
    (userName || 'A')
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() || '')
      .join('') || 'AG';

  return (
    <header className="sticky top-0 z-30 w-full pt-safe bg-[#08090C]/90 backdrop-blur-md border-b border-white/[0.05]">
      <div className="h-16 px-4 sm:px-6 flex items-center justify-between gap-2">
        {/* Esquerda: Monograma AURUS GYM + Seção Atual */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onOpenMobileMenu}
            className="lg:hidden w-10 h-10 -ml-1 rounded-xl bg-[#13151A] card-border flex items-center justify-center text-[#9CA3AF] hover:text-[#D4AF37] active:scale-95 transition shrink-0 cursor-pointer"
            aria-label="Abrir menu de navegação"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('inicio')}
            className="flex items-center gap-2.5 text-left min-w-0 cursor-pointer"
          >
            <AurusLogo size="sm" />
            <div className="flex flex-col min-w-0">
              <span className="text-[13px] font-bold tracking-wider text-[#D4AF37] leading-none uppercase truncate">
                AURUS GYM
              </span>
              <span className="text-[11px] font-medium text-[#9CA3AF] tracking-wide mt-0.5 leading-tight truncate">
                {sectionLabels[activeTab] || 'Início'}
              </span>
            </div>
          </button>
        </div>

        {/* Direita: Atalhos Desktop + Notificações/Backup + Avatar */}
        <div className="flex items-center gap-2 shrink-0">
          {activeTab !== 'scanner' && (
            <button
              type="button"
              onClick={() => setActiveTab('scanner')}
              className="hidden sm:inline-flex items-center gap-1.5 h-10 px-3 rounded-xl bg-[#13151A] card-border text-xs font-semibold text-[#F4F5F7] hover:border-[#D4AF37]/40 hover:text-[#D4AF37] transition cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Scanner 3D</span>
            </button>
          )}

          {activeTab !== 'executar' && (
            <button
              type="button"
              onClick={() => setActiveTab('executar')}
              className="hidden md:inline-flex items-center gap-1.5 h-10 px-3.5 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs font-bold text-[#D4AF37] hover:bg-[#D4AF37]/25 transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Treinar</span>
            </button>
          )}

          {onOpenDailyGuide && (
            <button
              type="button"
              onClick={onOpenDailyGuide}
              className="w-10 h-10 rounded-full flex items-center justify-center text-[#9CA3AF] hover:text-[#D4AF37] transition-colors relative cursor-pointer"
              aria-label="Guia de uso e backup"
              title="Guia de uso e backup"
            >
              <Bell className="w-5 h-5" />
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] absolute top-2.5 right-2.5" />
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('perfil')}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:opacity-90 transition cursor-pointer"
            aria-label={`Perfil de ${userName}`}
            title={`Perfil de ${userName}`}
          >
            {userPhotoUrl ? (
              <img
                src={userPhotoUrl}
                alt={`Foto de perfil de ${userName}`}
                className="w-8 h-8 rounded-full object-cover border border-white/10"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-[#1A1D24] border border-white/10 flex items-center justify-center text-[11px] font-bold text-[#D4AF37] tracking-wider">
                {initials}
              </div>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
