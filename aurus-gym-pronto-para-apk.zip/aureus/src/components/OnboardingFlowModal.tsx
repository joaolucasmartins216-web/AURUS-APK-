import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  Check,
  CheckCircle2,
  Dumbbell,
  Eye,
  Sparkles,
  TrendingUp,
  User,
  Wand2,
  X
} from 'lucide-react';
import { BiometricMetrics, UserProfile } from '../types';
import { AurusLogo } from './AurusLogo';

interface OnboardingFlowModalProps {
  isOpen: boolean;
  initialProfile: UserProfile;
  initialMetrics: BiometricMetrics;
  onCompleteOnboarding: (
    updatedProfile: UserProfile,
    updatedMetrics: BiometricMetrics,
    destinationTab?: 'inicio' | 'executar' | 'scanner'
  ) => void;
  onCloseOrSkip: () => void;
}

type OnboardingStep = 1 | 2 | 3 | 4 | 5;

const DAY_PILLS = [
  { id: 'seg', label: 'Seg', full: 'Segunda' },
  { id: 'ter', label: 'Ter', full: 'Terça' },
  { id: 'qua', label: 'Qua', full: 'Quarta' },
  { id: 'qui', label: 'Qui', full: 'Quinta' },
  { id: 'sex', label: 'Sex', full: 'Sexta' },
  { id: 'sab', label: 'Sáb', full: 'Sábado' },
  { id: 'dom', label: 'Dom', full: 'Domingo' }
];

const OBJECTIVES = [
  {
    id: 'Hipertrofia & Proporção Áurea',
    title: 'Hipertrofia & Estética',
    desc: 'Ganho de massa muscular com simetria proporcional.'
  },
  {
    id: 'Ganho de Força Bruta',
    title: 'Ganho de Força',
    desc: 'Progressão consistente de cargas nos grandes levantamentos.'
  },
  {
    id: 'Condicionamento Híbrido',
    title: 'Condicionamento & Esporte',
    desc: 'Equilíbrio entre musculação, resistência e esportes.'
  },
  {
    id: 'Definição & Recomposição',
    title: 'Definição Muscular',
    desc: 'Manutenção de massa magra e redução de percentual.'
  }
];

export function OnboardingFlowModal({
  isOpen,
  initialProfile,
  initialMetrics,
  onCompleteOnboarding,
  onCloseOrSkip
}: OnboardingFlowModalProps) {
  const [step, setStep] = useState<OnboardingStep>(1);

  // Step 3: Seu Perfil
  const [nome, setNome] = useState(initialProfile.nome || 'João');
  const [experiencia, setExperiencia] = useState<UserProfile['experiencia']>(
    initialProfile.experiencia || 'Intermediário'
  );
  const [objetivo, setObjetivo] = useState(
    initialProfile.objetivoPrincipal || 'Hipertrofia & Proporção Áurea'
  );
  const [pesoOpcional, setPesoOpcional] = useState<string>(
    String(initialMetrics.peso || 95)
  );

  // Step 4: Sua Rotina
  const [diasSelecionados, setDiasSelecionados] = useState<string[]>(
    initialProfile.diasSelecionados && initialProfile.diasSelecionados.length > 0
      ? initialProfile.diasSelecionados
      : ['seg', 'ter', 'qua', 'qui', 'sex']
  );
  const [duracaoMediaMin, setDuracaoMediaMin] = useState<number>(
    initialProfile.duracaoMediaMin || 60
  );
  const [modalidades, setModalidades] = useState<string[]>(
    initialProfile.modalidadesExtras && initialProfile.modalidadesExtras.length > 0
      ? initialProfile.modalidadesExtras
      : ['Musculação', 'Futsal / Esportes']
  );

  const [validationError, setValidationError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNextFromStep3 = () => {
    if (!nome.trim()) {
      setValidationError('Informe seu nome ou apelido para personalizar seu perfil.');
      return;
    }
    setValidationError(null);
    setStep(4);
  };

  const handleNextFromStep4 = () => {
    if (diasSelecionados.length === 0) {
      setValidationError('Selecione pelo menos 1 dia de treino por semana.');
      return;
    }
    setValidationError(null);
    setStep(5);
  };

  const handleToggleDay = (dayId: string) => {
    setDiasSelecionados((prev) => {
      if (prev.includes(dayId)) {
        if (prev.length <= 1) {
          setValidationError('Mantenha pelo menos 1 dia de treino selecionado.');
          return prev;
        }
        setValidationError(null);
        return prev.filter((d) => d !== dayId);
      }
      setValidationError(null);
      return [...prev, dayId];
    });
  };

  const handleToggleModality = (mod: string) => {
    setModalidades((prev) =>
      prev.includes(mod) ? prev.filter((m) => m !== mod) : [...prev, mod]
    );
  };

  const handleFinalize = (destination: 'inicio' | 'executar' = 'inicio') => {
    const parsedWeight = Number(pesoOpcional.replace(',', '.'));
    const validWeight =
      Number.isFinite(parsedWeight) && parsedWeight >= 35 && parsedWeight <= 250
        ? parsedWeight
        : initialMetrics.peso;

    const finalProfile: UserProfile = {
      ...initialProfile,
      nome: nome.trim() || 'Atleta',
      experiencia,
      objetivoPrincipal: objetivo,
      diasSelecionados,
      diasSemana: diasSelecionados.length,
      duracaoMediaMin,
      modalidadesExtras: modalidades.length > 0 ? modalidades : ['Musculação'],
      esporteComplementar: modalidades.includes('Futsal / Esportes')
        ? 'Futsal (1x a 2x/semana)'
        : 'Nenhum (Foco 100% Musculação)'
    };

    const finalMetrics: BiometricMetrics = {
      ...initialMetrics,
      peso: validWeight
    };

    onCompleteOnboarding(finalProfile, finalMetrics, destination);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Configuração inicial AURUS GYM"
      className="fixed inset-0 z-50 bg-[#08090C] text-[#F4F5F7] flex flex-col justify-between overflow-y-auto"
    >
      {/* Top Progress Header */}
      <header className="w-full max-w-md mx-auto px-5 pt-5 pb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => {
                setValidationError(null);
                setStep((prev) => Math.max(1, prev - 1) as OnboardingStep);
              }}
              aria-label="Voltar etapa anterior"
              className="w-9 h-9 rounded-xl bg-[#13151A] border border-white/[0.08] flex items-center justify-center text-[#F4F5F7] hover:bg-[#1A1D24] cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <AurusLogo size="sm" />
          )}
          <span className="text-xs font-bold tracking-wider uppercase text-[#D4AF37]">
            Etapa {step} de 5
          </span>
        </div>

        {/* Barra de progresso segmentada */}
        <div className="flex items-center gap-1.5 flex-1 max-w-[140px]">
          {[1, 2, 3, 4, 5].map((idx) => (
            <span
              key={idx}
              className={`h-1.5 flex-1 rounded-full transition-colors ${
                idx <= step ? 'bg-[#D4AF37]' : 'bg-[#1A1D24]'
              }`}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={onCloseOrSkip}
          aria-label="Pular configuração inicial"
          className="text-xs font-semibold text-[#9CA3AF] hover:text-[#F4F5F7] inline-flex items-center gap-1 cursor-pointer"
        >
          <span>Pular</span>
          <X className="w-4 h-4" />
        </button>
      </header>

      {/* Main Step Content */}
      <main className="flex-1 w-full max-w-md mx-auto px-5 py-4 flex flex-col justify-center">
        {/* ================================================================ */}
        {/* STEP 1: ABERTURA (SPLASH / IDENTIDADE AURUS GYM)                 */}
        {/* ================================================================ */}
        {step === 1 && (
          <div className="text-center space-y-6 py-6">
            <div className="relative mx-auto w-24 h-24 rounded-3xl bg-[#13151A] border border-[#D4AF37]/40 flex items-center justify-center shadow-[0_0_50px_rgba(212,175,55,0.18)]">
              <AurusLogo size="lg" />
            </div>

            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1A1D24] border border-[#D4AF37]/30 text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                <Sparkles className="w-3.5 h-3.5" />
                Performance Precision
              </span>
              <h1 className="text-3xl font-extrabold tracking-tight text-[#F4F5F7]">
                AURUS <span className="text-[#D4AF37]">GYM</span>
              </h1>
              <p className="text-sm text-[#9CA3AF] max-w-xs mx-auto leading-relaxed">
                Arquitetura de alta performance para acompanhamento de treinos, progressão de cargas e simetria corporal.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2.5 pt-2">
              <div className="p-3 rounded-2xl bg-[#13151A] border border-white/[0.06]">
                <div className="font-mono text-sm font-extrabold text-[#D4AF37]">
                  Arena
                </div>
                <div className="text-[11px] text-[#9CA3AF] mt-0.5">Séries & Timer</div>
              </div>
              <div className="p-3 rounded-2xl bg-[#13151A] border border-white/[0.06]">
                <div className="font-mono text-sm font-extrabold text-[#F4F5F7]">
                  Evolução
                </div>
                <div className="text-[11px] text-[#9CA3AF] mt-0.5">PRs & Volume</div>
              </div>
              <div className="p-3 rounded-2xl bg-[#13151A] border border-white/[0.06]">
                <div className="font-mono text-sm font-extrabold text-[#10B981]">
                  3D & IA
                </div>
                <div className="text-[11px] text-[#9CA3AF] mt-0.5">Simetria Áurea</div>
              </div>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <span>Começar configuração</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* STEP 2: BOAS-VINDAS (PILARES DO ECOSSISTEMA)                     */}
        {/* ================================================================ */}
        {step === 2 && (
          <div className="space-y-5 py-2">
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                BOAS-VINDAS AO AURUS GYM
              </span>
              <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
                Tudo para sua evolução na musculação
              </h1>
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                Em menos de 1 minuto vamos ajustar sua rotina semanal. Você não precisa preencher medidas corporais detalhadas agora para começar a treinar.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="p-3.5 rounded-2xl bg-[#13151A] border border-white/[0.06] flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1A1D24] text-[#D4AF37] flex items-center justify-center shrink-0">
                  <Dumbbell className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#F4F5F7]">
                    Arena de Execução e Cronômetros
                  </h2>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    Registre cargas, repetições e acompanhe o descanso mesmo se minimizar o aplicativo.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#13151A] border border-white/[0.06] flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1A1D24] text-[#D4AF37] flex items-center justify-center shrink-0">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#F4F5F7]">
                    Gráficos Reais de Evolução e PRs
                  </h2>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    Histórico fiel baseado exclusivamente nas séries que você concluir.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#13151A] border border-white/[0.06] flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#1A1D24] text-[#D4AF37] flex items-center justify-center shrink-0">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-[#F4F5F7]">
                    Scanner 3D & Coach IA
                  </h2>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    Mapeamento anatômico interativo e ajustes inteligentes na sua rotina.
                  </p>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setStep(3)}
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <span>Configurar meu perfil</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        )}

        {/* ================================================================ */}
        {/* STEP 3: SEU PERFIL (NOME, EXPERIÊNCIA, OBJETIVO)                 */}
        {/* ================================================================ */}
        {step === 3 && (
          <div className="space-y-5 py-2">
            <div className="space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                PASSO 1 • IDENTIFICAÇÃO
              </span>
              <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
                Seu Perfil
              </h1>
              <p className="text-xs text-[#9CA3AF]">
                Como devemos chamar você e qual seu foco atual de treinamento?
              </p>
            </div>

            {validationError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
                {validationError}
              </div>
            )}

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-2.5">
                <div className="col-span-2 space-y-1.5">
                  <label
                    htmlFor="onboarding-name-input"
                    className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]"
                  >
                    Seu Nome
                  </label>
                  <input
                    id="onboarding-name-input"
                    type="text"
                    value={nome}
                    onChange={(e) => {
                      setNome(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="Ex.: João"
                    className="w-full h-11 bg-[#13151A] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl px-3.5 text-sm font-bold text-[#F4F5F7] focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="onboarding-weight-input"
                    className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]"
                  >
                    Peso (kg)
                  </label>
                  <input
                    id="onboarding-weight-input"
                    type="number"
                    step="0.5"
                    value={pesoOpcional}
                    onChange={(e) => setPesoOpcional(e.target.value)}
                    className="w-full h-11 bg-[#13151A] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl px-3 font-mono text-sm font-bold text-[#F4F5F7] focus:outline-none"
                  />
                </div>
              </div>

              {/* Nível de Experiência */}
              <div className="space-y-1.5">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Experiência na Musculação
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(['Iniciante', 'Intermediário', 'Avançado'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setExperiencia(lvl)}
                      className={`h-11 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        experiencia === lvl
                          ? 'bg-[#D4AF37] border-[#D4AF37] text-[#08090C]'
                          : 'bg-[#13151A] border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Objetivo Principal */}
              <div className="space-y-1.5">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Objetivo Principal
                </span>
                <div className="space-y-2">
                  {OBJECTIVES.map((obj) => {
                    const isSelected = objetivo === obj.id;
                    return (
                      <button
                        key={obj.id}
                        type="button"
                        onClick={() => setObjetivo(obj.id)}
                        className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between gap-3 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#1A1D24] border-[#D4AF37]'
                            : 'bg-[#13151A] border-white/[0.06] hover:bg-[#1A1D24]/60'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-bold text-[#F4F5F7]">
                            {obj.title}
                          </div>
                          <div className="text-[11px] text-[#9CA3AF] mt-0.5">
                            {obj.desc}
                          </div>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                            isSelected
                              ? 'bg-[#D4AF37] text-[#08090C]'
                              : 'border border-white/20'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleNextFromStep3}
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <span>Continuar para Sua Rotina</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        )}

        {/* ================================================================ */}
        {/* STEP 4: SUA ROTINA (DIAS DA SEMANA E DURAÇÃO)                    */}
        {/* ================================================================ */}
        {step === 4 && (
          <div className="space-y-5 py-2">
            <div className="space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                PASSO 2 • DISPONIBILIDADE
              </span>
              <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
                Sua Rotina
              </h1>
              <p className="text-xs text-[#9CA3AF]">
                Selecione os dias em que pretende treinar e o tempo médio disponível por sessão.
              </p>
            </div>

            {validationError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
                {validationError}
              </div>
            )}

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#F4F5F7]">
                  Dias de treino na semana
                </span>
                <span className="font-mono text-xs font-bold text-[#D4AF37]">
                  {diasSelecionados.length} dias/sem
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {DAY_PILLS.map((d) => {
                  const active = diasSelecionados.includes(d.id);
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => handleToggleDay(d.id)}
                      className={`h-11 rounded-full text-xs font-bold transition-all cursor-pointer ${
                        active
                          ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                          : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {d.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
              <span className="block text-xs font-bold text-[#F4F5F7]">
                Duração média por sessão
              </span>
              <div className="grid grid-cols-4 gap-2">
                {[45, 60, 75, 90].map((min) => (
                  <button
                    key={min}
                    type="button"
                    onClick={() => setDuracaoMediaMin(min)}
                    className={`h-10 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer ${
                      duracaoMediaMin === min
                        ? 'bg-[#D4AF37] text-[#08090C]'
                        : 'bg-[#1A1D24] text-[#9CA3AF]'
                    }`}
                  >
                    {min} min
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
              <span className="block text-xs font-bold text-[#F4F5F7]">
                Modalidades complementares
              </span>
              <div className="flex flex-wrap gap-2">
                {['Musculação', 'Futsal / Esportes', 'Cardio / Corrida', 'Mobilidade'].map(
                  (mod) => {
                    const active = modalidades.includes(mod);
                    return (
                      <button
                        key={mod}
                        type="button"
                        onClick={() => handleToggleModality(mod)}
                        className={`h-9 px-3.5 rounded-full text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer ${
                          active
                            ? 'bg-[#D4AF37] text-[#08090C]'
                            : 'bg-[#1A1D24] text-[#9CA3AF]'
                        }`}
                      >
                        {active && <Check className="w-3.5 h-3.5" />}
                        <span>{mod}</span>
                      </button>
                    );
                  }
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={handleNextFromStep4}
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <span>Revisar Configuração</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        )}

        {/* ================================================================ */}
        {/* STEP 5: TUDO PRONTO (RESUMO E ACESSO AO DASHBOARD)               */}
        {/* ================================================================ */}
        {step === 5 && (
          <div className="space-y-5 py-2 text-center">
            <div className="w-16 h-16 rounded-full bg-[#10B981]/15 border border-[#10B981]/40 mx-auto flex items-center justify-center text-[#10B981]">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#10B981]">
                CONFIGURAÇÃO CONCLUÍDA
              </span>
              <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
                Tudo pronto, {nome.trim() || 'Atleta'}!
              </h1>
              <p className="text-xs text-[#9CA3AF] max-w-xs mx-auto leading-relaxed">
                Seu perfil e sua rotina semanal foram configurados. Você pode iniciar um treino na Arena agora ou explorar o painel principal.
              </p>
            </div>

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 text-left space-y-3">
              <div className="flex items-center justify-between text-xs border-b border-white/[0.05] pb-2.5">
                <span className="text-[#9CA3AF]">Atleta & Nível</span>
                <span className="font-bold text-[#F4F5F7]">
                  {nome.trim()} · {experiencia}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs border-b border-white/[0.05] pb-2.5">
                <span className="text-[#9CA3AF]">Objetivo</span>
                <span className="font-bold text-[#D4AF37] truncate max-w-[200px]">
                  {objetivo}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9CA3AF]">Programação</span>
                <span className="font-mono font-bold text-[#F4F5F7]">
                  {diasSelecionados.length} dias/sem · ~{duracaoMediaMin} min
                </span>
              </div>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={() => handleFinalize('inicio')}
                className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                <span>Ir para o Início (Dashboard)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFinalize('executar')}
                className="w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#F4F5F7] inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Dumbbell className="w-4 h-4 text-[#D4AF37]" />
                <span>Abrir Arena de Treino direto</span>
              </button>
            </div>
          </div>
        )}
      </main>

      <footer className="w-full max-w-md mx-auto px-5 pb-6 text-center">
        <span className="text-[11px] text-[#9CA3AF]">
          AURUS GYM • Seus dados ficam salvos localmente no seu dispositivo
        </span>
      </footer>
    </div>
  );
}
