import React, { ChangeEvent } from 'react';
import { Download, Smartphone, Upload, X } from 'lucide-react';

interface DailyGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExportBackup: () => void;
  onImportBackup: (event: ChangeEvent<HTMLInputElement>) => void;
}

export function DailyGuideModal({
  isOpen,
  onClose,
  onExportBackup,
  onImportBackup
}: DailyGuideModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#14161B] border border-[#D4AF37]/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#F5F1E8]/[0.08] pb-4">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-lg font-bold text-[#F5F1E8]">
              Como Usar o AURUS GYM no Dia a Dia na Academia
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#1B1E24] text-[#9BA0AA] hover:text-[#F5F1E8] transition"
            aria-label="Fechar Guia"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-[#0B0D10] border border-[#F5F1E8]/[0.08] rounded-xl p-4 space-y-2">
            <div className="text-[#D4AF37] font-bold uppercase">
              1. Acesso Rápido na Academia
            </div>
            <p className="text-[#F5F1E8] leading-relaxed">
              O AURUS GYM roda diretamente no navegador do seu celular com salvamento automático instantâneo:
            </p>
            <ul className="list-disc list-inside text-slate-400 space-y-1">
              <li>Funciona em qualquer smartphone sem precisar de download na App Store.</li>
              <li>Todas as suas medidas, cargas e anotações ficam salvas localmente e sincronizadas.</li>
              <li>Acesse o link do app no Safari (iPhone) ou Chrome (Android).</li>
            </ul>
          </div>

          <div className="bg-[#0B0F17] border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="text-emerald-400 font-black uppercase">
              2. Transformar em App na Tela Inicial
            </div>
            <p className="text-slate-300 leading-relaxed">
              Para abrir como um aplicativo nativo em tela cheia:
            </p>
            <ul className="list-disc list-inside text-slate-400 space-y-1">
              <li><strong>No iPhone (Safari):</strong> Toque no ícone de <em>Compartilhar</em> → <em>Adicionar à Tela de Início</em>.</li>
              <li><strong>No Android (Chrome):</strong> Toque no menu de <em>3 pontos</em> → <em>Adicionar à tela inicial / Instalar aplicativo</em>.</li>
              <li>Pronto! Ele abre sem barras de navegador, com ícone próprio na sua tela!</li>
            </ul>
          </div>
        </div>

        <div className="bg-[#0B0F17] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-black text-white">Backup Portátil de Segurança (JSON)</h4>
            <p className="text-xs text-slate-400">
              Além do salvamento automático, você pode baixar ou restaurar todas as suas medidas, cargas e treinos gerados pela IA.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onExportBackup}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 text-slate-950 font-black text-xs hover:brightness-110 transition"
            >
              <Download className="w-3.5 h-3.5" /> Baixar Backup
            </button>
            <label className="cursor-pointer flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition">
              <Upload className="w-3.5 h-3.5 text-emerald-400" /> Restaurar
              <input type="file" accept=".json" onChange={onImportBackup} className="hidden" />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
