import React from 'react';
import {
  BookOpen,
  Dumbbell,
  Home,
  TrendingUp,
  User
} from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  redZonesCount?: number;
}

export function BottomNav({
  activeTab,
  setActiveTab
}: BottomNavProps) {
  const items = [
    {
      id: 'inicio',
      matchIds: ['inicio'],
      label: 'Início',
      icon: Home
    },
    {
      id: 'executar',
      matchIds: ['executar'],
      label: 'Treinar',
      icon: Dumbbell
    },
    {
      id: 'evolucao',
      matchIds: ['evolucao'],
      label: 'Evolução',
      icon: TrendingUp
    },
    {
      id: 'ia',
      matchIds: ['ia', 'exercicios', 'scanner'],
      label: 'Exercícios',
      icon: BookOpen
    },
    {
      id: 'perfil',
      matchIds: ['perfil', 'questionario', 'workspace'],
      label: 'Perfil',
      icon: User
    }
  ];

  return (
    <nav
      aria-label="Navegação principal"
      className="fixed bottom-0 inset-x-0 z-40 lg:hidden pb-safe bg-[#08090C]/95 backdrop-blur-xl border-t border-white/[0.06]"
    >
      <div className="h-16 max-w-md mx-auto px-2 flex items-center justify-around">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = item.matchIds.includes(activeTab);

          return (
            <button
              key={item.id}
              type="button"
              aria-current={isActive ? 'page' : undefined}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] gap-1 transition-colors select-none cursor-pointer ${
                isActive
                  ? 'text-[#D4AF37]'
                  : 'text-[#9CA3AF] hover:text-[#F4F5F7] active:text-[#D4AF37]'
              }`}
            >
              <Icon
                className={`w-[22px] h-[22px] transition-transform ${
                  isActive
                    ? 'text-[#D4AF37] stroke-[2.3]'
                    : 'text-[#9CA3AF] stroke-[1.9]'
                }`}
              />

              <span
                className={`text-[11px] tracking-wide leading-none ${
                  isActive ? 'font-bold text-[#D4AF37]' : 'font-medium text-[#9CA3AF]'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
