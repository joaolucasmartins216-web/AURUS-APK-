import React, { useMemo } from 'react';
import {
  AlertTriangle,
  Bed,
  Bot,
  Calendar,
  CalendarCheck,
  Check,
  CheckCheck,
  ChevronRight,
  Clock,
  Dumbbell,
  Eye,
  ListChecks,
  Play,
  Sliders,
  Timer,
  TrendingDown,
  TrendingUp,
  Trophy
} from 'lucide-react';
import {
  BiometricMetrics,
  CheckinRecord,
  CompletedWorkout,
  GoldenAnalysis,
  UserProfile,
  WorkoutDay
} from '../types';
import { ALL_WEEK_DAYS } from '../utils/constants';
import {
  buildRecordedLoadsList,
  calculateCurrentWeekStats,
  calculatePredictedWorkoutLoad,
  cleanDisplayText,
  estimateWorkoutDurationMin,
  getShortMuscleLabel,
  isUserDataConfirmed,
  resolveWorkoutSchedule,
  splitCheckinsByOrigin
} from '../utils/dashboardLogic';

interface DashboardHomeViewProps {
  profile: UserProfile;
  metrics: BiometricMetrics;
  goldenAnalysis: GoldenAnalysis;
  onboardingCompleted: boolean;
  dynamicWorkouts: WorkoutDay[];
  currentDayWorkout: WorkoutDay;
  selectedDayId: string;
  onSelectDayId: (dayId: string) => void;
  workoutHistory: CompletedWorkout[];
  checkins: CheckinRecord[];
  lastExerciseWeights: Record<string, number>;
  onClearDemoCheckins?: () => void;
  onOpenDailyGuide?: () => void;
  onNavigateTab: (tab: string) => void;
  onStartWorkoutSession?: (dayId?: string) => void;
}

export function DashboardHomeView({
  profile,
  metrics,
  goldenAnalysis,
  onboardingCompleted,
  dynamicWorkouts,
  currentDayWorkout,
  selectedDayId,
  onSelectDayId,
  workoutHistory,
  checkins,
  lastExerciseWeights,
  onClearDemoCheckins,
  onNavigateTab,
  onStartWorkoutSession
}: DashboardHomeViewProps) {
  // Saudação baseada no horário real do dispositivo
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  }, []);

  // Formata o nome para leitura natural ("JOÃO" -> "João"), preservando o estado original
  const displayUserName = useMemo(() => {
    const raw = (profile.nome || 'Atleta').trim();
    if (raw === raw.toUpperCase() && raw.length > 1) {
      return raw
        .toLowerCase()
        .split(/\s+/)
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');
    }
    return raw;
  }, [profile.nome]);

  // Separar check-ins reais de simulações demonstrativas
  const { realCheckins, demoCheckins } = useMemo(
    () => splitCheckinsByOrigin(checkins),
    [checkins]
  );

  // Verificar se o perfil e as medidas foram efetivamente confirmados pelo usuário
  const userConfirmedData = useMemo(
    () =>
      isUserDataConfirmed({
        onboardingCompleted,
        profile,
        metrics
      }),
    [onboardingCompleted, profile, metrics]
  );

  // Variação real de peso apenas se houver pelo menos 2 check-ins reais registrados
  const realWeightDelta = useMemo(() => {
    if (realCheckins.length < 2) return null;
    const sorted = [...realCheckins].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    const diff = +(Number(sorted[0].peso) - Number(sorted[1].peso)).toFixed(1);
    return diff;
  }, [realCheckins]);

  // Cálculo consistente da semana atual (Segunda a Domingo no horário local)
  const stats = useMemo(() => {
    const targetDays = Math.max(1, profile.diasSemana || dynamicWorkouts.length || 1);
    return calculateCurrentWeekStats(workoutHistory, targetDays);
  }, [workoutHistory, profile.diasSemana, dynamicWorkouts.length]);

  // Identificação do treino programado para hoje vs próximo vs seleção manual
  const scheduleResolution = useMemo(() => {
    return resolveWorkoutSchedule(
      dynamicWorkouts,
      selectedDayId,
      stats.trainedWeekdayIds
    );
  }, [dynamicWorkouts, selectedDayId, stats.trainedWeekdayIds]);

  const displayedWorkout = scheduleResolution.displayedWorkout || currentDayWorkout;

  const estimatedDurationMin = useMemo(
    () => estimateWorkoutDurationMin(displayedWorkout),
    [displayedWorkout]
  );

  // Carga prevista real (somente quando houver pesos salvos para os exercícios da ficha)
  const predictedLoad = useMemo(
    () => calculatePredictedWorkoutLoad(displayedWorkout, lastExerciseWeights),
    [displayedWorkout, lastExerciseWeights]
  );

  // Cargas reais reconciliadas de workoutHistory e lastExerciseWeights
  const recordedLoads = useMemo(() => {
    return buildRecordedLoadsList(workoutHistory, lastExerciseWeights, dynamicWorkouts);
  }, [workoutHistory, lastExerciseWeights, dynamicWorkouts]);

  // Resumo curto de foco para o sub-card do Hero
  const heroFocusShort = useMemo(() => {
    if (!displayedWorkout) return 'Geral';
    const rawSub = cleanDisplayText(displayedWorkout.subtitle)
      .replace(/\(.*?\)/g, '')
      .replace(/^Foco:\s*/i, '')
      .trim();
    if (rawSub.length > 0 && rawSub.length <= 28) return rawSub;
    const exGroups = Array.from(
      new Set(
        (displayedWorkout.exercises || [])
          .map((e) => e.partLabel || e.targetGroup)
          .filter(Boolean)
      )
    );
    if (exGroups.length > 0) {
      return exGroups.slice(0, 2).join(' e ');
    }
    return getShortMuscleLabel(displayedWorkout);
  }, [displayedWorkout]);

  // Formatação técnica de duração para o Resumo da Semana
  const weeklyTimeDisplay = useMemo(() => {
    const sec = stats.weeklyDurationSec;
    if (!sec || sec <= 0) return { value: '0', unit: 'min' };
    const totalMin = Math.floor(sec / 60);
    if (totalMin === 0) return { value: `${sec}`, unit: 's' };
    if (totalMin < 60) return { value: `${totalMin}`, unit: 'min' };
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return {
      value: m > 0 ? `${h}h ${m}` : `${h}h`,
      unit: m > 0 ? 'min' : ''
    };
  }, [stats.weeklyDurationSec]);

  const averageSessionMin = useMemo(() => {
    if (stats.weeklySessionsCount <= 0 || stats.weeklyDurationSec <= 0) return 0;
    return Math.max(1, Math.round(stats.weeklyDurationSec / 60 / stats.weeklySessionsCount));
  }, [stats.weeklySessionsCount, stats.weeklyDurationSec]);

  const formatDurationInline = (sec: number) => {
    if (!sec || sec <= 0) return '0 min';
    const totalMin = Math.floor(sec / 60);
    if (totalMin === 0) return `${sec}s`;
    if (totalMin < 60) return `${totalMin} min`;
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return m > 0 ? `${h}h ${m}min` : `${h}h`;
  };

  const handleStartWorkout = (dayId?: string) => {
    if (onStartWorkoutSession) {
      onStartWorkoutSession(dayId);
      return;
    }
    if (dayId) {
      onSelectDayId(dayId);
    }
    onNavigateTab('executar');
  };

  // Extrai letra da ficha (A, B, C...) para a barra de programação semanal
  const getRoutineCode = (dayId: string): string => {
    const idx = dynamicWorkouts.findIndex((w) => w.id === dayId);
    if (idx === -1) return '—';
    const workout = dynamicWorkouts[idx];
    const match = workout.title?.match(/Treino\s+([A-Z])/i);
    if (match && match[1]) return match[1].toUpperCase();
    return String.fromCharCode(65 + (idx % 26));
  };

  const remainingWeeklySessions = Math.max(0, stats.targetWeeklyDays - stats.trainedDaysCount);

  return (
    <div className="flex flex-col w-full gap-6 text-[#F4F5F7]">
      {/* 1. SAUDAÇÃO E RESUMO RÁPIDO (FIEL AO GOOGLE STITCH) */}
      <section className="flex flex-col gap-3 pt-1">
        <div className="flex items-center justify-between gap-3">
          <div className="flex flex-col min-w-0">
            <h1 className="text-[24px] sm:text-[26px] leading-[30px] sm:leading-[32px] font-bold text-[#F4F5F7] tracking-tight truncate">
              {greeting}, {displayUserName}
            </h1>
            <p className="text-[14px] leading-[20px] text-[#9CA3AF] font-medium mt-0.5">
              Meta: {stats.targetWeeklyDays} treinos na semana
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('questionario')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1A1D24] card-border shrink-0 hover:border-[#D4AF37]/40 transition cursor-pointer"
            title={
              userConfirmedData
                ? 'Perfil confirmado — Editar medidas'
                : 'Valores padrão demonstrativos — Configurar perfil'
            }
          >
            <span
              className={`w-2 h-2 rounded-full ${
                userConfirmedData ? 'bg-[#10B981]' : 'bg-[#F59E0B]'
              }`}
            />
            <span className="text-[12px] font-semibold text-[#F4F5F7]">
              {userConfirmedData ? 'Ativo' : 'Perfil padrão'}
            </span>
          </button>
        </div>

        {/* AVISO CLARO QUANDO OS DADOS AINDA SÃO VALORES PADRÃO DEMONSTRATIVOS */}
        {!userConfirmedData && (
          <div className="bg-[#13151A] border border-[#D4AF37]/30 rounded-2xl p-3.5 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[12px] font-semibold text-[#D4AF37]">
                Configuração inicial pendente
              </div>
              <p className="text-[12px] text-[#9CA3AF] leading-snug mt-0.5">
                Exibindo medidas demonstrativas ({metrics.peso} kg · Φ{' '}
                {goldenAnalysis.indiceAdonisAtual}). Cadastre seus dados reais no Perfil.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('questionario')}
              className="shrink-0 min-h-[40px] px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] text-[12px] font-bold hover:bg-[#E5C158] transition cursor-pointer"
            >
              Configurar
            </button>
          </div>
        )}

        {/* INDICADORES DIRETOS / REAIS (2 CARTÕES LADO A LADO — STITCH) */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          {/* Card 1: Peso Atual */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <span className="text-[12px] font-semibold text-[#9CA3AF] uppercase tracking-wider">
              {userConfirmedData ? 'Peso Atual' : 'Peso (Padrão)'}
            </span>
            <div className="flex items-baseline gap-1.5 my-1">
              <span className="font-mono text-[22px] font-bold text-[#F4F5F7] tabular-nums">
                {Number(metrics.peso).toLocaleString('pt-BR', {
                  minimumFractionDigits: 1,
                  maximumFractionDigits: 1
                })}
              </span>
              <span className="text-[13px] font-medium text-[#9CA3AF]">kg</span>
            </div>
            {realWeightDelta !== null ? (
              <span className="text-[12px] font-medium text-[#10B981] flex items-center gap-1">
                {realWeightDelta <= 0 ? (
                  <TrendingDown className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="font-mono">
                  {realWeightDelta > 0
                    ? `+${realWeightDelta.toLocaleString('pt-BR')} kg`
                    : `${realWeightDelta.toLocaleString('pt-BR')} kg`}
                </span>
                <span>registrado</span>
              </span>
            ) : (
              <span className="text-[12px] font-medium text-[#10B981] flex items-center gap-1">
                <span>Simetria</span>
                <span className="font-mono font-semibold">{goldenAnalysis.overallScore}%</span>
                <span className="text-[#9CA3AF]">· Φ</span>
                <span className="font-mono font-semibold text-[#D4AF37]">
                  {goldenAnalysis.indiceAdonisAtual}
                </span>
              </span>
            )}
          </div>

          {/* Card 2: Frequência */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <span className="text-[12px] font-semibold text-[#9CA3AF] uppercase tracking-wider">
              Frequência
            </span>
            <div className="flex items-baseline gap-1.5 my-1">
              <span className="font-mono text-[22px] font-bold text-[#F4F5F7] tabular-nums">
                {stats.trainedDaysCount}
              </span>
              <span className="text-[13px] font-medium text-[#9CA3AF]">
                de {stats.targetWeeklyDays} treinos
              </span>
            </div>
            <div className="w-full bg-[#1A1D24] h-1.5 rounded-full overflow-hidden mt-1">
              <div
                className="bg-[#D4AF37] h-full rounded-full transition-all duration-300"
                style={{ width: `${stats.weeklyFrequencyPct}%` }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* 2. ATALHOS RÁPIDOS (HORIZONTAL SCROLL — STITCH) */}
      <section
        aria-label="Atalhos rápidos"
        className="flex items-center gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 py-0.5 sm:mx-0 sm:px-0"
      >
        <button
          type="button"
          onClick={() => onNavigateTab('scanner')}
          className="shrink-0 whitespace-nowrap min-h-[44px] flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#1A1D24] card-border text-[#F4F5F7] hover:text-[#D4AF37] transition-colors text-[13px] font-semibold cursor-pointer"
        >
          <Eye className="w-[18px] h-[18px] text-[#D4AF37] shrink-0" />
          <span>Scanner corporal</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigateTab('ia')}
          className="shrink-0 whitespace-nowrap min-h-[44px] flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#1A1D24] card-border text-[#F4F5F7] hover:text-[#D4AF37] transition-colors text-[13px] font-semibold cursor-pointer"
        >
          <Bot className="w-[18px] h-[18px] text-[#D4AF37] shrink-0" />
          <span>Assistente de treino</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigateTab('workspace')}
          className="shrink-0 whitespace-nowrap min-h-[44px] flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#1A1D24] card-border text-[#F4F5F7] hover:text-[#D4AF37] transition-colors text-[13px] font-semibold cursor-pointer"
        >
          <Calendar className="w-[18px] h-[18px] text-[#9CA3AF] shrink-0" />
          <span>Agenda</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigateTab('questionario')}
          className="shrink-0 whitespace-nowrap min-h-[44px] flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#1A1D24] card-border text-[#F4F5F7] hover:text-[#D4AF37] transition-colors text-[13px] font-semibold cursor-pointer"
        >
          <Sliders className="w-[18px] h-[18px] text-[#9CA3AF] shrink-0" />
          <span>Minha rotina</span>
        </button>
      </section>

      {/* 3. CARTÃO TREINO DE HOJE (DESTAQUE HERO — STITCH) */}
      <section className="bg-[#13151A] card-border rounded-2xl p-4 flex flex-col gap-4 relative overflow-hidden shadow-lg">
        <div className="flex items-center justify-between gap-2">
          <span className="shrink-0 whitespace-nowrap inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#1A1D24] text-[12px] font-semibold text-[#D4AF37] card-border">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
            <span>{scheduleResolution.badgeLabel}</span>
          </span>

          <div className="flex items-center gap-2 min-w-0">
            <span className="text-[13px] font-medium text-[#9CA3AF] truncate">
              {scheduleResolution.helperText}
            </span>
            {scheduleResolution.isManualSelection && scheduleResolution.recommendedWorkout && (
              <button
                type="button"
                onClick={() => onSelectDayId(scheduleResolution.recommendedWorkout!.id)}
                className="shrink-0 px-2 py-0.5 rounded-lg bg-[#1A1D24] border border-[#D4AF37]/40 text-[11px] font-semibold text-[#D4AF37] hover:bg-[#D4AF37]/15 transition cursor-pointer"
              >
                Ir para {scheduleResolution.recommendedWorkout.shortDay}
              </button>
            )}
          </div>
        </div>

        {displayedWorkout ? (
          <div className="flex flex-col gap-1">
            <h2 className="text-[18px] font-bold text-[#F4F5F7] leading-tight">
              {cleanDisplayText(displayedWorkout.title)}
            </h2>
            <p className="text-[14px] text-[#9CA3AF]">
              <span className="font-mono font-semibold text-[#F4F5F7]">
                {displayedWorkout.exercises.length}
              </span>{' '}
              exercícios ·{' '}
              <span className="font-mono font-semibold text-[#F4F5F7]">
                {displayedWorkout.totalDaySets || 0}
              </span>{' '}
              séries ·{' '}
              <span className="font-mono font-semibold text-[#F4F5F7]">
                ~{estimatedDurationMin}
              </span>{' '}
              min
            </p>
          </div>
        ) : (
          <div className="text-[14px] font-medium text-[#9CA3AF]">
            Nenhum treino programado para os dias selecionados.
          </div>
        )}

        {displayedWorkout && (
          <div className="grid grid-cols-2 gap-2.5 pt-0.5">
            <div className="bg-[#1A1D24] card-border rounded-xl p-2.5 flex items-center gap-2.5 min-w-0">
              <Dumbbell className="w-5 h-5 text-[#D4AF37] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span className="text-[11px] uppercase tracking-wider text-[#9CA3AF] font-semibold leading-tight">
                  Foco
                </span>
                <span className="text-[13px] font-semibold text-[#F4F5F7] leading-snug truncate mt-0.5">
                  {heroFocusShort}
                </span>
              </div>
            </div>

            <div className="bg-[#1A1D24] card-border rounded-xl p-2.5 flex items-center gap-2.5 min-w-0">
              <Timer className="w-5 h-5 text-[#D4AF37] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span className="text-[11px] uppercase tracking-wider text-[#9CA3AF] font-semibold leading-tight">
                  {predictedLoad.predictedLoadKg > 0 ? 'Carga prevista' : 'Volume da ficha'}
                </span>
                <span className="text-[13px] font-semibold text-[#F4F5F7] font-mono leading-snug mt-0.5">
                  {predictedLoad.predictedLoadKg > 0
                    ? `${predictedLoad.predictedLoadKg.toLocaleString('pt-BR')} kg`
                    : `${displayedWorkout.totalDaySets || 0} séries`}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* BOTÃO PRINCIPAL COM CONTRASTE CLARO (52px — DESIGN SYSTEM 3.1) */}
        <button
          type="button"
          onClick={() => handleStartWorkout(displayedWorkout?.id)}
          className="w-full h-[52px] rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] active:scale-[0.99] transition-all text-[#08090C] font-bold text-[15px] flex items-center justify-center gap-2 shadow-md cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>
            {scheduleResolution.isManualSelection
              ? `Iniciar treino (${displayedWorkout?.shortDay || ''})`
              : 'Iniciar treino'}
          </span>
        </button>
      </section>

      {/* 4. SEMANA ATUAL / PROGRAMAÇÃO SEMANAL (STITCH) */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-[20px] font-bold text-[#F4F5F7] shrink-0 whitespace-nowrap">
            Semana atual
          </h3>
          <span className="text-[13px] font-medium text-[#9CA3AF] font-mono">
            {stats.weekLabel}
          </span>
        </div>

        <div className="grid grid-cols-7 gap-1.5 bg-[#13151A] card-border p-2 rounded-2xl">
          {ALL_WEEK_DAYS.map((day) => {
            const workoutForDay = dynamicWorkouts.find((w) => w.id === day.id) || null;
            const isPlanned = Boolean(workoutForDay);
            const sessionsOnDay = stats.sessionsPerWeekday[day.id] || 0;
            const isTrained = sessionsOnDay > 0;
            const isSelected = (displayedWorkout?.id || selectedDayId) === day.id;
            const isToday = scheduleResolution.todayWeekdayId === day.id;
            const routineCode = getRoutineCode(day.id);
            const shortMuscle = getShortMuscleLabel(workoutForDay);

            if (isTrained) {
              return (
                <button
                  key={day.id}
                  type="button"
                  onClick={() => isPlanned && onSelectDayId(day.id)}
                  aria-label={`${day.full} - Feito`}
                  className={`flex flex-col items-center py-2 px-1 rounded-xl bg-[#1A1D24] text-center gap-1.5 transition cursor-pointer ${
                    isSelected ? 'ring-1 ring-[#D4AF37]/60' : ''
                  }`}
                >
                  <span className="text-[11px] font-semibold text-[#9CA3AF]">{day.short}</span>
                  <div className="w-7 h-7 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center">
                    <Check className="w-4 h-4 stroke-[2.5]" />
                  </div>
                  <span className="text-[10px] font-semibold text-[#10B981]">
                    {sessionsOnDay > 1 ? `${sessionsOnDay}x` : 'Feito'}
                  </span>
                </button>
              );
            }

            if (isSelected) {
              return (
                <button
                  key={day.id}
                  type="button"
                  onClick={() => isPlanned && onSelectDayId(day.id)}
                  aria-label={`${day.full} - ${isToday ? 'Hoje' : shortMuscle}`}
                  className="flex flex-col items-center py-2 px-1 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-center gap-1.5 transition cursor-pointer"
                >
                  <span className="text-[11px] font-bold text-[#D4AF37]">{day.short}</span>
                  <div className="w-7 h-7 rounded-full bg-[#D4AF37] text-[#08090C] flex items-center justify-center">
                    <Dumbbell className="w-4 h-4 stroke-[2.3]" />
                  </div>
                  <span className="text-[10px] font-bold text-[#D4AF37] truncate max-w-full">
                    {isToday ? 'Hoje' : shortMuscle}
                  </span>
                </button>
              );
            }

            if (isPlanned) {
              return (
                <button
                  key={day.id}
                  type="button"
                  onClick={() => onSelectDayId(day.id)}
                  aria-label={`${day.full} - Treino ${routineCode} (${shortMuscle})`}
                  className="flex flex-col items-center py-2 px-1 rounded-xl bg-transparent hover:bg-[#1A1D24]/60 text-center gap-1.5 transition cursor-pointer"
                >
                  <span className="text-[11px] font-medium text-[#9CA3AF]">{day.short}</span>
                  <div className="w-7 h-7 rounded-full bg-[#1A1D24] text-[#9CA3AF] flex items-center justify-center">
                    <span className="text-[12px] font-mono font-medium">{routineCode}</span>
                  </div>
                  <span className="text-[10px] font-medium text-[#9CA3AF] truncate max-w-full">
                    {isToday ? 'Hoje' : shortMuscle}
                  </span>
                </button>
              );
            }

            return (
              <div
                key={day.id}
                aria-label={`${day.full} - Descanso`}
                className="flex flex-col items-center py-2 px-1 rounded-xl bg-transparent text-center gap-1.5 opacity-60"
              >
                <span className="text-[11px] font-medium text-[#9CA3AF]">{day.short}</span>
                <div className="w-7 h-7 rounded-full bg-[#1A1D24] text-[#9CA3AF] flex items-center justify-center">
                  <Bed className="w-3.5 h-3.5" />
                </div>
                <span className="text-[10px] font-medium text-[#9CA3AF]">Off</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. RESUMO DA SEMANA (4 CARTÕES EM GRADE 2x2 — STITCH) */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-[20px] font-bold text-[#F4F5F7] shrink-0 whitespace-nowrap">
            Resumo da semana
          </h3>
          <span className="text-[12px] font-medium text-[#9CA3AF] truncate">
            {stats.lastWorkout
              ? `${stats.weeklySessionsCount} ${
                  stats.weeklySessionsCount === 1 ? 'treino na semana' : 'treinos na semana'
                }`
              : 'Segunda a Domingo'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* CARD 1: Treinos feitos */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#9CA3AF]">
              <span className="text-[12px] font-semibold uppercase tracking-wider">
                Treinos feitos
              </span>
              <CalendarCheck className="w-[18px] h-[18px] text-[#D4AF37] shrink-0" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-[24px] font-bold text-[#F4F5F7] tabular-nums">
                  {stats.trainedDaysCount}
                </span>
                <span className="text-[13px] text-[#9CA3AF]">de {stats.targetWeeklyDays}</span>
              </div>
            </div>
            <span className="text-[12px] text-[#9CA3AF]">
              {remainingWeeklySessions === 0
                ? 'Meta semanal atingida'
                : `Faltam ${remainingWeeklySessions} ${
                    remainingWeeklySessions === 1 ? 'sessão' : 'sessões'
                  }`}
            </span>
          </div>

          {/* CARD 2: Tempo total */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#9CA3AF]">
              <span className="text-[12px] font-semibold uppercase tracking-wider">
                Tempo total
              </span>
              <Clock className="w-[18px] h-[18px] text-[#D4AF37] shrink-0" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-[24px] font-bold text-[#F4F5F7] tabular-nums">
                  {weeklyTimeDisplay.value}
                </span>
                {weeklyTimeDisplay.unit && (
                  <span className="text-[13px] text-[#9CA3AF]">{weeklyTimeDisplay.unit}</span>
                )}
              </div>
            </div>
            <span className="text-[12px] text-[#9CA3AF]">
              {averageSessionMin > 0
                ? `Média: ${averageSessionMin} min / treino`
                : 'Nenhuma sessão na semana'}
            </span>
          </div>

          {/* CARD 3: Volume total */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#9CA3AF]">
              <span className="text-[12px] font-semibold uppercase tracking-wider">
                Volume total
              </span>
              <Dumbbell className="w-[18px] h-[18px] text-[#10B981] shrink-0" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-[24px] font-bold text-[#F4F5F7] tabular-nums">
                  {stats.weeklyTonnage.toLocaleString('pt-BR')}
                </span>
                <span className="text-[13px] text-[#9CA3AF]">kg</span>
              </div>
            </div>
            <span
              className={`text-[12px] font-medium ${
                stats.weeklyTonnage > 0 ? 'text-[#10B981]' : 'text-[#9CA3AF]'
              }`}
            >
              {stats.weeklySessionsCount > 0
                ? `${stats.weeklySessionsCount} ${
                    stats.weeklySessionsCount === 1 ? 'sessão concluída' : 'sessões concluídas'
                  }`
                : 'Aguardando 1º treino'}
            </span>
          </div>

          {/* CARD 4: Séries feitas */}
          <div className="bg-[#13151A] card-border p-3.5 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#9CA3AF]">
              <span className="text-[12px] font-semibold uppercase tracking-wider">
                Séries feitas
              </span>
              <ListChecks className="w-[18px] h-[18px] text-[#D4AF37] shrink-0" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-[24px] font-bold text-[#F4F5F7] tabular-nums">
                  {stats.weeklyCompletedSets}
                </span>
                <span className="text-[13px] text-[#9CA3AF]">séries</span>
              </div>
            </div>
            <span className="text-[12px] text-[#9CA3AF]">
              {stats.weeklyCompletedSets > 0
                ? `Histórico: ${stats.totalSessionsAllTime} ${
                    stats.totalSessionsAllTime === 1 ? 'treino' : 'treinos'
                  }`
                : '0 séries na semana'}
            </span>
          </div>
        </div>
      </section>

      {/* 6. ÚLTIMO TREINO CONCLUÍDO & CARGAS REGISTRADAS (STITCH) */}
      <section className="bg-[#13151A] card-border rounded-2xl p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-[#1A1D24] card-border flex items-center justify-center text-[#10B981] shrink-0">
              <CheckCheck className="w-[18px] h-[18px]" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#9CA3AF]">
                Último treino
              </span>
              {stats.lastWorkout ? (
                <span className="text-[14px] font-semibold text-[#F4F5F7] truncate">
                  {cleanDisplayText(stats.lastWorkout.title)} · {stats.lastWorkout.dateFormatted}
                </span>
              ) : (
                <span className="text-[14px] font-semibold text-[#9CA3AF]">
                  Nenhum treino registrado ainda
                </span>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('evolucao')}
            aria-label="Ver histórico de evolução"
            className="text-[#9CA3AF] hover:text-[#D4AF37] transition-colors p-1.5 rounded-lg cursor-pointer shrink-0"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {stats.lastWorkout && (
          <div className="flex flex-wrap items-center gap-2 text-[12px] text-[#9CA3AF] px-1">
            <span>
              Volume:{' '}
              <strong className="font-mono text-[#10B981]">
                {stats.lastWorkout.tonnage.toLocaleString('pt-BR')} kg
              </strong>
            </span>
            <span>·</span>
            <span>
              Séries:{' '}
              <strong className="font-mono text-[#F4F5F7]">
                {stats.lastWorkout.completedSets}/{stats.lastWorkout.totalSets}
              </strong>
            </span>
            <span>·</span>
            <span>
              Duração:{' '}
              <strong className="font-mono text-[#F4F5F7]">
                {formatDurationInline(stats.lastWorkout.durationSec)}
              </strong>
            </span>
          </div>
        )}

        {/* DESTAQUE DE CARGAS REAIS REGISTRADAS (OU ESTADO VAZIO TRANSPARENTE) */}
        {recordedLoads.length > 0 ? (
          <div className="flex flex-col gap-2">
            {recordedLoads.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-xl bg-[#1A1D24] card-border gap-2"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0">
                    <Trophy className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#D4AF37]">
                      {item.hasProgressionHistory ? 'Recorde registrado' : 'Carga registrada'}
                    </span>
                    <span className="text-[13px] font-semibold text-[#F4F5F7] truncate">
                      {item.name}
                    </span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-[#D4AF37]/20 text-[#D4AF37] text-[12px] font-mono font-bold shrink-0">
                  {item.lastWeight} kg
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#1A1D24] card-border gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0">
                <Trophy className="w-4 h-4" />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#D4AF37]">
                  Cargas e recordes
                </span>
                <span className="text-[12px] text-[#9CA3AF] leading-snug">
                  Conclua séries na aba Treinar para registrar suas cargas reais.
                </span>
              </div>
            </div>
          </div>
        )}

        {/* SEPARAÇÃO TRANSPARENTE DE SIMULAÇÕES DEMONSTRATIVAS SE EXISTIREM */}
        {demoCheckins.length > 0 && (
          <div className="bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-xl p-3 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-[12px] text-[#F4F5F7]">
              <AlertTriangle className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <span>
                Simulação ativa (<strong className="font-mono">{demoCheckins.length}</strong>{' '}
                registros demo separados dos dados reais).
              </span>
            </div>
            {onClearDemoCheckins && (
              <button
                type="button"
                onClick={onClearDemoCheckins}
                className="text-[12px] font-bold text-[#D4AF37] underline shrink-0 hover:text-[#E5C158] cursor-pointer"
              >
                Limpar
              </button>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
