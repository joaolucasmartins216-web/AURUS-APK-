import React from 'react';
import {
  BrainCircuit,
  CalendarDays,
  Dumbbell,
  Eye,
  Home,
  ShieldCheck,
  Sliders,
  Smartphone,
  TrendingUp,
  Wand2,
  X
} from 'lucide-react';
import { GoldenAnalysis, UserProfile } from '../types';
import { AurusLogo } from './AurusLogo';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  profile: UserProfile;
  goldenAnalysis: GoldenAnalysis;
  customAiWorkouts: any;
  onOpenDailyGuide: () => void;
  onQuickReformulateWeek: () => void;
  isGeneratingAi: boolean;
  onOpenWizard: () => void;
  googleUser?: any;
}

export function Sidebar({
  activeTab,
  setActiveTab,
  mobileMenuOpen,
  setMobileMenuOpen,
  profile,
  goldenAnalysis,
  customAiWorkouts,
  onOpenDailyGuide,
  onQuickReformulateWeek,
  isGeneratingAi,
  onOpenWizard,
  googleUser
}: SidebarProps) {
  const navItems = [
    {
      id: 'inicio',
      label: 'Início',
      sub: 'Resumo, treino de hoje e semana',
      icon: Home,
      badge: 'Início'
    },
    {
      id: 'executar',
      label: 'Treinar',
      sub: 'Execução de séries e descanso',
      icon: Dumbbell,
      badge: 'Ativo'
    },
    {
      id: 'evolucao',
      label: 'Evolução',
      sub: 'Histórico, cargas e check-ins',
      icon: TrendingUp
    },
    {
      id: 'ia',
      label: 'Exercícios',
      sub: 'Minha rotina e Coach IA',
      icon: BrainCircuit,
      badge: customAiWorkouts ? 'Coach IA' : 'Rotina'
    },
    {
      id: 'perfil',
      label: 'Perfil',
      sub: 'Rotina, ajustes, backup e conta',
      icon: Sliders
    },
    {
      id: 'scanner',
      label: 'Scanner 3D',
      sub: 'Mapeamento corporal e simetria',
      icon: Eye,
      badge: `${goldenAnalysis.redZones.length} Foco`
    },
    {
      id: 'workspace',
      label: 'Agenda e integrações',
      sub: 'Google Agenda e notificações',
      icon: CalendarDays,
      badge: googleUser ? 'Conectado' : 'Google'
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-[#08090C] border-r border-white/[0.06] flex flex-col justify-between transition-transform duration-300 ease-in-out pt-safe ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top: Logo & Profile Snapshot */}
        <div className="p-5 space-y-5 overflow-y-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AurusLogo size="md" />
              <div>
                <h1 className="text-base font-bold tracking-wider text-[#F4F5F7] leading-none">
                  AURUS <span className="text-[#D4AF37]">GYM</span>
                </h1>
                <span className="text-[11px] text-[#9CA3AF] font-medium">
                  Musculação e Performance
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-[#13151A] card-border text-[#9CA3AF] hover:text-[#F4F5F7]"
              aria-label="Fechar menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Telemetry Card */}
          <div className="bg-[#10131A] border border-zinc-800/90 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="truncate">
                <div className="text-[10px] uppercase tracking-wider text-[#D4AF37] font-bold">
                  {profile.experiencia} • {profile.diasSemana}x/sem
                </div>
                <div className="text-sm font-extrabold text-zinc-100 truncate">{profile.nome}</div>
              </div>
              <button
                type="button"
                onClick={onOpenWizard}
                className="min-w-[38px] min-h-[38px] flex items-center justify-center rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/20 transition"
                title="Reavaliar Medidas"
                aria-label="Reavaliar Medidas"
              >
                <Sliders className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="bg-[#07080A] p-2.5 rounded-xl border border-zinc-800/80">
                <div className="text-[10px] text-zinc-400">Índice Adônis</div>
                <div className="text-sm font-black text-[#D4AF37]">
                  {goldenAnalysis.indiceAdonisAtual}{' '}
                  <span className="text-[10px] text-zinc-500">/ 1.618</span>
                </div>
              </div>
              <div className="bg-[#07080A] p-2.5 rounded-xl border border-zinc-800/80">
                <div className="text-[10px] text-zinc-400">Simetria Áurea</div>
                <div className="text-sm font-black text-emerald-400">
                  {goldenAnalysis.overallScore}%
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-2 border-t border-zinc-800/80">
              <span className="text-rose-400 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                {goldenAnalysis.redZones.length} Prioridades
              </span>
              <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                {goldenAnalysis.greenZones.length} Medidas OK
              </span>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5">
            <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-widest text-zinc-500">
              Módulos do Sistema
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[52px] flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                    isActive
                      ? 'bg-[#141821] border-[#D4AF37]/60 text-zinc-100 shadow-sm'
                      : 'bg-transparent border-transparent text-zinc-400 hover:bg-[#10131A] hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-lg ${
                        isActive ? 'bg-[#D4AF37] text-zinc-950' : 'bg-[#12151E] text-zinc-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-extrabold leading-tight truncate">
                        {item.label}
                      </div>
                      <div className="text-[10px] text-zinc-500 truncate">{item.sub}</div>
                    </div>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[9px] font-black px-2 py-0.5 rounded-full shrink-0 ${
                        isActive
                          ? 'bg-[#D4AF37] text-zinc-950'
                          : 'bg-[#12151E] text-[#D4AF37] border border-[#D4AF37]/25'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800/80 space-y-2.5 bg-[#07080A] pb-safe">
          <button
            type="button"
            onClick={onQuickReformulateWeek}
            disabled={isGeneratingAi}
            className="w-full min-h-[44px] flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-zinc-950 font-black text-xs shadow-md hover:brightness-110 transition disabled:opacity-50"
          >
            <Wand2 className={`w-4 h-4 ${isGeneratingAi ? 'animate-spin' : ''}`} />
            {isGeneratingAi ? 'Recalibrando com IA...' : 'Reformular Semana (IA)'}
          </button>

          <button
            type="button"
            onClick={onOpenDailyGuide}
            className="w-full min-h-[42px] flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-[#10131A] hover:bg-zinc-800 border border-zinc-800 text-zinc-200 font-bold text-[11px] transition"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#D4AF37]" />
            Instalar no Celular & Backup
          </button>

          <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Sincronização Ativa
            </span>
            <span className="font-mono text-emerald-400 font-bold">Local + Nuvem</span>
          </div>
        </div>
      </aside>
    </>
  );
}
