import React from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Compass,
  Eye,
  Ruler,
  Sparkles,
  UserCheck,
  Wand2
} from 'lucide-react';
import { BiometricMetrics, GoldenAnalysis, UserProfile } from '../types';
import { ALL_WEEK_DAYS } from '../utils/constants';

interface BiometricsWizardProps {
  wizardStep: number;
  setWizardStep: (step: number) => void;
  profile: UserProfile;
  metrics: BiometricMetrics;
  goldenAnalysis: GoldenAnalysis;
  onProfileChange: (field: keyof UserProfile, value: any) => void;
  onMetricChange: (field: keyof BiometricMetrics, value: any) => void;
  onToggleTrainingDay: (dayId: string) => void;
  onSaveAndFinish: (targetTab: string) => void;
  onSaveAndGenerateAi: () => void;
  isSaving: boolean;
  isGeneratingAi: boolean;
  onboardingCompleted: boolean;
}

export function BiometricsWizard({
  wizardStep,
  setWizardStep,
  profile,
  metrics,
  goldenAnalysis,
  onProfileChange,
  onMetricChange,
  onToggleTrainingDay,
  onSaveAndFinish,
  onSaveAndGenerateAi,
  isSaving,
  isGeneratingAi,
  onboardingCompleted
}: BiometricsWizardProps) {
  const activeDays = profile.diasSelecionados || ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#131B2E] via-[#18223A] to-[#131B2E] border border-amber-500/40 rounded-2xl p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-amber-400 text-xs font-black uppercase tracking-widest">
              <Sparkles className="w-4 h-4" /> Calibração Inicial • Passo {wizardStep} de 3
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Mapeamento Biométrico & Estrutura Óssea
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Insira suas medidas reais para pintarmos seu <strong>Avatar 3D Holográfico</strong> e
              permitir que a <strong>Inteligência Artificial</strong> construa seu treino híbrido.
            </p>
          </div>

          {onboardingCompleted && (
            <button
              onClick={() => onSaveAndFinish('scanner')}
              className="self-start sm:self-auto px-4 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-xs font-bold text-slate-200 transition shrink-0"
            >
              Ir direto ao Scanner 3D →
            </button>
          )}
        </div>

        {/* Step Progress Bar */}
        <div className="grid grid-cols-3 gap-3 mt-6">
          {[
            { step: 1, title: '1. Perfil, Peso & Esporte' },
            { step: 2, title: '2. Âncora Óssea & Tronco' },
            { step: 3, title: '3. Membros & Geração IA' }
          ].map((s) => (
            <button
              key={s.step}
              onClick={() => setWizardStep(s.step)}
              className={`p-3 rounded-xl border text-left transition ${
                wizardStep === s.step
                  ? 'bg-amber-500/20 border-amber-400 text-white'
                  : wizardStep > s.step
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                  : 'bg-[#0B0F17]/60 border-slate-800 text-slate-500'
              }`}
            >
              <div className="text-xs font-black truncate">{s.title}</div>
            </button>
          ))}
        </div>
      </div>

      {/* STEP 1 */}
      {wizardStep === 1 && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2.5">
              <UserCheck className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-white">
                Etapa 1: Dados Base, Rotina & Modalidade Esportiva
              </h3>
            </div>
            <span className="text-xs text-slate-400">Proporção de Adônis</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1.5">
                Seu Nome / Apelido
              </label>
              <input
                type="text"
                value={profile.nome}
                onChange={(e) => onProfileChange('nome', e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1.5">
                Idade (anos)
              </label>
              <input
                type="number"
                value={metrics.idade}
                onChange={(e) => onMetricChange('idade', e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1.5">
                Peso Corporal Atual (kg)
              </label>
              <input
                type="number"
                step="0.1"
                value={metrics.peso}
                onChange={(e) => onMetricChange('peso', e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs text-amber-300 font-bold mb-1.5">
                Altura (cm) • Base Adônis
              </label>
              <input
                type="number"
                step="0.5"
                value={metrics.altura}
                onChange={(e) => onMetricChange('altura', e.target.value)}
                className="w-full bg-[#0B0F17] border border-amber-500/50 rounded-xl px-3.5 py-2.5 text-amber-300 font-bold focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1.5">
                Nível de Experiência
              </label>
              <select
                value={profile.experiencia}
                onChange={(e) => onProfileChange('experiencia', e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-bold focus:outline-none focus:border-amber-500"
              >
                <option value="Iniciante">Iniciante (0 a 1 ano)</option>
                <option value="Intermediário">Intermediário (1 a 3 anos)</option>
                <option value="Avançado">Avançado (+3 anos)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1.5">
                Esporte Complementar (Híbrido)
              </label>
              <select
                value={profile.esporteComplementar}
                onChange={(e) => onProfileChange('esporteComplementar', e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-bold focus:outline-none focus:border-amber-500"
              >
                <option value="Futsal / Futebol & Vôlei">Futsal / Futebol & Vôlei</option>
                <option value="Futevôlei & Beach Sports">Futevôlei & Beach Sports</option>
                <option value="Corrida de Rua & Endurance">Corrida de Rua & Endurance</option>
                <option value="Lutas / Artes Marciais">Lutas / Artes Marciais</option>
                <option value="Apenas Musculação Clássica">Apenas Musculação Clássica</option>
              </select>
            </div>
          </div>

          {/* Interactive Day of Week Selector */}
          <div className="bg-[#0B0F17] border border-amber-500/30 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <label className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4" /> Marque os Dias da Semana que Você Vai Treinar
                </label>
                <p className="text-xs text-slate-400 mt-0.5">
                  A Inteligência Artificial vai distribuir seus blocos de hipertrofia, mobilidade e cardio exatamente nos dias marcados abaixo:
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-black self-start sm:self-auto">
                {activeDays.length} {activeDays.length === 1 ? 'dia selecionado' : 'dias selecionados'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-7 gap-2 pt-1">
              {ALL_WEEK_DAYS.map((d) => {
                const isSelected = activeDays.includes(d.id);
                return (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => onToggleTrainingDay(d.id)}
                    className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'bg-gradient-to-b from-amber-500/25 to-amber-500/10 border-amber-400 text-white shadow-md shadow-amber-500/10'
                        : 'bg-[#111726] border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs font-black tracking-wider">{d.short}</span>
                    <span className="text-[10px] font-medium truncate">{d.label}</span>
                    <span
                      className={`mt-1 w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${
                        isSelected ? 'bg-amber-400 text-slate-950 font-black' : 'bg-slate-800 text-slate-600'
                      }`}
                    >
                      {isSelected ? '✓' : '+'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              onClick={() => setWizardStep(2)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-slate-950 font-black text-sm shadow-lg hover:brightness-110 transition"
            >
              Próxima Etapa: Âncora Óssea & Tronco <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2 */}
      {wizardStep === 2 && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2.5">
              <Compass className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-white">
                Etapa 2: Circunferência do Pulso & Medidas de Tronco (cm)
              </h3>
            </div>
            <span className="text-xs text-amber-400 font-bold">
              Meta Cintura: {goldenAnalysis.cinturaIdeal}cm | Meta Ombros: {goldenAnalysis.ombrosIdeais}cm
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-[#0B0F17] p-4 rounded-xl border border-amber-500/50">
              <label className="block text-xs text-amber-300 font-black mb-1">
                Pulso (cm) • Âncora Óssea
              </label>
              <p className="text-[11px] text-slate-400 mb-2">
                Meça logo acima do osso do punho. Base de cálculo da Fórmula de McCallum.
              </p>
              <input
                type="number"
                step="0.1"
                value={metrics.pulso}
                onChange={(e) => onMetricChange('pulso', e.target.value)}
                className="w-full bg-[#131B2E] border border-amber-500/40 rounded-lg px-3 py-2 text-white font-black text-base focus:outline-none focus:border-amber-400"
              />
            </div>

            {[
              { key: 'ombros' as const, label: 'Ombros / Deltoides (cm)', desc: `Meta Áurea: ${goldenAnalysis.ombrosIdeais} cm` },
              { key: 'peito' as const, label: 'Peitoral / Tórax (cm)', desc: `Meta McCallum: ${goldenAnalysis.peitoIdeal} cm` },
              { key: 'cintura' as const, label: 'Cintura Abdominal (cm)', desc: `Meta Adônis: ${goldenAnalysis.cinturaIdeal} cm` },
              { key: 'quadril' as const, label: 'Quadril / Glúteo (cm)', desc: `Meta McCallum: ${goldenAnalysis.quadrilIdeal} cm` },
              { key: 'pescoco' as const, label: 'Pescoço (cm)', desc: `Meta McCallum: ${goldenAnalysis.pescocoIdeal} cm` }
            ].map((item) => (
              <div key={item.key} className="bg-[#0B0F17] p-4 rounded-xl border border-slate-800">
                <label className="block text-xs text-white font-bold mb-1">{item.label}</label>
                <p className="text-[11px] text-amber-400/90 mb-2">{item.desc}</p>
                <input
                  type="number"
                  step="0.1"
                  value={metrics[item.key]}
                  onChange={(e) => onMetricChange(item.key, e.target.value)}
                  className="w-full bg-[#131B2E] border border-slate-700 rounded-lg px-3 py-2 text-white font-bold text-base focus:outline-none focus:border-amber-500"
                />
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setWizardStep(1)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700 transition"
            >
              <ChevronLeft className="w-4 h-4" /> Voltar
            </button>
            <button
              onClick={() => setWizardStep(3)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-slate-950 font-black text-sm shadow-lg hover:brightness-110 transition"
            >
              Próxima Etapa: Braços & Pernas <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3 */}
      {wizardStep === 3 && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2.5">
              <Ruler className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-white">
                Etapa 3: Membros Superiores, Inferiores & Foco Articular
              </h3>
            </div>
            <span className="text-xs text-emerald-400 font-bold">
              Simetria Calculada: {goldenAnalysis.overallScore}%
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { key: 'braco' as const, label: 'Braço Contraído (cm)', desc: `Meta: ${goldenAnalysis.bracoIdeal} cm` },
              { key: 'coxa' as const, label: 'Coxa Média (cm)', desc: `Meta: ${goldenAnalysis.coxaIdeal} cm` },
              { key: 'panturrilha' as const, label: 'Panturrilha (cm)', desc: `Meta: ${goldenAnalysis.panturrilhaIdeal} cm` }
            ].map((item) => (
              <div key={item.key} className="bg-[#0B0F17] p-4 rounded-xl border border-slate-800">
                <label className="block text-xs text-white font-bold mb-1">{item.label}</label>
                <p className="text-[11px] text-amber-400 mb-2">{item.desc}</p>
                <input
                  type="number"
                  step="0.1"
                  value={metrics[item.key]}
                  onChange={(e) => onMetricChange(item.key, e.target.value)}
                  className="w-full bg-[#131B2E] border border-slate-700 rounded-lg px-3 py-2 text-white font-bold text-base focus:outline-none focus:border-amber-500"
                />
              </div>
            ))}
          </div>

          <div>
            <label className="block text-xs text-slate-300 font-bold mb-1.5">
              Foco Principal de Mobilidade e Prevenção de Lesões
            </label>
            <input
              type="text"
              value={profile.focoMobilidade}
              onChange={(e) => onProfileChange('focoMobilidade', e.target.value)}
              className="w-full bg-[#0B0F17] border border-slate-700 rounded-xl px-4 py-2.5 text-white font-medium text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Diagnostic preview */}
          <div className="bg-[#0B0F17] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-bold text-white">
                Prévia do seu Scanner 3D:
              </div>
              <div className="text-xs text-slate-400">
                <strong className="text-rose-400">
                  {goldenAnalysis.redZones.length} regiões em Vermelho
                </strong>{' '}
                (receberão foco extra) e{' '}
                <strong className="text-emerald-400">
                  {goldenAnalysis.greenZones.length} regiões em Verde
                </strong>{' '}
                (medidas em dia!).
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-4 border-t border-slate-800">
            <button
              onClick={() => setWizardStep(2)}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700 transition"
            >
              <ChevronLeft className="w-4 h-4" /> Voltar
            </button>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={() => onSaveAndFinish('scanner')}
                disabled={isSaving}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg hover:brightness-110 transition"
              >
                <Eye className="w-4 h-4" />
                Concluir e Abrir Scanner 3D
              </button>

              <button
                onClick={onSaveAndGenerateAi}
                disabled={isGeneratingAi}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg hover:brightness-110 transition"
              >
                <Wand2 className="w-4 h-4" />
                {isGeneratingAi ? 'Gerando...' : 'Salvar + Gerar Treino com IA'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
