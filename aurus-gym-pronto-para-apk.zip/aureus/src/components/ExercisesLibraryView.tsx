import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Award,
  BarChart3,
  Bot,
  Calendar,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Dumbbell,
  Edit3,
  Layers,
  ListChecks,
  Plus,
  RotateCcw,
  Search,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  Wand2,
  X
} from 'lucide-react';
import {
  BodyPartKey,
  CatalogExercise,
  CompletedWorkout,
  ExerciseEquipmentCategory,
  ExerciseItem,
  ExerciseMuscleFilter,
  GoldenAnalysis,
  SetLog,
  UserProfile,
  WorkoutDay
} from '../types';
import { cleanDisplayText } from '../utils/dashboardLogic';
import {
  addOrUpdateExerciseInRoutine,
  buildExerciseCatalog,
  createCustomCatalogExercise,
  EQUIPMENT_FILTER_OPTIONS,
   filterExerciseCatalog,
  findExistingExerciseInRoutine,
  getExercisePersonalHistorySummary,
  MUSCLE_FILTER_OPTIONS
} from '../utils/exerciseCatalog';
import { AiArchitectureView } from './AiArchitectureView';

interface AiMessage {
  role: 'user' | 'assistant';
  text: string;
}

interface ExercisesLibraryViewProps {
  profile: UserProfile;
  goldenAnalysis: GoldenAnalysis;
  dynamicWorkouts: WorkoutDay[];
  customAiWorkouts: WorkoutDay[] | null;
  baseTemplateWorkouts: WorkoutDay[];
  selectedDayId: string;
  onSelectDayId: (id: string) => void;
  currentDayWorkout: WorkoutDay;
  activeSelectedDays: string[];
  onToggleTrainingDay: (dayId: string) => void;
  onReformulate: (options: { scope: 'week' | 'day'; customPrompt?: string }) => void;
  isGeneratingAi: boolean;
  onResetToDefault: () => void;
  onNavigateToArena: (dayId?: string) => void;
  onOpenExerciseEvolution: (exerciseId: string) => void;
  onOpenScanner3D: (partKey?: BodyPartKey) => void;
  workoutHistory: CompletedWorkout[];
  lastExerciseWeights: Record<string, number>;
  customExercises: CatalogExercise[];
  onSaveCustomExercises: (exercises: CatalogExercise[]) => void;
  onUpdateWorkoutsAndSessionSets: (
    updatedWorkouts: WorkoutDay[],
    updatedSessionSets: Record<string, SetLog[]>,
    toastMessage: string,
    toastType?: 'emerald' | 'rose' | 'gold'
  ) => void;
  sessionSets: Record<string, SetLog[]>;
  isSessionActive: boolean;
  activeSessionDayId: string;
  aiCoachMessages: AiMessage[];
  onAskCoach: (question: string) => void;
  isAskingCoach: boolean;
  initialSubView?: 'library' | 'routine' | 'ai' | null;
  onClearInitialSubView?: () => void;
  onApplyPreviewWorkouts?: (proposedWorkouts: WorkoutDay[], scope: 'week' | 'day') => void;
}

type ExercisesSubView = 'library' | 'details' | 'routine' | 'ai';

const REPS_PRESETS = ['6-8', '8-10', '10-12', '12-15'];
const SETS_PRESETS = [2, 3, 4, 5];

export function ExercisesLibraryView({
  profile,
  goldenAnalysis,
  dynamicWorkouts,
  customAiWorkouts,
  baseTemplateWorkouts,
  selectedDayId,
  onSelectDayId,
  currentDayWorkout,
  activeSelectedDays,
  onToggleTrainingDay,
  onReformulate,
  isGeneratingAi,
  onResetToDefault,
  onNavigateToArena,
  onOpenExerciseEvolution,
  onOpenScanner3D,
  workoutHistory,
  lastExerciseWeights,
  customExercises,
  onSaveCustomExercises,
  onUpdateWorkoutsAndSessionSets,
  sessionSets,
  isSessionActive,
  activeSessionDayId,
  aiCoachMessages,
  onAskCoach,
  isAskingCoach,
  initialSubView,
  onClearInitialSubView,
  onApplyPreviewWorkouts
}: ExercisesLibraryViewProps) {
  const [subView, setSubView] = useState<ExercisesSubView>(
    () => initialSubView || 'library'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [muscleFilter, setMuscleFilter] = useState<ExerciseMuscleFilter>('all');
  const [equipmentFilter, setEquipmentFilter] = useState<ExerciseEquipmentCategory | 'all'>('all');
  const [selectedExerciseId, setSelectedExerciseId] = useState<string | null>(null);

  // Estado de Edição da Rotina (Editar Rotina — Grupo 2)
  const [isEditingRoutine, setIsEditingRoutine] = useState(false);
  const [editingDayTitle, setEditingDayTitle] = useState('');
  const [editingDaySubtitle, setEditingDaySubtitle] = useState('');

  useEffect(() => {
    if (initialSubView) {
      setSubView(initialSubView);
      onClearInitialSubView?.();
    }
  }, [initialSubView, onClearInitialSubView]);

  // Estado do Bottom Sheet "Adicionar ao treino"
  const [addSheetExercise, setAddSheetExercise] = useState<CatalogExercise | null>(null);
  const [targetRoutineDayId, setTargetRoutineDayId] = useState<string>(
    () => currentDayWorkout?.id || dynamicWorkouts[0]?.id || 'seg'
  );
  const [plannedSets, setPlannedSets] = useState<number>(4);
  const [plannedReps, setPlannedReps] = useState<string>('8-10');
  const [routinePosition, setRoutinePosition] = useState<'start' | 'end'>('end');
  const [sheetFeedback, setSheetFeedback] = useState<{
    type: 'success' | 'warning' | 'error';
    text: string;
  } | null>(null);

  // Estado do Modal "Criar exercício personalizado"
  const [showCreateCustomModal, setShowCreateCustomModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customMuscle, setCustomMuscle] = useState<Exclude<ExerciseMuscleFilter, 'all'>>('peito');
  const [customEquipment, setCustomEquipment] = useState<ExerciseEquipmentCategory>('halteres');
  const [customCategory, setCustomCategory] =
    useState<CatalogExercise['categoryLabel']>('Composto');
  const [customDescription, setCustomDescription] = useState('');
  const [customError, setCustomError] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    }
  }, [subView, selectedExerciseId]);

  // Catálogo unificado (base + personalizados + rotinas + histórico)
  const fullCatalog = useMemo(
    () =>
      buildExerciseCatalog({
        customExercises,
        workouts: dynamicWorkouts,
        workoutHistory
      }),
    [customExercises, dynamicWorkouts, workoutHistory]
  );

  // Catálogo filtrado por pesquisa + grupo muscular + equipamento
  const filteredCatalog = useMemo(
    () =>
      filterExerciseCatalog(fullCatalog, {
        query: searchQuery,
        muscleFilter,
        equipmentFilter
      }),
    [fullCatalog, searchQuery, muscleFilter, equipmentFilter]
  );

  // Mapa rápido de histórico real por exercício para os cartões
  const historyByExerciseId = useMemo(() => {
    const map = new Map<
      string,
      ReturnType<typeof getExercisePersonalHistorySummary>
    >();
    for (const ex of fullCatalog) {
      map.set(
        ex.id,
        getExercisePersonalHistorySummary(
          ex,
          workoutHistory,
          lastExerciseWeights,
          dynamicWorkouts
        )
      );
    }
    return map;
  }, [fullCatalog, workoutHistory, lastExerciseWeights, dynamicWorkouts]);

  const selectedExercise = useMemo(() => {
    if (!selectedExerciseId) return null;
    return fullCatalog.find((ex) => ex.id === selectedExerciseId) || null;
  }, [fullCatalog, selectedExerciseId]);

  const selectedExerciseHistory = useMemo(() => {
    if (!selectedExercise) return null;
    return (
      historyByExerciseId.get(selectedExercise.id) ||
      getExercisePersonalHistorySummary(
        selectedExercise,
        workoutHistory,
        lastExerciseWeights,
        dynamicWorkouts
      )
    );
  }, [selectedExercise, historyByExerciseId, workoutHistory, lastExerciseWeights, dynamicWorkouts]);

  const handleOpenExerciseDetails = (exercise: CatalogExercise) => {
    setSelectedExerciseId(exercise.id);
    setSubView('details');
  };

  const handleOpenAddSheet = (exercise: CatalogExercise, defaultDayId?: string) => {
    const initialDayId = defaultDayId || currentDayWorkout?.id || dynamicWorkouts[0]?.id || 'seg';
    const targetDay = dynamicWorkouts.find((d) => d.id === initialDayId) || dynamicWorkouts[0];
    const existingInDay = findExistingExerciseInRoutine(targetDay, exercise);

    setAddSheetExercise(exercise);
    setTargetRoutineDayId(initialDayId);
    setPlannedSets(existingInDay?.baseSets || exercise.defaultSets || 4);
    setPlannedReps(existingInDay?.reps || exercise.defaultReps || '8-10');
    setRoutinePosition('end');
    setSheetFeedback(null);
  };

  const handleSelectTargetRoutineInSheet = (dayId: string) => {
    setTargetRoutineDayId(dayId);
    setSheetFeedback(null);
    if (!addSheetExercise) return;
    const targetDay = dynamicWorkouts.find((d) => d.id === dayId);
    const existingInDay = findExistingExerciseInRoutine(targetDay, addSheetExercise);
    if (existingInDay) {
      setPlannedSets(existingInDay.baseSets || addSheetExercise.defaultSets || 4);
      setPlannedReps(existingInDay.reps || addSheetExercise.defaultReps || '8-10');
    }
  };

  const handleConfirmAddToRoutine = () => {
    if (!addSheetExercise) return;

    const targetDay = dynamicWorkouts.find((d) => d.id === targetRoutineDayId);
    const alreadyExists = !!findExistingExerciseInRoutine(targetDay, addSheetExercise);
    const isTargetDaySessionActive =
      isSessionActive && activeSessionDayId === targetRoutineDayId;

    const result = addOrUpdateExerciseInRoutine({
      currentCustomWorkouts: customAiWorkouts,
      baseTemplate: baseTemplateWorkouts,
      targetDayId: targetRoutineDayId,
      catalogExercise: addSheetExercise,
      plannedSets,
      plannedReps,
      plannedRestSec: addSheetExercise.defaultRestSec,
      position: routinePosition,
      allowUpdateExisting: alreadyExists,
      sessionSets,
      isSessionActiveOnTargetDay: isTargetDaySessionActive,
      lastExerciseWeights
    });

    if (result.status === 'error') {
      setSheetFeedback({
        type: 'error',
        text: result.message
      });
      return;
    }

    onUpdateWorkoutsAndSessionSets(
      result.updatedWorkouts,
      result.updatedSessionSets,
      result.message,
      'emerald'
    );

    setSheetFeedback({
      type: 'success',
      text: result.message
    });

    setTimeout(() => {
      setAddSheetExercise(null);
      setSheetFeedback(null);
    }, 550);
  };

  const handleRemoveExerciseFromRoutine = (dayId: string, exerciseItem: ExerciseItem) => {
    const isTargetDayActive = isSessionActive && activeSessionDayId === dayId;
    const existingLogs = sessionSets[exerciseItem.id] || [];
    const hasCompletedSets = existingLogs.some((s) => s.completed);

    if (isTargetDayActive && hasCompletedSets) {
      onUpdateWorkoutsAndSessionSets(
        customAiWorkouts || baseTemplateWorkouts,
        sessionSets,
        `Não é possível remover "${cleanDisplayText(exerciseItem.name)}" pois já existem séries concluídas na sessão ativa.`,
        'rose'
      );
      return;
    }

    const sourceList = (
      customAiWorkouts && customAiWorkouts.length > 0
        ? customAiWorkouts
        : baseTemplateWorkouts
    ).map((day) => ({
      ...day,
      exercises: [...(day.exercises || [])]
    }));

    const targetDay = sourceList.find((d) => d.id === dayId);
    if (!targetDay) return;

    if (targetDay.exercises.length <= 1) {
      onUpdateWorkoutsAndSessionSets(
        sourceList,
        sessionSets,
        'Mantenha pelo menos 1 exercício na rotina deste dia.',
        'gold'
      );
      return;
    }

    targetDay.exercises = targetDay.exercises.filter((ex) => ex.id !== exerciseItem.id);
    const nextSessionSets = { ...sessionSets };
    if (!hasCompletedSets) {
      delete nextSessionSets[exerciseItem.id];
    }

    onUpdateWorkoutsAndSessionSets(
      sourceList,
      nextSessionSets,
      `${cleanDisplayText(exerciseItem.name)} removido de ${cleanDisplayText(targetDay.title)}.`,
      'gold'
    );
  };

  const handleCreateCustomExerciseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCustomError(null);

    const creation = createCustomCatalogExercise({
      name: customName,
      muscleFilter: customMuscle,
      equipmentCategory: customEquipment,
      categoryLabel: customCategory,
      shortDescription: customDescription,
      existingCatalog: fullCatalog
    });

    if (!creation.ok || !creation.exercise) {
      setCustomError(creation.error || 'Não foi possível cadastrar o exercício.');
      return;
    }

    const updatedCustomList = [creation.exercise, ...customExercises];
    onSaveCustomExercises(updatedCustomList);

    setCustomName('');
    setCustomDescription('');
    setShowCreateCustomModal(false);
    setSelectedExerciseId(creation.exercise.id);
    setSubView('details');
  };

  const handleResetAllFilters = () => {
    setSearchQuery('');
    setMuscleFilter('all');
    setEquipmentFilter('all');
  };

  const renderTopSubNav = () => (
    <div
      role="navigation"
      aria-label="Subnavegação de Exercícios"
      className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-[#13151A] border border-white/[0.06]"
    >
      <button
        type="button"
        onClick={() => setSubView('library')}
        aria-pressed={subView === 'library' || subView === 'details'}
        className={`h-10 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
          subView === 'library' || subView === 'details'
            ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
            : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
        }`}
      >
        <Dumbbell className="w-3.5 h-3.5" />
        <span>Catálogo</span>
      </button>

      <button
        type="button"
        onClick={() => setSubView('routine')}
        aria-pressed={subView === 'routine'}
        className={`h-10 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
          subView === 'routine'
            ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
            : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
        }`}
      >
        <ListChecks className="w-3.5 h-3.5" />
        <span>Minha rotina</span>
      </button>

      <button
        type="button"
        onClick={() => setSubView('ai')}
        aria-pressed={subView === 'ai'}
        className={`h-10 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
          subView === 'ai'
            ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
            : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
        }`}
      >
        <Wand2 className="w-3.5 h-3.5" />
        <span>Ajustar com IA</span>
      </button>
    </div>
  );

  // ============================================================================
  // SUBVIEW: DETALHES DO EXERCÍCIO (12._exerc_cios_detalhes_supino_reto)
  // ============================================================================
  const renderExerciseDetailsView = () => {
    if (!selectedExercise) {
      return (
        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-6 text-center space-y-3">
          <p className="text-sm text-[#9CA3AF]">Exercício não encontrado no catálogo.</p>
          <button
            type="button"
            onClick={() => setSubView('library')}
            className="px-4 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold"
          >
            Voltar para Exercícios
          </button>
        </div>
      );
    }

    const hist = selectedExerciseHistory;
    const hasRealHistory = !!hist?.hasHistory;

    return (
      <div className="max-w-lg mx-auto space-y-5 pb-20">
        {/* Barra superior de retorno */}
        <div className="flex items-center justify-between pt-1">
          <button
            type="button"
            onClick={() => setSubView('library')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-[#D4AF37]" />
            <span>Exercícios</span>
          </button>

          <div className="flex items-center gap-2">
            {selectedExercise.isCustom && (
              <span className="px-2.5 py-1 rounded-full bg-[#D4AF37]/15 text-[#D4AF37] text-[11px] font-bold uppercase tracking-wider">
                Personalizado
              </span>
            )}
            <button
              type="button"
              onClick={() => setSubView('routine')}
              className="px-3 py-1.5 rounded-xl bg-[#1A1D24] hover:bg-[#232730] text-xs font-semibold text-[#F4F5F7] transition-colors cursor-pointer"
            >
              Minha rotina
            </button>
          </div>
        </div>

        {/* Cabeçalho do Exercício */}
        <section className="space-y-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-[#1A1D24] text-[#D4AF37] text-[11px] font-bold uppercase tracking-wider">
              {selectedExercise.biomechanicalSubtitle}
            </span>
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#9CA3AF]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
              Nível {selectedExercise.difficultyLabel}
            </span>
          </div>

          <h1 className="text-2xl sm:text-[26px] font-extrabold tracking-tight text-[#F4F5F7] leading-tight">
            {selectedExercise.name}
          </h1>

          {/* Chips de Equipamento, Músculo Principal e Auxiliares */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            <span className="px-2.5 py-1 rounded-lg bg-[#1A1D24] text-[#F4F5F7] text-xs font-semibold inline-flex items-center gap-1.5">
              <Dumbbell className="w-3.5 h-3.5 text-[#D4AF37]" />
              {selectedExercise.equipmentLabel}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#1A1D24] text-[#F4F5F7] text-xs font-semibold inline-flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-[#D4AF37]" />
              {selectedExercise.primaryMuscleLabel}
            </span>
            {selectedExercise.auxiliaryMuscles.length > 0 && (
              <span className="px-2.5 py-1 rounded-lg bg-[#13151A] border border-white/[0.06] text-[#9CA3AF] text-xs font-medium">
                {selectedExercise.auxiliaryMuscles.join(' · ')}
              </span>
            )}
          </div>
        </section>

        {/* Cartão de Demonstração Biomecânica (Estática e Confiável) */}
        <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] overflow-hidden shadow-xl">
          <div className="relative w-full min-h-[220px] bg-[#0B0D12] flex flex-col justify-between overflow-hidden p-3.5 gap-3">
            {/* Grade Técnica SVG */}
            <svg
              className="absolute inset-0 w-full h-full opacity-10 pointer-events-none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern
                  id="aurus-tech-grid"
                  width="24"
                  height="24"
                  patternUnits="userSpaceOnUse"
                >
                  <path
                    d="M 24 0 L 0 0 0 24"
                    fill="none"
                    stroke="#F4F5F7"
                    strokeWidth="0.5"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#aurus-tech-grid)" />
            </svg>

            {/* Topo: Badges Técnicos Superiores */}
            <div className="relative z-10 flex flex-wrap items-center gap-1.5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#08090C]/90 border border-white/[0.07] backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                <span className="font-mono text-[11px] font-medium text-[#F4F5F7]">
                  {selectedExercise.angleCue}
                </span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#08090C]/90 border border-white/[0.07] backdrop-blur-md">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
                <span className="font-mono text-[11px] font-medium text-[#9CA3AF]">
                  {selectedExercise.postureCue}
                </span>
              </div>
            </div>

            {/* Centro: Diagrama Vetorial Biomecânico */}
            <div className="relative z-10 flex flex-col items-center justify-center py-1">
              <div className="w-20 h-20 rounded-2xl bg-[#1A1D24]/90 border border-[#D4AF37]/30 flex items-center justify-center shadow-[0_0_40px_rgba(212,175,55,0.12)]">
                <BiomechanicalVectorGraphic muscleFilter={selectedExercise.muscleFilter} />
              </div>
            </div>

            {/* Base: Cadência + Atalho para o Scanner 3D Corporal existente */}
            <div className="relative z-10 flex items-center justify-between gap-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#D4AF37]">
                Cadência: {selectedExercise.defaultCadence} · {selectedExercise.defaultRestSec}s
              </span>
              <button
                type="button"
                onClick={() => onOpenScanner3D(selectedExercise.targetGroup)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1A1D24]/95 hover:bg-[#242832] border border-white/[0.08] text-xs font-semibold text-[#F4F5F7] shadow-lg transition-colors cursor-pointer shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Scanner 3D Corporal</span>
              </button>
            </div>
          </div>

          {/* Rodapé da Demonstração */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-[#161920] border-t border-white/[0.05]">
            <div className="flex items-center gap-4 text-xs text-[#9CA3AF]">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#D4AF37]" />
                Motor Primário
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#343844]" />
                Sinergistas
              </span>
            </div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37]">
              {selectedExercise.kinematicChainLabel}
            </span>
          </div>
        </section>

        {/* Cartão de Histórico Pessoal / Recorde Real */}
        <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-4 space-y-3.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#1A1D24] flex items-center justify-center text-[#D4AF37] shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Histórico Pessoal
                </span>
                <span className="block text-xs text-[#F4F5F7] font-semibold truncate">
                  {hasRealHistory ? 'Sua melhor marca registrada' : 'Status de registros'}
                </span>
              </div>
            </div>

            {hasRealHistory && hist?.resolvedHistoryExerciseId && (
              <button
                type="button"
                onClick={() => onOpenExerciseEvolution(hist.resolvedHistoryExerciseId!)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#D4AF37] text-xs font-bold transition-colors cursor-pointer shrink-0 whitespace-nowrap"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Ver evolução</span>
              </button>
            )}
          </div>

          {hasRealHistory && hist ? (
            <>
              <div className="flex items-baseline justify-between pt-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono text-3xl font-bold text-[#D4AF37] tracking-tight">
                    {hist.bestWeightKg}
                  </span>
                  <span className="text-base font-bold text-[#9CA3AF]">kg</span>
                  {hist.bestReps !== null && (
                    <span className="text-xs text-[#9CA3AF] ml-1">
                      para {hist.bestReps} reps
                    </span>
                  )}
                </div>

                <div className="text-right">
                  {hist.progressionDeltaKg !== null && hist.progressionDeltaKg !== 0 ? (
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-mono font-semibold ${
                        hist.progressionDeltaKg > 0 ? 'text-[#10B981]' : 'text-[#9CA3AF]'
                      }`}
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      {hist.progressionDeltaKg > 0
                        ? `+${hist.progressionDeltaKg} kg`
                        : `${hist.progressionDeltaKg} kg`}
                    </span>
                  ) : (
                    <span className="text-xs font-mono text-[#9CA3AF]">
                      {hist.sessionsCount}{' '}
                      {hist.sessionsCount === 1 ? 'sessão' : 'sessões'}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#1A1D24] text-xs">
                <div className="flex items-center gap-2 text-[#9CA3AF]">
                  <Clock className="w-4 h-4 text-[#D4AF37]" />
                  <span>
                    Último registro:{' '}
                    <strong className="text-[#F4F5F7]">
                      {hist.lastDateLabel || 'Carga salva'}
                    </strong>
                  </span>
                </div>
                <span className="font-mono font-semibold text-[#F4F5F7]">
                  {hist.lastWeightKg} kg
                  {hist.lastReps !== null ? ` × ${hist.lastReps} reps` : ''}
                </span>
              </div>
            </>
          ) : (
            <div className="p-3.5 rounded-xl bg-[#1A1D24]/70 border border-white/[0.04] flex items-center justify-between gap-3">
              <div className="space-y-0.5">
                <p className="text-sm font-semibold text-[#F4F5F7]">
                  Você ainda não registrou este exercício.
                </p>
                <p className="text-xs text-[#9CA3AF]">
                  Adicione-o a uma rotina e conclua séries na Arena para acompanhar sua evolução.
                </p>
              </div>
            </div>
          )}
        </section>

        {/* Descrição do Movimento */}
        <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-4 space-y-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="text-base font-bold text-[#F4F5F7]">
              Descrição do movimento
            </h2>
          </div>
          <p className="text-sm text-[#9CA3AF] leading-relaxed">
            {selectedExercise.shortDescription}
          </p>
        </section>

        {/* Orientações de Execução */}
        <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ListChecks className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="text-base font-bold text-[#F4F5F7]">
                Orientações de execução
              </h2>
            </div>
            <span className="text-xs font-semibold text-[#9CA3AF]">
              {selectedExercise.executionSteps.length} passos chave
            </span>
          </div>

          <div className="space-y-2.5">
            {selectedExercise.executionSteps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3.5 rounded-xl bg-[#1A1D24]/80 border border-white/[0.04]"
              >
                <div className="w-7 h-7 rounded-lg bg-[#13151A] border border-[#D4AF37]/30 flex items-center justify-center shrink-0 font-mono text-xs font-bold text-[#D4AF37]">
                  {idx + 1}
                </div>
                <div className="space-y-0.5">
                  <h3 className="text-sm font-bold text-[#F4F5F7]">{step.title}</h3>
                  <p className="text-xs text-[#9CA3AF] leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Cuidados Importantes */}
        <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-4 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37]">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#F4F5F7]">
                Cuidados importantes
              </h2>
              <span className="text-xs text-[#9CA3AF]">
                Preservação articular e segurança biomecânica
              </span>
            </div>
          </div>

          <div className="space-y-2 p-3.5 rounded-xl bg-[#1A1D24]/70">
            {selectedExercise.safetyNotes.map((note, idx) => (
              <div key={idx} className="flex items-start gap-2.5 text-xs text-[#9CA3AF]">
                <AlertTriangle className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span className="leading-relaxed">{note}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Barra de Ação Inferior */}
        <div className="sticky bottom-20 z-30 bg-[#08090C]/90 backdrop-blur-xl p-3 rounded-2xl border border-white/[0.08] shadow-2xl flex items-center gap-2.5">
          {hasRealHistory && hist?.resolvedHistoryExerciseId && (
            <button
              type="button"
              onClick={() => onOpenExerciseEvolution(hist.resolvedHistoryExerciseId!)}
              className="h-12 px-4 rounded-xl bg-[#1A1D24] hover:bg-[#252934] text-[#F4F5F7] text-xs font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0"
            >
              <BarChart3 className="w-4 h-4 text-[#D4AF37]" />
              <span>Ver evolução</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleOpenAddSheet(selectedExercise)}
            className="flex-1 h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
            <span>Adicionar ao treino</span>
          </button>
        </div>
      </div>
    );
  };

  const handleMoveExerciseOrder = (
    dayId: string,
    index: number,
    direction: 'up' | 'down'
  ) => {
    const sourceList = (
      customAiWorkouts && customAiWorkouts.length > 0
        ? customAiWorkouts
        : baseTemplateWorkouts
    ).map((day) => ({
      ...day,
      exercises: [...(day.exercises || [])]
    }));

    const targetDay = sourceList.find((d) => d.id === dayId);
    if (!targetDay) return;

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= targetDay.exercises.length) return;

    const swapped = [...targetDay.exercises];
    const [moved] = swapped.splice(index, 1);
    swapped.splice(targetIndex, 0, moved);
    targetDay.exercises = swapped;

    onUpdateWorkoutsAndSessionSets(
      sourceList,
      sessionSets,
      `Ordem de "${cleanDisplayText(moved.name)}" atualizada na rotina.`,
      'emerald'
    );
  };

  const handleSaveDayHeaderEdit = (dayId: string) => {
    const trimmedTitle = editingDayTitle.trim();
    if (!trimmedTitle) return;

    const sourceList = (
      customAiWorkouts && customAiWorkouts.length > 0
        ? customAiWorkouts
        : baseTemplateWorkouts
    ).map((day) =>
      day.id === dayId
        ? {
            ...day,
            title: trimmedTitle,
            subtitle: editingDaySubtitle.trim() || day.subtitle
          }
        : { ...day, exercises: [...(day.exercises || [])] }
    );

    onUpdateWorkoutsAndSessionSets(
      sourceList,
      sessionSets,
      'Título e foco da rotina atualizados!',
      'emerald'
    );
    setIsEditingRoutine(false);
  };

  // ============================================================================
  // SUBVIEW: MINHA ROTINA & EDITAR ROTINA (Grupo 2)
  // ============================================================================
  const renderMyRoutineView = () => {
    const activeDay =
      dynamicWorkouts.find((d) => d.id === selectedDayId) || dynamicWorkouts[0];

    const startEditingCurrentDay = () => {
      if (!activeDay) return;
      setEditingDayTitle(cleanDisplayText(activeDay.title));
      setEditingDaySubtitle(cleanDisplayText(activeDay.subtitle));
      setIsEditingRoutine(true);
    };

    return (
      <div className="max-w-lg mx-auto space-y-5 pb-20">
        {renderTopSubNav()}

        <div className="flex items-center justify-between pt-1 gap-2">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
              PROGRAMAÇÃO SEMANAL
            </span>
            <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
              {isEditingRoutine ? 'Editar rotina' : 'Minha rotina'}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (isEditingRoutine) {
                  setIsEditingRoutine(false);
                } else {
                  startEditingCurrentDay();
                }
              }}
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
                isEditingRoutine
                  ? 'bg-[#D4AF37] text-[#08090C] border-[#D4AF37]'
                  : 'bg-[#1A1D24] hover:bg-[#232732] border-white/[0.08] text-[#F4F5F7]'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditingRoutine ? 'Concluir' : 'Editar rotina'}</span>
            </button>

            <button
              type="button"
              onClick={() => setSubView('ai')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-[#D4AF37]/30 text-xs font-bold text-[#D4AF37] transition-colors cursor-pointer"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>Ajustar IA</span>
            </button>
          </div>
        </div>

        {/* Seletor Horizontal de Dias da Rotina */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
          {dynamicWorkouts.map((day) => {
            const isSelected = day.id === activeDay?.id;
            const isRunningDay = isSessionActive && activeSessionDayId === day.id;
            return (
              <button
                key={day.id}
                type="button"
                onClick={() => {
                  onSelectDayId(day.id);
                  if (isEditingRoutine) {
                    setEditingDayTitle(cleanDisplayText(day.title));
                    setEditingDaySubtitle(cleanDisplayText(day.subtitle));
                  }
                }}
                className={`shrink-0 px-3.5 py-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#D4AF37] text-[#08090C] border-[#D4AF37] font-bold shadow-sm'
                    : 'bg-[#13151A] border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-extrabold uppercase">{day.shortDay}</span>
                  {isRunningDay && (
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isSelected ? 'bg-[#08090C]' : 'bg-[#10B981]'
                      }`}
                    />
                  )}
                </div>
                <div
                  className={`text-[11px] mt-0.5 ${
                    isSelected ? 'text-[#08090C]/80 font-semibold' : 'text-[#9CA3AF]'
                  }`}
                >
                  {day.exercises.length} exerc.
                </div>
              </button>
            );
          })}
        </div>

        {/* Detalhes da Rotina Selecionada */}
        {activeDay && (
          <section className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-4 space-y-4">
            {isEditingRoutine ? (
              <div className="p-3.5 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37]">
                    Editar Identificação • {activeDay.dayName}
                  </span>
                </div>
                <div className="space-y-2">
                  <input
                    type="text"
                    value={editingDayTitle}
                    onChange={(e) => setEditingDayTitle(e.target.value)}
                    placeholder="Nome da divisão (ex.: Treino A • Peito e Tríceps)"
                    className="w-full h-10 rounded-xl bg-[#13151A] border border-white/[0.08] px-3 text-xs font-bold text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                  />
                  <input
                    type="text"
                    value={editingDaySubtitle}
                    onChange={(e) => setEditingDaySubtitle(e.target.value)}
                    placeholder="Foco biomecânico da sessão"
                    className="w-full h-10 rounded-xl bg-[#13151A] border border-white/[0.08] px-3 text-xs text-[#9CA3AF] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => handleSaveDayHeaderEdit(activeDay.id)}
                    className="px-3.5 py-1.5 rounded-lg bg-[#D4AF37] text-[#08090C] text-xs font-bold cursor-pointer"
                  >
                    Salvar título
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between gap-3 border-b border-white/[0.06] pb-3.5">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#D4AF37]">
                      {activeDay.dayName}
                    </span>
                    {isSessionActive && activeSessionDayId === activeDay.id && (
                      <span className="px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] text-[10px] font-bold uppercase">
                        Sessão Ativa
                      </span>
                    )}
                  </div>
                  <h2 className="text-lg font-extrabold text-[#F4F5F7] leading-snug">
                    {cleanDisplayText(activeDay.title)}
                  </h2>
                  <p className="text-xs text-[#9CA3AF]">
                    {cleanDisplayText(activeDay.subtitle)}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onNavigateToArena(activeDay.id)}
                  className="px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] font-bold text-xs shrink-0 hover:bg-[#e2be46] transition-colors cursor-pointer"
                >
                  Ir para Arena
                </button>
              </div>
            )}

            <div className="space-y-2.5">
              {activeDay.exercises.map((ex, idx) => {
                const catalogMatch = fullCatalog.find((c) => c.id === ex.id);
                return (
                  <div
                    key={ex.id}
                    className="p-3.5 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-center justify-between gap-2.5"
                  >
                    <div
                      onClick={() => {
                        if (catalogMatch) handleOpenExerciseDetails(catalogMatch);
                      }}
                      className="min-w-0 flex-1 cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#D4AF37]">
                          #{idx + 1}
                        </span>
                        <h3 className="text-sm font-bold text-[#F4F5F7] truncate">
                          {cleanDisplayText(ex.name)}
                        </h3>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-[#9CA3AF]">
                        <span className="font-mono text-[#F4F5F7] font-semibold">
                          {ex.totalSets || ex.baseSets} séries × {ex.reps}
                        </span>
                        <span>·</span>
                        <span>Descanso: {ex.rest}s</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {/* Botões de Reordenação (Subir / Descer) */}
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMoveExerciseOrder(activeDay.id, idx, 'up')}
                        aria-label={`Mover ${cleanDisplayText(ex.name)} para cima`}
                        title="Subir posição"
                        className="p-1.5 rounded-lg bg-[#13151A] hover:bg-[#252934] disabled:opacity-30 text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors cursor-pointer"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === activeDay.exercises.length - 1}
                        onClick={() =>
                          handleMoveExerciseOrder(activeDay.id, idx, 'down')
                        }
                        aria-label={`Mover ${cleanDisplayText(ex.name)} para baixo`}
                        title="Descer posição"
                        className="p-1.5 rounded-lg bg-[#13151A] hover:bg-[#252934] disabled:opacity-30 text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors cursor-pointer"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      {catalogMatch && (
                        <button
                          type="button"
                          onClick={() => handleOpenAddSheet(catalogMatch, activeDay.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#13151A] hover:bg-[#252934] text-[11px] font-semibold text-[#D4AF37] transition-colors cursor-pointer"
                        >
                          Editar
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleRemoveExerciseFromRoutine(activeDay.id, ex)}
                        aria-label={`Remover ${cleanDisplayText(ex.name)}`}
                        className="p-1.5 rounded-lg bg-[#13151A] hover:bg-rose-950/60 text-[#9CA3AF] hover:text-rose-300 transition-colors cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setSubView('library')}
              className="w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-[#D4AF37]/30 text-xs font-bold text-[#D4AF37] inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar exercício do catálogo</span>
            </button>
          </section>
        )}
      </div>
    );
  };

  // ============================================================================
  // SUBVIEW: AJUSTAR COM IA (Preservação integral do Coach IA e Reformulação)
  // ============================================================================
  const renderAiCoachView = () => (
    <div className="space-y-5">
      <div className="max-w-lg mx-auto">{renderTopSubNav()}</div>
      <AiArchitectureView
        profile={profile}
        goldenAnalysis={goldenAnalysis}
        dynamicWorkouts={dynamicWorkouts}
        selectedDayId={selectedDayId}
        onSelectDayId={onSelectDayId}
        currentDayWorkout={currentDayWorkout}
        activeSelectedDays={activeSelectedDays}
        onToggleTrainingDay={onToggleTrainingDay}
        onReformulate={onReformulate}
        isGeneratingAi={isGeneratingAi}
        customAiWorkouts={customAiWorkouts}
        onResetToDefault={onResetToDefault}
        onNavigateToArena={() => onNavigateToArena(selectedDayId)}
        aiCoachMessages={aiCoachMessages}
        onAskCoach={onAskCoach}
        isAskingCoach={isAskingCoach}
        workoutHistory={workoutHistory}
        onApplyPreviewWorkouts={onApplyPreviewWorkouts}
      />
    </div>
  );

  // ============================================================================
  // SUBVIEW PRINCIPAL: BIBLIOTECA DE EXERCÍCIOS (11._exerc_cios_biblioteca)
  // ============================================================================
  const renderLibraryView = () => (
    <div className="max-w-lg mx-auto space-y-5">
      {renderTopSubNav()}

      {/* Cabeçalho Principal */}
      <section className="pt-1 space-y-1">
        <div className="flex items-center justify-between gap-2">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
              CATÁLOGO ATIVO
            </span>
            <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
              Exercícios
            </h1>
          </div>

          <div className="inline-flex items-center gap-1.5 bg-[#1A1D24] border border-white/[0.06] px-3 py-1.5 rounded-full">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            <span className="font-mono text-xs font-bold text-[#F4F5F7]">
              {fullCatalog.length} exercícios
            </span>
          </div>
        </div>

        <p className="text-xs sm:text-[13px] text-[#9CA3AF]">
          Explore variações biomecânicas, consulte orientações e monte suas rotinas de força.
        </p>
      </section>

      {/* Campo de Pesquisa em Tempo Real */}
      <section className="relative">
        <Search className="w-5 h-5 text-[#9CA3AF] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar por nome, músculo ou equipamento..."
          aria-label="Buscar exercícios"
          className={`w-full h-12 bg-[#1A1D24] border border-white/[0.07] focus:border-[#D4AF37] rounded-xl pl-10 ${
            searchQuery.trim().length > 0 ? 'pr-11' : 'pr-3.5'
          } text-[13px] text-[#F4F5F7] placeholder:text-[#9CA3AF] focus:outline-none transition-colors`}
        />
        {searchQuery.trim().length > 0 && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            aria-label="Limpar busca"
            className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#13151A] text-[#9CA3AF] hover:text-[#F4F5F7] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </section>

      {/* Filtros Horizontais: Grupo Muscular */}
      <section className="space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
            Músculo Alvo
          </span>
          <span className="text-[11px] font-semibold text-[#D4AF37]">
            Deslize para ver todos
          </span>
        </div>

        <div
          role="group"
          aria-label="Filtrar por grupo muscular"
          className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5"
        >
          {MUSCLE_FILTER_OPTIONS.map((item) => {
            const isSelected = muscleFilter === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={isSelected}
                onClick={() => setMuscleFilter(item.id)}
                className={`shrink-0 px-4 h-9 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                    : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Filtros Horizontais: Equipamento */}
      <section className="space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
            Aparelho & Carga
          </span>
          <span className="font-mono text-xs font-semibold text-[#9CA3AF]">
            {filteredCatalog.length}{' '}
            {filteredCatalog.length === 1 ? 'listado' : 'listados'}
          </span>
        </div>

        <div
          role="group"
          aria-label="Filtrar por equipamento"
          className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5"
        >
          {EQUIPMENT_FILTER_OPTIONS.map((item) => {
            const isSelected = equipmentFilter === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={isSelected}
                onClick={() => setEquipmentFilter(item.id)}
                className={`shrink-0 px-3.5 h-8 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                    : 'bg-[#1A1D24] border border-transparent text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Cartão de Destaque Biomecânico e Atalhos de Rotina */}
      <section className="bg-[#1A1D24] border border-white/[0.06] rounded-2xl p-4 shadow-md flex items-center justify-between gap-3">
        <div className="space-y-1 min-w-0">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider">
              Rotina Atual: {currentDayWorkout?.shortDay || 'SEG'}
            </span>
          </div>
          <h2 className="text-base font-bold text-[#F4F5F7] truncate pt-0.5">
            {cleanDisplayText(currentDayWorkout?.title || 'Treino Principal')}
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            {currentDayWorkout?.exercises.length || 0} exercícios planejados para este dia.
          </p>
        </div>

        <div className="flex flex-col gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setSubView('routine')}
            className="px-3 py-1.5 rounded-xl bg-[#13151A] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#F4F5F7] transition-colors cursor-pointer"
          >
            Ver rotina
          </button>
          <button
            type="button"
            onClick={() => setSubView('ai')}
            className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-xs font-bold text-[#D4AF37] transition-colors cursor-pointer"
          >
            Coach IA
          </button>
        </div>
      </section>

      {/* Lista de Cartões de Exercícios ou Estado Vazio */}
      {fullCatalog.length === 0 ? (
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-8 text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-[#1A1D24] mx-auto flex items-center justify-center text-[#D4AF37]">
            <Dumbbell className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h2 className="text-base font-bold text-[#F4F5F7]">
              Não existem exercícios cadastrados
            </h2>
            <p className="text-xs text-[#9CA3AF] max-w-xs mx-auto">
              Cadastre um exercício personalizado abaixo para iniciar seu catálogo.
            </p>
          </div>
        </section>
      ) : filteredCatalog.length === 0 ? (
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-8 text-center space-y-3.5">
          <div className="w-16 h-16 rounded-full bg-[#1A1D24] mx-auto flex items-center justify-center text-[#D4AF37]">
            <Search className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h2 className="text-base font-bold text-[#F4F5F7]">
              Nenhum exercício encontrado
            </h2>
            <p className="text-xs sm:text-sm text-[#9CA3AF] max-w-xs mx-auto">
              Tente outro nome ou ajuste os filtros.
            </p>
          </div>
          <button
            type="button"
            onClick={handleResetAllFilters}
            className="h-10 px-5 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold shadow-sm hover:bg-[#e2be46] transition-colors cursor-pointer"
          >
            Limpar filtros
          </button>
        </section>
      ) : (
        <section aria-label="Lista de exercícios" className="space-y-3">
          {filteredCatalog.map((exercise) => {
            const hist = historyByExerciseId.get(exercise.id);
            const hasPR = hist?.hasHistory && hist.bestWeightKg !== null;

            return (
              <article
                key={exercise.id}
                onClick={() => handleOpenExerciseDetails(exercise)}
                className="bg-[#13151A] hover:bg-[#171A21] border border-white/[0.06] rounded-2xl p-3.5 shadow-sm transition-all active:scale-[0.99] cursor-pointer flex items-center justify-between gap-2.5 group"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-12 h-12 rounded-xl bg-[#1A1D24] border border-white/[0.05] shrink-0 flex items-center justify-center text-[#D4AF37]">
                    <BiomechanicalVectorGraphic
                      muscleFilter={exercise.muscleFilter}
                      compact
                    />
                  </div>

                  <div className="flex flex-col min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#D4AF37]/12 text-[#D4AF37]">
                        {exercise.categoryLabel}
                      </span>
                      {exercise.isCustom && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#1A1D24] text-[#9CA3AF]">
                          Personalizado
                        </span>
                      )}
                      {hasPR && (
                        <span className="font-mono text-[11px] font-semibold text-[#10B981]">
                          PR: {hist!.bestWeightKg} kg
                        </span>
                      )}
                    </div>

                    <h3 className="text-[15px] font-bold text-[#F4F5F7] leading-snug line-clamp-2 mt-1">
                      {exercise.name}
                    </h3>

                    <p className="text-xs text-[#9CA3AF] truncate mt-0.5">
                      {exercise.primaryMuscleLabel} · {exercise.equipmentLabel}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenAddSheet(exercise);
                    }}
                    aria-label={`Adicionar ${exercise.name} ao treino`}
                    className="w-8 h-8 rounded-full bg-[#1A1D24] hover:bg-[#D4AF37] text-[#D4AF37] hover:text-[#08090C] flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                  </button>
                  <div className="w-8 h-8 rounded-full bg-[#1A1D24] flex items-center justify-center text-[#9CA3AF] group-hover:text-[#D4AF37] transition-colors">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </article>
            );
          })}
        </section>
      )}

      {/* Barra Flutuante para Criar Exercício Personalizado */}
      <div className="pt-2">
        <div className="bg-[#1A1D24]/95 border border-white/[0.08] rounded-2xl p-3.5 shadow-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Plus className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="block text-xs font-bold text-[#F4F5F7]">
                Personalizar Catálogo
              </span>
              <span className="block text-xs text-[#9CA3AF] truncate">
                Cadastre um exercício personalizado permanente
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setCustomError(null);
              setShowCreateCustomModal(true);
            }}
            className="h-10 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#e2be46] text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 shrink-0 transition-transform active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Novo</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="w-full">
      {subView === 'library' && renderLibraryView()}
      {subView === 'details' && renderExerciseDetailsView()}
      {subView === 'routine' && renderMyRoutineView()}
      {subView === 'ai' && renderAiCoachView()}

      {/* ==================================================================== */}
      {/* BOTTOM SHEET: ADICIONAR AO TREINO (13._exerc_cios_adicionar_rotina)  */}
      {/* ==================================================================== */}
      {addSheetExercise && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Adicionar ao treino"
          className="fixed inset-0 z-50 flex flex-col justify-end bg-black/70 backdrop-blur-sm"
        >
          <div
            onClick={() => setAddSheetExercise(null)}
            className="flex-1 w-full cursor-pointer"
          />

          <div className="w-full max-w-lg mx-auto bg-[#13151A] border-t border-white/[0.08] rounded-t-3xl shadow-2xl max-h-[86vh] overflow-y-auto pb-safe flex flex-col">
            {/* Drag Handle */}
            <div className="w-full pt-3 pb-1 flex items-center justify-center">
              <div className="w-10 h-1 rounded-full bg-white/20" />
            </div>

            {/* Header */}
            <div className="px-4 pt-2 pb-3 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <ListChecks className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                    ROTINAS & CICLOS
                  </span>
                </div>
                <h2 className="text-xl font-extrabold text-[#F4F5F7] tracking-tight">
                  Adicionar ao treino
                </h2>
                <p className="text-xs text-[#9CA3AF] mt-0.5 leading-snug">
                  <strong className="text-[#F4F5F7]">{addSheetExercise.name}</strong> ·
                  Selecione para qual rotina deseja enviar este exercício
                </p>
              </div>

              <button
                type="button"
                onClick={() => setAddSheetExercise(null)}
                aria-label="Fechar janela de rotina"
                className="w-9 h-9 rounded-full bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] flex items-center justify-center shrink-0 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Lista de Rotinas Disponíveis */}
            <div className="px-4 py-1.5 space-y-2 max-h-[34vh] overflow-y-auto">
              {dynamicWorkouts.map((day) => {
                const isSelected = day.id === targetRoutineDayId;
                const existingInRoutine = findExistingExerciseInRoutine(
                  day,
                  addSheetExercise
                );
                const isCurrentActiveSessionDay =
                  isSessionActive && activeSessionDayId === day.id;

                return (
                  <button
                    key={day.id}
                    type="button"
                    onClick={() => handleSelectTargetRoutineInSheet(day.id)}
                    className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-[#1A1D24] border-[#D4AF37] shadow-md'
                        : 'bg-[#1A1D24]/60 border-white/[0.05] hover:bg-[#1A1D24]'
                    }`}
                  >
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`text-sm font-bold ${
                            isSelected ? 'text-[#D4AF37]' : 'text-[#F4F5F7]'
                          }`}
                        >
                          {cleanDisplayText(day.title)}
                        </span>
                        {day.id === currentDayWorkout?.id && (
                          <span className="px-2 py-0.5 rounded-full bg-[#D4AF37]/15 text-[#D4AF37] text-[10px] font-bold uppercase">
                            Ativo
                          </span>
                        )}
                        {existingInRoutine && (
                          <span className="px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] text-[10px] font-bold uppercase">
                            Já na rotina
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-xs text-[#9CA3AF]">
                        <span className="inline-flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#9CA3AF]" />
                          {day.dayName}
                        </span>
                        <span>•</span>
                        <span>{day.exercises.length} exercícios atuais</span>
                      </div>

                      {isSelected && (
                        <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#08090C] text-[11px] font-medium text-[#9CA3AF]">
                          <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                          <span>
                            Previsão: {plannedSets} séries de trabalho ({plannedReps} reps)
                          </span>
                        </div>
                      )}

                      {isSelected && isCurrentActiveSessionDay && (
                        <div className="mt-1.5 text-[11px] text-[#10B981] flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>
                            Sessão em andamento protegida: suas séries já concluídas serão preservadas.
                          </span>
                        </div>
                      )}
                    </div>

                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-1 border ${
                        isSelected
                          ? 'bg-[#D4AF37] border-[#D4AF37] text-[#08090C]'
                          : 'bg-[#13151A] border-white/15'
                      }`}
                    >
                      {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-[#08090C]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Configuração Inicial de Séries, Repetições e Posição */}
            <div className="px-4 pt-2 space-y-2.5">
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] space-y-1.5">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Séries Planejadas
                  </span>
                  <div className="flex items-center gap-1">
                    {SETS_PRESETS.map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setPlannedSets(num)}
                        className={`flex-1 h-8 rounded-lg font-mono text-xs font-bold transition-colors cursor-pointer ${
                          plannedSets === num
                            ? 'bg-[#D4AF37] text-[#08090C]'
                            : 'bg-[#13151A] text-[#9CA3AF] hover:text-[#F4F5F7]'
                        }`}
                      >
                        {num}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] space-y-1.5">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Faixa de Reps
                  </span>
                  <div className="grid grid-cols-2 gap-1">
                    {REPS_PRESETS.map((rep) => (
                      <button
                        key={rep}
                        type="button"
                        onClick={() => setPlannedReps(rep)}
                        className={`h-8 rounded-lg font-mono text-[11px] font-bold transition-colors cursor-pointer ${
                          plannedReps === rep
                            ? 'bg-[#D4AF37] text-[#08090C]'
                            : 'bg-[#13151A] text-[#9CA3AF] hover:text-[#F4F5F7]'
                        }`}
                      >
                        {rep}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Posição na Rotina */}
              <div className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-center justify-between gap-2">
                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Ordem de Execução
                  </span>
                  <span className="text-xs font-semibold text-[#F4F5F7]">
                    Posição na rotina
                  </span>
                </div>

                <div className="flex items-center p-1 rounded-lg bg-[#08090C] gap-1">
                  <button
                    type="button"
                    onClick={() => setRoutinePosition('start')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                      routinePosition === 'start'
                        ? 'bg-[#1A1D24] text-[#D4AF37]'
                        : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    Início (1º)
                  </button>
                  <button
                    type="button"
                    onClick={() => setRoutinePosition('end')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                      routinePosition === 'end'
                        ? 'bg-[#1A1D24] text-[#D4AF37]'
                        : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    Final
                  </button>
                </div>
              </div>

              {/* Feedback de Status */}
              {sheetFeedback ? (
                <div
                  className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold ${
                    sheetFeedback.type === 'success'
                      ? 'bg-[#10B981]/15 text-[#10B981]'
                      : sheetFeedback.type === 'error'
                      ? 'bg-rose-500/15 text-rose-300'
                      : 'bg-[#D4AF37]/15 text-[#D4AF37]'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{sheetFeedback.text}</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] text-xs font-medium">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>
                    {findExistingExerciseInRoutine(
                      dynamicWorkouts.find((d) => d.id === targetRoutineDayId),
                      addSheetExercise
                    )
                      ? 'Este exercício já está na rotina selecionada. Confirmar atualizará suas séries e repetições.'
                      : 'Exercício configurado e pronto para a rotina selecionada.'}
                  </span>
                </div>
              )}
            </div>

            {/* Botões de Ação */}
            <div className="px-4 pt-3 pb-6 space-y-2">
              <button
                type="button"
                onClick={handleConfirmAddToRoutine}
                className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e2be46] text-[#08090C] font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>
                  {findExistingExerciseInRoutine(
                    dynamicWorkouts.find((d) => d.id === targetRoutineDayId),
                    addSheetExercise
                  )
                    ? 'Atualizar exercício na rotina'
                    : 'Salvar exercício na rotina'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAddSheetExercise(null);
                  setSubView('routine');
                }}
                className="w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] text-[#F4F5F7] text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <ListChecks className="w-4 h-4 text-[#D4AF37]" />
                <span>Gerenciar Minha Rotina</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: CADASTRAR EXERCÍCIO PERSONALIZADO NO CATÁLOGO                 */}
      {/* ==================================================================== */}
      {showCreateCustomModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Novo exercício personalizado"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
        >
          <form
            onSubmit={handleCreateCustomExerciseSubmit}
            className="w-full max-w-md bg-[#13151A] border border-white/[0.08] rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl pb-safe"
          >
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  CATÁLOGO PERMANENTE
                </span>
                <h2 className="text-lg font-extrabold text-[#F4F5F7]">
                  Novo Exercício Personalizado
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateCustomModal(false)}
                className="w-9 h-9 rounded-full bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#9CA3AF] mb-1">
                  Nome do exercício
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="Ex: Supino Articulado Declinado"
                  className="w-full h-11 rounded-xl bg-[#1A1D24] border border-white/[0.08] px-3.5 text-sm text-[#F4F5F7] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-[#9CA3AF] mb-1">
                    Grupo muscular
                  </label>
                  <select
                    value={customMuscle}
                    onChange={(e) =>
                      setCustomMuscle(
                        e.target.value as Exclude<ExerciseMuscleFilter, 'all'>
                      )
                    }
                    className="w-full h-11 rounded-xl bg-[#1A1D24] border border-white/[0.08] px-3 text-xs font-semibold text-[#F4F5F7] focus:outline-none focus:border-[#D4AF37]"
                  >
                    {MUSCLE_FILTER_OPTIONS.filter((m) => m.id !== 'all').map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#9CA3AF] mb-1">
                    Equipamento
                  </label>
                  <select
                    value={customEquipment}
                    onChange={(e) =>
                      setCustomEquipment(e.target.value as ExerciseEquipmentCategory)
                    }
                    className="w-full h-11 rounded-xl bg-[#1A1D24] border border-white/[0.08] px-3 text-xs font-semibold text-[#F4F5F7] focus:outline-none focus:border-[#D4AF37]"
                  >
                    {EQUIPMENT_FILTER_OPTIONS.filter((eq) => eq.id !== 'all').map(
                      (eq) => (
                        <option key={eq.id} value={eq.id}>
                          {eq.label}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#9CA3AF] mb-1">
                  Categoria biomecânica
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Composto', 'Isolamento'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCustomCategory(cat)}
                      className={`h-9 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                        customCategory === cat
                          ? 'bg-[#D4AF37] text-[#08090C]'
                          : 'bg-[#1A1D24] text-[#9CA3AF]'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#9CA3AF] mb-1">
                  Observação de execução (opcional)
                </label>
                <textarea
                  rows={2}
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  placeholder="Ex: Pegada neutra com pausa de 1s no pico da contração."
                  className="w-full rounded-xl bg-[#1A1D24] border border-white/[0.08] p-3 text-xs text-[#F4F5F7] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              {customError && (
                <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-200">
                  {customError}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowCreateCustomModal(false)}
                className="flex-1 h-11 rounded-xl bg-[#1A1D24] text-xs font-bold text-[#9CA3AF] hover:text-[#F4F5F7] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 h-11 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold hover:bg-[#e2be46] cursor-pointer"
              >
                Salvar no Catálogo
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

/**
 * Ilustração vetorial anatômica/biomecânica limpa, rápida e sem imagens externas quebradas.
 */
function BiomechanicalVectorGraphic({
  muscleFilter,
  compact = false
}: {
  muscleFilter: Exclude<ExerciseMuscleFilter, 'all'>;
  compact?: boolean;
}) {
  const sizeClass = compact ? 'w-7 h-7' : 'w-12 h-12';

  switch (muscleFilter) {
    case 'peito':
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M6 24H42" />
          <path d="M11 17V31" />
          <path d="M37 17V31" />
          <path d="M16 20C19 16 29 16 32 20" strokeOpacity="0.65" />
          <circle cx="24" cy="24" r="3" fill="currentColor" />
        </svg>
      );
    case 'costas':
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M10 12H38" />
          <path d="M24 12V36" />
          <path d="M14 18L24 28L34 18" />
          <path d="M18 36H30" strokeOpacity="0.65" />
        </svg>
      );
    case 'pernas':
    case 'panturrilha':
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="24" cy="10" r="3.5" />
          <path d="M14 16H34" />
          <path d="M20 16L16 28L18 40" />
          <path d="M28 16L32 28L30 40" />
        </svg>
      );
    case 'ombros':
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="24" cy="12" r="3.5" />
          <path d="M10 26L18 18H30L38 26" />
          <path d="M24 18V36" />
        </svg>
      );
    case 'bracos':
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M14 30C14 22 20 18 26 22L32 14" />
          <path d="M14 30H28C32 30 34 27 34 24" />
          <circle cx="33" cy="13" r="3" fill="currentColor" />
        </svg>
      );
    case 'abdomen':
    case 'pescoco':
    default:
      return (
        <svg
          className={`${sizeClass} text-[#D4AF37]`}
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="15" y="10" width="18" height="28" rx="5" />
          <path d="M24 12V36" />
          <path d="M17 19H31" />
          <path d="M17 27H31" />
        </svg>
      );
  }
}
