import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Bot,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Dumbbell,
  Eye,
  Layers,
  MessageSquare,
  Play,
  RefreshCw,
  RotateCcw,
  Send,
  Sparkles,
  Wand2,
  X
} from 'lucide-react';
import {
  CompletedWorkout,
  ExerciseItem,
  GoldenAnalysis,
  UserProfile,
  WorkoutDay
} from '../types';
import { cleanDisplayText } from '../utils/dashboardLogic';

interface AiMessage {
  role: 'user' | 'assistant';
  text: string;
}

interface AiArchitectureViewProps {
  profile: UserProfile;
  goldenAnalysis: GoldenAnalysis;
  dynamicWorkouts: WorkoutDay[];
  selectedDayId: string;
  onSelectDayId: (id: string) => void;
  currentDayWorkout: WorkoutDay;
  activeSelectedDays: string[];
  onToggleTrainingDay: (dayId: string) => void;
  onReformulate: (options: { scope: 'week' | 'day'; customPrompt?: string }) => void;
  isGeneratingAi: boolean;
  customAiWorkouts: WorkoutDay[] | null;
  onResetToDefault: () => void;
  onNavigateToArena: () => void;
  aiCoachMessages: AiMessage[];
  onAskCoach: (question: string) => void;
  isAskingCoach: boolean;
  workoutHistory?: CompletedWorkout[];
  onApplyPreviewWorkouts?: (proposedWorkouts: WorkoutDay[], scope: 'week' | 'day') => void;
}

const ALL_WEEK_DAYS = [
  { id: 'seg', short: 'SEG', label: 'Segunda' },
  { id: 'ter', short: 'TER', label: 'Terça' },
  { id: 'qua', short: 'QUA', label: 'Quarta' },
  { id: 'qui', short: 'QUI', label: 'Quinta' },
  { id: 'sex', short: 'SEX', label: 'Sexta' },
  { id: 'sab', short: 'SAB', label: 'Sábado' },
  { id: 'dom', short: 'DOM', label: 'Domingo' }
];

const QUICK_COACH_QUESTIONS = [
  'Como progredir carga nos exercícios compostos com segurança?',
  'Quais ajustes priorizar para melhorar minha simetria de ombros e peitoral?',
  'Como distribuir o descanso entre treinos intensos de pernas e esportes?',
  'Qual a faixa ideal de séries semanais para meu nível atual?'
];

const QUICK_ADJUST_PRESETS = [
  {
    id: 'focus_vtaper',
    label: 'Ênfase em Ombros & Peito Superior',
    prompt:
      'Priorizar deltoide lateral, peitoral clavicular e largura dorsal com controle articular.'
  },
  {
    id: 'time_45',
    label: 'Treino Compacto (~45 min)',
    prompt:
      'Otimizar volume para sessões densas de 45 minutos focadas em multiarticulares.'
  },
  {
    id: 'joint_care',
    label: 'Preservação Articular (Halteres/Cabos)',
    prompt:
      'Substituir barras retas por halteres, cabos e máquinas convergentes para conforto articular.'
  },
  {
    id: 'strength_focus',
    label: 'Progressão de Força (6-8 reps)',
    prompt:
      'Ajustar exercícios principais para faixas de força de 6-8 repetições com descanso de 120s.'
  }
];

export function AiArchitectureView({
  profile,
  goldenAnalysis,
  dynamicWorkouts,
  selectedDayId,
  onSelectDayId,
  currentDayWorkout,
  activeSelectedDays,
  onToggleTrainingDay,
  onReformulate,
  isGeneratingAi,
  customAiWorkouts,
  onResetToDefault,
  onNavigateToArena,
  aiCoachMessages,
  onAskCoach,
  isAskingCoach,
  workoutHistory = [],
  onApplyPreviewWorkouts
}: AiArchitectureViewProps) {
  const [aiMode, setAiMode] = useState<'coach' | 'adjust'>('coach');
  const [chatInput, setChatInput] = useState('');
  const [adjustScope, setAdjustScope] = useState<'day' | 'week'>('day');
  const [customPrompt, setCustomPrompt] = useState('');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('focus_vtaper');

  // Estado da Prévia de Ajuste antes de aplicar na rotina
  const [previewProposal, setPreviewProposal] = useState<{
    scope: 'day' | 'week';
    summaryLabel: string;
    proposedWorkouts: WorkoutDay[];
  } | null>(null);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isAskingCoach) return;
    onAskCoach(chatInput.trim());
    setChatInput('');
  };

  const priorityPartsLabel = useMemo(() => {
    if (goldenAnalysis.redZones.length === 0) return 'Equilíbrio Global';
    return goldenAnalysis.redZones
      .slice(0, 3)
      .map((p) => p.shortLabel)
      .join(', ');
  }, [goldenAnalysis.redZones]);

  const handleBuildPreviewProposal = () => {
    const activePreset = QUICK_ADJUST_PRESETS.find((p) => p.id === selectedPresetId);
    const instruction = customPrompt.trim() || activePreset?.prompt || 'Otimização biomecânica';

    const proposed = dynamicWorkouts.map((day) => {
      if (adjustScope === 'day' && day.id !== currentDayWorkout.id) {
        return day;
      }

      const adjustedExercises: ExerciseItem[] = day.exercises.map((ex, idx) => {
        if (selectedPresetId === 'strength_focus' && idx < 2) {
          return {
            ...ex,
            baseSets: 4,
            totalSets: 4,
            reps: '6-8',
            rest: 120,
            tip: `${cleanDisplayText(ex.tip)} · Foco em progressão de carga.`
          };
        }
        if (selectedPresetId === 'time_45') {
          return {
            ...ex,
            baseSets: 3,
            totalSets: 3,
            reps: '8-10',
            rest: 60
          };
        }
        if (selectedPresetId === 'joint_care') {
          return {
            ...ex,
            reps: '10-12',
            rest: 75,
            cadence: '3-1-2-1'
          };
        }
        // Default: focus_vtaper
        const isPriorityGroup =
          ex.targetGroup === 'ombros' || ex.targetGroup === 'peito';
        return {
          ...ex,
          baseSets: isPriorityGroup ? Math.min(5, (ex.baseSets || 3) + 1) : ex.baseSets,
          totalSets: isPriorityGroup
            ? Math.min(5, (ex.totalSets || ex.baseSets || 3) + 1)
            : ex.totalSets || ex.baseSets,
          reps: isPriorityGroup ? '8-10' : ex.reps
        };
      });

      return {
        ...day,
        subtitle: `${cleanDisplayText(day.subtitle)} • Ajustado (${
          activePreset?.label || 'Personalizado'
        })`,
        exercises: adjustedExercises,
        totalDaySets: adjustedExercises.reduce(
          (acc, item) => acc + (item.totalSets || item.baseSets || 3),
          0
        )
      };
    });

    setPreviewProposal({
      scope: adjustScope,
      summaryLabel: instruction,
      proposedWorkouts: proposed
    });
  };

  return (
    <div className="max-w-lg mx-auto space-y-5 pb-20">
      {/* Sub-seletor: Coach IA (Chat) vs Ajustar Treino com IA */}
      <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-[#13151A] border border-white/[0.06]">
        <button
          type="button"
          onClick={() => setAiMode('coach')}
          className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            aiMode === 'coach'
              ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>Coach IA</span>
        </button>

        <button
          type="button"
          onClick={() => setAiMode('adjust')}
          className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            aiMode === 'adjust'
              ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <Wand2 className="w-4 h-4" />
          <span>Ajustar Rotina</span>
        </button>
      </div>

      {/* Contexto Real do Atleta */}
      <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="block text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                CONTEXTO DO ATLETA
              </span>
              <h2 className="text-sm font-extrabold text-[#F4F5F7] truncate">
                {profile.nome} · {profile.experiencia}
              </h2>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 text-[10px] font-bold text-[#10B981] shrink-0">
            • Online
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="p-2.5 rounded-xl bg-[#1A1D24] text-center">
            <div className="font-mono text-xs font-bold text-[#F4F5F7]">
              {activeSelectedDays.length}x/sem
            </div>
            <div className="text-[10px] text-[#9CA3AF]">Frequência</div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#1A1D24] text-center">
            <div className="font-mono text-xs font-bold text-[#D4AF37]">
              {goldenAnalysis.indiceAdonisAtual}
            </div>
            <div className="text-[10px] text-[#9CA3AF]">Índice Áureo</div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#1A1D24] text-center">
            <div className="font-mono text-xs font-bold text-[#F4F5F7]">
              {workoutHistory.length}
            </div>
            <div className="text-[10px] text-[#9CA3AF]">Sessões</div>
          </div>
        </div>
      </section>

      {aiMode === 'coach' ? (
        /* ================================================================== */
        /* MODO 1: COACH IA CONVERSACIONAL                                    */
        /* ================================================================== */
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
          <div className="space-y-1">
            <h3 className="text-base font-extrabold text-[#F4F5F7]">
              Assistente Técnico de Musculação
            </h3>
            <p className="text-xs text-[#9CA3AF]">
              Tire dúvidas sobre biomecânica, progressão de cargas, volume semanal e recuperação.
            </p>
          </div>

          {/* Sugestões Rápidas */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
              Sugestões rápidas
            </span>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_COACH_QUESTIONS.map((q, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isAskingCoach}
                  onClick={() => onAskCoach(q)}
                  className="text-left px-3 py-1.5 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.06] text-[11px] font-semibold text-[#F4F5F7] transition-colors cursor-pointer disabled:opacity-50"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Feed de Mensagens */}
          <div className="bg-[#0B0D12] border border-white/[0.05] rounded-2xl p-3.5 max-h-96 overflow-y-auto space-y-3">
            {aiCoachMessages.length === 0 ? (
              <div className="py-6 text-center space-y-2">
                <MessageSquare className="w-7 h-7 text-[#D4AF37] mx-auto opacity-80" />
                <p className="text-xs font-semibold text-[#F4F5F7]">
                  Como posso ajudar no seu treino hoje?
                </p>
                <p className="text-[11px] text-[#9CA3AF] max-w-xs mx-auto">
                  Foco prioritário identificado: <strong className="text-[#D4AF37]">{priorityPartsLabel}</strong>. Escolha uma pergunta acima ou envie sua dúvida abaixo.
                </p>
              </div>
            ) : (
              aiCoachMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#F4F5F7] ml-6'
                      : 'bg-[#1A1D24] border border-white/[0.06] text-[#F4F5F7] mr-3'
                  }`}
                >
                  <div className="text-[10px] font-bold uppercase tracking-wider text-[#D4AF37] mb-1">
                    {msg.role === 'user' ? profile.nome : 'Coach IA AURUS'}
                  </div>
                  <div className="whitespace-pre-line">{msg.text}</div>
                </div>
              ))
            )}

            {isAskingCoach && (
              <div className="p-3.5 rounded-2xl bg-[#1A1D24] border border-white/[0.06] text-xs text-[#D4AF37] flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Analisando seu perfil e rotina para responder...</span>
              </div>
            )}
          </div>

          {/* Campo de Entrada */}
          <form onSubmit={handleChatSubmit} className="flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Pergunte sobre séries, exercícios ou divisão..."
              className="flex-1 h-11 bg-[#1A1D24] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl px-3.5 text-xs text-[#F4F5F7] placeholder:text-[#9CA3AF] focus:outline-none"
            />
            <button
              type="submit"
              disabled={isAskingCoach || !chatInput.trim()}
              aria-label="Enviar pergunta ao Coach IA"
              className="w-11 h-11 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] disabled:opacity-40 text-[#08090C] flex items-center justify-center shrink-0 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </section>
      ) : (
        /* ================================================================== */
        /* MODO 2: AJUSTAR TREINO COM IA (COM PRÉVIA ANTES DE APLICAR)        */
        /* ================================================================== */
        <div className="space-y-4">
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  PRESCRIÇÃO INTELIGENTE
                </span>
                <h3 className="text-base font-extrabold text-[#F4F5F7]">
                  Ajustar Treino com IA
                </h3>
              </div>
              {customAiWorkouts && (
                <button
                  type="button"
                  onClick={onResetToDefault}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1A1D24] hover:bg-[#252A36] text-[11px] font-bold text-[#9CA3AF] hover:text-[#F4F5F7] cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Padrão</span>
                </button>
              )}
            </div>

            {/* Escopo do Ajuste: Dia Atual vs Semana Completa */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Escopo do Ajuste
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setAdjustScope('day');
                    setPreviewProposal(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    adjustScope === 'day'
                      ? 'bg-[#1A1D24] border-[#D4AF37] text-[#F4F5F7]'
                      : 'bg-[#0E1015] border-white/[0.05] text-[#9CA3AF]'
                  }`}
                >
                  <div className="text-xs font-bold text-[#D4AF37]">
                    Apenas {currentDayWorkout?.shortDay || 'Hoje'}
                  </div>
                  <div className="text-[11px] text-[#9CA3AF] truncate mt-0.5">
                    {cleanDisplayText(currentDayWorkout?.title || 'Treino do Dia')}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAdjustScope('week');
                    setPreviewProposal(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    adjustScope === 'week'
                      ? 'bg-[#1A1D24] border-[#D4AF37] text-[#F4F5F7]'
                      : 'bg-[#0E1015] border-white/[0.05] text-[#9CA3AF]'
                  }`}
                >
                  <div className="text-xs font-bold text-[#D4AF37]">
                    Semana Completa
                  </div>
                  <div className="text-[11px] text-[#9CA3AF] mt-0.5">
                    {activeSelectedDays.length} dias programados
                  </div>
                </button>
              </div>
            </div>

            {/* Seletor de Dias da Semana */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Dias Ativos na Semana
                </span>
                <span className="font-mono text-xs font-bold text-[#D4AF37]">
                  {activeSelectedDays.length} dias
                </span>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {ALL_WEEK_DAYS.map((d) => {
                  const isActive = activeSelectedDays.includes(d.id);
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => onToggleTrainingDay(d.id)}
                      className={`h-9 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#D4AF37] text-[#08090C]'
                          : 'bg-[#1A1D24] text-[#9CA3AF]'
                      }`}
                    >
                      {d.short}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Diretrizes Rápidas */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Objetivo do Ajuste
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {QUICK_ADJUST_PRESETS.map((preset) => {
                  const active = selectedPresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedPresetId(preset.id);
                        setCustomPrompt(preset.prompt);
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        active
                          ? 'bg-[#1A1D24] border-[#D4AF37] text-[#F4F5F7]'
                          : 'bg-[#0E1015] border-white/[0.05] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold">{preset.label}</span>
                        {active && <Check className="w-3.5 h-3.5 text-[#D4AF37]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Instrução personalizada */}
            <div className="space-y-1.5">
              <label
                htmlFor="ai-custom-prompt-input"
                className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]"
              >
                Instrução Específica (Opcional)
              </label>
              <textarea
                id="ai-custom-prompt-input"
                rows={2}
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="Ex.: Substituir supino reto por halteres, focar em deltoide lateral..."
                className="w-full bg-[#1A1D24] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl p-3 text-xs text-[#F4F5F7] placeholder:text-[#9CA3AF]/60 focus:outline-none resize-none"
              />
            </div>

            {/* Botões de Geração de Prévia e Recalibração IA */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={handleBuildPreviewProposal}
                className="h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-[#D4AF37]/40 text-xs font-bold text-[#D4AF37] inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>Visualizar Prévia do Ajuste</span>
              </button>

              <button
                type="button"
                disabled={isGeneratingAi}
                onClick={() =>
                  onReformulate({
                    scope: adjustScope,
                    customPrompt: customPrompt.trim() || undefined
                  })
                }
                className="h-11 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] disabled:opacity-50 text-xs font-bold text-[#08090C] inline-flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer"
              >
                <Wand2 className={`w-4 h-4 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                <span>
                  {isGeneratingAi
                    ? 'Gerando com IA...'
                    : adjustScope === 'day'
                    ? `Recalibrar ${currentDayWorkout?.shortDay || 'Dia'} com IA`
                    : 'Recalibrar Semana com IA'}
                </span>
              </button>
            </div>
          </section>

          {/* Painel de Prévia Antes de Aplicar na Rotina */}
          {previewProposal && (
            <section className="bg-[#13151A] border border-[#D4AF37]/50 rounded-2xl p-4 space-y-4 shadow-2xl">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15 text-[10px] font-bold uppercase tracking-wider text-[#D4AF37]">
                    <Sparkles className="w-3 h-3" />
                    Prévia da Rotina Proposta
                  </span>
                  <h4 className="text-sm font-extrabold text-[#F4F5F7] mt-1">
                    Revise antes de aplicar à sua rotina
                  </h4>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    {previewProposal.summaryLabel}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setPreviewProposal(null)}
                  aria-label="Fechar prévia"
                  className="p-1.5 rounded-lg bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {previewProposal.proposedWorkouts
                  .filter((d) =>
                    previewProposal.scope === 'day'
                      ? d.id === currentDayWorkout.id
                      : true
                  )
                  .map((day) => (
                    <div
                      key={day.id}
                      className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.06] space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-[#D4AF37]">
                          {day.dayName} — {cleanDisplayText(day.title)}
                        </span>
                        <span className="font-mono text-[11px] text-[#9CA3AF]">
                          {day.exercises.length} exerc.
                        </span>
                      </div>
                      <div className="space-y-1">
                        {day.exercises.map((ex, i) => (
                          <div
                            key={ex.id}
                            className="flex items-center justify-between text-xs text-[#F4F5F7] py-0.5"
                          >
                            <span className="truncate pr-2">
                              {i + 1}. {cleanDisplayText(ex.name)}
                            </span>
                            <span className="font-mono text-[11px] text-[#D4AF37] shrink-0">
                              {ex.totalSets || ex.baseSets}x {ex.reps} · {ex.rest}s
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>

              <div className="flex items-center gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => setPreviewProposal(null)}
                  className="flex-1 h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] text-xs font-bold text-[#9CA3AF] hover:text-[#F4F5F7] cursor-pointer"
                >
                  Descartar prévia
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (onApplyPreviewWorkouts) {
                      onApplyPreviewWorkouts(
                        previewProposal.proposedWorkouts,
                        previewProposal.scope
                      );
                    } else {
                      onReformulate({
                        scope: previewProposal.scope,
                        customPrompt: previewProposal.summaryLabel
                      });
                    }
                    setPreviewProposal(null);
                  }}
                  className="flex-1 h-11 rounded-xl bg-[#10B981] hover:bg-[#0ea572] text-[#08090C] text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Aplicar na Rotina</span>
                </button>
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
