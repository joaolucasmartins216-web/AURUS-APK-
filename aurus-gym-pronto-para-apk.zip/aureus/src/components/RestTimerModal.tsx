import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  Dumbbell,
  FileText,
  Gauge,
  Lightbulb,
  Pause,
  Play,
  X,
  Zap
} from 'lucide-react';
import { ExerciseItem, RestTimerState, SetLog } from '../types';
import { formatArenaTimer } from '../utils/arenaLogic';

interface RestTimerModalProps {
  restTimer: RestTimerState;
  remainingSec: number;
  activeExercise?: ExerciseItem;
  activeExerciseIndex: number;
  totalExercises: number;
  activeSets: SetLog[];
  onMinimize: () => void;
  onAdjustRest: (deltaSec: number) => void;
  onTogglePauseRest: () => void;
  onSkipRest: () => void;
}

export const RestTimerModal: React.FC<RestTimerModalProps> = ({
  restTimer,
  remainingSec,
  activeExercise,
  activeExerciseIndex,
  totalExercises,
  activeSets,
  onMinimize,
  onAdjustRest,
  onTogglePauseRest,
  onSkipRest
}) => {
  const [showTips, setShowTips] = useState(false);

  if (!restTimer.isModalOpen || restTimer.status === 'idle') {
    return null;
  }

  const isCompleted = restTimer.status === 'completed' || remainingSec <= 0;
  const isPaused = restTimer.status === 'paused';
  const targetSec = Math.max(1, restTimer.targetSec || 60);

  // SVG Ring math (r = 102, circumference = ~640.88)
  const radius = 102;
  const circumference = 2 * Math.PI * radius;
  const ratio = isCompleted ? 0 : Math.min(1, Math.max(0, remainingSec / targetSec));
  const strokeDashoffset = circumference * (1 - ratio);

  const completedCount = activeSets.filter((s) => s.completed).length;
  const totalSetsCount = activeSets.length || activeExercise?.baseSets || 3;

  const exerciseName =
    restTimer.contextExerciseName || activeExercise?.name || 'Exercício atual';
  const completedSetNum = restTimer.completedSetNumber || completedCount || 1;
  const completedSetObj =
    activeSets.find((s) => s.setNumber === completedSetNum) ||
    activeSets[Math.max(0, completedSetNum - 1)];

  const nextPendingSet = activeSets.find((s) => !s.completed);
  const nextSetNumber = restTimer.nextSetNumber ?? nextPendingSet?.setNumber ?? null;
  const nextSetWeight = restTimer.nextSetWeight ?? nextPendingSet?.weight ?? null;
  const nextSetReps = restTimer.nextSetReps ?? nextPendingSet?.reps ?? null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Descanso Ativo"
      className="fixed inset-0 z-50 bg-[#08090C]/95 backdrop-blur-xl flex flex-col overflow-y-auto text-[#F4F5F7]"
    >
      {/* Top Bar */}
      <header className="sticky top-0 z-20 h-16 px-4 flex items-center justify-between bg-[#13151A]/90 border-b border-white/[0.06] backdrop-blur-md shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onMinimize}
            aria-label="Voltar ao treino mantendo descanso"
            className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h1 className="text-[17px] font-extrabold tracking-tight text-[#F4F5F7]">
            Descanso Ativo
          </h1>
        </div>

        <span className="font-mono text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#1A1D24] border border-white/[0.06] text-[#D4AF37]">
          AURUS GYM
        </span>
      </header>

      <div className="flex-1 w-full max-w-md mx-auto px-4 py-4 flex flex-col justify-between gap-4">
        {/* Contextual Dimmed Workout Preview */}
        <div className="opacity-55 select-none space-y-2">
          <div className="flex items-center justify-between bg-[#13151A] p-3.5 rounded-xl border border-white/[0.06]">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#1A1D24] flex items-center justify-center text-[#D4AF37] shrink-0">
                <Dumbbell className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Exercício {activeExerciseIndex + 1} de {totalExercises}
                </span>
                <p className="text-[14px] font-bold text-[#F4F5F7] truncate">
                  {exerciseName}
                </p>
              </div>
            </div>
            <span className="font-mono text-[11px] font-bold text-[#10B981] bg-[#10B981]/10 border border-[#10B981]/25 px-2.5 py-1 rounded-full shrink-0">
              Série {completedCount}/{totalSetsCount} Feita
            </span>
          </div>

          {completedSetObj && (
            <div className="bg-[#13151A]/70 px-3.5 py-2.5 rounded-xl border border-white/[0.04] flex items-center justify-between">
              <span className="font-mono text-[11px] font-semibold text-[#9CA3AF] uppercase">
                SÉRIE {completedSetObj.setNumber}: {completedSetObj.weight} kg ×{' '}
                {completedSetObj.reps} reps
              </span>
              <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
            </div>
          )}
        </div>

        {/* Main Immersive Rest Card */}
        <section className="w-full bg-[#13151A] border border-white/[0.08] rounded-2xl p-4 sm:p-5 shadow-[0_12px_40px_rgba(0,0,0,0.65)] flex flex-col items-center">
          {/* Top HUD Controls */}
          <div className="w-full flex items-center justify-between gap-2 mb-3">
            <button
              type="button"
              onClick={onMinimize}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7] text-[11px] font-bold uppercase tracking-wider transition-colors min-h-[38px]"
            >
              <ChevronDown className="w-4 h-4" />
              <span>Flutuar HUD</span>
            </button>

            <div className="flex items-center gap-1.5 bg-[#08090C] px-3 py-1.5 rounded-full border border-white/[0.06]">
              <span
                className={`w-2 h-2 rounded-full ${
                  isCompleted
                    ? 'bg-[#10B981]'
                    : isPaused
                    ? 'bg-amber-400'
                    : 'bg-[#D4AF37] animate-pulse'
                }`}
              />
              <span
                className={`text-[10px] font-extrabold uppercase tracking-widest ${
                  isCompleted ? 'text-[#10B981]' : 'text-[#D4AF37]'
                }`}
              >
                {isCompleted
                  ? 'Descanso Concluído'
                  : isPaused
                  ? 'Descanso Pausado'
                  : 'Descanso Ativo'}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setShowTips((prev) => !prev)}
              aria-label="Alternar dica técnica"
              className="w-9 h-9 rounded-full bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#9CA3AF] hover:text-[#D4AF37] transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>

          {/* Exercise Context & Next Set Target */}
          <div className="text-center w-full my-1">
            <p className="text-[10px] font-bold text-[#D4AF37] tracking-widest uppercase mb-1">
              {completedCount > 0
                ? `Série ${completedSetNum} concluída com sucesso`
                : 'Recuperação programada'}
            </p>
            <h2 className="text-[20px] font-extrabold text-[#F4F5F7] tracking-tight">
              {exerciseName}
            </h2>

            <div className="mt-2 inline-flex items-center gap-1.5 bg-[#1A1D24] border border-white/[0.06] px-3.5 py-1 rounded-full">
              <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
              {nextSetNumber !== null ? (
                <p className="text-[12px] font-medium text-[#9CA3AF]">
                  Próxima:{' '}
                  <span className="text-[#F4F5F7] font-bold">
                    Série {nextSetNumber} de {totalSetsCount}
                  </span>{' '}
                  •{' '}
                  <span className="font-mono text-[#D4AF37] font-bold">
                    {nextSetWeight} kg × {nextSetReps} reps
                  </span>
                </p>
              ) : (
                <p className="text-[12px] font-bold text-[#10B981]">
                  Todas as séries deste exercício foram concluídas
                </p>
              )}
            </div>
          </div>

          {/* Giant Circular Countdown Ring */}
          <div className="relative w-56 h-56 sm:w-60 sm:h-60 my-4 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 240 240">
              <circle
                cx="120"
                cy="120"
                r={radius}
                fill="none"
                stroke="#08090C"
                strokeWidth="9"
              />
              <circle
                cx="120"
                cy="120"
                r={radius}
                fill="none"
                stroke={isCompleted ? '#10B981' : '#D4AF37'}
                strokeWidth="9"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-300 ease-out"
              />
            </svg>

            <div className="absolute inset-0 flex flex-col items-center justify-center select-none">
              <span className="text-[10px] font-bold uppercase text-[#9CA3AF] tracking-widest">
                {isCompleted ? 'Pronto para atacar' : 'Tempo Restante'}
              </span>
              <span
                data-testid="rest-modal-countdown"
                className={`font-mono text-[40px] sm:text-[44px] font-bold tracking-tight my-1 tabular-nums ${
                  isCompleted ? 'text-[#10B981]' : 'text-[#D4AF37]'
                }`}
              >
                {formatArenaTimer(remainingSec, false)}
              </span>
              <span className="font-mono text-[11px] font-semibold text-[#9CA3AF] bg-[#08090C] px-3 py-0.5 rounded-full border border-white/[0.05]">
                Meta: {targetSec}s
              </span>
            </div>
          </div>

          {/* Quick Adjustments Grid (-15s, +15s, +30s, +60s) */}
          <div className="w-full grid grid-cols-4 gap-2 mb-4">
            {[-15, 15, 30, 60].map((delta) => (
              <button
                key={delta}
                type="button"
                onClick={() => onAdjustRest(delta)}
                className="min-h-[44px] bg-[#1A1D24] hover:bg-white/[0.08] active:scale-95 border border-white/[0.06] rounded-xl font-mono text-[13px] font-bold text-[#F4F5F7] transition-all"
              >
                {delta > 0 ? `+${delta}s` : `${delta}s`}
              </button>
            ))}
          </div>

          {/* Primary Action Controls (Pausar/Retomar + Próxima Série) */}
          <div className="w-full flex items-center gap-2.5 mb-3">
            <button
              type="button"
              onClick={onTogglePauseRest}
              disabled={isCompleted}
              className="w-1/3 min-h-[52px] bg-[#1A1D24] hover:bg-white/[0.08] border border-white/[0.08] active:scale-95 rounded-xl flex items-center justify-center gap-1.5 text-[#F4F5F7] text-[13px] font-bold transition-all disabled:opacity-40"
            >
              {isPaused ? (
                <>
                  <Play className="w-4 h-4 text-[#10B981]" />
                  <span>Retomar</span>
                </>
              ) : (
                <>
                  <Pause className="w-4 h-4 text-[#D4AF37]" />
                  <span>Pausar</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onSkipRest}
              className={`w-2/3 min-h-[52px] rounded-xl flex items-center justify-center gap-2 font-extrabold text-[14px] uppercase tracking-wider transition-all active:scale-[0.98] ${
                isCompleted
                  ? 'bg-[#10B981] text-[#08090C] shadow-[0_4px_20px_rgba(16,185,129,0.3)]'
                  : 'bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] shadow-[0_4px_20px_rgba(212,175,55,0.25)]'
              }`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{isCompleted ? 'Voltar ao Treino' : 'Próxima Série'}</span>
            </button>
          </div>

          {/* Support Links */}
          <div className="w-full flex items-center justify-around pt-1 text-[#9CA3AF] text-[12px]">
            <button
              type="button"
              onClick={() => setShowTips((prev) => !prev)}
              className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-lg hover:text-[#D4AF37] transition-colors"
            >
              <Lightbulb className="w-4 h-4 text-[#D4AF37]" />
              <span>Dica técnica</span>
            </button>
            <span className="w-1 h-1 rounded-full bg-white/15" />
            <div className="flex items-center gap-1.5 py-1.5 px-2.5">
              <Gauge className="w-4 h-4 text-[#D4AF37]" />
              <span>
                Cadência{' '}
                <strong className="font-mono text-[#F4F5F7]">
                  {activeExercise?.cadence || '2-0-1-0'}
                </strong>
              </span>
            </div>
          </div>

          {/* Collapsible Technique Card */}
          {showTips && activeExercise && (
            <div className="w-full mt-3 bg-[#1A1D24] p-3.5 rounded-xl border border-white/[0.06] text-left space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-wider">
                  Orientação Biomecânica
                </span>
                <button
                  type="button"
                  onClick={() => setShowTips(false)}
                  className="text-[11px] text-[#9CA3AF] hover:text-[#F4F5F7]"
                >
                  Fechar
                </button>
              </div>
              <p className="text-[12px] text-[#9CA3AF] leading-relaxed">
                {activeExercise.tip}
              </p>
            </div>
          )}
        </section>

        {/* Footer Recovery Note */}
        <div className="w-full px-3 py-2 flex items-center justify-center gap-2 text-[#9CA3AF]">
          <Zap className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-center">
            O cronômetro calcula o tempo real mesmo com a tela bloqueada
          </span>
        </div>
      </div>
    </div>
  );
};
