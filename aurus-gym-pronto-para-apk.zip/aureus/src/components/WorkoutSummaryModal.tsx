import React from 'react';
import {
  Award,
  CheckCircle2,
  Dumbbell,
  History,
  Home,
  ListOrdered,
  Lock,
  Timer,
  X
} from 'lucide-react';
import { CompletedWorkout } from '../types';
import { cleanDisplayText } from '../utils/dashboardLogic';
import { formatArenaTimer } from '../utils/arenaLogic';

interface WorkoutSummaryModalProps {
  completedWorkout: CompletedWorkout | null;
  workoutHistory: CompletedWorkout[];
  onUpdateSummaryMeta: (workoutId: string, rpe: number | undefined, notes: string) => void;
  onGoHome: () => void;
  onGoHistory: () => void;
}

const RPE_DESCRIPTIONS: Record<string, string> = {
  '6': '6.0 · Aquecimento robusto ou recuperação ativa',
  '7': '7.0 · Moderado (3-4 repetições na reserva)',
  '7.5': '7.5 · Carga moderada para alta (3 reps na reserva)',
  '8': '8.0 · Intenso (2 repetições sólidas na reserva)',
  '8.5': '8.5 · Intenso e controlado (1-2 reps na reserva)',
  '9': '9.0 · Próximo da falha (1 repetição na reserva)',
  '9.5': '9.5 · Esforço máximo com forma estrita',
  '10': '10.0 · Esforço máximo na série'
};

export const WorkoutSummaryModal: React.FC<WorkoutSummaryModalProps> = ({
  completedWorkout,
  workoutHistory,
  onUpdateSummaryMeta,
  onGoHome,
  onGoHistory
}) => {
  if (!completedWorkout) return null;

  const sessionNumber = Math.max(1, workoutHistory.length);
  const cleanTitle = cleanDisplayText(completedWorkout.title);
  const durationMin = Math.max(1, Math.round((completedWorkout.durationSec || 60) / 60));

  const endTimeStr = new Date(completedWorkout.timestamp).toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });
  const startTimeStr = completedWorkout.startedAtTimestamp
    ? new Date(completedWorkout.startedAtTimestamp).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      })
    : null;

  const adherencePct =
    completedWorkout.totalSets > 0
      ? Math.round((completedWorkout.completedSets / completedWorkout.totalSets) * 100)
      : 100;

  const executedExercises = completedWorkout.exercisesSummary.filter(
    (ex) => ex.setsCompleted > 0
  );

  // Genuine Personal Record check (only when previousBestWeight existed and was exceeded)
  const genuinePrItems = completedWorkout.exercisesSummary.filter(
    (ex) =>
      ex.isPersonalRecord &&
      typeof ex.previousBestWeight === 'number' &&
      ex.previousBestWeight > 0 &&
      ex.maxWeight > ex.previousBestWeight
  );
  const topPr = genuinePrItems[0] || null;

  // Genuine comparison with previous workout of the same dayId (if any exists in workoutHistory)
  const previousSameDayWorkout = workoutHistory.find(
    (wk) => wk.id !== completedWorkout.id && wk.dayId === completedWorkout.dayId && wk.tonnage > 0
  );
  const volumeDeltaPct =
    previousSameDayWorkout && previousSameDayWorkout.tonnage > 0
      ? Math.round(
          ((completedWorkout.tonnage - previousSameDayWorkout.tonnage) /
            previousSameDayWorkout.tonnage) *
            100
        )
      : null;

  const currentRpe: number | undefined =
    typeof completedWorkout.sessionRpe === 'number' && !Number.isNaN(completedWorkout.sessionRpe)
      ? completedWorkout.sessionRpe
      : undefined;
  const currentNotes = completedWorkout.sessionNotes ?? '';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Resumo do Treino Concluído"
      className="fixed inset-0 z-50 bg-[#08090C] text-[#F4F5F7] overflow-y-auto flex flex-col"
    >
      {/* Top Header */}
      <header className="sticky top-0 z-20 h-16 px-4 flex items-center justify-between bg-[#13151A]/90 border-b border-white/[0.06] backdrop-blur-md shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onGoHome}
            aria-label="Fechar resumo"
            className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h1 className="text-[17px] font-extrabold tracking-tight text-[#F4F5F7]">
            Resumo do Treino
          </h1>
        </div>

        <span className="font-mono text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#1A1D24] border border-white/[0.06] text-[#D4AF37]">
          AURUS GYM
        </span>
      </header>

      <div className="flex-1 w-full max-w-md mx-auto pb-10">
        {/* Hero Celebration Header */}
        <div className="relative w-full overflow-hidden bg-[#13151A] px-4 py-6 border-b border-white/[0.06] shadow-md">
          <div className="absolute -right-12 -top-12 w-44 h-44 rounded-full bg-[#D4AF37]/10 blur-3xl pointer-events-none" />
          <div className="relative z-10 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1A1D24] border border-[#D4AF37]/30 text-[#D4AF37] font-mono text-[11px] font-bold uppercase tracking-wider">
                <Award className="w-3.5 h-3.5" />
                Sessão #{sessionNumber} Finalizada
              </span>
              <span className="font-mono text-[11px] text-[#9CA3AF]">
                {completedWorkout.dateFormatted}
              </span>
            </div>

            <div>
              <h2 className="text-[24px] font-extrabold text-[#F4F5F7] tracking-tight">
                Treino concluído
              </h2>
              <p className="text-[14px] text-[#9CA3AF] mt-0.5">
                {cleanTitle} finalizado com sucesso.
              </p>
            </div>

            {/* Real Personal Record Callout OR Factual First Record Notice */}
            {topPr ? (
              <div className="mt-2 flex items-center gap-3 p-3.5 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/35">
                <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] font-extrabold text-[#D4AF37] uppercase tracking-wider">
                      Novo Recorde Pessoal
                    </span>
                    <span className="text-[11px] text-[#9CA3AF] truncate">
                      • {topPr.name}
                    </span>
                  </div>
                  <p className="font-mono text-[13px] text-[#F4F5F7] font-bold truncate">
                    {topPr.maxWeight} kg × {topPr.bestSetReps || 1} repetições (+
                    {Math.round((topPr.maxWeight - (topPr.previousBestWeight || 0)) * 10) / 10} kg)
                  </p>
                </div>
              </div>
            ) : (
              <div className="mt-2 flex items-center gap-3 p-3.5 rounded-xl bg-[#1A1D24] border border-white/[0.06]">
                <div className="w-10 h-10 rounded-lg bg-[#10B981]/15 flex items-center justify-center text-[#10B981] shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[11px] font-extrabold text-[#10B981] uppercase tracking-wider">
                    Cargas Registradas com Sucesso
                  </span>
                  <p className="text-[12px] text-[#9CA3AF] truncate">
                    Suas marcas desta sessão foram salvas no histórico oficial.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="px-4 space-y-6 mt-5">
          {/* Consolidated Metrics Grid (2x2) */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-[11px] font-bold text-[#9CA3AF] uppercase tracking-wider">
                Métricas da Sessão
              </span>
              <span className="font-mono text-[11px] font-bold text-[#10B981]">
                {adherencePct}% das séries concluídas
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Duração Total */}
              <div className="p-3.5 rounded-xl bg-[#13151A] border border-white/[0.06] flex flex-col justify-between">
                <div className="flex items-center justify-between text-[#9CA3AF]">
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    Duração Total
                  </span>
                  <Timer className="w-4 h-4 text-[#D4AF37]" />
                </div>
                <div className="mt-2">
                  <span
                    data-testid="summary-duration"
                    className="font-mono text-[26px] font-bold text-[#F4F5F7] tracking-tight"
                  >
                    {durationMin}
                    <span className="text-[13px] font-sans font-normal text-[#9CA3AF] ml-1">
                      min
                    </span>
                  </span>
                  <p className="font-mono text-[11px] text-[#9CA3AF] mt-0.5">
                    {startTimeStr ? `${startTimeStr} • ${endTimeStr}` : formatArenaTimer(completedWorkout.durationSec, true)}
                  </p>
                </div>
              </div>

              {/* Volume Movimentado */}
              <div className="p-3.5 rounded-xl bg-[#13151A] border border-white/[0.06] flex flex-col justify-between">
                <div className="flex items-center justify-between text-[#9CA3AF]">
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    Volume Movimentado
                  </span>
                  <Dumbbell className="w-4 h-4 text-[#D4AF37]" />
                </div>
                <div className="mt-2">
                  <span
                    data-testid="summary-tonnage"
                    className="font-mono text-[26px] font-bold text-[#D4AF37] tracking-tight"
                  >
                    {completedWorkout.tonnage.toLocaleString('pt-BR')}
                    <span className="text-[13px] font-sans font-normal text-[#9CA3AF] ml-1">
                      kg
                    </span>
                  </span>
                  <p className="text-[11px] text-[#10B981] mt-0.5 font-medium">
                    {volumeDeltaPct !== null
                      ? `${volumeDeltaPct >= 0 ? `+${volumeDeltaPct}%` : `${volumeDeltaPct}%`} vs última sessão`
                      : 'Volume real contabilizado'}
                  </p>
                </div>
              </div>

              {/* Séries Concluídas */}
              <div className="p-3.5 rounded-xl bg-[#13151A] border border-white/[0.06] flex flex-col justify-between">
                <div className="flex items-center justify-between text-[#9CA3AF]">
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    Séries Concluídas
                  </span>
                  <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
                </div>
                <div className="mt-2">
                  <span
                    data-testid="summary-sets"
                    className="font-mono text-[26px] font-bold text-[#F4F5F7] tracking-tight"
                  >
                    {completedWorkout.completedSets}
                    <span className="text-[14px] font-normal text-[#9CA3AF] ml-0.5">
                      /{completedWorkout.totalSets}
                    </span>
                  </span>
                  <p className="text-[11px] text-[#9CA3AF] mt-0.5">
                    {adherencePct}% de conclusão
                  </p>
                </div>
              </div>

              {/* Exercícios */}
              <div className="p-3.5 rounded-xl bg-[#13151A] border border-white/[0.06] flex flex-col justify-between">
                <div className="flex items-center justify-between text-[#9CA3AF]">
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    Exercícios
                  </span>
                  <ListOrdered className="w-4 h-4 text-[#D4AF37]" />
                </div>
                <div className="mt-2">
                  <span className="font-mono text-[26px] font-bold text-[#F4F5F7] tracking-tight">
                    {executedExercises.length}
                    <span className="text-[13px] font-sans font-normal text-[#9CA3AF] ml-1">
                      mov.
                    </span>
                  </span>
                  <p className="text-[11px] text-[#9CA3AF] mt-0.5 truncate">
                    {completedWorkout.dayName}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Registro de Execução (Exercise List) */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-[11px] font-bold text-[#9CA3AF] uppercase tracking-wider">
                Registro de Execução
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF]">
                Melhor Carga
              </span>
            </div>

            <div className="bg-[#13151A] rounded-2xl p-2.5 border border-white/[0.06] space-y-1.5">
              {completedWorkout.exercisesSummary.map((item, idx) => (
                <div
                  key={item.exerciseId}
                  className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.04] flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-[#13151A] border border-white/[0.06] flex items-center justify-center font-mono text-[12px] font-bold text-[#9CA3AF] shrink-0">
                      {idx + 1}
                    </div>
                    <div className="min-w-0">
                      <span className="block text-[13px] font-bold text-[#F4F5F7] truncate">
                        {item.name}
                      </span>
                      <span className="block font-mono text-[11px] text-[#9CA3AF]">
                        {item.setsCompleted} de {item.totalSets} séries concluídas
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 pl-2">
                    {item.setsCompleted > 0 ? (
                      <>
                        <span className="font-mono text-[13px] font-bold text-[#F4F5F7]">
                          {item.maxWeight} kg
                          {item.bestSetReps ? ` × ${item.bestSetReps}` : ''}
                        </span>
                        {item.isPersonalRecord && (
                          <span className="px-1.5 py-0.5 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-mono text-[10px] font-extrabold">
                            PR
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-[11px] text-[#6B7280]">Não realizado</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* RPE (Perceived Exertion) Scale */}
          <section className="p-4 rounded-2xl bg-[#13151A] border border-white/[0.06] space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <span className="block text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">
                  Percepção de Esforço (RPE)
                </span>
                <span className="block text-[13px] font-semibold text-[#F4F5F7] mt-0.5">
                  {currentRpe !== undefined
                    ? RPE_DESCRIPTIONS[String(currentRpe)] || `${currentRpe} · Esforço registrado`
                    : 'Opcional · Selecione o esforço percebido na sessão'}
                </span>
              </div>
              {currentRpe !== undefined ? (
                <span
                  data-testid="summary-rpe-badge"
                  className="px-2.5 py-1 rounded-lg bg-[#D4AF37] text-[#08090C] font-mono text-[15px] font-extrabold"
                >
                  {currentRpe}
                </span>
              ) : (
                <span
                  data-testid="summary-rpe-badge"
                  className="px-2.5 py-1 rounded-lg bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] font-mono text-[12px] font-semibold"
                >
                  Não informado
                </span>
              )}
            </div>

            <div className="grid grid-cols-8 gap-1 pt-1">
              {[6, 7, 7.5, 8, 8.5, 9, 9.5, 10].map((val) => {
                const isSelected = currentRpe === val;
                return (
                  <button
                    key={val}
                    type="button"
                    aria-pressed={isSelected}
                    onClick={() =>
                      onUpdateSummaryMeta(
                        completedWorkout.id,
                        isSelected ? undefined : val,
                        currentNotes
                      )
                    }
                    className={`py-2 rounded-lg font-mono text-[11px] font-bold transition-all ${
                      isSelected
                        ? 'bg-[#D4AF37] text-[#08090C] shadow'
                        : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    {val}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Optional Session Notes */}
          <section className="space-y-1.5">
            <label
              htmlFor="workout-summary-notes"
              className="block text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider px-0.5"
            >
              Anotações da Sessão
            </label>
            <div className="rounded-2xl bg-[#13151A] border border-white/[0.06] p-3.5">
              <textarea
                id="workout-summary-notes"
                rows={2}
                value={currentNotes}
                onChange={(e) =>
                  onUpdateSummaryMeta(completedWorkout.id, currentRpe, e.target.value)
                }
                placeholder="Ex: Estabilidade articular excelente, progressão de carga mantida."
                className="w-full bg-transparent text-[13px] text-[#F4F5F7] placeholder-[#6B7280] resize-none focus:outline-none"
              />
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/[0.05] text-[10px] text-[#9CA3AF]">
                <span className="flex items-center gap-1 text-[#D4AF37] font-semibold">
                  <Lock className="w-3 h-3" /> Salvo automaticamente no histórico
                </span>
                <span className="font-mono">{currentNotes.length} caracteres</span>
              </div>
            </div>
          </section>

          {/* Bottom Action Buttons */}
          <div className="flex flex-col gap-2.5 pt-2">
            <button
              type="button"
              onClick={onGoHome}
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] font-extrabold text-[15px] flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <Home className="w-4 h-4" />
              <span>Voltar ao início</span>
            </button>

            <button
              type="button"
              onClick={onGoHistory}
              className="w-full h-12 rounded-xl bg-[#1A1D24] hover:bg-white/[0.08] border border-white/10 text-[#F4F5F7] font-bold text-[14px] flex items-center justify-center gap-2 transition-all"
            >
              <History className="w-4 h-4 text-[#D4AF37]" />
              <span>Ver histórico</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
