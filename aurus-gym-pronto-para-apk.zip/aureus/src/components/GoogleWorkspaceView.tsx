import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Calendar,
  Mail,
  CheckCircle2,
  Plus,
  Trash2,
  Send,
  RefreshCw,
  LogOut,
  ExternalLink,
  Clock,
  Sparkles,
  ShieldCheck,
  Dumbbell
} from 'lucide-react';
import {
  AppPreferences,
  GoogleCalendarEvent,
  GoogleGmailMessage,
  WorkoutDay,
  UserProfile,
  GoldenAnalysis
} from '../types';
import {
  getGoogleAuthEnvironmentStatus,
  googleSignIn,
  logoutGoogle
} from '../utils/googleAuth';
import {
  fetchCalendarEvents,
  createCalendarEvent,
  deleteCalendarEvent
} from '../utils/googleCalendar';
import {
  fetchRecentGmailMessages,
  sendGmailMessage
} from '../utils/googleGmail';
import { cleanDisplayText } from '../utils/dashboardLogic';

interface GoogleWorkspaceViewProps {
  user: any;
  accessToken: string | null;
  onAuthSuccess: (user: any, token: string) => void;
  onLogout: () => void;
  profile: UserProfile;
  goldenAnalysis: GoldenAnalysis;
  dynamicWorkouts: WorkoutDay[];
  onShowToast: (message: string, type?: 'emerald' | 'rose' | 'gold') => void;
  preferences?: AppPreferences;
  onUpdatePreferences?: (updated: AppPreferences) => void;
  onBackToProfile?: () => void;
}

export function GoogleWorkspaceView({
  user,
  accessToken,
  onAuthSuccess,
  onLogout,
  profile,
  goldenAnalysis,
  dynamicWorkouts,
  onShowToast,
  preferences,
  onUpdatePreferences,
  onBackToProfile
}: GoogleWorkspaceViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<'calendar' | 'gmail'>('calendar');
  const [isConnecting, setIsConnecting] = useState(false);
  const authEnv = getGoogleAuthEnvironmentStatus();

  // Calendar State
  const [events, setEvents] = useState<GoogleCalendarEvent[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [selectedWorkoutId, setSelectedWorkoutId] = useState<string>(
    dynamicWorkouts[0]?.id || 'seg'
  );
  const [eventDate, setEventDate] = useState<string>(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [eventTime, setEventTime] = useState<string>(
    preferences?.preferredWorkoutTime || '18:00'
  );
  const [eventDurationMin, setEventDurationMin] = useState<number>(
    profile.duracaoMediaMin || 60
  );
  const [creatingEvent, setCreatingEvent] = useState(false);

  // Gmail State
  const [messages, setMessages] = useState<GoogleGmailMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState<string>(user?.email || '');
  const [emailSubject, setEmailSubject] = useState<string>(
    `Relatório AURUS GYM — ${profile.nome} (Índice Áureo: ${goldenAnalysis.indiceAdonisAtual})`
  );
  const [emailBody, setEmailBody] = useState<string>(() =>
    generateWorkoutReportText(profile, goldenAnalysis, dynamicWorkouts)
  );
  const [sendingEmail, setSendingEmail] = useState(false);

  useEffect(() => {
    if (user?.email && !recipientEmail) {
      setRecipientEmail(user.email);
    }
  }, [user]);

  useEffect(() => {
    setEmailSubject(
      `Relatório AURUS GYM — ${profile.nome} (Índice Áureo: ${goldenAnalysis.indiceAdonisAtual})`
    );
    setEmailBody(generateWorkoutReportText(profile, goldenAnalysis, dynamicWorkouts));
  }, [profile, goldenAnalysis, dynamicWorkouts]);

  useEffect(() => {
    if (accessToken) {
      loadCalendarData();
      loadGmailData();
    }
  }, [accessToken]);

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    try {
      const { user: signedInUser, accessToken: token } = await googleSignIn();
      if (token) {
        onAuthSuccess(signedInUser, token);
        onShowToast(
          'Conta Google conectada com sucesso! Agenda e Gmail sincronizados.',
          'emerald'
        );
      } else {
        onShowToast(
          'Autenticado, mas o token de acesso do Workspace não foi retornado. Tente novamente.',
          'rose'
        );
      }
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      onShowToast(err?.message || 'Erro ao conectar com o Google Workspace.', 'rose');
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await logoutGoogle();
    onLogout();
    setEvents([]);
    setMessages([]);
    onShowToast('Sessão do Google Workspace encerrada.', 'gold');
  };

  const loadCalendarData = async () => {
    if (!accessToken) return;
    setLoadingEvents(true);
    try {
      const items = await fetchCalendarEvents(accessToken, 12);
      setEvents(items);
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Erro ao carregar Google Calendar.', 'rose');
    } finally {
      setLoadingEvents(false);
    }
  };

  const loadGmailData = async () => {
    if (!accessToken) return;
    setLoadingMessages(true);
    try {
      const items = await fetchRecentGmailMessages(accessToken, 8);
      setMessages(items);
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Erro ao carregar mensagens do Gmail.', 'rose');
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleScheduleWorkout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken) return;

    const workout =
      dynamicWorkouts.find((w) => w.id === selectedWorkoutId) || dynamicWorkouts[0];
    if (!workout) return;

    setCreatingEvent(true);
    try {
      const startDateObj = new Date(`${eventDate}T${eventTime}:00`);
      const endDateObj = new Date(startDateObj.getTime() + eventDurationMin * 60000);

      const exercisesText = workout.exercises
        .map(
          (ex, idx) =>
            `${idx + 1}. ${cleanDisplayText(ex.name)} — ${
              ex.totalSets || ex.baseSets
            }x (${ex.reps}) | Carga base: ${ex.defaultWeight}kg`
        )
        .join('\n');

      const description = [
        `🏋️ AURUS GYM — SESSÃO DE TREINAMENTO`,
        `Atleta: ${profile.nome} | Nível: ${profile.experiencia}`,
        `Índice Áureo Atual: ${goldenAnalysis.indiceAdonisAtual} / 1.618 (Simetria: ${goldenAnalysis.overallScore}%)`,
        ``,
        `📋 EXERCÍCIOS PRESCRITOS:`,
        exercisesText,
        ``,
        workout.cardioBlock
          ? `🔥 CARDIO PÓS-TREINO: ${workout.cardioBlock.mode} (${workout.cardioBlock.protocol})`
          : ''
      ].join('\n');

      await createCalendarEvent(accessToken, {
        summary: `⚡ AURUS GYM: ${cleanDisplayText(workout.dayName)} - ${cleanDisplayText(
          workout.title
        )}`,
        description,
        startDateTime: startDateObj.toISOString(),
        endDateTime: endDateObj.toISOString(),
        location: 'Academia // AURUS GYM'
      });

      onShowToast(
        `Treino "${cleanDisplayText(workout.title)}" agendado no seu Google Agenda!`,
        'emerald'
      );
      await loadCalendarData();
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Falha ao criar evento no Google Calendar.', 'rose');
    } finally {
      setCreatingEvent(false);
    }
  };

  const handleScheduleFullWeek = async () => {
    if (!accessToken) return;
    setCreatingEvent(true);
    try {
      const dayMap: Record<string, number> = {
        dom: 0,
        seg: 1,
        ter: 2,
        qua: 3,
        qui: 4,
        sex: 5,
        sab: 6
      };

      const now = new Date();
      let createdCount = 0;

      for (const workout of dynamicWorkouts) {
        if (!profile.diasSelecionados.includes(workout.id)) continue;

        const targetDow = dayMap[workout.id] ?? 1;
        const nextDate = new Date(now);
        const diff = (targetDow + 7 - now.getDay()) % 7 || 7;
        nextDate.setDate(now.getDate() + diff);

        const [hours, minutes] = eventTime.split(':').map(Number);
        nextDate.setHours(hours || 18, minutes || 0, 0, 0);
        const endDate = new Date(nextDate.getTime() + eventDurationMin * 60000);

        const exercisesText = workout.exercises
          .map(
            (ex, i) =>
              `${i + 1}. ${cleanDisplayText(ex.name)} (${ex.totalSets || ex.baseSets}x ${
                ex.reps
              })`
          )
          .join('\n');

        await createCalendarEvent(accessToken, {
          summary: `⚡ AURUS GYM: ${cleanDisplayText(workout.dayName)} - ${cleanDisplayText(
            workout.title
          )}`,
          description: `Sessão Semanal AURUS GYM\n\nExercícios:\n${exercisesText}`,
          startDateTime: nextDate.toISOString(),
          endDateTime: endDate.toISOString(),
          location: 'Academia // AURUS GYM'
        });
        createdCount++;
      }

      onShowToast(
        `${createdCount} sessões da semana agendadas no Google Agenda!`,
        'emerald'
      );
      await loadCalendarData();
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Erro ao agendar semana completa.', 'rose');
    } finally {
      setCreatingEvent(false);
    }
  };

  const handleDeleteEvent = async (eventId: string) => {
    if (!accessToken) return;
    try {
      await deleteCalendarEvent(accessToken, eventId);
      setEvents((prev) => prev.filter((e) => e.id !== eventId));
      onShowToast('Evento removido do Google Agenda.', 'gold');
    } catch (err: any) {
      onShowToast(err.message || 'Erro ao remover evento.', 'rose');
    }
  };

  const handleSendReportEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !recipientEmail.trim()) return;

    setSendingEmail(true);
    try {
      await sendGmailMessage(
        accessToken,
        recipientEmail.trim(),
        user?.email || 'me',
        emailSubject,
        `<pre style="font-family:monospace;white-space:pre-wrap">${emailBody}</pre>`
      );
      onShowToast(`Relatório enviado com sucesso para ${recipientEmail}!`, 'emerald');
      await loadGmailData();
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Erro ao enviar e-mail pelo Gmail.', 'rose');
    } finally {
      setSendingEmail(false);
    }
  };

  const nextWorkoutPreview = dynamicWorkouts[0];

  return (
    <div className="max-w-lg mx-auto space-y-5 pb-20">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-3">
          {onBackToProfile && (
            <button
              type="button"
              onClick={onBackToProfile}
              aria-label="Voltar para Perfil"
              className="w-10 h-10 rounded-xl bg-[#13151A] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-[#1A1D24] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
              ECOSSISTEMA AURUS
            </span>
            <h1 className="text-xl font-extrabold tracking-tight text-[#F4F5F7]">
              Integrações & Agenda
            </h1>
          </div>
        </div>

        <div className="w-9 h-9 rounded-full bg-[#D4AF37] flex items-center justify-center text-[#08090C] font-bold text-xs">
          {(profile.nome || 'A').slice(0, 2).toUpperCase()}
        </div>
      </div>

      <p className="text-xs sm:text-[13px] text-[#9CA3AF] leading-relaxed">
        Conecte sua conta Google Workspace para agendar seus treinos programados no Google Agenda e enviar relatórios técnicos pelo Gmail.
      </p>

      {/* Card Principal: Google Agenda & OAuth */}
      <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4 shadow-xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-extrabold text-[#F4F5F7] truncate">
                Google Agenda & Gmail
              </h2>
              <p className="text-xs text-[#9CA3AF] truncate">
                {user?.email ? user.email : 'Nenhuma conta Google autenticada'}
              </p>
            </div>
          </div>

          {accessToken ? (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 text-[11px] font-bold text-[#10B981] shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
              Conectado
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#1A1D24] border border-white/[0.08] text-[11px] font-semibold text-[#9CA3AF] shrink-0">
              Desconectado
            </span>
          )}
        </div>

        {/* Status box */}
        <div className="p-3.5 rounded-xl bg-[#1A1D24]/90 border border-white/[0.05] space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold text-[#F4F5F7]">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>
              {accessToken
                ? 'Sincronização Google OAuth 2.0 ativa'
                : 'Pronto para autenticar via Google OAuth 2.0'}
            </span>
          </div>
          <p className="text-xs text-[#9CA3AF]">
            {nextWorkoutPreview
              ? `Próximo treino da rotina: Hoje às ${eventTime} (${cleanDisplayText(
                  nextWorkoutPreview.title
                )})`
              : `Horário preferido configurado: ${eventTime}`}
          </p>
        </div>

        {authEnv.isAndroidWebView && !accessToken && (
          <div className="p-3.5 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 space-y-1.5">
            <div className="text-xs font-bold text-[#D4AF37]">
              Aviso de Segurança Android WebView (OAuth 2.0)
            </div>
            <p className="text-[11px] text-[#9CA3AF] leading-relaxed">
              O Google bloqueia janelas popup de login dentro de WebViews Android (política{' '}
              <code className="text-[#F4F5F7] font-mono">disallowed_useragent</code>). Todos os recursos locais do AURUS GYM funcionam 100% sem login. Para autenticar no APK nativo, registre o pacote{' '}
              <code className="text-[#F4F5F7] font-mono">com.aurusgym.app</code> e a chave SHA-1 no Google Cloud Console.
            </p>
          </div>
        )}

        {/* Preferências de Sincronização da Agenda */}
        {preferences && onUpdatePreferences && (
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs sm:text-sm font-medium text-[#F4F5F7]">
                Adicionar treinos programados
              </span>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.autoSyncCalendar}
                onClick={() =>
                  onUpdatePreferences({
                    ...preferences,
                    autoSyncCalendar: !preferences.autoSyncCalendar
                  })
                }
                className={`w-12 h-7 rounded-full p-0.5 transition-colors flex items-center cursor-pointer ${
                  preferences.autoSyncCalendar ? 'bg-[#D4AF37]' : 'bg-[#252934]'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full transition-transform ${
                    preferences.autoSyncCalendar
                      ? 'translate-x-5 bg-[#08090C]'
                      : 'translate-x-0 bg-[#9CA3AF]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between gap-3">
              <span className="text-xs sm:text-sm font-medium text-[#F4F5F7]">
                Registrar duração real após conclusão
              </span>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.logRealDurationToCalendar}
                onClick={() =>
                  onUpdatePreferences({
                    ...preferences,
                    logRealDurationToCalendar: !preferences.logRealDurationToCalendar
                  })
                }
                className={`w-12 h-7 rounded-full p-0.5 transition-colors flex items-center cursor-pointer ${
                  preferences.logRealDurationToCalendar ? 'bg-[#D4AF37]' : 'bg-[#252934]'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full transition-transform ${
                    preferences.logRealDurationToCalendar
                      ? 'translate-x-5 bg-[#08090C]'
                      : 'translate-x-0 bg-[#9CA3AF]'
                  }`}
                />
              </button>
            </div>
          </div>
        )}

        {/* Botões de Ação OAuth */}
        {!accessToken ? (
          <button
            type="button"
            onClick={handleConnectGoogle}
            disabled={isConnecting}
            className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-xs sm:text-sm inline-flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] disabled:opacity-50 cursor-pointer"
          >
            {isConnecting ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
            )}
            <span>
              {isConnecting
                ? 'Autenticando com Google...'
                : 'Conectar com Google Agenda & Gmail'}
            </span>
          </button>
        ) : (
          <div className="flex items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={() => {
                loadCalendarData();
                loadGmailData();
                onShowToast('Agenda e Gmail sincronizados!', 'emerald');
              }}
              disabled={loadingEvents || loadingMessages}
              className="h-10 px-4 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#F4F5F7] inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 text-[#D4AF37] ${
                  loadingEvents || loadingMessages ? 'animate-spin' : ''
                }`}
              />
              <span>Sincronizar agora</span>
            </button>

            <button
              type="button"
              onClick={handleDisconnect}
              className="h-10 px-3 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer inline-flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Desconectar</span>
            </button>
          </div>
        )}
      </section>

      {/* Painel Operacional (quando conectado ou para visualização das ferramentas reais) */}
      {accessToken ? (
        <div className="space-y-4">
          {/* Sub-navegação Calendar vs Gmail */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#13151A] border border-white/[0.06]">
            <button
              type="button"
              onClick={() => setActiveSubTab('calendar')}
              className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeSubTab === 'calendar'
                  ? 'bg-[#D4AF37] text-[#08090C]'
                  : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Google Agenda</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('gmail')}
              className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeSubTab === 'gmail'
                  ? 'bg-[#D4AF37] text-[#08090C]'
                  : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Relatórios Gmail</span>
            </button>
          </div>

          {activeSubTab === 'calendar' ? (
            <div className="space-y-4">
              {/* Agendar Treino */}
              <form
                onSubmit={handleScheduleWorkout}
                className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3.5"
              >
                <div className="flex items-center gap-2">
                  <Plus className="w-4 h-4 text-[#D4AF37]" />
                  <h3 className="text-sm font-bold text-[#F4F5F7]">
                    Agendar Sessão no Google Agenda
                  </h3>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Divisão da Rotina
                  </label>
                  <select
                    value={selectedWorkoutId}
                    onChange={(e) => setSelectedWorkoutId(e.target.value)}
                    className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 text-xs font-semibold text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                  >
                    {dynamicWorkouts.map((w) => (
                      <option key={w.id} value={w.id}>
                        {cleanDisplayText(w.dayName)} — {cleanDisplayText(w.title)} (
                        {w.exercises.length} exerc.)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                      Data
                    </label>
                    <input
                      type="date"
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      required
                      className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 font-mono text-xs text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                      Horário
                    </label>
                    <input
                      type="time"
                      value={eventTime}
                      onChange={(e) => setEventTime(e.target.value)}
                      required
                      className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 font-mono text-xs text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Duração Estimada
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[45, 60, 75, 90].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => setEventDurationMin(mins)}
                        className={`h-9 rounded-xl font-mono text-xs font-bold border transition cursor-pointer ${
                          eventDurationMin === mins
                            ? 'bg-[#D4AF37] border-[#D4AF37] text-[#08090C]'
                            : 'bg-[#1A1D24] border-white/[0.06] text-[#9CA3AF]'
                        }`}
                      >
                        {mins}m
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-1">
                  <button
                    type="submit"
                    disabled={creatingEvent}
                    className="w-full h-11 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-xs inline-flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>
                      {creatingEvent ? 'Agendando...' : 'Agendar Sessão Selecionada'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleScheduleFullWeek}
                    disabled={creatingEvent}
                    className="w-full h-10 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-[#D4AF37]/30 text-[#D4AF37] font-bold text-xs inline-flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>
                      Exportar Semana Completa ({profile.diasSelecionados.length} dias)
                    </span>
                  </button>
                </div>
              </form>

              {/* Próximos Eventos */}
              <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-[#F4F5F7]">
                    Próximos Eventos na Agenda ({events.length})
                  </h3>
                  <button
                    type="button"
                    onClick={loadCalendarData}
                    disabled={loadingEvents}
                    className="p-1.5 rounded-lg bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${loadingEvents ? 'animate-spin' : ''}`}
                    />
                  </button>
                </div>

                {events.length === 0 ? (
                  <p className="text-xs text-[#9CA3AF] py-4 text-center">
                    Nenhum evento futuro encontrado. Agende sua próxima sessão acima.
                  </p>
                ) : (
                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {events.map((ev) => {
                      const rawStart = ev.start?.dateTime || ev.start?.date || '';
                      const formattedStart = rawStart
                        ? new Date(rawStart).toLocaleString('pt-BR', {
                            weekday: 'short',
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : 'Data indefinida';

                      return (
                        <div
                          key={ev.id}
                          className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-start justify-between gap-2.5"
                        >
                          <div className="min-w-0 space-y-1">
                            <div className="text-xs font-bold text-[#F4F5F7] truncate">
                              {ev.summary || '(Sem título)'}
                            </div>
                            <div className="text-[11px] font-mono text-[#D4AF37] flex items-center gap-1.5">
                              <Clock className="w-3 h-3" />
                              <span>{formattedStart}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {ev.htmlLink && (
                              <a
                                href={ev.htmlLink}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1.5 rounded-lg bg-[#13151A] text-[#9CA3AF] hover:text-[#D4AF37]"
                                title="Abrir no Google Calendar"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            )}
                            <button
                              type="button"
                              onClick={() => handleDeleteEvent(ev.id)}
                              className="p-1.5 rounded-lg bg-[#13151A] text-[#9CA3AF] hover:text-rose-400 cursor-pointer"
                              title="Remover evento"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Enviar Relatório por Gmail */}
              <form
                onSubmit={handleSendReportEmail}
                className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3"
              >
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4 text-[#D4AF37]" />
                  <h3 className="text-sm font-bold text-[#F4F5F7]">
                    Enviar Relatório de Treino por E-mail
                  </h3>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Destinatário
                  </label>
                  <input
                    type="email"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    required
                    placeholder="exemplo@gmail.com"
                    className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 text-xs text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Assunto
                  </label>
                  <input
                    type="text"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    required
                    className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 text-xs text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                    Resumo da Prescrição
                  </label>
                  <textarea
                    rows={5}
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    required
                    className="w-full bg-[#1A1D24] border border-white/[0.08] rounded-xl p-3 font-mono text-[11px] text-[#F4F5F7] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={sendingEmail}
                  className="w-full h-11 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-xs inline-flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{sendingEmail ? 'Enviando...' : 'Enviar via Gmail'}</span>
                </button>
              </form>

              {/* Mensagens recentes */}
              {messages.length > 0 && (
                <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-2.5">
                  <h3 className="text-sm font-bold text-[#F4F5F7]">
                    Mensagens Recentes ({messages.length})
                  </h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] space-y-1"
                      >
                        <div className="text-xs font-bold text-[#F4F5F7] truncate">
                          {msg.subject}
                        </div>
                        <div className="text-[11px] text-[#9CA3AF] truncate">
                          {msg.from}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </div>
      ) : (
        /* Resumo informativo honesto quando desconectado */
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2.5">
            <Dumbbell className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="text-sm font-bold text-[#F4F5F7]">
              Recursos disponíveis após conectar
            </h3>
          </div>
          <ul className="space-y-2 text-xs text-[#9CA3AF]">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
              <span>
                Exportação direta da sua rotina semanal para o Google Agenda com séries, repetições e cargas.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
              <span>
                Envio de relatórios técnicos de evolução e simetria diretamente pelo Gmail.
              </span>
            </li>
          </ul>
        </section>
      )}

      {/* Rodapé de Segurança */}
      <footer className="pt-2 text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#9CA3AF]">
          <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
          <span>Autenticação oficial Google OAuth 2.0 no navegador</span>
        </div>
      </footer>
    </div>
  );
}

function generateWorkoutReportText(
  profile: UserProfile,
  goldenAnalysis: GoldenAnalysis,
  dynamicWorkouts: WorkoutDay[]
): string {
  const workoutsBlock = dynamicWorkouts
    .filter((w) => profile.diasSelecionados.includes(w.id))
    .map((w) => {
      const exLines = w.exercises
        .map(
          (ex, idx) =>
            `   ${idx + 1}. ${cleanDisplayText(ex.name)} — ${
              ex.totalSets || ex.baseSets
            } séries x ${ex.reps} (Descanso: ${ex.rest}s)`
        )
        .join('\n');
      return `📌 ${cleanDisplayText(w.dayName).toUpperCase()} — ${cleanDisplayText(
        w.title
      )}\n${exLines}`;
    })
    .join('\n\n');

  return [
    `==================================================`,
    `🏆 AURUS GYM — DOSSIÊ BIOMECÂNICO & PRESCRIÇÃO`,
    `==================================================`,
    `Atleta: ${profile.nome}`,
    `Nível: ${profile.experiencia} | Frequência: ${profile.diasSelecionados.length} dias/semana`,
    `Objetivo: ${cleanDisplayText(profile.objetivoPrincipal)}`,
    ``,
    `📐 ANÁLISE DE PROPORÇÃO ÁUREA (1.618):`,
    `• Índice Adônis Atual: ${goldenAnalysis.indiceAdonisAtual} / 1.618`,
    `• Simetria Corporal Global: ${goldenAnalysis.overallScore}%`,
    ``,
    `🏋️ PLANILHA SEMANAL ATIVA:`,
    workoutsBlock
  ].join('\n');
}
