import React, { useState } from 'react';
import {
  Award,
  Calendar,
  Check,
  ChevronRight,
  Clock,
  Dumbbell,
  FileText,
  Flame,
  TrendingUp,
  X
} from 'lucide-react';
import { CompletedWorkout } from '../types';
import {
  ExerciseSessionRecord,
  formatDurationHoursMinutes,
  formatSessionFriendlyDate,
  getMuscleGroupDisplayLabel,
  VolumeChartSeries
} from '../utils/evolutionLogic';
import { cleanDisplayText } from '../utils/dashboardLogic';

interface VolumeEvolutionChartProps {
  series: VolumeChartSeries;
  onResetFilterToAll?: () => void;
  isFilteredPeriod?: boolean;
}

export const VolumeEvolutionChart: React.FC<VolumeEvolutionChartProps> = ({
  series,
  onResetFilterToAll,
  isFilteredPeriod = false
}) => {
  const { points, scaleLabel, averageLabel, averageVolumeKg } = series;
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const activeIdx =
    selectedIndex !== null && selectedIndex >= 0 && selectedIndex < points.length
      ? selectedIndex
      : points.length - 1;

  const activePoint = points[activeIdx] || null;

  if (points.length === 0) {
    return (
      <section
        aria-labelledby="chart-title"
        className="bg-[#13151A] border border-white/[0.06] p-4 rounded-2xl flex flex-col gap-3"
      >
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 id="chart-title" className="text-[17px] font-semibold text-[#F4F5F7] tracking-tight">
              Volume de treino
            </h2>
            <p className="text-xs text-[#9CA3AF]">Evolução do volume movimentado</p>
          </div>
          <span className="bg-[#1A1D24] px-2.5 py-1 rounded-lg text-[11px] font-mono text-[#D4AF37]">
            {scaleLabel}
          </span>
        </div>

        <div className="py-8 px-4 rounded-xl bg-[#08090C]/60 border border-white/[0.04] text-center space-y-2.5">
          <p className="text-sm font-medium text-[#F4F5F7]">
            Nenhum treino registrado neste período.
          </p>
          <p className="text-xs text-[#9CA3AF]">
            Altere o filtro de período para visualizar sessões anteriores.
          </p>
          {isFilteredPeriod && onResetFilterToAll && (
            <button
              type="button"
              onClick={onResetFilterToAll}
              className="mt-1 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#1A1D24] hover:bg-[#242832] text-xs font-semibold text-[#D4AF37] transition-colors"
            >
              Ver todo o histórico
            </button>
          )}
        </div>
      </section>
    );
  }

  // Calcular coordenadas SVG reais
  const maxVol = Math.max(...points.map((p) => p.volumeKg), 1);
  const minVol = Math.min(...points.map((p) => p.volumeKg), 0);
  const volSpan = Math.max(maxVol - minVol, maxVol * 0.25, 100);

  const svgWidth = 320;
  const svgHeight = 120;
  const padLeft = 22;
  const padRight = 22;
  const padTop = 22;
  const padBottom = 16;
  const usableWidth = svgWidth - padLeft - padRight;
  const usableHeight = svgHeight - padTop - padBottom;

  const coords = points.map((pt, idx) => {
    const x =
      points.length === 1
        ? svgWidth / 2
        : padLeft + (idx / (points.length - 1)) * usableWidth;
    const normY =
      points.length === 1
        ? 0.55
        : (pt.volumeKg - minVol * 0.85) / (maxVol - minVol * 0.85 || volSpan);
    const clampedNorm = Math.max(0.08, Math.min(0.95, normY));
    const y = padTop + usableHeight * (1 - clampedNorm);
    return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, pt, idx };
  });

  const linePoints = coords.map((c) => `${c.x},${c.y}`).join(' ');
  const areaPoints =
    coords.length > 1
      ? `${coords[0].x},${svgHeight - 10} ${linePoints} ${coords[coords.length - 1].x},${svgHeight - 10}`
      : '';

  return (
    <section
      aria-labelledby="chart-title"
      className="bg-[#13151A] border border-white/[0.06] p-4 rounded-2xl flex flex-col gap-3.5"
    >
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 id="chart-title" className="text-[17px] font-semibold text-[#F4F5F7] tracking-tight">
            Volume de treino
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            {points.length === 1
              ? '1 intervalo com registro no período'
              : 'Toque em um ponto para inspecionar o volume'}
          </p>
        </div>
        <span className="bg-[#1A1D24] px-2.5 py-1 rounded-lg text-[11px] font-mono font-medium text-[#D4AF37] shrink-0">
          {scaleLabel}
        </span>
      </div>

      {/* Tooltip Ativo */}
      {activePoint && (
        <div
          data-testid="volume-chart-tooltip"
          className="flex items-center justify-between gap-2 bg-[#1A1D24] border border-[#D4AF37]/30 px-3 py-2 rounded-xl"
        >
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37] shrink-0" />
            <span className="font-mono text-xs font-semibold text-[#F4F5F7] truncate">
              {activePoint.tooltipTitle}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="font-mono text-xs font-semibold text-[#D4AF37]">
              {activePoint.volumeKg.toLocaleString('pt-BR')} kg
            </span>
            <span className="text-[11px] text-[#9CA3AF]">
              · {activePoint.sessionsCount}{' '}
              {activePoint.sessionsCount === 1 ? 'sessão' : 'sessões'}
            </span>
          </div>
        </div>
      )}

      {/* Área do Gráfico SVG + Botões de Toque Acessíveis */}
      <div className="relative w-full pt-1">
        <div className="relative w-full h-32">
          <svg
            className="w-full h-full overflow-visible"
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            preserveAspectRatio="none"
            aria-label="Gráfico de evolução de volume"
          >
            <defs>
              <linearGradient id="aurusGoldVolumeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.32" />
                <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Linhas horizontais discretas */}
            <line
              x1="0"
              y1="24"
              x2={svgWidth}
              y2="24"
              stroke="#242832"
              strokeDasharray="3 3"
              strokeWidth="1"
            />
            <line
              x1="0"
              y1="67"
              x2={svgWidth}
              y2="67"
              stroke="#242832"
              strokeDasharray="3 3"
              strokeWidth="1"
            />
            <line
              x1="0"
              y1={svgHeight - 10}
              x2={svgWidth}
              y2={svgHeight - 10}
              stroke="#242832"
              strokeWidth="1"
            />

            {/* Preenchimento sob a curva (quando há 2+ pontos) */}
            {coords.length > 1 && (
              <polygon points={areaPoints} fill="url(#aurusGoldVolumeGrad)" />
            )}

            {/* Linha dourada conectando pontos reais */}
            {coords.length > 1 && (
              <polyline
                fill="none"
                points={linePoints}
                stroke="#D4AF37"
                strokeWidth="2.75"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}

            {/* Pontos do gráfico */}
            {coords.map(({ x, y, pt, idx }) => {
              const isSelected = idx === activeIdx;
              return (
                <g key={pt.key}>
                  {isSelected && (
                    <circle
                      cx={x}
                      cy={y}
                      r="8"
                      fill="#D4AF37"
                      fillOpacity="0.22"
                    />
                  )}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 5 : 3.5}
                    fill={isSelected ? '#D4AF37' : '#13151A'}
                    stroke={isSelected ? '#08090C' : '#D4AF37'}
                    strokeWidth={isSelected ? 2 : 2}
                  />
                </g>
              );
            })}
          </svg>
        </div>

        {/* Botões de seleção dos pontos no eixo X (confortáveis para toque mobile) */}
        <div
          className="flex items-center justify-between gap-1 pt-1.5 overflow-x-auto"
          role="group"
          aria-label="Selecionar ponto do gráfico de volume"
        >
          {points.map((pt, idx) => {
            const isSelected = idx === activeIdx;
            return (
              <button
                key={pt.key}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                aria-label={`Selecionar ${pt.tooltipTitle}: ${pt.volumeKg.toLocaleString('pt-BR')} kg`}
                aria-pressed={isSelected}
                className={`px-2 py-1.5 rounded-lg font-mono text-[11px] transition-colors min-h-[34px] shrink-0 ${
                  isSelected
                    ? 'bg-[#D4AF37]/15 text-[#D4AF37] font-semibold'
                    : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                {pt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Rodapé de Média Calculada */}
      <div className="pt-2 border-t border-white/[0.05] flex items-center justify-between bg-[#1A1D24]/70 px-3 py-2.5 rounded-xl">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <span className="text-xs text-[#9CA3AF]">{averageLabel}</span>
        </div>
        <span className="font-mono text-xs font-semibold text-[#F4F5F7]">
          {averageVolumeKg.toLocaleString('pt-BR')} kg
        </span>
      </div>
    </section>
  );
};

interface ExerciseProgressionChartProps {
  points: ExerciseSessionRecord[];
}

export const ExerciseProgressionChart: React.FC<ExerciseProgressionChartProps> = ({
  points
}) => {
  const [metricMode, setMetricMode] = useState<'maxWeight' | 'volumeKg'>('maxWeight');
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const hasVolumeData = points.some((p) => typeof p.volumeKg === 'number' && p.volumeKg > 0);
  const activeMode = metricMode === 'volumeKg' && !hasVolumeData ? 'maxWeight' : metricMode;

  const activeIdx =
    selectedIndex !== null && selectedIndex >= 0 && selectedIndex < points.length
      ? selectedIndex
      : points.length - 1;

  const activePoint = points[activeIdx] || null;

  if (points.length === 0) {
    return (
      <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
        <div>
          <h2 className="text-[17px] font-semibold text-[#F4F5F7]">
            Progressão de carga máxima
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            Nenhum registro deste exercício no período selecionado.
          </p>
        </div>
      </div>
    );
  }

  const getVal = (p: ExerciseSessionRecord) =>
    activeMode === 'volumeKg' ? p.volumeKg || p.maxWeight : p.maxWeight;

  const values = points.map(getVal);
  const maxVal = Math.max(...values, 1);
  const minVal = Math.min(...values, 0);
  const stepBase = Math.max(5, Math.ceil((maxVal - minVal) / 3) || 10);
  const topScale = Math.ceil(maxVal / 5) * 5 + 5;
  const bottomScale = Math.max(0, Math.floor(minVal / 5) * 5 - 5);
  const scaleSpan = Math.max(10, topScale - bottomScale);

  const yLabels = [
    topScale,
    Math.round(bottomScale + scaleSpan * 0.75),
    Math.round(bottomScale + scaleSpan * 0.5),
    Math.round(bottomScale + scaleSpan * 0.25),
    bottomScale
  ];

  const svgWidth = 320;
  const svgHeight = 120;
  const padLeft = 36;
  const padRight = 18;
  const padTop = 14;
  const padBottom = 14;
  const usableWidth = svgWidth - padLeft - padRight;
  const usableHeight = svgHeight - padTop - padBottom;

  const coords = points.map((pt, idx) => {
    const val = getVal(pt);
    const x =
      points.length === 1
        ? padLeft + usableWidth / 2
        : padLeft + (idx / (points.length - 1)) * usableWidth;
    const normY = (val - bottomScale) / scaleSpan;
    const clampedNorm = Math.max(0.06, Math.min(0.94, normY));
    const y = padTop + usableHeight * (1 - clampedNorm);
    return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, val, pt, idx };
  });

  const linePoints = coords.map((c) => `${c.x},${c.y}`).join(' ');
  const areaPoints =
    coords.length > 1
      ? `${coords[0].x},${svgHeight - padBottom} ${linePoints} ${coords[coords.length - 1].x},${svgHeight - padBottom}`
      : '';

  void stepBase;

  return (
    <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 flex flex-col gap-3.5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-[17px] font-semibold text-[#F4F5F7] tracking-tight">
            {activeMode === 'maxWeight'
              ? 'Progressão de carga máxima'
              : 'Progressão de volume no exercício'}
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            {activeMode === 'maxWeight'
              ? 'Baseado na maior carga válida por sessão'
              : 'Volume total movimentado neste exercício por sessão'}
          </p>
        </div>
      </div>

      {/* Seletor de Métrica */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
        <button
          type="button"
          onClick={() => setMetricMode('maxWeight')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
            activeMode === 'maxWeight'
              ? 'bg-[#D4AF37] text-[#08090C]'
              : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          Carga Máxima (kg)
        </button>
        {hasVolumeData && (
          <button
            type="button"
            onClick={() => setMetricMode('volumeKg')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
              activeMode === 'volumeKg'
                ? 'bg-[#D4AF37] text-[#08090C]'
                : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
            }`}
          >
            Volume no Exercício (kg)
          </button>
        )}
      </div>

      {/* Tooltip Flutuante do Ponto Selecionado */}
      {activePoint && (
        <div
          data-testid="exercise-chart-tooltip"
          className="flex items-center justify-between gap-2 bg-[#1A1D24] border border-[#D4AF37]/30 rounded-xl px-3 py-2"
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            <span className="font-mono text-xs text-[#F4F5F7] font-semibold">
              {activePoint.dateShortLabel}
            </span>
            {activePoint.isPersonalRecord && (
              <span className="text-[10px] font-mono font-semibold text-[#D4AF37]">
                · PR
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1.5 font-mono text-xs">
            <span className="text-[#D4AF37] font-semibold">
              {getVal(activePoint).toLocaleString('pt-BR')} kg
            </span>
            {activeMode === 'maxWeight' && activePoint.bestSetReps && (
              <span className="text-[#9CA3AF] text-[11px]">
                · {activePoint.bestSetReps} reps
              </span>
            )}
          </div>
        </div>
      )}

      {/* Área SVG do Gráfico */}
      <div className="relative w-full pt-1">
        <div className="relative w-full h-36">
          <svg
            className="w-full h-full overflow-visible"
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            preserveAspectRatio="none"
            aria-label="Gráfico de progressão do exercício"
          >
            <defs>
              <linearGradient id="exerciseGoldGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.32" />
                <stop offset="75%" stopColor="#D4AF37" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Eixo Y e linhas horizontais */}
            {yLabels.map((lbl, i) => {
              const yPos = padTop + (i / (yLabels.length - 1)) * usableHeight;
              return (
                <g key={`grid-${i}`}>
                  <line
                    x1={padLeft - 4}
                    y1={yPos}
                    x2={svgWidth - 4}
                    y2={yPos}
                    stroke="#242832"
                    strokeDasharray="3 3"
                    strokeWidth="0.75"
                  />
                  <text
                    x="2"
                    y={yPos + 3}
                    fill="#9CA3AF"
                    fontFamily="IBM Plex Mono, monospace"
                    fontSize="9"
                  >
                    {lbl}
                  </text>
                </g>
              );
            })}

            {coords.length > 1 && (
              <polygon points={areaPoints} fill="url(#exerciseGoldGrad)" />
            )}

            {coords.length > 1 && (
              <polyline
                fill="none"
                points={linePoints}
                stroke="#D4AF37"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}

            {coords.map(({ x, y, pt, idx }) => {
              const isSelected = idx === activeIdx;
              return (
                <g key={`${pt.workoutId}_${idx}`}>
                  {isSelected && (
                    <circle
                      cx={x}
                      cy={y}
                      r="7"
                      fill="#D4AF37"
                      fillOpacity="0.28"
                    />
                  )}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 4.5 : 3.5}
                    fill={isSelected ? '#D4AF37' : '#13151A'}
                    stroke={isSelected ? '#08090C' : '#D4AF37'}
                    strokeWidth="2"
                  />
                </g>
              );
            })}
          </svg>
        </div>

        {/* Rótulos do Eixo X (selecionáveis por toque) */}
        <div
          className="flex items-center justify-between gap-1 pl-7 pr-1 pt-2 overflow-x-auto"
          role="group"
          aria-label="Selecionar sessão no gráfico do exercício"
        >
          {points.map((pt, idx) => {
            const isSelected = idx === activeIdx;
            return (
              <button
                key={`${pt.workoutId}_${idx}`}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                aria-label={`Sessão ${pt.dateShortLabel}: ${getVal(pt)} kg`}
                aria-pressed={isSelected}
                className={`px-2 py-1 rounded-lg font-mono text-[11px] min-h-[32px] transition-colors shrink-0 ${
                  isSelected
                    ? 'bg-[#D4AF37]/15 text-[#D4AF37] font-semibold'
                    : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                {pt.dateShortLabel}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

interface SessionDetailModalProps {
  workout: CompletedWorkout | null;
  onClose: () => void;
  onSelectExercise?: (exerciseId: string) => void;
}

export const SessionDetailModal: React.FC<SessionDetailModalProps> = ({
  workout,
  onClose,
  onSelectExercise
}) => {
  if (!workout) return null;

  const duration = formatDurationHoursMinutes(workout.durationSec);
  const friendlyDate = formatSessionFriendlyDate(workout.timestamp);
  const hasRpe =
    typeof workout.sessionRpe === 'number' && !Number.isNaN(workout.sessionRpe);
  const hasNotes =
    typeof workout.sessionNotes === 'string' && workout.sessionNotes.trim().length > 0;
  const exercises = Array.isArray(workout.exercisesSummary)
    ? workout.exercisesSummary
    : [];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Detalhes do treino ${cleanDisplayText(workout.title)}`}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
    >
      <div className="w-full max-w-lg max-h-[90dvh] bg-[#08090C] border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Top Bar */}
        <div className="px-4 py-3.5 bg-[#13151A] border-b border-white/[0.06] flex items-center justify-between">
          <div className="flex flex-col min-w-0">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#D4AF37]">
              Detalhes da Sessão
            </span>
            <h2 className="text-base font-bold text-[#F4F5F7] truncate">
              {cleanDisplayText(workout.title)}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar detalhes da sessão"
            className="w-10 h-10 rounded-xl bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Meta Info */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#9CA3AF]">
            <span className="inline-flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
              {friendlyDate}
            </span>
            <span>{workout.dayName}</span>
          </div>

          {/* 3 Main Stats */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-[#13151A] border border-white/[0.05] rounded-2xl p-3 text-center">
              <div className="flex items-center justify-center text-[#9CA3AF] mb-1">
                <Clock className="w-4 h-4" />
              </div>
              <div className="font-mono text-sm font-bold text-[#F4F5F7]">
                {duration.label}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Duração
              </div>
            </div>

            <div className="bg-[#13151A] border border-white/[0.05] rounded-2xl p-3 text-center">
              <div className="flex items-center justify-center text-[#10B981] mb-1">
                <Check className="w-4 h-4" />
              </div>
              <div className="font-mono text-sm font-bold text-[#F4F5F7]">
                {workout.completedSets}/{workout.totalSets}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Séries
              </div>
            </div>

            <div className="bg-[#13151A] border border-white/[0.05] rounded-2xl p-3 text-center">
              <div className="flex items-center justify-center text-[#D4AF37] mb-1">
                <Dumbbell className="w-4 h-4" />
              </div>
              <div className="font-mono text-sm font-bold text-[#F4F5F7]">
                {(workout.tonnage || 0).toLocaleString('pt-BR')} kg
              </div>
              <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Volume
              </div>
            </div>
          </div>

          {/* RPE e Observações (apenas quando efetivamente registrados!) */}
          {(hasRpe || hasNotes || workout.cardioCompleted) && (
            <div className="bg-[#13151A] border border-white/[0.05] rounded-2xl p-3.5 space-y-2.5">
              <div className="flex flex-wrap items-center gap-3 text-xs">
                {hasRpe && (
                  <div className="flex items-center gap-1.5 text-[#F4F5F7]">
                    <Flame className="w-4 h-4 text-[#D4AF37]" />
                    <span className="text-[#9CA3AF]">RPE informado:</span>
                    <span className="font-mono font-bold text-[#D4AF37]">
                      {workout.sessionRpe}
                    </span>
                  </div>
                )}
                {workout.cardioCompleted && (
                  <div className="flex items-center gap-1.5 text-[#10B981]">
                    <Check className="w-4 h-4" />
                    <span>Cardio concluído</span>
                  </div>
                )}
              </div>

              {hasNotes && (
                <div className="pt-1 border-t border-white/[0.05] flex items-start gap-2">
                  <FileText className="w-4 h-4 text-[#9CA3AF] shrink-0 mt-0.5" />
                  <p className="text-xs text-[#F4F5F7] leading-relaxed">
                    {workout.sessionNotes}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Lista de Exercícios Realizados */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#9CA3AF]">
              Exercícios registrados ({exercises.length})
            </h3>

            {exercises.length === 0 ? (
              <div className="bg-[#13151A] rounded-2xl p-4 text-xs text-[#9CA3AF] text-center">
                Nenhum detalhe de exercício salvo para esta sessão.
              </div>
            ) : (
              <div className="space-y-2.5">
                {exercises.map((ex, idx) => {
                  const hasSetsDetail =
                    Array.isArray(ex.setsDetail) && ex.setsDetail.length > 0;
                  return (
                    <div
                      key={`${ex.exerciseId}_${idx}`}
                      className="bg-[#13151A] border border-white/[0.05] rounded-2xl p-3.5 space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm text-[#F4F5F7] truncate">
                              {ex.name}
                            </span>
                            {ex.isPersonalRecord && (
                              <span className="inline-flex items-center gap-0.5 text-[10px] font-mono font-bold text-[#D4AF37]">
                                <Award className="w-3 h-3" /> PR
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-[#9CA3AF] mt-0.5">
                            {getMuscleGroupDisplayLabel(ex.targetGroup)} ·{' '}
                            <span className="font-mono">
                              {ex.setsCompleted}/{ex.totalSets} séries
                            </span>
                            {typeof ex.volumeKg === 'number' && ex.volumeKg > 0 && (
                              <span>
                                {' '}
                                · Volume:{' '}
                                <strong className="font-mono text-[#F4F5F7]">
                                  {ex.volumeKg.toLocaleString('pt-BR')} kg
                                </strong>
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className="font-mono text-sm font-bold text-[#D4AF37]">
                            {ex.maxWeight > 0 ? `${ex.maxWeight} kg` : '—'}
                          </div>
                          {typeof ex.bestSetReps === 'number' && ex.bestSetReps > 0 && (
                            <div className="font-mono text-[11px] text-[#9CA3AF]">
                              × {ex.bestSetReps} reps
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Séries individuais se disponíveis (sem reconstruir se ausentes) */}
                      {hasSetsDetail && ex.setsDetail && (
                        <div className="bg-[#1A1D24] rounded-xl p-2.5 space-y-1">
                          <div className="grid grid-cols-3 text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF] pb-1 border-b border-white/[0.05]">
                            <span>Série</span>
                            <span className="text-center">Carga</span>
                            <span className="text-right">Repetições</span>
                          </div>
                          {ex.setsDetail.map((s) => (
                            <div
                              key={s.setNumber}
                              className="grid grid-cols-3 text-xs font-mono py-0.5 text-[#F4F5F7]"
                            >
                              <span className="text-[#9CA3AF]">#{s.setNumber}</span>
                              <span className="text-center font-semibold">
                                {s.weight} kg
                              </span>
                              <span className="text-right">{s.reps} reps</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {onSelectExercise && ex.exerciseId && (
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onSelectExercise(ex.exerciseId);
                          }}
                          className="w-full pt-1 flex items-center justify-between text-xs font-semibold text-[#D4AF37] hover:underline"
                        >
                          <span>Ver evolução deste exercício</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Bottom Action */}
        <div className="p-4 bg-[#13151A] border-t border-white/[0.06]">
          <button
            type="button"
            onClick={onClose}
            className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#08090C] font-semibold text-sm hover:brightness-105 transition"
          >
            Fechar detalhes
          </button>
        </div>
      </div>
    </div>
  );
};
