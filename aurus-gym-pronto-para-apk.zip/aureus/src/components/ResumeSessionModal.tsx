import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Dumbbell,
  Info,
  Play,
  Timer,
  Trash2
} from 'lucide-react';
import { ActiveWorkoutSession, WorkoutDay } from '../types';
import { calculateArenaSessionStats, formatArenaTimer } from '../utils/arenaLogic';
import { cleanDisplayText } from '../utils/dashboardLogic';

interface ResumeSessionBannerProps {
  session: ActiveWorkoutSession;
  dayWorkout: WorkoutDay;
  elapsedSec: number;
  onContinueSession: () => void;
  onRequestDiscard: () => void;
}

export const ResumeSessionBanner: React.FC<ResumeSessionBannerProps> = ({
  session,
  dayWorkout,
  elapsedSec,
  onContinueSession,
  onRequestDiscard
}) => {
  const exercises = dayWorkout.exercises || [];
  const { totalSets, completedSets, tonnage, progressPct } = calculateArenaSessionStats(
    exercises,
    session.sessionSets
  );

  const startedTimeFormatted = new Date(session.startedAtMs).toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });

  // Identify completed vs pending exercises
  const exerciseProgressList = exercises.map((ex, idx) => {
    const sets = session.sessionSets[ex.id] || [];
    const doneCount = sets.filter((s) => s.completed).length;
    const totalCount = sets.length || ex.baseSets || 3;
    const exVolume = sets
      .filter((s) => s.completed)
      .reduce((acc, s) => acc + (Number(s.weight) || 0) * (Number(s.reps) || 0), 0);
    return {
      exercise: ex,
      index: idx,
      doneCount,
      totalCount,
      exVolume: Math.round(exVolume * 10) / 10,
      isFullyDone: totalCount > 0 && doneCount === totalCount
    };
  });

  const fullyDoneExercises = exerciseProgressList.filter((item) => item.isFullyDone);
  const nextActiveItem =
    exerciseProgressList.find((item) => !item.isFullyDone) || exerciseProgressList[0];

  return (
    <section
      aria-label="Retomada de treino em andamento"
      className="bg-[#13151A] border border-[#D4AF37]/40 rounded-2xl p-4 sm:p-5 shadow-[0_12px_36px_rgba(0,0,0,0.55)] space-y-4 relative overflow-hidden"
    >
      <div className="absolute -right-8 -top-8 w-28 h-28 bg-[#D4AF37]/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top Status & Elapsed Pill */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#D4AF37]" />
          </span>
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#D4AF37]">
            Treino em andamento
          </span>
        </div>

        <div className="flex items-center gap-1.5 bg-[#1A1D24] border border-white/[0.06] px-2.5 py-1 rounded-lg text-[#9CA3AF] font-mono text-[12px] font-bold">
          <Timer className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>{formatArenaTimer(elapsedSec, false)}</span>
        </div>
      </div>

      {/* Title & Description */}
      <div>
        <h2 className="text-[19px] sm:text-[21px] font-extrabold text-[#F4F5F7] tracking-tight">
          {cleanDisplayText(dayWorkout.title)}
        </h2>
        <p className="text-[12px] text-[#9CA3AF] mt-0.5">
          Você tem um treino que ainda não foi finalizado · Iniciado às{' '}
          <span className="font-mono text-[#F4F5F7]">{startedTimeFormatted}</span>
        </p>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[12px]">
          <span className="text-[#9CA3AF] font-medium">
            <strong className="font-mono text-[#F4F5F7]">{completedSets}</strong> de{' '}
            <strong className="font-mono text-[#F4F5F7]">{totalSets}</strong> séries concluídas
          </span>
          <span className="font-mono font-bold text-[#D4AF37]">{progressPct}%</span>
        </div>
        <div className="w-full bg-[#08090C] h-2 rounded-full overflow-hidden p-[1px]">
          <div
            className="bg-[#D4AF37] h-full rounded-full transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-[#1A1D24] p-3 rounded-xl border border-white/[0.05]">
          <span className="block text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">
            Volume Acumulado
          </span>
          <span className="font-mono text-[18px] font-bold text-[#F4F5F7] mt-0.5 block">
            {tonnage.toLocaleString('pt-BR')}{' '}
            <span className="text-[11px] font-normal text-[#9CA3AF]">kg</span>
          </span>
        </div>

        <div className="bg-[#1A1D24] p-3 rounded-xl border border-white/[0.05]">
          <span className="block text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">
            Exercícios Concluídos
          </span>
          <span className="font-mono text-[18px] font-bold text-[#10B981] mt-0.5 block">
            {fullyDoneExercises.length}{' '}
            <span className="text-[11px] font-normal text-[#9CA3AF]">
              de {exercises.length}
            </span>
          </span>
        </div>
      </div>

      {/* Exercise Trail Preview */}
      {nextActiveItem && (
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between px-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
              Progresso dos Exercícios
            </span>
            <span className="text-[11px] font-mono font-semibold text-[#D4AF37]">
              {fullyDoneExercises.length} concluídos •{' '}
              {Math.max(0, exercises.length - fullyDoneExercises.length)} na fila
            </span>
          </div>

          {fullyDoneExercises.slice(0, 2).map((item) => (
            <div
              key={item.exercise.id}
              className="flex items-center justify-between p-3 bg-[#1A1D24]/60 rounded-xl border border-white/[0.04]"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-[#10B981]/15 flex items-center justify-center text-[#10B981] shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[13px] font-bold text-[#F4F5F7] truncate">
                    {item.exercise.name}
                  </span>
                  <span className="block font-mono text-[11px] text-[#9CA3AF]">
                    {item.doneCount} de {item.totalCount} séries finalizadas •{' '}
                    {item.exVolume.toLocaleString('pt-BR')} kg
                  </span>
                </div>
              </div>
            </div>
          ))}

          <div className="flex items-center justify-between p-3 bg-[#1A1D24] rounded-xl border border-[#D4AF37]/30 relative overflow-hidden">
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#D4AF37]" />
            <div className="flex items-center gap-2.5 min-w-0 pl-1">
              <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0">
                <Dumbbell className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[13px] font-bold text-[#F4F5F7] truncate">
                    {nextActiveItem.exercise.name}
                  </span>
                  <span className="bg-[#D4AF37]/20 text-[#D4AF37] text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded shrink-0">
                    Próximo
                  </span>
                </div>
                <span className="block font-mono text-[11px] text-[#D4AF37]">
                  Série { Math.min(nextActiveItem.doneCount + 1, nextActiveItem.totalCount) } de{' '}
                  {nextActiveItem.totalCount} pendente
                </span>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-[#D4AF37] shrink-0" />
          </div>
        </div>
      )}

      {/* Primary Action: Continuar treino + Secondary: Descartar treino */}
      <div className="space-y-2 pt-1">
        <button
          type="button"
          onClick={onContinueSession}
          className="w-full h-[52px] bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] rounded-xl font-extrabold text-[15px] flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition-all"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>Continuar treino</span>
        </button>

        <button
          type="button"
          onClick={onRequestDiscard}
          className="w-full h-11 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] hover:bg-[#EF4444]/25 font-bold text-[13px] flex items-center justify-center gap-2 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span>Descartar treino</span>
        </button>
      </div>
    </section>
  );
};

interface DiscardConfirmationModalProps {
  isOpen: boolean;
  completedSets: number;
  tonnage: number;
  elapsedSec: number;
  workoutTitle: string;
  onCancelKeepTraining: () => void;
  onConfirmDiscard: () => void;
}

export const DiscardConfirmationModal: React.FC<DiscardConfirmationModalProps> = ({
  isOpen,
  completedSets,
  tonnage,
  elapsedSec,
  workoutTitle,
  onCancelKeepTraining,
  onConfirmDiscard
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Descartar este treino?"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#08090C]/85 backdrop-blur-sm p-0 sm:p-4"
    >
      <div className="w-full max-w-lg bg-[#1A1D24] border-t sm:border border-white/10 rounded-t-2xl sm:rounded-2xl p-5 flex flex-col gap-4 shadow-2xl">
        <div className="w-10 h-1 bg-white/15 rounded-full mx-auto -mt-1 mb-1 sm:hidden" />

        {/* Alert Header */}
        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-[#EF4444]/20 border border-[#EF4444]/30 flex items-center justify-center text-[#EF4444] shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] font-extrabold uppercase tracking-widest text-[#EF4444]">
              Confirmação de Segurança
            </span>
            <h3 className="text-[20px] font-extrabold text-[#F4F5F7] tracking-tight">
              Descartar este treino?
            </h3>
            <p className="text-[12px] text-[#9CA3AF] mt-0.5">
              {cleanDisplayText(workoutTitle)}
            </p>
          </div>
        </div>

        {/* Impact Summary Box */}
        <div className="bg-[#13151A] p-4 rounded-xl border border-white/[0.06] space-y-2">
          {completedSets > 0 ? (
            <p className="text-[14px] text-[#9CA3AF] leading-relaxed">
              Você já registrou{' '}
              <strong className="font-mono font-bold text-[#F4F5F7]">
                {completedSets} {completedSets === 1 ? 'série' : 'séries'}
              </strong>{' '}
              e{' '}
              <strong className="font-mono font-bold text-[#D4AF37]">
                {tonnage.toLocaleString('pt-BR')} kg
              </strong>{' '}
              de volume nesta sessão.
            </p>
          ) : (
            <p className="text-[14px] text-[#9CA3AF] leading-relaxed">
              Você tem uma sessão ativa com tempo decorrido de{' '}
              <strong className="font-mono font-bold text-[#F4F5F7]">
                {formatArenaTimer(elapsedSec, false)}
              </strong>
              .
            </p>
          )}
          <div className="flex items-start gap-2 text-[#EF4444] text-[12px]">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              Esses dados não serão salvos no histórico nem contarão para sua meta semanal.
            </span>
          </div>
        </div>

        {/* Actions: Primary Preserve (Gold) & Secondary Destructive (Red) */}
        <div className="flex flex-col gap-2.5 pt-1">
          <button
            type="button"
            onClick={onCancelKeepTraining}
            className="w-full h-[52px] bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] rounded-xl font-extrabold text-[15px] flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition-all"
          >
            <Dumbbell className="w-5 h-5" />
            <span>Continuar treinando</span>
          </button>

          <button
            type="button"
            onClick={onConfirmDiscard}
            className="w-full h-12 bg-[#EF4444]/15 hover:bg-[#EF4444]/25 border border-[#EF4444]/30 text-[#EF4444] rounded-xl font-bold text-[13px] flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Sim, descartar treino</span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface AiReformulateProtectionModalProps {
  isOpen: boolean;
  scope: 'week' | 'day';
  completedSets: number;
  tonnage: number;
  workoutTitle: string;
  onPreserveAndApply: () => void;
  onReplaceAndDiscard: () => void;
  onCancel: () => void;
}

export const AiReformulateProtectionModal: React.FC<AiReformulateProtectionModalProps> = ({
  isOpen,
  scope,
  completedSets,
  tonnage,
  workoutTitle,
  onPreserveAndApply,
  onReplaceAndDiscard,
  onCancel
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Proteger sessão em andamento"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#08090C]/85 backdrop-blur-sm p-0 sm:p-4"
    >
      <div className="w-full max-w-lg bg-[#1A1D24] border-t sm:border border-white/10 rounded-t-2xl sm:rounded-2xl p-5 flex flex-col gap-4 shadow-2xl">
        <div className="w-10 h-1 bg-white/15 rounded-full mx-auto -mt-1 mb-1 sm:hidden" />

        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] font-extrabold uppercase tracking-widest text-[#D4AF37]">
              Proteção de Sessão Ativa
            </span>
            <h3 className="text-[19px] font-extrabold text-[#F4F5F7] tracking-tight">
              Reformular rotina com treino em andamento?
            </h3>
            <p className="text-[12px] text-[#9CA3AF] mt-0.5">
              {cleanDisplayText(workoutTitle)}
            </p>
          </div>
        </div>

        <div className="bg-[#13151A] p-4 rounded-xl border border-white/[0.06] space-y-2">
          <p className="text-[13px] text-[#9CA3AF] leading-relaxed">
            Você possui uma sessão ativa com{' '}
            <strong className="font-mono font-bold text-[#F4F5F7]">
              {completedSets} {completedSets === 1 ? 'série concluída' : 'séries concluídas'}
            </strong>{' '}
            e{' '}
            <strong className="font-mono font-bold text-[#D4AF37]">
              {tonnage.toLocaleString('pt-BR')} kg
            </strong>{' '}
            de volume registrado.
          </p>
          <div className="flex items-start gap-2 text-[#10B981] text-[12px]">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              Recomendado: preserve os exercícios já iniciados hoje e aplique a reformulação{' '}
              {scope === 'week' ? 'nos demais dias da semana' : 'apenas nos exercícios pendentes'}.
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-2.5 pt-1">
          <button
            type="button"
            onClick={onPreserveAndApply}
            className="w-full h-[52px] bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] rounded-xl font-extrabold text-[14px] flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition-all"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>Preservar sessão ativa e atualizar rotina</span>
          </button>

          <button
            type="button"
            onClick={onReplaceAndDiscard}
            className="w-full h-11 bg-[#EF4444]/15 hover:bg-[#EF4444]/25 border border-[#EF4444]/30 text-[#EF4444] rounded-xl font-bold text-[13px] flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Descartar sessão ativa e substituir tudo</span>
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="w-full h-10 bg-transparent hover:bg-white/[0.05] text-[#9CA3AF] hover:text-[#F4F5F7] rounded-xl font-semibold text-[13px] transition-colors"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};

interface BackupImportConfirmModalProps {
  isOpen: boolean;
  completedSets: number;
  tonnage: number;
  hasActiveSessionInBackup: boolean;
  onImportPreservingCurrentSession: () => void;
  onImportReplacingCurrentSession: () => void;
  onCancel: () => void;
}

export const BackupImportConfirmModal: React.FC<BackupImportConfirmModalProps> = ({
  isOpen,
  completedSets,
  tonnage,
  hasActiveSessionInBackup,
  onImportPreservingCurrentSession,
  onImportReplacingCurrentSession,
  onCancel
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Confirmar importação de backup"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#08090C]/85 backdrop-blur-sm p-0 sm:p-4"
    >
      <div className="w-full max-w-lg bg-[#1A1D24] border-t sm:border border-white/10 rounded-t-2xl sm:rounded-2xl p-5 flex flex-col gap-4 shadow-2xl">
        <div className="w-10 h-1 bg-white/15 rounded-full mx-auto -mt-1 mb-1 sm:hidden" />

        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] font-extrabold uppercase tracking-widest text-[#D4AF37]">
              Sessão em Andamento Detectada
            </span>
            <h3 className="text-[19px] font-extrabold text-[#F4F5F7] tracking-tight">
              Como deseja importar este backup?
            </h3>
            <p className="text-[12px] text-[#9CA3AF] mt-0.5">
              Proteção contra perda acidental de progresso
            </p>
          </div>
        </div>

        <div className="bg-[#13151A] p-4 rounded-xl border border-white/[0.06] space-y-2">
          <p className="text-[13px] text-[#9CA3AF] leading-relaxed">
            Há um treino ativo no dispositivo com{' '}
            <strong className="font-mono font-bold text-[#F4F5F7]">
              {completedSets} {completedSets === 1 ? 'série' : 'séries'}
            </strong>{' '}
            e{' '}
            <strong className="font-mono font-bold text-[#D4AF37]">
              {tonnage.toLocaleString('pt-BR')} kg
            </strong>{' '}
            acumulados.
          </p>
          <p className="text-[12px] text-[#9CA3AF]">
            {hasActiveSessionInBackup
              ? 'O arquivo de backup também contém um rascunho de sessão ativa salvo.'
              : 'O arquivo de backup contém apenas histórico e configurações (sem rascunho de sessão ativa).'}
          </p>
        </div>

        <div className="flex flex-col gap-2.5 pt-1">
          <button
            type="button"
            onClick={onImportPreservingCurrentSession}
            className="w-full h-[52px] bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] rounded-xl font-extrabold text-[14px] flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition-all"
          >
            <Dumbbell className="w-5 h-5" />
            <span>Importar mantendo sessão atual ativa</span>
          </button>

          <button
            type="button"
            onClick={onImportReplacingCurrentSession}
            className="w-full h-11 bg-[#EF4444]/15 hover:bg-[#EF4444]/25 border border-[#EF4444]/30 text-[#EF4444] rounded-xl font-bold text-[13px] flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Substituir sessão atual pelo backup</span>
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="w-full h-10 bg-transparent hover:bg-white/[0.05] text-[#9CA3AF] hover:text-[#F4F5F7] rounded-xl font-semibold text-[13px] transition-colors"
          >
            Cancelar importação
          </button>
        </div>
      </div>
    </div>
  );
};
