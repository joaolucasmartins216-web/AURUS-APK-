import React, { useRef, useState } from 'react';
import {
  ArrowRight,
  Award,
  Check,
  CheckCircle2,
  ChevronRight,
  Flame,
  Hourglass,
  Maximize2,
  Minus,
  MoreVertical,
  Pause,
  Play,
  Plus,
  Repeat,
  Sparkles,
  Timer,
  Trash2,
  Wand2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  ActiveWorkoutSession,
  CompletedWorkout,
  ExerciseItem,
  RestTimerState,
  SetLog,
  WorkoutDay
} from '../types';
import { ALL_WEEK_DAYS, AI_REFORMULATION_PRESETS } from '../utils/constants';
import { cleanDisplayText } from '../utils/dashboardLogic';
import {
  calculateArenaSessionStats,
  formatArenaTimer,
  getExercisePreviousReference,
  resolveFocusedSetIndex
} from '../utils/arenaLogic';
import { RestTimerModal } from './RestTimerModal';
import { DiscardConfirmationModal, ResumeSessionBanner } from './ResumeSessionModal';

interface ArenaViewProps {
  currentDayWorkout: WorkoutDay;
  dynamicWorkouts: WorkoutDay[];
  selectedDayId: string;
  onSelectDayId: (id: string) => void;
  activeExerciseIndex: number;
  setActiveExerciseIndex: (idx: number) => void;
  arenaPhase: 'mobilidade' | 'hipertrofia' | 'cardio';
  setArenaPhase: (phase: 'mobilidade' | 'hipertrofia' | 'cardio') => void;
  mobilityChecked: Record<string, boolean>;
  onToggleMobility: (id: string) => void;
  cardioCompleted: boolean;
  onToggleCardio: () => void;
  sessionSets: Record<string, SetLog[]>;
  onUpdateSetField: (exerciseId: string, setIndex: number, field: keyof SetLog, value: any) => void;
  onStepSetWeight: (exerciseId: string, setIndex: number, deltaKg: number) => void;
  onStepSetReps: (exerciseId: string, setIndex: number, deltaReps: number) => void;
  onAddExtraSet: (exerciseId: string) => void;
  onToggleSetCompleted: (exercise: ExerciseItem, setIndex: number) => void;
  onFinishWorkout: () => void;
  isSavingWorkout: boolean;
  activeSelectedDays: string[];
  onToggleTrainingDay: (dayId: string) => void;
  onReformulate: (options: { scope: 'week' | 'day'; customPrompt?: string }) => void;
  isGeneratingAi: boolean;
  swappingExerciseId: string | null;
  onSwapSingleExercise: (exercise: ExerciseItem, reason: string) => void;
  onAddCustomExercise: (name: string) => void;
  // Rest timer
  timerSeconds: number;
  timerTarget: number;
  timerRunning: boolean;
  restTimerState: RestTimerState;
  onStartRestTimer: (sec: number) => void;
  onAdjustRestTimer: (delta: number) => void;
  onTogglePauseRestTimer: () => void;
  onResetRestTimer: () => void;
  onOpenRestModal: () => void;
  onMinimizeRestModal: () => void;
  // Session & Stopwatch
  sessionStatus: 'not_started' | 'running' | 'paused';
  activeSession: ActiveWorkoutSession | null;
  showResumeBanner: boolean;
  onStartSession: () => void;
  onContinueResumedSession: () => void;
  showDiscardModal: boolean;
  onRequestDiscardSession: () => void;
  onCancelDiscardSession: () => void;
  onConfirmDiscardSession: () => void;
  workoutElapsedSec: number;
  workoutStopwatchRunning: boolean;
  onToggleStopwatch: () => void;
  // Historical data for real ANTERIOR / PR display
  lastExerciseWeights?: Record<string, number>;
  workoutHistory?: CompletedWorkout[];
}

export const ArenaView: React.FC<ArenaViewProps> = ({
  currentDayWorkout,
  dynamicWorkouts,
  selectedDayId,
  onSelectDayId,
  activeExerciseIndex,
  setActiveExerciseIndex,
  arenaPhase,
  setArenaPhase,
  mobilityChecked,
  onToggleMobility,
  cardioCompleted,
  onToggleCardio,
  sessionSets,
  onUpdateSetField,
  onStepSetWeight,
  onStepSetReps,
  onAddExtraSet,
  onToggleSetCompleted,
  onFinishWorkout,
  isSavingWorkout,
  activeSelectedDays,
  onToggleTrainingDay,
  onReformulate,
  isGeneratingAi,
  swappingExerciseId,
  onSwapSingleExercise,
  onAddCustomExercise,
  timerSeconds,
  timerTarget,
  timerRunning,
  restTimerState,
  onStartRestTimer,
  onAdjustRestTimer,
  onTogglePauseRestTimer,
  onResetRestTimer,
  onOpenRestModal,
  onMinimizeRestModal,
  sessionStatus,
  activeSession,
  showResumeBanner,
  onStartSession,
  onContinueResumedSession,
  showDiscardModal,
  onRequestDiscardSession,
  onCancelDiscardSession,
  onConfirmDiscardSession,
  workoutElapsedSec,
  workoutStopwatchRunning,
  onToggleStopwatch,
  lastExerciseWeights = {},
  workoutHistory = []
}) => {
  const [showAiDrawer, setShowAiDrawer] = useState(false);
  const [customAiPrompt, setCustomAiPrompt] = useState('');
  const [showAddExerciseModal, setShowAddExerciseModal] = useState(false);
  const [customExName, setCustomExName] = useState('');
  const [showSwapDrawer, setShowSwapDrawer] = useState(false);
  const [manualFocusedSetIdx, setManualFocusedSetIdx] = useState<number | null>(null);

  const weightInputRef = useRef<HTMLInputElement | null>(null);
  const repsInputRef = useRef<HTMLInputElement | null>(null);

  const exercises = currentDayWorkout.exercises || [];
  const safeExerciseIdx =
    activeExerciseIndex >= 0 && activeExerciseIndex < exercises.length ? activeExerciseIndex : 0;
  const activeExercise = exercises[safeExerciseIdx] || exercises[0];
  const activeSets = activeExercise ? sessionSets[activeExercise.id] || [] : [];

  const focusedSetIndex = resolveFocusedSetIndex(activeSets, manualFocusedSetIdx);
  const focusedSet = activeSets[focusedSetIndex] || activeSets[0];

  // Calculate live session totals
  const { totalSets, completedSets, tonnage, progressPct } = calculateArenaSessionStats(
    exercises,
    sessionSets
  );

  // Mobility progress
  const mobilityList = currentDayWorkout.mobility || [];
  const mobilityDoneCount = mobilityList.filter((m) => mobilityChecked[m.id]).length;

  // Session letter (A, B, C...) based on index in dynamicWorkouts
  const dayOrderIdx = Math.max(
    0,
    dynamicWorkouts.findIndex((d) => d.id === currentDayWorkout.id)
  );
  const sessionLetter = String.fromCharCode(65 + (dayOrderIdx % 6));
  const rawCleanTitle = cleanDisplayText(currentDayWorkout.title);
  const displayWorkoutTitle = /^Treino\s+[A-Z]/i.test(rawCleanTitle)
    ? rawCleanTitle
    : `Treino ${sessionLetter} · ${rawCleanTitle}`;

  // Rest timer SVG ring math
  const ringRadius = 18;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const restRatio =
    timerTarget > 0 ? Math.min(1, Math.max(0, timerSeconds / timerTarget)) : 0;
  const ringDashoffset = ringCircumference * (1 - restRatio);

  // Historical load reference for active exercise
  const prevRef = activeExercise
    ? getExercisePreviousReference(activeExercise, lastExerciseWeights, workoutHistory)
    : null;

  // Next exercise in queue
  const nextExerciseIdx =
    safeExerciseIdx + 1 < exercises.length ? safeExerciseIdx + 1 : null;
  const nextExercise = nextExerciseIdx !== null ? exercises[nextExerciseIdx] : null;

  const handleSelectExercise = (idx: number) => {
    setActiveExerciseIndex(idx);
    setManualFocusedSetIdx(null);
    setShowSwapDrawer(false);
  };

  const handleCompleteOrRevertFocusedSet = () => {
    if (!activeExercise || !focusedSet) return;
    const wasCompleted = focusedSet.completed;
    onToggleSetCompleted(activeExercise, focusedSetIndex);
    if (!wasCompleted) {
      setManualFocusedSetIdx(null);
    }
  };

  const handleFinishWithCelebration = () => {
    if (completedSets > 0) {
      try {
        confetti({
          particleCount: 70,
          spread: 65,
          origin: { y: 0.65 },
          colors: ['#D4AF37', '#10B981', '#F59E0B']
        });
      } catch {
        // Ignore confetti errors in headless browsers
      }
    }
    onFinishWorkout();
  };

  const isSessionActive = sessionStatus === 'running' || sessionStatus === 'paused';

  return (
    <div>
      {/* MODAL IMERSIVO DE DESCANSO ATIVO (STITCH 4._descanso_arena_aurus_gym) */}
      <RestTimerModal
        restTimer={restTimerState}
        remainingSec={timerSeconds}
        activeExercise={activeExercise}
        activeExerciseIndex={safeExerciseIdx}
        totalExercises={exercises.length}
        activeSets={activeSets}
        onMinimize={onMinimizeRestModal}
        onAdjustRest={onAdjustRestTimer}
        onTogglePauseRest={onTogglePauseRestTimer}
        onSkipRest={onResetRestTimer}
      />

      {/* MODAL DE CONFIRMAÇÃO DE DESCARTE (STITCH 5._retomar_treino_arena_aurus_gym) */}
      <DiscardConfirmationModal
        isOpen={showDiscardModal}
        completedSets={completedSets}
        tonnage={tonnage}
        elapsedSec={workoutElapsedSec}
        workoutTitle={currentDayWorkout.title}
        onCancelKeepTraining={onCancelDiscardSession}
        onConfirmDiscard={onConfirmDiscardSession}
      />

      <div className="w-full max-w-md mx-auto lg:max-w-3xl space-y-5 pb-8 text-[#F4F5F7]">

      {/* BANNER DE RETOMADA DE TREINO INTERROMPIDO (STITCH 5._retomar_treino_arena_aurus_gym) */}
      {showResumeBanner && activeSession && (
        <ResumeSessionBanner
          session={activeSession}
          dayWorkout={currentDayWorkout}
          elapsedSec={workoutElapsedSec}
          onContinueSession={onContinueResumedSession}
          onRequestDiscard={onRequestDiscardSession}
        />
      )}

      {/* 1. CARD PRINCIPAL DA SESSÃO */}
      <section
        aria-label="Resumo da sessão em andamento"
        className="bg-[#13151A] rounded-2xl p-4 sm:p-5 border border-white/[0.06] shadow-[0_8px_28px_rgba(0,0,0,0.45)]"
      >
        {/* Status Indicator + Session Code + AI Trigger */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${
                sessionStatus === 'running'
                  ? 'bg-[#10B981] animate-pulse'
                  : sessionStatus === 'paused'
                  ? 'bg-amber-400'
                  : 'bg-[#D4AF37]'
              }`}
            />
            <span
              className={`text-[11px] font-bold uppercase tracking-wider truncate ${
                sessionStatus === 'running'
                  ? 'text-[#10B981]'
                  : sessionStatus === 'paused'
                  ? 'text-amber-400'
                  : 'text-[#D4AF37]'
              }`}
            >
              {sessionStatus === 'running'
                ? 'Treino em andamento'
                : sessionStatus === 'paused'
                ? 'Treino pausado'
                : 'Pronto para iniciar'}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[12px] font-medium text-[#9CA3AF]">
              Sessão {sessionLetter}
            </span>
            <button
              type="button"
              onClick={() => setShowAiDrawer((prev) => !prev)}
              className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold flex items-center gap-1.5 transition-colors ${
                showAiDrawer
                  ? 'bg-[#D4AF37] text-[#08090C] border-[#D4AF37]'
                  : 'bg-[#1A1D24] text-[#D4AF37] border-[#D4AF37]/30 hover:border-[#D4AF37]/60'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>Ajustar IA</span>
            </button>
          </div>
        </div>

        {/* Workout Title */}
        <h1 className="text-[20px] sm:text-[22px] font-extrabold tracking-tight text-[#F4F5F7] leading-tight mb-3">
          {displayWorkoutTitle}
        </h1>

        {/* Day Selector Pills */}
        <div
          role="tablist"
          aria-label="Selecionar dia de treino"
          className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-3 mb-3 border-b border-white/[0.06]"
        >
          {dynamicWorkouts.map((day, idx) => {
            const isSelected = day.id === selectedDayId;
            const code = String.fromCharCode(65 + (idx % 6));
            return (
              <button
                key={day.id}
                role="tab"
                aria-selected={isSelected}
                type="button"
                onClick={() => {
                  onSelectDayId(day.id);
                  setManualFocusedSetIdx(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all shrink-0 border ${
                  isSelected
                    ? 'bg-[#D4AF37]/15 text-[#D4AF37] border-[#D4AF37]/50'
                    : 'bg-[#1A1D24]/70 text-[#9CA3AF] border-white/[0.05] hover:text-[#F4F5F7]'
                }`}
              >
                {day.shortDay} · Treino {code}
              </button>
            );
          })}
        </div>

        {/* Collapsible AI Workout Reformulation Panel */}
        {showAiDrawer && (
          <div className="mb-4 p-3.5 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Reformulação Inteligente (IA)
              </span>
              <button
                type="button"
                onClick={() => setShowAiDrawer(false)}
                className="text-[11px] font-semibold text-[#9CA3AF] hover:text-[#F4F5F7]"
              >
                Fechar
              </button>
            </div>

            <div>
              <p className="text-[11px] text-[#9CA3AF] mb-1.5">
                Dias ativos na semana ({activeSelectedDays.length}d):
              </p>
              <div className="grid grid-cols-7 gap-1">
                {ALL_WEEK_DAYS.map((d) => {
                  const active = activeSelectedDays.includes(d.id);
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => onToggleTrainingDay(d.id)}
                      className={`py-1.5 rounded-lg text-[10px] font-bold border transition-all ${
                        active
                          ? 'bg-[#D4AF37] text-[#08090C] border-[#D4AF37]'
                          : 'bg-[#13151A] text-[#6B7280] border-white/[0.06]'
                      }`}
                    >
                      {d.short}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {AI_REFORMULATION_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setCustomAiPrompt(preset.prompt)}
                  className="px-2.5 py-1 rounded-lg bg-[#13151A] border border-white/[0.06] text-[11px] text-[#9CA3AF] hover:text-[#D4AF37] hover:border-[#D4AF37]/40 transition"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={customAiPrompt}
              onChange={(e) => setCustomAiPrompt(e.target.value)}
              placeholder="Ex: Treino de 40 min focado em halteres..."
              aria-label="Instrução personalizada para IA"
              className="w-full px-3 py-2 rounded-lg bg-[#13151A] border border-white/10 text-[12px] text-[#F4F5F7] placeholder-[#6B7280] focus:outline-none focus:border-[#D4AF37]"
            />

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={isGeneratingAi}
                onClick={() => onReformulate({ scope: 'day', customPrompt: customAiPrompt })}
                className="py-2 px-3 rounded-lg bg-[#13151A] border border-[#D4AF37]/40 text-[#D4AF37] text-[11px] font-bold hover:bg-[#D4AF37]/10 transition disabled:opacity-50"
              >
                {isGeneratingAi ? 'Recalculando...' : 'Reformular Hoje'}
              </button>
              <button
                type="button"
                disabled={isGeneratingAi}
                onClick={() => onReformulate({ scope: 'week', customPrompt: customAiPrompt })}
                className="py-2 px-3 rounded-lg bg-[#D4AF37] text-[#08090C] text-[11px] font-extrabold hover:bg-[#e2be46] transition disabled:opacity-50"
              >
                {isGeneratingAi ? 'Gerando...' : 'Recalcular Semana'}
              </button>
            </div>
          </div>
        )}

        {/* Main Session Timer Box */}
        <div className="bg-[#1A1D24] rounded-xl p-3.5 border border-white/[0.06] flex items-center justify-between gap-3 mb-3">
          <div>
            <span className="block text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF] mb-1">
              Tempo de treino
            </span>
            <div
              data-testid="session-stopwatch"
              className="font-mono text-[32px] sm:text-[38px] font-bold text-[#F4F5F7] leading-none tracking-tight tabular-nums"
            >
              {formatArenaTimer(workoutElapsedSec, true)}
            </div>
          </div>

          {sessionStatus === 'not_started' ? (
            <button
              type="button"
              onClick={onStartSession}
              className="h-10 px-4 rounded-lg bg-[#D4AF37] hover:bg-[#e3be42] text-[#08090C] text-[13px] font-extrabold flex items-center gap-2 shadow active:scale-[0.98] transition-all shrink-0"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Iniciar treino</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onToggleStopwatch}
              className="h-10 px-3.5 rounded-lg bg-[#13151A] border border-white/10 flex items-center gap-2 text-[#F4F5F7] text-[13px] font-semibold hover:bg-white/[0.04] active:scale-[0.98] transition-all shrink-0"
            >
              {workoutStopwatchRunning ? (
                <>
                  <Pause className="w-4 h-4 text-[#D4AF37]" />
                  <span>Pausar</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-[#10B981]" />
                  <span>Retomar</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* 2-Column Live Metrics: Volume total & Progresso */}
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div className="bg-[#1A1D24]/60 rounded-xl p-3 border border-white/[0.06]">
            <span className="text-[12px] font-medium text-[#9CA3AF] block mb-1">
              Volume total
            </span>
            <div className="flex items-baseline gap-1">
              <span
                data-testid="session-tonnage"
                className="font-mono text-[22px] sm:text-[24px] font-bold text-[#D4AF37] leading-none tracking-tight tabular-nums"
              >
                {tonnage.toLocaleString('pt-BR')}
              </span>
              <span className="text-[12px] font-medium text-[#9CA3AF]">kg</span>
            </div>
          </div>

          <div className="bg-[#1A1D24]/60 rounded-xl p-3 border border-white/[0.06]">
            <span className="text-[12px] font-medium text-[#9CA3AF] block mb-1">
              Progresso
            </span>
            <div className="flex items-baseline gap-1.5">
              <span
                data-testid="session-completed-sets"
                className="font-mono text-[22px] sm:text-[24px] font-bold text-[#10B981] leading-none tracking-tight tabular-nums"
              >
                {completedSets}
              </span>
              <span className="text-[13px] font-medium text-[#9CA3AF]">
                de {totalSets} séries
              </span>
            </div>
          </div>
        </div>

        {/* Smooth Progress Bar */}
        <div className="w-full h-1.5 bg-[#1A1D24] rounded-full overflow-hidden">
          <div
            className="bg-[#10B981] h-full rounded-full transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </section>

      {/* 2. BARRA DO CRONÔMETRO DE DESCANSO */}
      <section
        aria-label="Cronômetro de descanso"
        className="bg-[#13151A] rounded-2xl p-3.5 sm:p-4 border border-white/[0.06]"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            {/* Circular SVG Ring */}
            <button
              type="button"
              onClick={onOpenRestModal}
              aria-label="Abrir tela de descanso ativo"
              className="relative w-11 h-11 flex items-center justify-center shrink-0 rounded-full focus:outline-none"
            >
              <svg className="w-full h-full -rotate-90" viewBox="0 0 44 44">
                <circle
                  cx="22"
                  cy="22"
                  r={ringRadius}
                  fill="transparent"
                  stroke="#1A1D24"
                  strokeWidth="3.5"
                />
                <circle
                  cx="22"
                  cy="22"
                  r={ringRadius}
                  fill="transparent"
                  stroke={
                    restTimerState.status === 'completed'
                      ? '#10B981'
                      : timerRunning
                      ? '#D4AF37'
                      : '#6B7280'
                  }
                  strokeWidth="3.5"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringDashoffset}
                  strokeLinecap="round"
                />
              </svg>
              <Hourglass
                className={`w-4 h-4 absolute ${
                  timerRunning ? 'text-[#D4AF37] animate-pulse' : 'text-[#D4AF37]'
                }`}
              />
            </button>

            <div className="min-w-0">
              <span className="block text-[12px] font-medium text-[#9CA3AF] leading-none mb-1 truncate">
                {restTimerState.status === 'completed'
                  ? 'Descanso concluído'
                  : restTimerState.status === 'paused'
                  ? 'Descanso pausado'
                  : 'Tempo de descanso'}
              </span>
              <span
                data-testid="rest-timer-display"
                className={`font-mono text-[24px] sm:text-[26px] font-bold leading-none tracking-tight tabular-nums ${
                  restTimerState.status === 'completed' ? 'text-[#10B981]' : 'text-[#F4F5F7]'
                }`}
              >
                {formatArenaTimer(timerSeconds, false)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {(restTimerState.status === 'running' || restTimerState.status === 'paused') && (
              <>
                <button
                  type="button"
                  onClick={onOpenRestModal}
                  aria-label="Expandir descanso"
                  className="h-9 px-2.5 rounded-lg bg-[#1A1D24] border border-[#D4AF37]/30 text-[11px] font-bold text-[#D4AF37] hover:bg-[#D4AF37]/10 flex items-center gap-1 transition-all"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Tela cheia</span>
                </button>
                <button
                  type="button"
                  onClick={onTogglePauseRestTimer}
                  aria-label={
                    restTimerState.status === 'paused' ? 'Retomar descanso' : 'Pausar descanso'
                  }
                  className="h-9 px-2.5 rounded-lg bg-[#1A1D24] border border-white/10 text-[12px] font-bold text-[#F4F5F7] hover:bg-white/[0.06] transition-all"
                >
                  {restTimerState.status === 'paused' ? 'Retomar' : 'Pausar'}
                </button>
              </>
            )}
            <button
              type="button"
              onClick={() => onAdjustRestTimer(30)}
              className="h-9 px-3 rounded-lg bg-[#1A1D24] border border-white/10 text-[12px] font-bold text-[#F4F5F7] hover:bg-white/[0.06] active:scale-95 transition-all"
            >
              +30s
            </button>
            <button
              type="button"
              onClick={onResetRestTimer}
              className="h-9 px-3 rounded-lg bg-[#1A1D24] border border-white/10 text-[12px] font-semibold text-[#9CA3AF] hover:text-[#F4F5F7] active:scale-95 transition-all"
            >
              Pular
            </button>
          </div>
        </div>

        {/* Quick Rest Timer Presets */}
        <div className="flex items-center justify-between gap-1.5 mt-3 pt-2.5 border-t border-white/[0.05]">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#6B7280]">
            Iniciar:
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            {[45, 60, 90, 120].map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => onStartRestTimer(sec)}
                className={`px-2.5 py-1 rounded-md font-mono text-[11px] font-bold transition ${
                  timerRunning && timerTarget === sec
                    ? 'bg-[#D4AF37] text-[#08090C]'
                    : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] border border-white/[0.05]'
                }`}
              >
                {sec}s
              </button>
            ))}
            <button
              type="button"
              onClick={() => onAdjustRestTimer(-15)}
              className="px-2 py-1 rounded-md font-mono text-[11px] font-semibold bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] border border-white/[0.05]"
            >
              -15s
            </button>
          </div>
        </div>
      </section>

      {/* 3. SELETOR DE ETAPAS DA SESSÃO (MOBILIDADE · MUSCULAÇÃO · CARDIO) */}
      <div
        role="tablist"
        aria-label="Fases da sessão de treino"
        className="grid grid-cols-3 gap-1.5 p-1 bg-[#13151A] rounded-xl border border-white/[0.06]"
      >
        <button
          role="tab"
          aria-selected={arenaPhase === 'mobilidade'}
          type="button"
          onClick={() => setArenaPhase('mobilidade')}
          className={`py-2 px-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
            arenaPhase === 'mobilidade'
              ? 'bg-[#1A1D24] text-[#D4AF37] border border-[#D4AF37]/40 shadow'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <span>Mobilidade</span>
          <span className="font-mono text-[10px] opacity-80">
            {mobilityDoneCount}/{mobilityList.length}
          </span>
        </button>

        <button
          role="tab"
          aria-selected={arenaPhase === 'hipertrofia'}
          type="button"
          onClick={() => setArenaPhase('hipertrofia')}
          className={`py-2 px-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
            arenaPhase === 'hipertrofia'
              ? 'bg-[#1A1D24] text-[#D4AF37] border border-[#D4AF37]/40 shadow'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <span>Musculação</span>
          <span className="font-mono text-[10px] opacity-80">
            {completedSets}/{totalSets}
          </span>
        </button>

        <button
          role="tab"
          aria-selected={arenaPhase === 'cardio'}
          type="button"
          onClick={() => setArenaPhase('cardio')}
          className={`py-2 px-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
            arenaPhase === 'cardio'
              ? 'bg-[#1A1D24] text-[#D4AF37] border border-[#D4AF37]/40 shadow'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <span>Cardio</span>
          <span className="font-mono text-[10px] opacity-80">
            {cardioCompleted ? '✓' : '•'}
          </span>
        </button>
      </div>

      {/* FASE 1: MOBILIDADE ARTICULAR */}
      {arenaPhase === 'mobilidade' && (
        <section className="bg-[#13151A] rounded-2xl p-4 sm:p-5 border border-white/[0.06] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#D4AF37] block">
                Preparação Articular
              </span>
              <h2 className="text-[18px] font-bold text-[#F4F5F7]">
                Mobilidade e Ativação
              </h2>
            </div>
            <span className="font-mono text-[12px] font-bold text-[#10B981]">
              {mobilityDoneCount} de {mobilityList.length} concluídos
            </span>
          </div>

          <div className="space-y-2.5">
            {mobilityList.map((item) => {
              const checked = !!mobilityChecked[item.id];
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onToggleMobility(item.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    checked
                      ? 'bg-[#10B981]/10 border-[#10B981]/30'
                      : 'bg-[#1A1D24] border-white/[0.06] hover:border-white/15'
                  }`}
                >
                  <div className="min-w-0">
                    <p
                      className={`text-[14px] font-bold ${
                        checked ? 'line-through text-[#9CA3AF]' : 'text-[#F4F5F7]'
                      }`}
                    >
                      {item.name}
                    </p>
                    <p className="text-[12px] text-[#9CA3AF] mt-0.5">
                      {item.focus} · <span className="font-mono text-[#D4AF37]">{item.duration}</span>
                    </p>
                  </div>
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border ${
                      checked
                        ? 'bg-[#10B981] text-[#08090C] border-[#10B981]'
                        : 'bg-[#13151A] text-transparent border-white/15'
                    }`}
                  >
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => setArenaPhase('hipertrofia')}
            className="w-full h-12 rounded-xl bg-[#D4AF37] text-[#08090C] font-extrabold text-[14px] flex items-center justify-center gap-2"
          >
            <span>Ir para Musculação</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </section>
      )}

      {/* FASE 3: CARDIO METABÓLICO */}
      {arenaPhase === 'cardio' && (
        <section className="bg-[#13151A] rounded-2xl p-4 sm:p-5 border border-white/[0.06] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#D4AF37] block">
                Condicionamento Final
              </span>
              <h2 className="text-[18px] font-bold text-[#F4F5F7]">
                {currentDayWorkout.cardioBlock?.mode || 'Protocolo Cardio Metabólico'}
              </h2>
            </div>
            <Flame className="w-6 h-6 text-[#D4AF37]" />
          </div>

          {currentDayWorkout.cardioBlock && (
            <div className="space-y-3 bg-[#1A1D24] p-4 rounded-xl border border-white/[0.06]">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] block">
                  Protocolo Prescrito
                </span>
                <p className="text-[14px] font-semibold text-[#F4F5F7] mt-0.5">
                  {currentDayWorkout.cardioBlock.protocol}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/[0.06]">
                <div>
                  <span className="text-[10px] uppercase text-[#9CA3AF] block">
                    Gasto Estimado
                  </span>
                  <span className="font-mono text-[13px] font-bold text-[#D4AF37]">
                    {currentDayWorkout.cardioBlock.caloriesEst}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-[#9CA3AF] block">
                    Descompressão
                  </span>
                  <span className="text-[12px] font-medium text-[#F4F5F7]">
                    {currentDayWorkout.cardioBlock.stretching}
                  </span>
                </div>
              </div>
            </div>
          )}

          <button
            type="button"
            onClick={onToggleCardio}
            className={`w-full h-12 rounded-xl font-extrabold text-[14px] flex items-center justify-center gap-2 transition-all ${
              cardioCompleted
                ? 'bg-[#10B981]/20 border border-[#10B981]/40 text-[#10B981]'
                : 'bg-[#D4AF37] text-[#08090C]'
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>
              {cardioCompleted
                ? 'Cardio Concluído (Toque para desmarcar)'
                : 'Marcar Cardio como Concluído'}
            </span>
          </button>
        </section>
      )}

      {/* FASE 2 (PRINCIPAL): EXERCÍCIO EM ANDAMENTO & REGISTRO DE SÉRIES */}
      {arenaPhase === 'hipertrofia' && activeExercise && (
        <section aria-label="Exercício em andamento e registro de séries" className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
              Exercício em andamento ({safeExerciseIdx + 1} de {exercises.length})
            </h2>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37]">
              {activeExercise.partLabel || activeExercise.targetGroup}
            </span>
          </div>

          <div className="bg-[#13151A] rounded-2xl p-4 sm:p-5 border border-white/[0.06] shadow-[0_8px_28px_rgba(0,0,0,0.45)] space-y-4">
            {/* Active Exercise Header */}
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-[20px] sm:text-[22px] font-extrabold text-[#F4F5F7] tracking-tight leading-snug">
                  {activeExercise.name}
                </h3>
                <p className="text-[13px] font-medium text-[#9CA3AF] mt-0.5">
                  {activeExercise.partLabel || activeExercise.targetGroup} · Cadência{' '}
                  <span className="font-mono text-[#F4F5F7]">{activeExercise.cadence}</span> · Descanso{' '}
                  <span className="font-mono text-[#F4F5F7]">{activeExercise.rest}s</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowSwapDrawer((prev) => !prev)}
                aria-label="Opções do exercício"
                className="w-9 h-9 rounded-xl bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#9CA3AF] hover:text-[#F4F5F7] shrink-0"
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>

            {/* Historical Reference / PR Bar (100% real data, never fabricated) */}
            {prevRef && (
              <div className="flex items-center justify-between gap-2 bg-[#1A1D24]/80 border border-white/[0.06] rounded-xl px-3.5 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/10 border border-[#D4AF37]/25 flex items-center justify-center text-[#D4AF37] shrink-0">
                    <Award className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-[#D4AF37]">
                      {prevRef.hasHistory ? 'Recorde / Histórico Real' : 'Referência Inicial'}
                    </span>
                    <span className="block font-mono text-[12px] font-semibold text-[#F4F5F7] truncate">
                      {prevRef.summaryText}
                    </span>
                  </div>
                </div>
                <div className="px-2.5 py-1 rounded-full bg-[#13151A] border border-white/[0.06] flex items-center gap-1.5 shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                  <span className="font-mono text-[11px] font-bold text-[#F4F5F7]">
                    Série {focusedSetIndex + 1}/{activeSets.length}
                  </span>
                </div>
              </div>
            )}

            {/* Collapsible Biomechanical Tip & AI Equipment Swap Drawer */}
            {showSwapDrawer && (
              <div className="p-3.5 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 space-y-3">
                <p className="text-[12px] text-[#9CA3AF] leading-relaxed">
                  <strong className="text-[#D4AF37]">Dica biomecânica:</strong> {activeExercise.tip}
                </p>
                <div className="pt-2 border-t border-white/[0.06]">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mb-2">
                    Substituir exercício com IA (Aparelho ocupado / Desconforto):
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {[
                      'Aparelho ocupado (usar halteres)',
                      'Aparelho ocupado (usar polia/cabos)',
                      'Desconforto articular (variação segura)'
                    ].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        disabled={swappingExerciseId === activeExercise.id}
                        onClick={() => onSwapSingleExercise(activeExercise, reason)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#13151A] border border-white/10 text-[11px] font-semibold text-[#F4F5F7] hover:border-[#D4AF37] hover:text-[#D4AF37] transition disabled:opacity-50"
                      >
                        {swappingExerciseId === activeExercise.id ? 'Trocando...' : reason}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* SETS TABLE (SÉRIE | ANTERIOR | CARGA & REPS | STATUS) */}
            <div className="space-y-1.5">
              <div className="grid grid-cols-12 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-[#6B7280]">
                <div className="col-span-2">Série</div>
                <div className="col-span-4">Anterior</div>
                <div className="col-span-4">Carga & Reps</div>
                <div className="col-span-2 text-right">Status</div>
              </div>

              {activeSets.map((setItem, idx) => {
                const isFocused = idx === focusedSetIndex;
                return (
                  <div
                    key={setItem.setNumber}
                    onClick={() => setManualFocusedSetIdx(idx)}
                    className={`grid grid-cols-12 items-center px-3 py-2.5 rounded-xl border transition-all cursor-pointer ${
                      isFocused
                        ? 'bg-[#1A1D24] border-[#D4AF37]/50 shadow-sm'
                        : setItem.completed
                        ? 'bg-[#1A1D24]/45 border-white/[0.05] opacity-90'
                        : 'bg-[#1A1D24]/25 border-white/[0.04] hover:border-white/10'
                    }`}
                  >
                    <div className="col-span-2 flex items-center gap-1.5">
                      <span
                        className={`font-mono text-[13px] font-bold ${
                          isFocused
                            ? 'text-[#D4AF37]'
                            : setItem.completed
                            ? 'text-[#10B981]'
                            : 'text-[#9CA3AF]'
                        }`}
                      >
                        #{setItem.setNumber}
                      </span>
                    </div>

                    <div className="col-span-4 font-mono text-[11px] text-[#9CA3AF] truncate pr-1">
                      {prevRef?.tableCellText || 'Sem registro'}
                    </div>

                    <div className="col-span-4 font-mono text-[13px] font-bold text-[#F4F5F7]">
                      {setItem.weight} kg × {setItem.reps}
                    </div>

                    <div className="col-span-2 flex justify-end">
                      <button
                        type="button"
                        aria-label={
                          setItem.completed
                            ? `Reverter série ${setItem.setNumber}`
                            : `Concluir série ${setItem.setNumber}`
                        }
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleSetCompleted(activeExercise, idx);
                        }}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                          setItem.completed
                            ? 'bg-[#10B981]/15 border border-[#10B981]/35 text-[#10B981]'
                            : 'bg-[#13151A] border border-white/10 text-[#6B7280] hover:text-[#F4F5F7]'
                        }`}
                      >
                        <Check className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* ACTIVE SET HERO BOX */}
            {focusedSet && (
              <div className="bg-[#1A1D24] border border-[#D4AF37]/35 rounded-2xl p-4 relative overflow-hidden shadow-[0_10px_30px_rgba(0,0,0,0.5)] space-y-3.5">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#D4AF37]" />

                {/* Active Set Header */}
                <div className="flex items-center justify-between gap-2 pt-0.5 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="bg-[#D4AF37] text-[#08090C] text-[10px] font-extrabold uppercase px-2 py-0.5 rounded tracking-wider">
                      Série {focusedSet.setNumber} de {activeSets.length}
                    </span>
                    <span className="text-[12px] font-semibold text-[#9CA3AF]">
                      Alvo: {activeExercise.reps} reps
                    </span>
                  </div>
                  {prevRef?.hasHistory && prevRef.lastWeightKg ? (
                    <span className="text-[11px] font-mono font-semibold text-[#D4AF37] bg-[#D4AF37]/10 px-2 py-0.5 rounded">
                      Último: {prevRef.lastWeightKg} kg
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono text-[#9CA3AF]">
                      Base: {activeExercise.defaultWeight} kg
                    </span>
                  )}
                </div>

                {/* Control 1: CARGA DE TRABALHO (KG) */}
                <div className="bg-[#13151A] rounded-xl p-3 border border-white/[0.05]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                      Carga de trabalho
                    </span>
                    <button
                      type="button"
                      onClick={() => weightInputRef.current?.focus()}
                      className="text-[10px] font-bold uppercase tracking-wider text-[#D4AF37] hover:underline"
                    >
                      Digitar
                    </button>
                  </div>

                  <div className="flex items-center justify-between gap-1">
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        aria-label="Diminuir 2.5 kg"
                        onClick={() => onStepSetWeight(activeExercise.id, focusedSetIndex, -2.5)}
                        className="h-10 px-2 rounded-lg bg-[#1A1D24] border border-white/[0.06] font-mono text-[11px] font-bold text-[#9CA3AF] hover:text-[#F4F5F7] active:scale-95 transition-all"
                      >
                        -2.5
                      </button>
                      <button
                        type="button"
                        aria-label="Diminuir 1 kg"
                        onClick={() => onStepSetWeight(activeExercise.id, focusedSetIndex, -1)}
                        className="h-10 w-9 rounded-lg bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-white/[0.06] active:scale-95 transition-all"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-baseline justify-center gap-1 min-w-0 px-1">
                      <input
                        ref={weightInputRef}
                        type="number"
                        inputMode="decimal"
                        step="0.5"
                        min="0"
                        aria-label="Carga da série em kg"
                        value={focusedSet.weight}
                        onChange={(e) =>
                          onUpdateSetField(
                            activeExercise.id,
                            focusedSetIndex,
                            'weight',
                            e.target.value === '' ? 0 : Math.max(0, Number(e.target.value))
                          )
                        }
                        className="w-14 sm:w-16 text-center bg-transparent font-mono text-[24px] sm:text-[28px] font-bold text-[#F4F5F7] leading-none tracking-tight tabular-nums focus:outline-none focus:ring-1 focus:ring-[#D4AF37] rounded py-0.5 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <span className="text-[11px] font-mono font-bold text-[#D4AF37] uppercase shrink-0">
                        kg
                      </span>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        aria-label="Aumentar 1 kg"
                        onClick={() => onStepSetWeight(activeExercise.id, focusedSetIndex, 1)}
                        className="h-10 w-9 rounded-lg bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-white/[0.06] active:scale-95 transition-all"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="Aumentar 2.5 kg"
                        onClick={() => onStepSetWeight(activeExercise.id, focusedSetIndex, 2.5)}
                        className="h-10 px-2 rounded-lg bg-[#1A1D24] border border-white/[0.06] font-mono text-[11px] font-bold text-[#9CA3AF] hover:text-[#F4F5F7] active:scale-95 transition-all"
                      >
                        +2.5
                      </button>
                    </div>
                  </div>
                </div>

                {/* Control 2: REPETIÇÕES */}
                <div className="bg-[#13151A] rounded-xl p-3 border border-white/[0.05]">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] whitespace-nowrap">
                      Repetições
                    </span>
                    <div className="flex items-center gap-1 shrink-0">
                      <span className="text-[10px] font-mono font-semibold text-[#6B7280] mr-0.5">
                        RPE:
                      </span>
                      {[7, 8, 9, 10].map((rpeVal) => (
                        <button
                          key={rpeVal}
                          type="button"
                          aria-label={`RPE ${rpeVal}`}
                          onClick={() =>
                            onUpdateSetField(activeExercise.id, focusedSetIndex, 'rpe', rpeVal)
                          }
                          className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold whitespace-nowrap transition ${
                            focusedSet.rpe === rpeVal
                              ? 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40'
                              : 'text-[#6B7280] hover:text-[#9CA3AF]'
                          }`}
                        >
                          {rpeVal}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      aria-label="Diminuir 1 repetição"
                      onClick={() => onStepSetReps(activeExercise.id, focusedSetIndex, -1)}
                      className="h-11 w-12 rounded-lg bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-white/[0.06] active:scale-95 transition-all shrink-0"
                    >
                      <Minus className="w-4 h-4" />
                    </button>

                    <div className="flex items-baseline justify-center gap-1.5 flex-1 min-w-0">
                      <input
                        ref={repsInputRef}
                        type="number"
                        inputMode="numeric"
                        step="1"
                        min="0"
                        aria-label="Repetições da série"
                        value={focusedSet.reps}
                        onChange={(e) =>
                          onUpdateSetField(
                            activeExercise.id,
                            focusedSetIndex,
                            'reps',
                            e.target.value === '' ? 0 : Math.max(0, Number(e.target.value))
                          )
                        }
                        className="w-16 text-center bg-transparent font-mono text-[26px] sm:text-[30px] font-bold text-[#F4F5F7] leading-none tracking-tight tabular-nums focus:outline-none focus:ring-1 focus:ring-[#D4AF37] rounded py-0.5 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <span className="text-[12px] font-mono font-bold text-[#D4AF37] uppercase shrink-0">
                        reps
                      </span>
                    </div>

                    <button
                      type="button"
                      aria-label="Aumentar 1 repetição"
                      onClick={() => onStepSetReps(activeExercise.id, focusedSetIndex, 1)}
                      className="h-11 w-12 rounded-lg bg-[#1A1D24] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-white/[0.06] active:scale-95 transition-all shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Post-set Rest Quick Bar */}
                <div className="flex items-center justify-between px-1 text-[12px]">
                  <div className="flex items-center gap-1.5 text-[#9CA3AF]">
                    <Timer className="w-4 h-4 text-[#D4AF37]" />
                    <span>
                      Descanso pós-série:{' '}
                      <strong className="font-mono text-[#F4F5F7]">
                        {formatArenaTimer(activeExercise.rest, false)}
                      </strong>
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onStartRestTimer(activeExercise.rest)}
                    className="text-[#D4AF37] font-semibold hover:underline"
                  >
                    Disparar descanso
                  </button>
                </div>

                {/* PRIMARY CTA: CONCLUIR SÉRIE / REVERTER SÉRIE */}
                <button
                  type="button"
                  onClick={handleCompleteOrRevertFocusedSet}
                  className={`w-full h-[52px] rounded-xl font-extrabold text-[15px] flex items-center justify-center gap-2 transition-all active:scale-[0.99] ${
                    focusedSet.completed
                      ? 'bg-[#10B981]/15 border border-[#10B981]/40 text-[#10B981]'
                      : 'bg-[#D4AF37] hover:bg-[#e0bb3e] text-[#08090C] shadow-[0_4px_20px_rgba(212,175,55,0.25)]'
                  }`}
                >
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                  <span>
                    {focusedSet.completed
                      ? `Série #${focusedSet.setNumber} Concluída · Reverter`
                      : 'Concluir Série'}
                  </span>
                </button>
              </div>
            )}

            {/* Secondary Controls: Add Extra Set & Swap Exercise */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => onAddExtraSet(activeExercise.id)}
                className="h-11 rounded-xl bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7] text-[12px] font-bold flex items-center justify-center gap-1.5 transition"
              >
                <Plus className="w-4 h-4 text-[#D4AF37]" />
                <span>Adicionar série extra</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSwapDrawer((prev) => !prev)}
                className="h-11 rounded-xl bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7] text-[12px] font-bold flex items-center justify-center gap-1.5 transition"
              >
                <Repeat className="w-4 h-4 text-[#D4AF37]" />
                <span>Substituir</span>
              </button>
            </div>

            {/* Next Exercise Callout */}
            {nextExercise && nextExerciseIdx !== null && (
              <button
                type="button"
                onClick={() => handleSelectExercise(nextExerciseIdx)}
                className="w-full p-3.5 rounded-xl bg-[#1A1D24]/60 border border-white/[0.06] hover:border-[#D4AF37]/40 flex items-center justify-between gap-3 transition text-left"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-[#13151A] border border-white/[0.06] flex items-center justify-center text-[#D4AF37] shrink-0">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                      A seguir
                    </span>
                    <span className="block text-[14px] font-bold text-[#F4F5F7] truncate">
                      {nextExercise.name}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[#9CA3AF] shrink-0">
                  <span className="font-mono text-[12px] font-medium">
                    {(sessionSets[nextExercise.id] || []).length || nextExercise.baseSets} séries
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            )}
          </div>
        </section>
      )}

      {/* 4. FILA COMPLETA DE EXERCÍCIOS DO TREINO */}
      <section aria-label="Próximos exercícios" className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
            Próximos exercícios ({exercises.length})
          </h2>
          <span className="text-[11px] font-medium text-[#6B7280]">
            Toque para alternar
          </span>
        </div>

        <div className="space-y-2">
          {exercises.map((ex, idx) => {
            const exSets = sessionSets[ex.id] || [];
            const exDone = exSets.filter((s) => s.completed).length;
            const exTotal = exSets.length || ex.baseSets;
            const isCurrent = idx === safeExerciseIdx && arenaPhase === 'hipertrofia';
            const isAllDone = exTotal > 0 && exDone === exTotal;
            const refLoad = lastExerciseWeights[ex.id] || ex.defaultWeight;

            return (
              <button
                key={ex.id}
                type="button"
                onClick={() => {
                  setArenaPhase('hipertrofia');
                  handleSelectExercise(idx);
                }}
                className={`w-full text-left bg-[#13151A] rounded-2xl p-3.5 border transition-all flex items-center justify-between gap-3 ${
                  isCurrent
                    ? 'border-[#D4AF37]/50 bg-[#1A1D24]/80'
                    : isAllDone
                    ? 'border-[#10B981]/30 opacity-90'
                    : 'border-white/[0.06] hover:border-white/15'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-mono text-[13px] font-bold shrink-0 border ${
                      isAllDone
                        ? 'bg-[#10B981]/15 text-[#10B981] border-[#10B981]/30'
                        : isCurrent
                        ? 'bg-[#D4AF37] text-[#08090C] border-[#D4AF37]'
                        : 'bg-[#1A1D24] text-[#9CA3AF] border-white/[0.06]'
                    }`}
                  >
                    {isAllDone ? <Check className="w-4 h-4 stroke-[2.5]" /> : idx + 1}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-[14px] font-bold text-[#F4F5F7] truncate">
                      {ex.name}
                    </h4>
                    <p className="text-[12px] text-[#9CA3AF] mt-0.5 font-mono">
                      {exDone}/{exTotal} séries · {ex.reps} reps · {refLoad} kg
                    </p>
                  </div>
                </div>
                <ChevronRight
                  className={`w-5 h-5 shrink-0 ${
                    isCurrent ? 'text-[#D4AF37]' : 'text-[#6B7280]'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </section>

      {/* MODAL / DRAWER PARA ADICIONAR EXERCÍCIO PERSONALIZADO */}
      {showAddExerciseModal && (
        <div className="bg-[#13151A] rounded-2xl p-4 border border-[#D4AF37]/40 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-bold uppercase tracking-wider text-[#D4AF37]">
              Novo Exercício na Sessão
            </span>
            <button
              type="button"
              onClick={() => setShowAddExerciseModal(false)}
              className="text-[12px] text-[#9CA3AF] hover:text-[#F4F5F7]"
            >
              Cancelar
            </button>
          </div>
          <input
            type="text"
            value={customExName}
            onChange={(e) => setCustomExName(e.target.value)}
            placeholder="Nome do exercício (ex: Crucifixo Máquina)"
            aria-label="Nome do novo exercício"
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#1A1D24] border border-white/10 text-[13px] text-[#F4F5F7] placeholder-[#6B7280] focus:outline-none focus:border-[#D4AF37]"
          />
          <button
            type="button"
            onClick={() => {
              if (!customExName.trim()) return;
              onAddCustomExercise(customExName.trim());
              setCustomExName('');
              setShowAddExerciseModal(false);
            }}
            className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#08090C] font-extrabold text-[13px]"
          >
            Confirmar Exercício
          </button>
        </div>
      )}

      {/* 5. AÇÕES FINAIS DA SESSÃO */}
      <div className="pt-2 space-y-2.5">
        <button
          type="button"
          onClick={() => setShowAddExerciseModal((prev) => !prev)}
          className="w-full h-12 rounded-xl bg-[#13151A] border border-white/10 text-[#F4F5F7] font-semibold text-[14px] flex items-center justify-center gap-2 hover:bg-[#1A1D24] transition-all"
        >
          <Plus className="w-4 h-4 text-[#D4AF37]" />
          <span>Adicionar exercício</span>
        </button>

        <button
          type="button"
          disabled={isSavingWorkout}
          onClick={handleFinishWithCelebration}
          className="w-full h-12 rounded-xl bg-[#10B981]/15 border border-[#10B981]/35 text-[#10B981] font-extrabold text-[14px] flex items-center justify-center gap-2 hover:bg-[#10B981]/25 transition-all disabled:opacity-50"
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>
            {isSavingWorkout
              ? 'Salvando treino...'
              : `Finalizar treino (${completedSets}/${totalSets} séries)`}
          </span>
        </button>

        {(isSessionActive || completedSets > 0) && (
          <button
            type="button"
            onClick={onRequestDiscardSession}
            className="w-full h-11 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/25 text-[#EF4444] hover:bg-[#EF4444]/20 font-semibold text-[13px] flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Descartar sessão de treino</span>
          </button>
        )}
      </div>
      </div>
    </div>
  );
};
