import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Award,
  BarChart3,
  BookOpen,
  Calendar,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Dumbbell,
  History,
  Layers,
  Plus,
  Repeat,
  Ruler,
  Search,
  Sparkles,
  Trash2,
  TrendingUp,
  Trophy,
  X
} from 'lucide-react';
import {
  BiometricMetrics,
  CheckinRecord,
  CompletedWorkout,
  GoldenAnalysis,
  UserProfile,
  WorkoutDay
} from '../types';
import { cleanDisplayText, isDemoCheckin } from '../utils/dashboardLogic';
import {
  calculateEvolutionOverviewStats,
  deduplicateAndSortWorkouts,
  EvolutionPeriod,
  filterWorkoutHistoryFeed,
  filterWorkoutsByPeriod,
  formatDurationHoursMinutes,
  formatSessionFriendlyDate,
  getAvailableHistoryCategories,
  getExerciseEvolutionDetail,
  getRegisteredExercisesList,
  groupVolumeByInterval,
  groupWorkoutsByMonth,
  splitCheckinsByOrigin
} from '../utils/evolutionLogic';
import {
  ExerciseProgressionChart,
  SessionDetailModal,
  VolumeEvolutionChart
} from './EvolutionCharts';

interface EvolutionViewProps {
  profile?: UserProfile;
  metrics: BiometricMetrics;
  goldenAnalysis: GoldenAnalysis;
  checkins: CheckinRecord[];
  workoutHistory: CompletedWorkout[];
  lastExerciseWeights?: Record<string, number>;
  dynamicWorkouts?: WorkoutDay[];
  initialExerciseId?: string | null;
  onClearInitialExerciseId?: () => void;
  initialSubView?: EvolutionSubView | null;
  onClearInitialSubView?: () => void;
  onAddCheckin: (note: string) => void;
  onDeleteCheckin: (id: string) => void;
  onSeedDemoEvolution: () => void;
  onClearDemoCheckins?: () => void;
  isSavingCheckin: boolean;
  onNavigateTab?: (
    tab:
      | 'inicio'
      | 'questionario'
      | 'scanner'
      | 'executar'
      | 'ia'
      | 'evolucao'
      | 'workspace'
      | 'perfil'
  ) => void;
}

type EvolutionSubView = 'overview' | 'exercise' | 'history' | 'measures';

const PERIOD_OPTIONS: Array<{ id: EvolutionPeriod; label: string }> = [
  { id: '7d', label: '7 dias' },
  { id: '30d', label: '30 dias' },
  { id: '90d', label: '90 dias' },
  { id: 'all', label: 'Tudo' }
];

export function EvolutionView({
  profile,
  metrics,
  goldenAnalysis,
  checkins,
  workoutHistory,
  lastExerciseWeights = {},
  dynamicWorkouts = [],
  initialExerciseId,
  onClearInitialExerciseId,
  initialSubView,
  onClearInitialSubView,
  onAddCheckin,
  onDeleteCheckin,
  onSeedDemoEvolution,
  onClearDemoCheckins,
  isSavingCheckin,
  onNavigateTab
}: EvolutionViewProps) {
  const [subView, setSubView] = useState<EvolutionSubView>(() =>
    initialExerciseId ? 'exercise' : initialSubView || 'overview'
  );
  const [period, setPeriod] = useState<EvolutionPeriod>('30d');
  const [selectedExerciseId, setSelectedExerciseId] = useState<string | null>(
    () => initialExerciseId ?? null
  );
  const [showExerciseSelector, setShowExerciseSelector] = useState(false);
  const [showAllExercisesInOverview, setShowAllExercisesInOverview] = useState(false);

  // Estados da tela Histórico Completo
  const [historySearchQuery, setHistorySearchQuery] = useState('');
  const [historyCategoryFilter, setHistoryCategoryFilter] = useState('all');

  // Modal de detalhes de uma sessão
  const [inspectedWorkout, setInspectedWorkout] = useState<CompletedWorkout | null>(null);

  // Estado de check-ins biométricos
  const [checkinNote, setCheckinNote] = useState('');

  useEffect(() => {
    if (initialExerciseId) {
      setSelectedExerciseId(initialExerciseId);
      setSubView('exercise');
      onClearInitialExerciseId?.();
    }
  }, [initialExerciseId, onClearInitialExerciseId]);

  useEffect(() => {
    if (initialSubView) {
      setSubView(initialSubView);
      onClearInitialSubView?.();
    }
  }, [initialSubView, onClearInitialSubView]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    }
  }, [subView, selectedExerciseId]);

  // Histórico completo deduplicado e ordenado
  const allCompletedWorkouts = useMemo(
    () => deduplicateAndSortWorkouts(workoutHistory, 'desc'),
    [workoutHistory]
  );

  // Treinos filtrados pelo período selecionado
  const periodFilteredWorkouts = useMemo(
    () => filterWorkoutsByPeriod(allCompletedWorkouts, period),
    [allCompletedWorkouts, period]
  );

  // Indicadores principais da Visão Geral
  const targetWeeklyDays = profile?.diasSemana || 5;
  const overviewStats = useMemo(
    () => calculateEvolutionOverviewStats(periodFilteredWorkouts, targetWeeklyDays),
    [periodFilteredWorkouts, targetWeeklyDays]
  );

  // Série do gráfico de volume
  const volumeChartSeries = useMemo(
    () => groupVolumeByInterval(periodFilteredWorkouts, period),
    [periodFilteredWorkouts, period]
  );

  // Lista de exercícios registrados pelo usuário
  const registeredExercises = useMemo(
    () =>
      getRegisteredExercisesList(
        allCompletedWorkouts,
        lastExerciseWeights,
        dynamicWorkouts
      ),
    [allCompletedWorkouts, lastExerciseWeights, dynamicWorkouts]
  );

  // Exercício ativo para a tela de Evolução por Exercício
  const activeExerciseId = useMemo(() => {
    if (
      selectedExerciseId &&
      registeredExercises.some((e) => e.exerciseId === selectedExerciseId)
    ) {
      return selectedExerciseId;
    }
    return registeredExercises[0]?.exerciseId || null;
  }, [selectedExerciseId, registeredExercises]);

  const exerciseDetail = useMemo(() => {
    if (!activeExerciseId) return null;
    return getExerciseEvolutionDetail({
      exerciseId: activeExerciseId,
      workoutHistory: allCompletedWorkouts,
      period,
      lastExerciseWeights,
      dynamicWorkouts
    });
  }, [
    activeExerciseId,
    allCompletedWorkouts,
    period,
    lastExerciseWeights,
    dynamicWorkouts
  ]);

  // Feed filtrado do Histórico Completo
  const filteredHistoryFeed = useMemo(
    () =>
      filterWorkoutHistoryFeed({
        workoutHistory: allCompletedWorkouts,
        period,
        searchQuery: historySearchQuery,
        categoryFilter: historyCategoryFilter
      }),
    [allCompletedWorkouts, period, historySearchQuery, historyCategoryFilter]
  );

  const monthGroups = useMemo(
    () => groupWorkoutsByMonth(filteredHistoryFeed),
    [filteredHistoryFeed]
  );

  const availableCategories = useMemo(
    () => getAvailableHistoryCategories(allCompletedWorkouts),
    [allCompletedWorkouts]
  );

  // Check-ins reais vs simulados
  const { realCheckins, demoCheckins } = useMemo(
    () => splitCheckinsByOrigin(checkins),
    [checkins]
  );

  const handleOpenExerciseEvolution = (exerciseId: string) => {
    setSelectedExerciseId(exerciseId);
    setShowExerciseSelector(false);
    setSubView('exercise');
  };

  const handleSaveCheckin = () => {
    onAddCheckin(checkinNote);
    setCheckinNote('');
  };

  // ============================================================================
  // SUB-VIEW 2: EVOLUÇÃO POR EXERCÍCIO (Referência: evolu_o_supino_reto_com_barra)
  // ============================================================================
  if (subView === 'exercise' && exerciseDetail) {
    const lastLoadValue =
      exerciseDetail.lastRecord?.maxWeight || exerciseDetail.fallbackLastWeight || 0;

    return (
      <div className="flex flex-col w-full pb-8 space-y-4 text-[#F4F5F7]">
        {/* Sub-header Navigation Bar */}
        <div className="flex items-center justify-between pt-1">
          <button
            type="button"
            onClick={() => setSubView('overview')}
            className="flex items-center gap-1.5 text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors py-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-[15px] font-medium">Evolução</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('history')}
            className="px-3 py-2 rounded-xl bg-[#1A1D24] text-xs font-semibold text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors flex items-center gap-1.5"
          >
            <History className="w-4 h-4 text-[#D4AF37]" />
            <span>Histórico</span>
          </button>
        </div>

        {/* Exercise Title Card with Selector */}
        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 flex flex-col gap-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex flex-col gap-1 min-w-0">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#9CA3AF]">
                {exerciseDetail.groupLabel} · Histórico Comprovado
              </span>
              <h1 className="text-[22px] sm:text-[26px] leading-tight font-bold text-[#F4F5F7] tracking-tight break-words">
                {exerciseDetail.name}
              </h1>
            </div>
            <div className="w-11 h-11 rounded-xl bg-[#1A1D24] shrink-0 flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-[#D4AF37]" />
            </div>
          </div>

          {/* Seletor de Exercício */}
          {registeredExercises.length > 1 && (
            <div className="pt-0.5 space-y-2">
              <button
                type="button"
                onClick={() => setShowExerciseSelector((prev) => !prev)}
                aria-expanded={showExerciseSelector}
                className="w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#222631] px-3.5 flex items-center justify-between text-[#F4F5F7] transition-colors"
              >
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Repeat className="w-4 h-4 text-[#D4AF37]" />
                  <span>Trocar exercício ({registeredExercises.length})</span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-[#9CA3AF] transition-transform ${
                    showExerciseSelector ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {showExerciseSelector && (
                <div
                  role="listbox"
                  aria-label="Selecionar exercício"
                  className="bg-[#08090C] border border-white/10 rounded-xl p-1.5 max-h-60 overflow-y-auto space-y-1"
                >
                  {registeredExercises.map((ex) => {
                    const isCurrent = ex.exerciseId === exerciseDetail.exerciseId;
                    return (
                      <button
                        key={ex.exerciseId}
                        type="button"
                        role="option"
                        aria-selected={isCurrent}
                        onClick={() => handleOpenExerciseEvolution(ex.exerciseId)}
                        className={`w-full px-3 py-2.5 rounded-lg text-left flex items-center justify-between gap-2 transition-colors ${
                          isCurrent
                            ? 'bg-[#D4AF37]/15 text-[#D4AF37]'
                            : 'text-[#F4F5F7] hover:bg-[#1A1D24]'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="text-sm font-semibold truncate">{ex.name}</div>
                          <div className="text-[11px] text-[#9CA3AF]">
                            {ex.groupLabel} · {ex.sessionsCount}{' '}
                            {ex.sessionsCount === 1 ? 'sessão' : 'sessões'}
                          </div>
                        </div>
                        <span className="font-mono text-xs font-semibold shrink-0">
                          {ex.maxWeight} kg
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Filtro de Período */}
        <nav
          aria-label="Filtro de período do exercício"
          className="bg-[#1A1D24] p-1 rounded-xl flex items-center justify-between gap-1"
        >
          {PERIOD_OPTIONS.map((opt) => {
            const isActive = period === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => setPeriod(opt.id)}
                aria-pressed={isActive}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold text-center transition-colors ${
                  isActive
                    ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                    : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                }`}
              >
                {opt.label}
              </button>
            );
          })}
        </nav>

        {/* Key Stats Summary (Maior carga registrada & Última carga registrada) */}
        <div className="grid grid-cols-2 gap-3">
          {/* Card 1: Maior carga registrada no histórico */}
          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-3.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between gap-1">
                <span className="text-xs font-semibold text-[#9CA3AF]">
                  Maior carga
                </span>
                <Award className="w-4 h-4 text-[#D4AF37] shrink-0" />
              </div>
              <div className="flex items-baseline gap-1 pt-0.5">
                <span className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] font-mono">
                  {exerciseDetail.allTimeMaxWeight > 0
                    ? exerciseDetail.allTimeMaxWeight.toLocaleString('pt-BR')
                    : '—'}
                </span>
                {exerciseDetail.allTimeMaxWeight > 0 && (
                  <span className="font-mono text-sm font-semibold text-[#D4AF37]">
                    kg
                  </span>
                )}
              </div>
              <div className="text-xs text-[#9CA3AF]">
                {exerciseDetail.allTimeMaxReps
                  ? `Melhor série: ${exerciseDetail.allTimeMaxReps} reps`
                  : 'Maior marca no histórico'}
              </div>
            </div>

            <div className="mt-3 pt-2 border-t border-white/[0.05] text-[11px] text-[#D4AF37] flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
              <span>
                {exerciseDetail.allTimeMaxDateLabel
                  ? `Registrado em ${exerciseDetail.allTimeMaxDateLabel}`
                  : `${exerciseDetail.allTimeSessionsCount} sessões`}
              </span>
            </div>
          </div>

          {/* Card 2: Última carga registrada */}
          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-3.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between gap-1">
                <span className="text-xs font-semibold text-[#9CA3AF]">
                  Última carga
                </span>
                <History className="w-4 h-4 text-[#9CA3AF] shrink-0" />
              </div>
              <div className="flex items-baseline gap-1 pt-0.5">
                <span className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] font-mono">
                  {lastLoadValue > 0 ? lastLoadValue.toLocaleString('pt-BR') : '—'}
                </span>
                {lastLoadValue > 0 && (
                  <span className="font-mono text-sm font-medium text-[#9CA3AF]">
                    kg
                  </span>
                )}
              </div>
              <div className="text-xs text-[#9CA3AF]">
                {exerciseDetail.lastRecord
                  ? `${exerciseDetail.lastRecord.dateShortLabel}${
                      exerciseDetail.lastRecord.bestSetReps
                        ? ` · ${exerciseDetail.lastRecord.bestSetReps} reps`
                        : ''
                    }`
                  : 'Carga base salva'}
              </div>
            </div>

            <div className="mt-3 pt-2 border-t border-white/[0.05] text-[11px] text-[#9CA3AF] flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
              <span className="truncate">
                {exerciseDetail.lastRecord?.volumeKg
                  ? `Volume: ${exerciseDetail.lastRecord.volumeKg.toLocaleString('pt-BR')} kg`
                  : exerciseDetail.lastRecord
                  ? `${exerciseDetail.lastRecord.setsCompleted}/${exerciseDetail.lastRecord.totalSets} séries`
                  : 'Sem sessão registrada'}
              </span>
            </div>
          </div>
        </div>

        {/* Gráfico de Progressão do Exercício */}
        <ExerciseProgressionChart points={exerciseDetail.progressionPoints} />

        {/* Lista de Sessões Anteriores do Exercício */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#F4F5F7]">
                Histórico de sessões
              </h2>
              <span className="text-xs text-[#9CA3AF]">
                · {exerciseDetail.periodSessions.length}{' '}
                {exerciseDetail.periodSessions.length === 1
                  ? 'registro'
                  : 'registros'}
              </span>
            </div>
            {period !== 'all' &&
              exerciseDetail.allTimeSessionsCount >
                exerciseDetail.periodSessions.length && (
                <button
                  type="button"
                  onClick={() => setPeriod('all')}
                  className="text-xs font-semibold text-[#D4AF37] hover:underline"
                >
                  Ver todas ({exerciseDetail.allTimeSessionsCount})
                </button>
              )}
          </div>

          {exerciseDetail.periodSessions.length === 0 ? (
            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-5 text-center space-y-2">
              <p className="text-sm font-medium text-[#F4F5F7]">
                Nenhuma sessão deste exercício no período selecionado.
              </p>
              {period !== 'all' && (
                <button
                  type="button"
                  onClick={() => setPeriod('all')}
                  className="px-3.5 py-2 rounded-xl bg-[#1A1D24] text-xs font-semibold text-[#D4AF37]"
                >
                  Exibir todo o histórico
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {exerciseDetail.periodSessions.map((sess) => {
                const fullWk =
                  allCompletedWorkouts.find((w) => w.id === sess.workoutId) ||
                  null;

                return (
                  <article
                    key={sess.workoutId}
                    className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-[#1A1D24] flex items-center justify-center text-[#D4AF37] shrink-0 mt-0.5">
                          <Calendar className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-semibold text-[15px] text-[#F4F5F7]">
                              {sess.dateShortLabel}
                            </span>
                            {sess.isPersonalRecord && (
                              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#D4AF37]">
                                · Maior Carga
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-[#9CA3AF] truncate">
                            {sess.workoutTitle}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF]">
                          {typeof sess.volumeKg === 'number' && sess.volumeKg > 0
                            ? 'Volume'
                            : 'Maior Carga'}
                        </span>
                        <div className="font-mono text-sm font-bold text-[#F4F5F7]">
                          {typeof sess.volumeKg === 'number' && sess.volumeKg > 0
                            ? `${sess.volumeKg.toLocaleString('pt-BR')} kg`
                            : `${sess.maxWeight} kg`}
                        </div>
                      </div>
                    </div>

                    {/* REGRA DE INTEGRIDADE:
                        Se houver séries individuais salvas (setsDetail), mostra a tabela real de séries.
                        Se o registro for agregado (sem setsDetail), mostra apenas os indicadores comprovados sem reconstruir séries fictícias. */}
                    {sess.hasIndividualSets ? (
                      <div className="bg-[#1A1D24] rounded-xl p-2.5 space-y-1">
                        <div className="grid grid-cols-4 text-center text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF] pb-1 border-b border-white/[0.05]">
                          <span>SÉRIE</span>
                          <span>CARGA</span>
                          <span>REPS</span>
                          <span>STATUS</span>
                        </div>
                        {sess.setsDetail.map((setRow) => {
                          const isTopSet =
                            setRow.weight === sess.maxWeight && sess.maxWeight > 0;
                          return (
                            <div
                              key={setRow.setNumber}
                              className={`grid grid-cols-4 items-center text-center py-1.5 rounded-lg font-mono text-xs ${
                                isTopSet
                                  ? 'bg-[#13151A] text-[#D4AF37] font-bold'
                                  : 'text-[#F4F5F7]'
                              }`}
                            >
                              <span>{setRow.setNumber}</span>
                              <span>{setRow.weight} kg</span>
                              <span>{setRow.reps}</span>
                              <span className="flex items-center justify-center">
                                {isTopSet && sess.isPersonalRecord ? (
                                  <span className="text-[10px] uppercase font-sans font-bold text-[#D4AF37]">
                                    Pico
                                  </span>
                                ) : (
                                  <Check className="w-3.5 h-3.5 text-[#10B981]" />
                                )}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="bg-[#1A1D24] rounded-xl p-3 grid grid-cols-2 sm:grid-cols-3 gap-2 text-center">
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                            Maior carga
                          </div>
                          <div className="font-mono text-xs font-bold text-[#F4F5F7] mt-0.5">
                            {sess.maxWeight} kg
                            {sess.bestSetReps ? ` × ${sess.bestSetReps}` : ''}
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                            Séries feitas
                          </div>
                          <div className="font-mono text-xs font-bold text-[#F4F5F7] mt-0.5">
                            {sess.setsCompleted}/{sess.totalSets} séries
                          </div>
                        </div>
                        {typeof sess.volumeKg === 'number' && sess.volumeKg > 0 && (
                          <div className="col-span-2 sm:col-span-1">
                            <div className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                              Volume no exercício
                            </div>
                            <div className="font-mono text-xs font-bold text-[#D4AF37] mt-0.5">
                              {sess.volumeKg.toLocaleString('pt-BR')} kg
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {fullWk && (
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => setInspectedWorkout(fullWk)}
                          className="text-xs font-semibold text-[#D4AF37] hover:underline inline-flex items-center gap-1"
                        >
                          <span>Abrir detalhes da sessão</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </div>

        {/* Orientação para Registrar Novas Cargas na Arena */}
        <div className="bg-[#1A1D24] rounded-2xl p-4 flex items-center justify-between gap-3">
          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Para registrar novas séries neste exercício, inicie uma sessão na aba{' '}
            <strong className="text-[#F4F5F7]">Treinar</strong>.
          </p>
          {onNavigateTab && (
            <button
              type="button"
              onClick={() => onNavigateTab('executar')}
              className="px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold shrink-0"
            >
              Ir para Treinar
            </button>
          )}
        </div>

        <SessionDetailModal
          workout={inspectedWorkout}
          onClose={() => setInspectedWorkout(null)}
          onSelectExercise={handleOpenExerciseEvolution}
        />
      </div>
    );
  }

  // ============================================================================
  // SUB-VIEW 3: HISTÓRICO COMPLETO DE TREINOS (Referência: evolu_o_hist_rico_de_treinos)
  // ============================================================================
  if (subView === 'history') {
    return (
      <div className="flex flex-col w-full pb-8 space-y-4 text-[#F4F5F7]">
        {/* Top Navigation & Page Title */}
        <div className="flex flex-col pt-1 gap-1.5">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setSubView('overview')}
              aria-label="Voltar para Evolução"
              className="flex items-center gap-1.5 text-[#9CA3AF] hover:text-[#F4F5F7] py-1.5 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm font-medium">Voltar para Evolução</span>
            </button>

            <div className="flex items-center gap-1.5 bg-[#1A1D24] px-3 py-1.5 rounded-xl">
              <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="font-mono text-xs text-[#9CA3AF]">
                {allCompletedWorkouts.length}{' '}
                {allCompletedWorkouts.length === 1 ? 'sessão' : 'sessões'}
              </span>
            </div>
          </div>

          <h1 className="text-[24px] sm:text-[26px] font-bold text-[#F4F5F7] tracking-tight">
            Histórico de Treinos
          </h1>
          <p className="text-sm text-[#9CA3AF]">
            Todas as suas sessões registradas em ordem cronológica
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col gap-3">
          {/* Search Input */}
          <div className="relative w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9CA3AF] pointer-events-none" />
            <input
              type="search"
              value={historySearchQuery}
              onChange={(e) => setHistorySearchQuery(e.target.value)}
              placeholder="Buscar por treino ou exercício..."
              aria-label="Buscar por treino ou exercício"
              className="w-full h-11 pl-10 pr-9 rounded-xl bg-[#1A1D24] border border-white/[0.06] text-sm text-[#F4F5F7] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#D4AF37]"
            />
            {historySearchQuery && (
              <button
                type="button"
                onClick={() => setHistorySearchQuery('')}
                aria-label="Limpar busca"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 w-6 h-6 rounded-lg flex items-center justify-center text-[#9CA3AF] hover:text-[#F4F5F7]"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Period Filter Segmented Control */}
          <nav
            aria-label="Filtro de período do histórico"
            className="bg-[#1A1D24] p-1 rounded-xl flex items-center justify-between gap-1"
          >
            {PERIOD_OPTIONS.map((opt) => {
              const isActive = period === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setPeriod(opt.id)}
                  aria-pressed={isActive}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold text-center transition-colors ${
                    isActive
                      ? 'bg-[#D4AF37] text-[#08090C]'
                      : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </nav>

          {/* Category / Workout Filter Buttons */}
          {availableCategories.length > 1 && (
            <div
              role="group"
              aria-label="Filtrar por grupamento muscular"
              className="flex items-center gap-1.5 overflow-x-auto pb-1"
            >
              {availableCategories.map((cat) => {
                const isActive = historyCategoryFilter === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setHistoryCategoryFilter(cat.id)}
                    aria-pressed={isActive}
                    className={`h-9 px-3.5 rounded-xl text-xs font-semibold shrink-0 transition-colors ${
                      isActive
                        ? 'bg-[#D4AF37] text-[#08090C]'
                        : 'bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Feed Cronológico Agrupado por Mês */}
        {monthGroups.length === 0 ? (
          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-6 text-center space-y-3">
            <p className="text-sm font-semibold text-[#F4F5F7]">
              Nenhuma sessão encontrada para os filtros selecionados.
            </p>
            <p className="text-xs text-[#9CA3AF]">
              Experimente limpar a pesquisa ou selecionar o período &quot;Tudo&quot;.
            </p>
            <button
              type="button"
              onClick={() => {
                setHistorySearchQuery('');
                setHistoryCategoryFilter('all');
                setPeriod('all');
              }}
              className="px-4 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold"
            >
              Limpar filtros
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {monthGroups.map((group) => (
              <section key={group.monthKey} className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-medium text-[#9CA3AF]">
                    {group.monthLabel} ·{' '}
                    <strong className="text-[#F4F5F7]">
                      {group.workouts.length}{' '}
                      {group.workouts.length === 1
                        ? 'treino concluído'
                        : 'treinos concluídos'}
                    </strong>
                  </span>
                </div>

                <div className="space-y-3">
                  {group.workouts.map((wk) => {
                    const duration = formatDurationHoursMinutes(wk.durationSec);
                    const friendlyDate = formatSessionFriendlyDate(wk.timestamp);
                    const prExercise = (wk.exercisesSummary || []).find(
                      (ex) => ex.isPersonalRecord
                    );
                    const exercisesLine = (wk.exercisesSummary || [])
                      .filter((ex) => ex.setsCompleted > 0 || ex.maxWeight > 0)
                      .map((ex) => `${ex.name} (${ex.setsCompleted})`)
                      .join(', ');

                    return (
                      <article
                        key={wk.sessionId || wk.id}
                        onClick={() => setInspectedWorkout(wk)}
                        className="bg-[#13151A] border border-white/[0.06] hover:border-[#D4AF37]/30 rounded-2xl p-4 space-y-3 transition-colors cursor-pointer"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2 text-xs text-[#9CA3AF] mb-1">
                              <span>{wk.dayName}</span>
                              <span>·</span>
                              <span className="font-mono">{friendlyDate}</span>
                              {typeof wk.sessionRpe === 'number' && (
                                <>
                                  <span>·</span>
                                  <span className="font-mono text-[#D4AF37]">
                                    RPE {wk.sessionRpe}
                                  </span>
                                </>
                              )}
                            </div>
                            <h2 className="text-[17px] font-semibold text-[#F4F5F7] truncate">
                              {cleanDisplayText(wk.title)}
                            </h2>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setInspectedWorkout(wk);
                            }}
                            aria-label={`Ver detalhes de ${cleanDisplayText(wk.title)}`}
                            className="w-9 h-9 rounded-xl bg-[#1A1D24] text-[#9CA3AF] hover:text-[#F4F5F7] flex items-center justify-center shrink-0"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Recorde Pessoal (apenas quando comprovado na sessão) */}
                        {prExercise && (
                          <div className="flex items-center gap-2 bg-[#D4AF37]/10 px-3 py-2 rounded-xl text-[#D4AF37] text-xs font-medium">
                            <Award className="w-4 h-4 shrink-0" />
                            <span className="truncate">
                              Novo Recorde Pessoal: {prExercise.name} (
                              {prExercise.maxWeight} kg)
                            </span>
                          </div>
                        )}

                        {/* Linha de Métricas (Duração, Séries, Volume) */}
                        <div className="grid grid-cols-3 gap-2 bg-[#1A1D24] rounded-xl p-2.5 text-center">
                          <div className="flex flex-col items-center justify-center">
                            <Clock className="w-4 h-4 text-[#9CA3AF] mb-0.5" />
                            <span className="font-mono text-xs font-semibold text-[#F4F5F7]">
                              {duration.label}
                            </span>
                            <span className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                              Duração
                            </span>
                          </div>

                          <div className="flex flex-col items-center justify-center">
                            <Layers className="w-4 h-4 text-[#9CA3AF] mb-0.5" />
                            <span className="font-mono text-xs font-semibold text-[#F4F5F7]">
                              {wk.completedSets}
                            </span>
                            <span className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                              Séries
                            </span>
                          </div>

                          <div className="flex flex-col items-center justify-center">
                            <Dumbbell className="w-4 h-4 text-[#D4AF37] mb-0.5" />
                            <span className="font-mono text-xs font-semibold text-[#F4F5F7]">
                              {(wk.tonnage || 0).toLocaleString('pt-BR')} kg
                            </span>
                            <span className="text-[10px] uppercase tracking-wider text-[#9CA3AF]">
                              Volume
                            </span>
                          </div>
                        </div>

                        {/* Lista Resumida de Exercícios */}
                        {exercisesLine && (
                          <p className="text-xs text-[#9CA3AF] line-clamp-2 leading-relaxed">
                            {exercisesLine}
                          </p>
                        )}
                      </article>
                    );
                  })}
                </div>
              </section>
            ))}

            <div className="flex items-center justify-center gap-2 py-2 text-center">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]/60" />
              <span className="text-xs text-[#9CA3AF]">
                Mostrando {filteredHistoryFeed.length}{' '}
                {filteredHistoryFeed.length === 1
                  ? 'sessão registrada'
                  : 'sessões registradas'}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]/60" />
            </div>
          </div>
        )}

        <SessionDetailModal
          workout={inspectedWorkout}
          onClose={() => setInspectedWorkout(null)}
          onSelectExercise={handleOpenExerciseEvolution}
        />
      </div>
    );
  }

  // ============================================================================
  // SUB-VIEW 4: MEDIDAS REGISTRADAS / CHECK-INS BIOMÉTRICOS (Preservação Integral)
  // ============================================================================
  if (subView === 'measures') {
    return (
      <div className="flex flex-col w-full pb-8 space-y-5 text-[#F4F5F7]">
        {/* Top Bar */}
        <div className="flex items-center justify-between pt-1">
          <button
            type="button"
            onClick={() => setSubView('overview')}
            className="flex items-center gap-1.5 text-[#9CA3AF] hover:text-[#F4F5F7] py-1.5 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm font-medium">Voltar para Evolução</span>
          </button>

          <span className="text-xs font-mono text-[#D4AF37] bg-[#1A1D24] px-3 py-1.5 rounded-xl">
            Reais: {realCheckins.length}
            {demoCheckins.length > 0 ? ` · Simulação: ${demoCheckins.length}` : ''}
          </span>
        </div>

        <div>
          <h1 className="text-[24px] font-bold text-[#F4F5F7] tracking-tight">
            Medidas registradas
          </h1>
          <p className="text-sm text-[#9CA3AF]">
            Histórico de check-ins biométricos e acompanhamento corporal
          </p>
        </div>

        {/* Formulário de Novo Check-in */}
        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3.5">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37] flex items-center gap-1.5">
              <Ruler className="w-4 h-4" /> Registrar Check-in Biométrico
            </div>
            <p className="text-xs text-[#9CA3AF]">
              Salve suas medidas atuais: Peso ({metrics.peso} kg), Ombros (
              {metrics.ombros} cm), Cintura ({metrics.cintura} cm) e Braço (
              {metrics.braco} cm).
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <input
              type="text"
              placeholder="Ex: Avaliação mensal - Foco dorsal"
              value={checkinNote}
              onChange={(e) => setCheckinNote(e.target.value)}
              aria-label="Observação do check-in biométrico"
              className="flex-1 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3.5 py-2.5 text-sm text-[#F4F5F7] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              type="button"
              onClick={handleSaveCheckin}
              disabled={isSavingCheckin}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#08090C] font-bold text-xs sm:text-sm hover:brightness-105 transition disabled:opacity-50"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar Check-in</span>
            </button>
            {demoCheckins.length === 0 && (
              <button
                type="button"
                onClick={onSeedDemoEvolution}
                disabled={isSavingCheckin}
                className="px-3.5 py-2.5 rounded-xl bg-[#1A1D24] hover:bg-[#242832] text-[#D4AF37] text-xs font-semibold transition"
              >
                Simular 3 Meses
              </button>
            )}
          </div>
        </div>

        {/* Aviso quando há simulação ativa */}
        {demoCheckins.length > 0 && (
          <div className="bg-[#1A1D24] border border-[#D4AF37]/40 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
                  Simulação Demonstrativa Ativa ({demoCheckins.length} registros)
                </div>
                <p className="text-xs text-[#9CA3AF]">
                  Os registros marcados como{' '}
                  <strong className="text-[#F4F5F7]">Simulação Demonstrativa</strong>{' '}
                  são exemplos visuais e nunca são misturados às estatísticas reais de
                  treino ({realCheckins.length}{' '}
                  {realCheckins.length === 1
                    ? 'medição real salva'
                    : 'medições reais salvas'}
                  ).
                </p>
              </div>
            </div>
            {onClearDemoCheckins && (
              <button
                type="button"
                onClick={onClearDemoCheckins}
                className="px-3.5 py-2 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#D4AF37] text-xs font-bold shrink-0 transition"
              >
                Limpar Simulação
              </button>
            )}
          </div>
        )}

        {/* Lista de Check-ins */}
        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3.5">
          <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
            <h2 className="text-base font-bold text-[#F4F5F7]">
              Linha do Tempo de Medidas ({checkins.length})
            </h2>
            <span className="text-xs text-[#9CA3AF]">
              Proporção atual: Φ {goldenAnalysis.indiceAdonisAtual}
            </span>
          </div>

          {checkins.length === 0 ? (
            <div className="text-center py-8 space-y-2">
              <Ruler className="w-8 h-8 text-[#9CA3AF] mx-auto" />
              <div className="text-sm font-semibold text-[#F4F5F7]">
                Nenhum check-in registrado ainda
              </div>
              <p className="text-xs text-[#9CA3AF]">
                Salve seu primeiro check-in real acima ou utilize a simulação
                demonstrativa.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {checkins.map((chk) => {
                const isDemo = isDemoCheckin(chk);
                return (
                  <div
                    key={chk.id}
                    className={`rounded-xl p-3.5 space-y-3 border ${
                      isDemo
                        ? 'bg-[#08090C]/90 border-[#D4AF37]/35'
                        : 'bg-[#08090C] border-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2 min-w-0">
                        <span className="font-mono text-xs font-semibold text-[#D4AF37]">
                          {chk.dateFormatted}
                        </span>
                        <span>·</span>
                        <span
                          className={`text-[11px] font-semibold ${
                            isDemo ? 'text-[#D4AF37]' : 'text-[#10B981]'
                          }`}
                        >
                          {isDemo ? 'Simulação Demonstrativa' : 'Registro Real'}
                        </span>
                        <h3 className="font-semibold text-sm text-[#F4F5F7] truncate">
                          {cleanDisplayText(chk.note)}
                        </h3>
                      </div>

                      <button
                        type="button"
                        onClick={() => onDeleteCheckin(chk.id)}
                        aria-label={`Excluir check-in ${chk.note}`}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-[#9CA3AF] hover:text-rose-400 transition shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Peso</div>
                        <div className="font-mono text-xs font-bold text-[#F4F5F7]">
                          {chk.peso} kg
                        </div>
                      </div>
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Ombros</div>
                        <div className="font-mono text-xs font-bold text-[#F4F5F7]">
                          {chk.ombros} cm
                        </div>
                      </div>
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Cintura</div>
                        <div className="font-mono text-xs font-bold text-[#F4F5F7]">
                          {chk.cintura} cm
                        </div>
                      </div>
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Peito</div>
                        <div className="font-mono text-xs font-bold text-[#F4F5F7]">
                          {chk.peito} cm
                        </div>
                      </div>
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Braço</div>
                        <div className="font-mono text-xs font-bold text-[#F4F5F7]">
                          {chk.braco} cm
                        </div>
                      </div>
                      <div className="bg-[#13151A] p-2 rounded-lg">
                        <div className="text-[10px] text-[#9CA3AF]">Relação O/C</div>
                        <div className="font-mono text-xs font-bold text-[#D4AF37]">
                          {chk.indiceAdonis}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ============================================================================
  // SUB-VIEW 1 (PADRÃO): VISÃO GERAL DA EVOLUÇÃO & ESTADO VAZIO
  // ============================================================================
  const hasAnyCompletedWorkout = allCompletedWorkouts.length > 0;

  // ESTADO VAZIO (Referência: evolu_o_estado_vazio)
  if (!hasAnyCompletedWorkout) {
    return (
      <div className="flex flex-col w-full pb-8 space-y-5 text-[#F4F5F7]">
        {/* Header Section with Title & Period Selector */}
        <section className="flex flex-col gap-3.5 pt-1">
          <div className="flex items-center justify-between gap-2">
            <div className="flex flex-col">
              <span className="text-[11px] font-semibold uppercase tracking-widest text-[#D4AF37]">
                Métricas e Cargas
              </span>
              <h1 className="text-[26px] leading-tight font-bold text-[#F4F5F7] tracking-tight">
                Evolução
              </h1>
              <p className="text-sm text-[#9CA3AF] mt-0.5">
                Acompanhe seus treinos e seu desempenho.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setSubView('measures')}
              className="px-3 py-2 rounded-xl bg-[#1A1D24] hover:bg-[#222631] text-xs font-semibold text-[#F4F5F7] flex items-center gap-1.5 shrink-0 transition-colors"
            >
              <Ruler className="w-4 h-4 text-[#D4AF37]" />
              <span>Medidas ({realCheckins.length})</span>
            </button>
          </div>

          {/* Period Selector (Ghost/Disabled state when empty, with Tudo active) */}
          <div
            aria-label="Filtro de período"
            className="flex items-center justify-between p-1 bg-[#13151A] border border-white/[0.05] rounded-xl"
          >
            <button
              type="button"
              disabled
              className="flex-1 py-1.5 text-center text-xs font-semibold text-[#9CA3AF] opacity-40 cursor-not-allowed rounded-lg"
            >
              7 dias
            </button>
            <button
              type="button"
              disabled
              className="flex-1 py-1.5 text-center text-xs font-semibold text-[#9CA3AF] opacity-40 cursor-not-allowed rounded-lg"
            >
              30 dias
            </button>
            <button
              type="button"
              disabled
              className="flex-1 py-1.5 text-center text-xs font-semibold text-[#9CA3AF] opacity-40 cursor-not-allowed rounded-lg"
            >
              90 dias
            </button>
            <div className="flex-1 py-1.5 text-center text-xs font-semibold text-[#D4AF37] bg-[#1A1D24] rounded-lg">
              Tudo
            </div>
          </div>
        </section>

        {/* Empty State Hero Container */}
        <section className="flex flex-col items-center text-center p-6 bg-[#13151A] border border-white/[0.06] rounded-2xl relative overflow-hidden">
          {/* Geometric Milestone Vector Artwork */}
          <div className="relative w-24 h-24 mb-5 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-[#1A1D24]" />
            <div className="absolute inset-2 rounded-full bg-[#13151A]" />
            <svg
              className="relative w-12 h-12 text-[#D4AF37]"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 48 48"
              aria-hidden="true"
            >
              <circle
                cx="12"
                cy="34"
                r="2.5"
                fill="currentColor"
                fillOpacity="0.2"
                strokeWidth="1.5"
              />
              <circle
                cx="24"
                cy="24"
                r="2.5"
                fill="currentColor"
                fillOpacity="0.3"
                strokeWidth="1.5"
              />
              <circle cx="36" cy="14" r="3" fill="currentColor" strokeWidth="1.5" />
              <path
                d="M12 34L24 24L36 14"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path d="M36 8V10" strokeLinecap="round" strokeWidth="1.5" />
              <path d="M42 14H40" strokeLinecap="round" strokeWidth="1.5" />
              <path d="M40.5 9.5L39 11" strokeLinecap="round" strokeWidth="1.5" />
            </svg>
            <span className="absolute -bottom-1 font-mono text-[9px] tracking-wider text-[#D4AF37] bg-[#1A1D24] px-2 py-0.5 rounded-md font-semibold">
              AURUS · METRICS
            </span>
          </div>

          <h2 className="text-xl font-bold text-[#F4F5F7] tracking-tight mb-2">
            Seus treinos aparecerão aqui.
          </h2>
          <p className="text-sm text-[#9CA3AF] max-w-xs mb-6 leading-relaxed">
            Registre seus exercícios para acompanhar seu histórico.
          </p>

          <button
            type="button"
            onClick={() => onNavigateTab?.('executar')}
            className="w-full h-12 bg-[#D4AF37] hover:brightness-105 text-[#08090C] font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.99]"
          >
            <Dumbbell className="w-5 h-5" />
            <span>Ir para Treinar</span>
          </button>
        </section>

        {/* Se o usuário já possui cargas base salvas sem sessão concluída */}
        {registeredExercises.length > 0 && (
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-[#F4F5F7]">
                Cargas salvas na ficha ({registeredExercises.length})
              </h3>
              <span className="text-xs text-[#9CA3AF]">Aguardando 1ª sessão</span>
            </div>
            <div className="space-y-2">
              {registeredExercises.slice(0, 4).map((ex) => (
                <button
                  key={ex.exerciseId}
                  type="button"
                  onClick={() => handleOpenExerciseEvolution(ex.exerciseId)}
                  className="w-full bg-[#1A1D24] p-3 rounded-xl flex items-center justify-between text-left hover:bg-[#222631] transition-colors"
                >
                  <div>
                    <div className="text-sm font-semibold text-[#F4F5F7]">
                      {ex.name}
                    </div>
                    <div className="text-xs text-[#9CA3AF]">{ex.groupLabel}</div>
                  </div>
                  <span className="font-mono text-sm font-bold text-[#D4AF37]">
                    {ex.maxWeight} kg
                  </span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Educational Insight Guide Card */}
        <section className="flex flex-col bg-[#13151A] border border-white/[0.06] rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-base font-semibold text-[#F4F5F7]">
              O que o AURUS GYM analisa para você
            </h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#1A1D24] flex items-center justify-center shrink-0 mt-0.5">
                <BarChart3 className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-[#F4F5F7]">
                  Sobrecarga progressiva
                </h4>
                <p className="text-xs text-[#9CA3AF] leading-relaxed mt-0.5">
                  Acompanhe se você está aumentando cargas ou repetições semana a
                  semana.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#1A1D24] flex items-center justify-center shrink-0 mt-0.5">
                <Trophy className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-[#F4F5F7]">
                  Recordes Pessoais (PR)
                </h4>
                <p className="text-xs text-[#9CA3AF] leading-relaxed mt-0.5">
                  Identificação automática da sua maior carga comprovada em cada
                  exercício.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#1A1D24] flex items-center justify-center shrink-0 mt-0.5">
                <Calendar className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-[#F4F5F7]">
                  Volume e consistência
                </h4>
                <p className="text-xs text-[#9CA3AF] leading-relaxed mt-0.5">
                  Veja a tonelagem acumulada e a frequência das suas semanas de
                  treino.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Secondary Links: Biblioteca de Exercícios e Medidas Registradas */}
        <section className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={() => onNavigateTab?.('ia')}
            className="w-full h-12 bg-[#13151A] hover:bg-[#1A1D24] border border-white/[0.06] text-[#F4F5F7] font-medium text-sm rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <BookOpen className="w-4 h-4 text-[#9CA3AF]" />
            <span>Ver biblioteca de exercícios</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('measures')}
            className="w-full h-12 bg-[#13151A] hover:bg-[#1A1D24] border border-white/[0.06] text-[#F4F5F7] font-medium text-sm rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <Ruler className="w-4 h-4 text-[#D4AF37]" />
            <span>
              Medidas registradas ({realCheckins.length}{' '}
              {realCheckins.length === 1 ? 'registro real' : 'registros reais'})
            </span>
          </button>
        </section>
      </div>
    );
  }

  // VISÃO GERAL COM DADOS (Referência: evolu_o_vis_o_geral)
  const displayedExercises = showAllExercisesInOverview
    ? registeredExercises
    : registeredExercises.slice(0, 4);

  const recentWorkouts = periodFilteredWorkouts.length > 0
    ? periodFilteredWorkouts.slice(0, 3)
    : allCompletedWorkouts.slice(0, 3);

  return (
    <div className="flex flex-col w-full pb-8 space-y-5 text-[#F4F5F7]">
      {/* Header Section */}
      <header className="flex flex-col gap-1 pt-1">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-[26px] leading-tight font-bold text-[#F4F5F7] tracking-tight">
            Evolução
          </h1>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSubView('measures')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A1D24] hover:bg-[#222631] text-xs font-semibold text-[#F4F5F7] transition-colors"
            >
              <Ruler className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Medidas</span>
            </button>
            <button
              type="button"
              onClick={() => setSubView('history')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A1D24] hover:bg-[#222631] text-xs font-semibold text-[#D4AF37] transition-colors"
            >
              <History className="w-3.5 h-3.5" />
              <span>Histórico</span>
            </button>
          </div>
        </div>
        <p className="text-sm text-[#9CA3AF]">
          Acompanhe seus treinos e seu desempenho.
        </p>
      </header>

      {/* Filtro de Período (7 dias | 30 dias | 90 dias | Tudo) */}
      <nav
        aria-label="Filtro de período"
        className="bg-[#1A1D24] p-1 rounded-xl flex items-center justify-between gap-1"
      >
        {PERIOD_OPTIONS.map((opt) => {
          const isActive = period === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => setPeriod(opt.id)}
              aria-pressed={isActive}
              className={`flex-1 py-1.5 text-center rounded-lg text-xs font-semibold transition-colors ${
                isActive
                  ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                  : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
              }`}
            >
              {opt.label}
            </button>
          );
        })}
      </nav>

      {/* Grid 2x2 de Indicadores Principais */}
      <section aria-label="Métricas principais" className="grid grid-cols-2 gap-3">
        {/* Card 1: Treinos realizados */}
        <article className="bg-[#13151A] border border-white/[0.06] p-3.5 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9CA3AF] truncate">
              Treinos realizados
            </span>
            <CheckCircle2 className="w-4 h-4 text-[#9CA3AF] shrink-0" />
          </div>
          <div>
            <div className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] tracking-tight font-mono">
              {overviewStats.sessionsCount}{' '}
              <span className="text-xs font-sans font-normal text-[#9CA3AF]">
                {overviewStats.sessionsCount === 1 ? 'sessão' : 'sessões'}
              </span>
            </div>
            <div className="text-[11px] text-[#10B981] font-medium mt-1">
              {overviewStats.distinctTrainedDays}{' '}
              {overviewStats.distinctTrainedDays === 1
                ? 'dia distinto treinado'
                : 'dias distintos treinados'}
            </div>
          </div>
        </article>

        {/* Card 2: Tempo total de treinamento */}
        <article className="bg-[#13151A] border border-white/[0.06] p-3.5 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9CA3AF] truncate">
              Tempo total
            </span>
            <Clock className="w-4 h-4 text-[#9CA3AF] shrink-0" />
          </div>
          <div>
            <div className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] tracking-tight font-mono">
              {overviewStats.durationFormatted.label}
            </div>
            <div className="text-[11px] text-[#9CA3AF] mt-1">
              {overviewStats.sessionsCount > 0
                ? `Média: ${overviewStats.avgDurationMin} min / treino`
                : 'Sem sessões no período'}
            </div>
          </div>
        </article>

        {/* Card 3: Volume movimentado */}
        <article className="bg-[#13151A] border border-white/[0.06] p-3.5 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9CA3AF] truncate">
              Volume movimentado
            </span>
            <Dumbbell className="w-4 h-4 text-[#9CA3AF] shrink-0" />
          </div>
          <div>
            <div className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] tracking-tight font-mono">
              {overviewStats.volumeFormatted.value}{' '}
              <span className="text-xs font-sans font-normal text-[#9CA3AF]">
                {overviewStats.volumeFormatted.unit}
              </span>
            </div>
            <div className="text-[11px] text-[#9CA3AF] mt-1">
              {overviewStats.volumeFormatted.unit === 'ton'
                ? `${overviewStats.volumeFormatted.exactKgLabel} · ${overviewStats.totalCompletedSets} séries`
                : `${overviewStats.totalCompletedSets} séries concluídas`}
            </div>
          </div>
        </article>

        {/* Card 4: Frequência de treinamento */}
        <article className="bg-[#13151A] border border-white/[0.06] p-3.5 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9CA3AF] truncate">
              Frequência
            </span>
            <Calendar className="w-4 h-4 text-[#9CA3AF] shrink-0" />
          </div>
          <div>
            <div className="text-[26px] leading-tight font-extrabold text-[#F4F5F7] tracking-tight font-mono">
              {overviewStats.weeklyFrequency.toLocaleString('pt-BR')}
              <span className="text-xs font-sans font-normal text-[#9CA3AF]">
                x/sem
              </span>
            </div>
            <div className="text-[11px] text-[#9CA3AF] mt-1">
              Meta: {overviewStats.targetWeeklyDays}x por semana
            </div>
          </div>
        </article>
      </section>

      {/* Gráfico de Evolução de Volume */}
      <VolumeEvolutionChart
        series={volumeChartSeries}
        isFilteredPeriod={period !== 'all'}
        onResetFilterToAll={() => setPeriod('all')}
      />

      {/* Seção: Seus Exercícios */}
      <section aria-labelledby="exercises-title" className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 id="exercises-title" className="text-lg font-bold text-[#F4F5F7]">
            Seus exercícios
          </h2>
          {registeredExercises.length > 4 && (
            <button
              type="button"
              onClick={() => setShowAllExercisesInOverview((prev) => !prev)}
              className="text-xs font-semibold text-[#D4AF37] hover:underline flex items-center gap-0.5"
            >
              <span>
                {showAllExercisesInOverview
                  ? 'Mostrar menos'
                  : `Ver todos (${registeredExercises.length})`}
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {registeredExercises.length === 0 ? (
          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 text-xs text-[#9CA3AF]">
            Nenhum exercício com carga registrada nas sessões concluídas.
          </div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {displayedExercises.map((ex) => (
              <button
                key={ex.exerciseId}
                type="button"
                onClick={() => handleOpenExerciseEvolution(ex.exerciseId)}
                className="w-full bg-[#13151A] hover:bg-[#1A1D24] border border-white/[0.06] p-3.5 rounded-2xl flex items-center justify-between text-left transition-colors active:scale-[0.99]"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#1A1D24] flex items-center justify-center shrink-0">
                    <Dumbbell className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[15px] text-[#F4F5F7] truncate">
                        {ex.name}
                      </span>
                      <span className="text-[11px] text-[#9CA3AF] shrink-0">
                        · {ex.groupLabel}
                      </span>
                    </div>
                    <span className="text-xs text-[#9CA3AF] mt-0.5">
                      {ex.sessionsCount > 0
                        ? `Maior carga histórica · ${ex.sessionsCount} ${
                            ex.sessionsCount === 1 ? 'sessão' : 'sessões'
                          }`
                        : 'Carga base salva'}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0 pl-2">
                  <span className="font-mono text-[15px] font-bold text-[#F4F5F7]">
                    {ex.maxWeight.toLocaleString('pt-BR')} kg
                  </span>
                  {ex.weightDeltaKg !== null && ex.weightDeltaKg !== 0 ? (
                    <span
                      className={`font-mono text-[11px] font-semibold ${
                        ex.weightDeltaKg > 0 ? 'text-[#10B981]' : 'text-[#9CA3AF]'
                      }`}
                    >
                      {ex.weightDeltaKg > 0
                        ? `+${ex.weightDeltaKg.toLocaleString('pt-BR')} kg`
                        : `${ex.weightDeltaKg.toLocaleString('pt-BR')} kg`}
                    </span>
                  ) : (
                    <span className="text-[11px] text-[#9CA3AF]">
                      Última: {ex.lastWeight.toLocaleString('pt-BR')} kg
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Seção: Histórico Recente */}
      <section aria-labelledby="history-title" className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 id="history-title" className="text-lg font-bold text-[#F4F5F7]">
            Histórico recente
          </h2>
          <button
            type="button"
            onClick={() => setSubView('history')}
            className="text-xs font-semibold text-[#D4AF37] hover:underline flex items-center gap-0.5"
          >
            <span>Ver completo</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="flex flex-col gap-2.5">
          {recentWorkouts.map((wk) => {
            const duration = formatDurationHoursMinutes(wk.durationSec);
            const friendlyDate = formatSessionFriendlyDate(wk.timestamp);

            return (
              <button
                key={wk.sessionId || wk.id}
                type="button"
                onClick={() => setInspectedWorkout(wk)}
                className="w-full bg-[#13151A] hover:bg-[#1A1D24] border border-white/[0.06] p-4 rounded-2xl flex items-center justify-between text-left transition-colors"
              >
                <div className="flex flex-col min-w-0 pr-3">
                  <span className="font-semibold text-[16px] text-[#F4F5F7] truncate">
                    {cleanDisplayText(wk.title)}
                  </span>
                  <div className="flex items-center flex-wrap gap-x-2 gap-y-0.5 text-xs text-[#9CA3AF] mt-1">
                    <span>{friendlyDate}</span>
                    <span>•</span>
                    <span className="font-mono">{duration.label}</span>
                    <span>•</span>
                    <span className="font-mono">{wk.completedSets} séries</span>
                    <span>•</span>
                    <span className="font-mono text-[#F4F5F7] font-semibold">
                      {(wk.tonnage || 0).toLocaleString('pt-BR')} kg
                    </span>
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full bg-[#1A1D24] flex items-center justify-center shrink-0 text-[#9CA3AF]">
                  <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Seção Secundária: Medidas Registradas (Check-ins Biométricos Preservados) */}
      <section
        aria-labelledby="measures-card-title"
        className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-[#1A1D24] flex items-center justify-center shrink-0">
            <Ruler className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <div className="min-w-0">
            <h3
              id="measures-card-title"
              className="text-sm font-semibold text-[#F4F5F7]"
            >
              Medidas registradas
            </h3>
            <p className="text-xs text-[#9CA3AF] truncate">
              {realCheckins.length}{' '}
              {realCheckins.length === 1
                ? 'check-in real salvo'
                : 'check-ins reais salvos'}
              {demoCheckins.length > 0
                ? ` · ${demoCheckins.length} em simulação`
                : ` · Peso atual: ${metrics.peso} kg`}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setSubView('measures')}
          className="px-3.5 py-2 rounded-xl bg-[#1A1D24] hover:bg-[#242832] text-xs font-semibold text-[#D4AF37] shrink-0 transition-colors"
        >
          Gerenciar
        </button>
      </section>

      <SessionDetailModal
        workout={inspectedWorkout}
        onClose={() => setInspectedWorkout(null)}
        onSelectExercise={handleOpenExerciseEvolution}
      />
    </div>
  );
}
