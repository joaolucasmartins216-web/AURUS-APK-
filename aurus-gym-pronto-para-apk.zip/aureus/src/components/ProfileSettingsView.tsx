import React, { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Bell,
  BookOpen,
  Calendar,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Database,
  Download,
  Dumbbell,
  Edit3,
  Eye,
  FileJson,
  FileSpreadsheet,
  History,
  Info,
  Layers,
  LogOut,
  Palette,
  RefreshCw,
  Ruler,
  Settings,
  Shield,
  ShieldAlert,
  Sparkles,
  Trash2,
  Upload,
  User,
  Volume2,
  Wand2
} from 'lucide-react';
import {
  AppPreferences,
  BiometricMetrics,
  CheckinRecord,
  CompletedWorkout,
  GoldenAnalysis,
  UserProfile,
  WorkoutDay
} from '../types';
import { cleanDisplayText, isUserDataConfirmed } from '../utils/dashboardLogic';
import {
  calculateLocalStorageUsageBytes,
  exportWorkoutHistoryCSV,
  loadLastBackupAt
} from '../utils/storage';

export type ProfileSubView = 'profile_home' | 'edit_profile' | 'settings' | 'backup';

interface ProfileSettingsViewProps {
  subView: ProfileSubView;
  onChangeSubView: (view: ProfileSubView) => void;
  profile: UserProfile;
  metrics: BiometricMetrics;
  goldenAnalysis: GoldenAnalysis;
  onboardingCompleted: boolean;
  dynamicWorkouts: WorkoutDay[];
  workoutHistory: CompletedWorkout[];
  checkins: CheckinRecord[];
  catalogCount: number;
  preferences: AppPreferences;
  onUpdatePreferences: (updated: AppPreferences) => void;
  onSaveFullProfile: (updatedProfile: UserProfile) => void;
  onExportBackup: () => void;
  onImportBackup: (event: ChangeEvent<HTMLInputElement>) => void;
  onClearDemoCheckins: () => void;
  onResetWorkoutHistory: () => void;
  isSessionActive: boolean;
  googleUser: {
    name?: string;
    email?: string;
    photoURL?: string;
  } | null;
  onLogoutGoogle: () => void;
  onNavigateToRoutine: () => void;
  onNavigateToCoachIa: () => void;
  onNavigateToHistory: () => void;
  onNavigateToBiometrics: () => void;
  onNavigateToScanner3D: () => void;
  onNavigateToWorkspace: () => void;
  onOpenOnboardingTour: () => void;
  onShowToast: (msg: string, type?: 'emerald' | 'rose' | 'gold') => void;
}

const DAY_PILLS: Array<{ id: string; label: string }> = [
  { id: 'seg', label: 'Seg' },
  { id: 'ter', label: 'Ter' },
  { id: 'qua', label: 'Qua' },
  { id: 'qui', label: 'Qui' },
  { id: 'sex', label: 'Sex' },
  { id: 'sab', label: 'Sáb' },
  { id: 'dom', label: 'Dom' }
];

const OBJECTIVE_OPTIONS = [
  {
    id: 'Hipertrofia & Proporção Áurea',
    shortLabel: 'Hipertrofia'
  },
  {
    id: 'Ganho de Força Bruta',
    shortLabel: 'Ganho de força'
  },
  {
    id: 'Condicionamento Híbrido',
    shortLabel: 'Condicionamento'
  },
  {
    id: 'Definição & Recomposição',
    shortLabel: 'Resistência & Definição'
  }
];

const MODALITY_OPTIONS = [
  'Musculação',
  'Futsal / Esportes',
  'Cardio / Corrida',
  'Mobilidade'
];

const DURATION_OPTIONS = [45, 60, 75, 90];

export function ProfileSettingsView({
  subView,
  onChangeSubView,
  profile,
  metrics,
  onboardingCompleted,
  dynamicWorkouts,
  workoutHistory,
  checkins,
  catalogCount,
  preferences,
  onUpdatePreferences,
  onSaveFullProfile,
  onExportBackup,
  onImportBackup,
  onClearDemoCheckins,
  onResetWorkoutHistory,
  isSessionActive,
  googleUser,
  onLogoutGoogle,
  onNavigateToRoutine,
  onNavigateToCoachIa,
  onNavigateToHistory,
  onNavigateToBiometrics,
  onNavigateToScanner3D,
  onNavigateToWorkspace,
  onOpenOnboardingTour,
  onShowToast
}: ProfileSettingsViewProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0);
    }
  }, [subView]);

  // Estado local do formulário Editar Perfil
  const [draftName, setDraftName] = useState(profile.nome);
  const [draftObjective, setDraftObjective] = useState(profile.objetivoPrincipal);
  const [draftExperience, setDraftExperience] = useState<UserProfile['experiencia']>(
    profile.experiencia
  );
  const [draftModalities, setDraftModalities] = useState<string[]>(() => {
    if (Array.isArray(profile.modalidadesExtras) && profile.modalidadesExtras.length > 0) {
      return profile.modalidadesExtras;
    }
    const base = ['Musculação'];
    if (profile.esporteComplementar && !profile.esporteComplementar.toLowerCase().includes('nenhum')) {
      base.push('Futsal / Esportes');
    }
    return base;
  });
  const [draftDays, setDraftDays] = useState<string[]>(() =>
    profile.diasSelecionados && profile.diasSelecionados.length > 0
      ? profile.diasSelecionados
      : ['seg', 'ter', 'qua', 'qui', 'sex']
  );
  const [draftDurationMin, setDraftDurationMin] = useState<number>(
    profile.duracaoMediaMin || 60
  );
  const [draftNotes, setDraftNotes] = useState<string>(
    profile.observacoesFisiologicas || profile.focoMobilidade || ''
  );
  const [formError, setFormError] = useState<string | null>(null);

  // Estado para confirmação de exclusão de histórico em Dados e Backup
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [resetConfirmationText, setResetConfirmationText] = useState('');

  // Sincronizar rascunho ao abrir Editar Perfil
  const openEditProfile = () => {
    setDraftName(profile.nome);
    setDraftObjective(profile.objetivoPrincipal);
    setDraftExperience(profile.experiencia);
    setDraftModalities(
      Array.isArray(profile.modalidadesExtras) && profile.modalidadesExtras.length > 0
        ? profile.modalidadesExtras
        : ['Musculação', 'Futsal / Esportes']
    );
    setDraftDays(
      profile.diasSelecionados && profile.diasSelecionados.length > 0
        ? profile.diasSelecionados
        : ['seg', 'ter', 'qua', 'qui', 'sex']
    );
    setDraftDurationMin(profile.duracaoMediaMin || 60);
    setDraftNotes(profile.observacoesFisiologicas || profile.focoMobilidade || '');
    setFormError(null);
    onChangeSubView('edit_profile');
  };

  const isDemoValues = useMemo(
    () =>
      !isUserDataConfirmed({
        profile,
        metrics,
        onboardingCompleted
      }),
    [profile, metrics, onboardingCompleted]
  );

  const initials = useMemo(() => {
    return (
      (profile.nome || 'A')
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map((p) => p[0]?.toUpperCase() || '')
        .join('') || 'AG'
    );
  }, [profile.nome]);

  const formattedWeight = useMemo(() => {
    if (preferences.weightUnit === 'lbs') {
      return `${(metrics.peso * 2.20462).toFixed(1).replace('.', ',')}`;
    }
    return `${metrics.peso.toFixed(1).replace('.0', '').replace('.', ',')}`;
  }, [metrics.peso, preferences.weightUnit]);

  const formattedDaysSummary = useMemo(() => {
    const mapLabel: Record<string, string> = {
      seg: 'Seg',
      ter: 'Ter',
      qua: 'Qua',
      qui: 'Qui',
      sex: 'Sex',
      sab: 'Sáb',
      dom: 'Dom'
    };
    const labels = (profile.diasSelecionados || []).map((d) => mapLabel[d] || d);
    return `${labels.join(', ')} (${labels.length} ${labels.length === 1 ? 'dia' : 'dias'})`;
  }, [profile.diasSelecionados]);

  const handleToggleDraftModality = (mod: string) => {
    setDraftModalities((prev) =>
      prev.includes(mod) ? prev.filter((m) => m !== mod) : [...prev, mod]
    );
  };

  const handleToggleDraftDay = (dayId: string) => {
    setDraftDays((prev) => {
      if (prev.includes(dayId)) {
        if (prev.length <= 1) {
          setFormError('Mantenha pelo menos 1 dia ativo na sua programação semanal.');
          return prev;
        }
        setFormError(null);
        return prev.filter((id) => id !== dayId);
      }
      setFormError(null);
      return [...prev, dayId];
    });
  };

  const handleSaveProfileChanges = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = draftName.trim();
    if (!trimmedName) {
      setFormError('Por favor, informe seu nome para salvar o perfil.');
      return;
    }
    if (draftDays.length === 0) {
      setFormError('Selecione pelo menos 1 dia de treino por semana.');
      return;
    }

    const updatedProfile: UserProfile = {
      ...profile,
      nome: trimmedName,
      experiencia: draftExperience,
      objetivoPrincipal: draftObjective,
      diasSelecionados: draftDays,
      diasSemana: draftDays.length,
      duracaoMediaMin: draftDurationMin,
      observacoesFisiologicas: draftNotes.trim(),
      focoMobilidade: draftNotes.trim() || profile.focoMobilidade,
      modalidadesExtras: draftModalities.length > 0 ? draftModalities : ['Musculação'],
      esporteComplementar: draftModalities.includes('Futsal / Esportes')
        ? 'Futsal (1x a 2x/semana)'
        : 'Nenhum (Foco 100% Musculação)'
    };

    onSaveFullProfile(updatedProfile);
    onChangeSubView('profile_home');
  };

  const handleTogglePref = <K extends keyof AppPreferences>(
    key: K,
    value: AppPreferences[K]
  ) => {
    const next = {
      ...preferences,
      [key]: value
    };
    onUpdatePreferences(next);
  };

  // ============================================================================
  // SUBVIEW 2: EDITAR PERFIL (editar_perfil_aurus_gym)
  // ============================================================================
  if (subView === 'edit_profile') {
    return (
      <div className="max-w-lg mx-auto space-y-6 pb-20">
        {/* Top Bar */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onChangeSubView('profile_home')}
              aria-label="Voltar para Meu Perfil"
              className="w-10 h-10 rounded-xl bg-[#13151A] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-[#1A1D24] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold tracking-tight text-[#F4F5F7]">
              Editar Perfil
            </h1>
          </div>

          <div className="w-9 h-9 rounded-full bg-[#D4AF37] flex items-center justify-center text-[#08090C] font-bold text-xs">
            {initials}
          </div>
        </div>

        {/* Avatar Header */}
        <section className="flex flex-col items-center pt-1 pb-2">
          <div className="relative">
            <div className="w-24 h-24 rounded-full p-[2px] bg-gradient-to-tr from-[#D4AF37] via-[#D4AF37]/40 to-[#1A1D24]">
              {googleUser?.photoURL ? (
                <img
                  src={googleUser.photoURL}
                  alt={draftName || 'Atleta'}
                  className="w-full h-full rounded-full object-cover border-2 border-[#08090C]"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full rounded-full bg-[#13151A] border-2 border-[#08090C] flex items-center justify-center text-2xl font-extrabold text-[#D4AF37]">
                  {initials}
                </div>
              )}
            </div>
          </div>
          <p className="mt-3 text-sm font-bold text-[#F4F5F7]">
            {draftName || profile.nome}{' '}
            <span className="text-[#D4AF37] mx-1">•</span>
            <span className="text-[#9CA3AF] font-medium text-xs">
              {onboardingCompleted ? 'Perfil Ativo' : 'Configuração Inicial'}
            </span>
          </p>
        </section>

        <form onSubmit={handleSaveProfileChanges} className="space-y-5">
          {formError && (
            <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* 1. Dados Pessoais */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-[#D4AF37]" />
                <h2 className="text-sm font-bold text-[#F4F5F7]">Dados Pessoais</h2>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#10B981]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {onboardingCompleted ? 'Confirmado' : 'Editável'}
              </span>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="profile-name-input"
                className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]"
              >
                Nome Completo
              </label>
              <div className="relative flex items-center">
                <input
                  id="profile-name-input"
                  type="text"
                  value={draftName}
                  onChange={(e) => {
                    setDraftName(e.target.value);
                    if (formError) setFormError(null);
                  }}
                  placeholder="Digite seu nome"
                  className="w-full h-12 bg-[#1A1D24] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl px-4 pr-10 text-sm font-semibold text-[#F4F5F7] focus:outline-none transition-colors"
                />
                <Check className="w-4 h-4 text-[#10B981] absolute right-3.5 pointer-events-none" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Conta Google Workspace
                </span>
                <span className="text-[11px] text-[#9CA3AF]">
                  {googleUser?.email ? 'Sincronizado' : 'Opcional'}
                </span>
              </div>
              {googleUser?.email ? (
                <div className="w-full h-12 bg-[#0E1015] border border-white/[0.04] rounded-xl px-4 flex items-center justify-between text-sm text-[#9CA3AF]">
                  <span className="truncate">{googleUser.email}</span>
                  <Shield className="w-4 h-4 text-[#D4AF37] shrink-0" />
                </div>
              ) : (
                <div className="w-full bg-[#0E1015] border border-white/[0.05] rounded-xl p-3 flex items-center justify-between gap-2">
                  <span className="text-xs text-[#9CA3AF]">
                    Nenhuma conta Google conectada
                  </span>
                  <button
                    type="button"
                    onClick={onNavigateToWorkspace}
                    className="px-3 py-1.5 rounded-lg bg-[#1A1D24] hover:bg-[#232732] text-xs font-bold text-[#D4AF37] transition-colors cursor-pointer shrink-0"
                  >
                    Conectar
                  </button>
                </div>
              )}
            </div>
          </section>

          {/* 2. Preferências de Treinamento */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
            <div className="flex items-center gap-2">
              <Dumbbell className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="text-sm font-bold text-[#F4F5F7]">
                Preferências de Treinamento
              </h2>
            </div>

            {/* Objetivo Principal */}
            <div className="space-y-2">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Objetivo Principal
              </span>
              <div className="grid grid-cols-2 gap-2">
                {OBJECTIVE_OPTIONS.map((opt) => {
                  const isSelected =
                    draftObjective === opt.id ||
                    draftObjective.toLowerCase().includes(opt.shortLabel.toLowerCase());
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setDraftObjective(opt.id)}
                      className={`h-11 px-3 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                          : 'bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      <span className="truncate">{opt.shortLabel}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Nível de Experiência */}
            <div className="space-y-2">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Nível de Experiência
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['Iniciante', 'Intermediário', 'Avançado'] as const).map((lvl) => {
                  const isSelected = draftExperience === lvl;
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setDraftExperience(lvl)}
                      className={`h-11 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                          : 'bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Modalidades Praticadas */}
            <div className="space-y-2">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Modalidades Praticadas
              </span>
              <div className="flex flex-wrap gap-2">
                {MODALITY_OPTIONS.map((mod) => {
                  const active = draftModalities.includes(mod);
                  return (
                    <button
                      key={mod}
                      type="button"
                      onClick={() => handleToggleDraftModality(mod)}
                      className={`h-9 px-3.5 rounded-full text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                        active
                          ? 'bg-[#D4AF37] text-[#08090C]'
                          : 'bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {active && <Check className="w-3.5 h-3.5" />}
                      <span>{mod}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>

          {/* 3. Rotina e Disponibilidade */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="text-sm font-bold text-[#F4F5F7]">
                Rotina e Disponibilidade
              </h2>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Dias de Treino por Semana
                </span>
                <span className="font-mono text-xs font-bold text-[#D4AF37]">
                  {draftDays.length} {draftDays.length === 1 ? 'dia ativo' : 'dias ativos'}
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {DAY_PILLS.map((day) => {
                  const isSelected = draftDays.includes(day.id);
                  return (
                    <button
                      key={day.id}
                      type="button"
                      onClick={() => handleToggleDraftDay(day.id)}
                      className={`h-11 rounded-full text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                          : 'bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {day.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Duração Média Desejada
              </span>
              <div className="grid grid-cols-4 gap-2">
                {DURATION_OPTIONS.map((min) => {
                  const isSelected = draftDurationMin === min;
                  return (
                    <button
                      key={min}
                      type="button"
                      onClick={() => setDraftDurationMin(min)}
                      className={`h-10 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#D4AF37] text-[#08090C]'
                          : 'bg-[#1A1D24] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                      }`}
                    >
                      {min}m
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="profile-notes-textarea"
                className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]"
              >
                Observações Físicas & Articulações
              </label>
              <textarea
                id="profile-notes-textarea"
                rows={2}
                value={draftNotes}
                onChange={(e) => setDraftNotes(e.target.value)}
                placeholder="Ex.: Preservação de manguito rotador, mobilidade de quadril..."
                className="w-full bg-[#1A1D24] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl p-3 text-xs text-[#F4F5F7] placeholder:text-[#9CA3AF]/60 focus:outline-none transition-colors resize-none"
              />
            </div>
          </section>

          {/* Info Note */}
          <div className="bg-[#13151A]/80 border border-white/[0.05] rounded-2xl p-3.5 flex items-start gap-3">
            <Info className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              Essas informações ajudam a calcular metas e sugerir rotinas personalizadas sem alterar seus dados históricos de treino.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-1">
            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-sm inline-flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar alterações</span>
            </button>

            <button
              type="button"
              onClick={() => onChangeSubView('profile_home')}
              className="w-full h-11 rounded-xl bg-[#13151A] hover:bg-[#1A1D24] border border-white/[0.06] text-xs font-semibold text-[#9CA3AF] hover:text-[#F4F5F7] transition-colors cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    );
  }

  // ============================================================================
  // SUBVIEW 3: CONFIGURAÇÕES (configura_es_aurus_gym)
  // ============================================================================
  if (subView === 'settings') {
    return (
      <div className="max-w-lg mx-auto space-y-5 pb-20">
        {/* Top Bar */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onChangeSubView('profile_home')}
              aria-label="Voltar para Meu Perfil"
              className="w-10 h-10 rounded-xl bg-[#13151A] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-[#1A1D24] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold tracking-tight text-[#F4F5F7]">
              Configurações
            </h1>
          </div>

          <div className="w-9 h-9 rounded-full bg-[#D4AF37] flex items-center justify-center text-[#08090C] font-bold text-xs">
            {initials}
          </div>
        </div>

        {/* Status Card */}
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/25 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Settings className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-[#F4F5F7] truncate">
                Preferências Gerais
              </h2>
              <p className="text-xs text-[#9CA3AF] truncate">
                Salvo automaticamente neste dispositivo
              </p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[10px] font-bold uppercase tracking-wider text-[#D4AF37] shrink-0">
            • ATIVO
          </span>
        </section>

        {/* 1. Aparência */}
        <section className="space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Palette className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Aparência
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05]">
            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">Tema visual</div>
                <div className="text-xs text-[#9CA3AF]">
                  Modo escuro profundo ativo (otimizado para AMOLED)
                </div>
              </div>
              <span className="px-3 py-1.5 rounded-xl bg-[#1A1D24] border border-white/[0.08] text-xs font-bold text-[#F4F5F7]">
                Escuro
              </span>
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Contraste reforçado
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Aumentar contraste dos textos e bordas dos cards
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.enhancedContrast}
                onChange={(v) => handleTogglePref('enhancedContrast', v)}
                label="Alternar contraste reforçado"
              />
            </div>
          </div>
        </section>

        {/* 2. Treino e Sons */}
        <section className="space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Volume2 className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Treino e Sons
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05]">
            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Avisos sonoros no descanso
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Emitir bipe sonoro ao concluir o cronômetro de recuperação
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.restSoundEnabled}
                onChange={(v) => handleTogglePref('restSoundEnabled', v)}
                label="Alternar avisos sonoros no descanso"
              />
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Vibração ao finalizar série
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Feedback tátil na confirmação de séries e descanso
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.vibrationEnabled}
                onChange={(v) => handleTogglePref('vibrationEnabled', v)}
                label="Alternar vibração ao finalizar série"
              />
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">Manter tela ativa</div>
                <div className="text-xs text-[#9CA3AF]">
                  Solicitar bloqueio de suspensão durante sessões na Arena
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.keepScreenAwake}
                onChange={(v) => handleTogglePref('keepScreenAwake', v)}
                label="Alternar manter tela ativa"
              />
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">Unidade de medida</div>
                <div className="text-xs text-[#9CA3AF]">
                  Padrão de exibição para peso corporal e cargas
                </div>
              </div>
              <div className="inline-flex p-1 rounded-xl bg-[#1A1D24] border border-white/[0.06]">
                {(['kg', 'lbs'] as const).map((unit) => (
                  <button
                    key={unit}
                    type="button"
                    onClick={() => handleTogglePref('weightUnit', unit)}
                    className={`px-3 py-1 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer ${
                      preferences.weightUnit === unit
                        ? 'bg-[#D4AF37] text-[#08090C]'
                        : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    {unit}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 3. Notificações e Agenda */}
        <section className="space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Bell className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Notificações e Rotina
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05]">
            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">Lembrete de treino</div>
                <div className="text-xs text-[#9CA3AF]">
                  Destacar horário programado no Dashboard e Agenda
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.workoutReminderEnabled}
                onChange={(v) => handleTogglePref('workoutReminderEnabled', v)}
                label="Alternar lembrete de treino"
              />
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <label
                  htmlFor="preferred-time-input"
                  className="text-sm font-bold text-[#F4F5F7] block"
                >
                  Horário preferido
                </label>
                <div className="text-xs text-[#9CA3AF]">
                  Momento padrão da rotina diária
                </div>
              </div>
              <div className="flex items-center gap-1.5 bg-[#1A1D24] border border-white/[0.08] rounded-xl px-3 py-1.5">
                <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                <input
                  id="preferred-time-input"
                  type="time"
                  value={preferences.preferredWorkoutTime}
                  onChange={(e) =>
                    handleTogglePref('preferredWorkoutTime', e.target.value || '18:00')
                  }
                  className="bg-transparent font-mono text-xs font-bold text-[#F4F5F7] focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Resumo semanal de evolução
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Exibir consolidado semanal na tela Inicial e Evolução
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.weeklySummaryEnabled}
                onChange={(v) => handleTogglePref('weeklySummaryEnabled', v)}
                label="Alternar resumo semanal"
              />
            </div>
          </div>
        </section>

        {/* 4. Acessibilidade */}
        <section className="space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Activity className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Acessibilidade
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05]">
            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">Tamanho do texto</div>
                <div className="text-xs text-[#9CA3AF]">
                  Escala tipográfica nos treinos e cards
                </div>
              </div>
              <div className="inline-flex p-1 rounded-xl bg-[#1A1D24] border border-white/[0.06]">
                {(
                  [
                    { id: 'default', label: 'Padrão' },
                    { id: 'large', label: 'Grande' }
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleTogglePref('textScale', opt.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      preferences.textScale === opt.id
                        ? 'bg-[#D4AF37] text-[#08090C]'
                        : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Redução de movimento
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Minimizar transições e animações visuais no app
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.reducedMotion}
                onChange={(v) => handleTogglePref('reducedMotion', v)}
                label="Alternar redução de movimento"
              />
            </div>
          </div>
        </section>

        {/* 5. Privacidade */}
        <section className="space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Shield className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Privacidade
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05]">
            <div className="p-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-[#F4F5F7]">
                  Histórico em modo discreto
                </div>
                <div className="text-xs text-[#9CA3AF]">
                  Ocultar peso corporal nos cartões de resumo rápido
                </div>
              </div>
              <ToggleSwitch
                checked={preferences.privateHistoryMode}
                onChange={(v) => handleTogglePref('privateHistoryMode', v)}
                label="Alternar modo discreto"
              />
            </div>
          </div>
        </section>

        <footer className="text-center pt-2 space-y-1">
          <div className="text-[11px] font-mono font-bold text-[#D4AF37]">
            • AURUS GYM • ARQUITETURA DE ALTA PERFORMANCE
          </div>
          <p className="text-[11px] text-[#9CA3AF]">
            Preferências persistidas localmente com integridade imediata
          </p>
        </footer>
      </div>
    );
  }

  // ============================================================================
  // SUBVIEW 4: DADOS E BACKUP (dados_e_backup_aurus_gym)
  // ============================================================================
  if (subView === 'backup') {
    const storageStats = calculateLocalStorageUsageBytes();
    const lastBackupIso = loadLastBackupAt();
    const lastBackupLabel = lastBackupIso
      ? new Date(lastBackupIso).toLocaleString('pt-BR', {
          day: '2-digit',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit'
        })
      : 'Nenhum backup exportado ainda';
    const hasDemoCheckins = checkins.some((c) => c.id.startsWith('chk_demo_'));

    return (
      <div className="max-w-lg mx-auto space-y-5 pb-20">
        {/* Top Bar */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onChangeSubView('profile_home')}
              aria-label="Voltar para Meu Perfil"
              className="w-10 h-10 rounded-xl bg-[#13151A] border border-white/[0.06] flex items-center justify-center text-[#F4F5F7] hover:bg-[#1A1D24] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold tracking-tight text-[#F4F5F7]">
              Dados e Backup
            </h1>
          </div>

          <div className="w-9 h-9 rounded-full bg-[#D4AF37] flex items-center justify-center text-[#08090C] font-bold text-xs">
            {initials}
          </div>
        </div>

        {/* Status de Armazenamento Local Real */}
        <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-[#F4F5F7]">
                  Status de Armazenamento
                </h2>
                <p className="text-xs text-[#9CA3AF]">Persistência Local no Navegador</p>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 text-[10px] font-bold text-[#10B981]">
              • íntegro
            </span>
          </div>

          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Seus treinos, medidas e rotinas estão salvos no armazenamento local deste dispositivo. Exporte cópias em JSON para transferir ou proteger seu histórico.
          </p>

          <div className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-center justify-between text-xs">
            <span className="text-[#9CA3AF] flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
              Último backup exportado:
            </span>
            <span className="font-mono font-bold text-[#F4F5F7]">{lastBackupLabel}</span>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05] text-center">
              <div className="font-mono text-sm font-extrabold text-[#F4F5F7]">
                {storageStats.formattedSize}
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Memória
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05] text-center">
              <div className="font-mono text-sm font-extrabold text-[#F4F5F7]">
                {workoutHistory.length}{' '}
                <span className="text-xs font-normal text-[#9CA3AF]">sessões</span>
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Histórico
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05] text-center">
              <div className="font-mono text-sm font-extrabold text-[#D4AF37]">
                {catalogCount}{' '}
                <span className="text-xs font-normal text-[#9CA3AF]">exerc.</span>
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
                Catálogo
              </div>
            </div>
          </div>
        </section>

        {/* Exportar Dados */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 px-1">
            <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Exportar Dados
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              Gere um arquivo consolidado contendo seu histórico de cargas, rotinas personalizadas, check-ins biométricos e preferências.
            </p>

            <button
              type="button"
              onClick={onExportBackup}
              className="w-full h-12 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] font-bold text-xs sm:text-sm inline-flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] cursor-pointer"
            >
              <FileJson className="w-4 h-4 stroke-[2.3]" />
              <span>Exportar backup completo (.json)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                exportWorkoutHistoryCSV(workoutHistory, checkins);
                onShowToast('Planilha CSV exportada com sucesso!', 'emerald');
              }}
              className="w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.07] text-[#F4F5F7] font-bold text-xs inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#D4AF37]" />
              <span>Exportar para planilha (.csv)</span>
            </button>
          </div>
        </section>

        {/* Importar e Restaurar */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 px-1">
            <Upload className="w-3.5 h-3.5 text-[#D4AF37]" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
              Importar e Restaurar
            </h2>
          </div>

          <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={onImportBackup}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-6 px-4 rounded-xl border border-dashed border-[#D4AF37]/40 bg-[#1A1D24]/60 hover:bg-[#1A1D24] transition-colors flex flex-col items-center justify-center gap-2 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-[#13151A] border border-white/[0.08] flex items-center justify-center text-[#D4AF37]">
                <Upload className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-[#F4F5F7]">
                Selecionar arquivo de backup
              </span>
              <span className="text-[11px] text-[#9CA3AF]">
                Suporta arquivos .json gerados pelo AURUS GYM
              </span>
            </button>

            <div className="p-3 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/25 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
              <p className="text-[11px] text-[#9CA3AF] leading-relaxed">
                O arquivo será validado antes da restauração. Se houver uma sessão ativa na Arena, você poderá optar por preservá-la.
              </p>
            </div>
          </div>
        </section>

        {/* Zona de Segurança */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 px-1">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <h2 className="text-[11px] font-bold uppercase tracking-widest text-rose-400">
              Zona de Segurança
            </h2>
          </div>

          <div className="bg-[#13151A] border border-rose-500/20 rounded-2xl p-4 space-y-3">
            {hasDemoCheckins && (
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/[0.05]">
                <div>
                  <div className="text-xs font-bold text-[#F4F5F7]">
                    Remover check-ins demonstrativos
                  </div>
                  <div className="text-[11px] text-[#9CA3AF]">
                    Limpa apenas a simulação trimestral mantendo seus dados reais
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onClearDemoCheckins}
                  className="px-3 py-2 rounded-xl bg-[#1A1D24] hover:bg-[#252A36] text-xs font-bold text-[#D4AF37] shrink-0 cursor-pointer"
                >
                  Limpar Demo
                </button>
              </div>
            )}

            <div className="space-y-2.5">
              <div className="text-xs font-bold text-[#F4F5F7]">
                Redefinir histórico de treinos
              </div>
              <p className="text-[11px] text-[#9CA3AF] leading-relaxed">
                Remove todas as sessões concluídas e cargas salvas neste dispositivo. Exporte um backup antes de prosseguir.
              </p>
              <button
                type="button"
                onClick={() => {
                  setResetConfirmationText('');
                  setShowResetConfirmModal(true);
                }}
                className="w-full h-11 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/30 text-rose-200 font-bold text-xs inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4 text-rose-400" />
                <span>Redefinir histórico de treinos</span>
              </button>
            </div>
          </div>
        </section>

        {/* Modal de Confirmação Explícita para Redefinir Histórico */}
        {showResetConfirmModal && (
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="reset-history-modal-title"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="w-full max-w-md bg-[#13151A] border border-rose-500/30 rounded-2xl p-5 space-y-4 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-950/80 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3
                    id="reset-history-modal-title"
                    className="text-base font-extrabold text-[#F4F5F7]"
                  >
                    Confirmar redefinição de histórico
                  </h3>
                  <p className="text-xs text-[#9CA3AF]">
                    Esta ação apagará {workoutHistory.length} sessões registradas.
                  </p>
                </div>
              </div>

              {isSessionActive && (
                <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-500/30 text-xs text-amber-200">
                  Atenção: Você possui um treino em andamento na Arena. Seu rascunho atual na Arena será preservado, mas o histórico anterior será limpo.
                </div>
              )}

              <div className="space-y-1.5">
                <label
                  htmlFor="confirm-delete-input"
                  className="block text-xs text-[#9CA3AF]"
                >
                  Para confirmar, digite <strong className="text-rose-300">EXCLUIR</strong> no campo abaixo:
                </label>
                <input
                  id="confirm-delete-input"
                  type="text"
                  value={resetConfirmationText}
                  onChange={(e) => setResetConfirmationText(e.target.value)}
                  placeholder="Digite EXCLUIR"
                  className="w-full h-11 bg-[#1A1D24] border border-white/[0.08] focus:border-rose-400 rounded-xl px-3.5 text-sm font-mono font-bold text-[#F4F5F7] focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => setShowResetConfirmModal(false)}
                  className="flex-1 h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] text-xs font-bold text-[#F4F5F7] cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={resetConfirmationText.trim().toUpperCase() !== 'EXCLUIR'}
                  onClick={() => {
                    onResetWorkoutHistory();
                    setShowResetConfirmModal(false);
                  }}
                  className="flex-1 h-11 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-xs font-bold text-white cursor-pointer transition-opacity"
                >
                  Apagar Histórico
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ============================================================================
  // SUBVIEW 1 (DEFAULT): MEU PERFIL (meu_perfil_aurus_gy._m)
  // ============================================================================
  return (
    <div className="max-w-lg mx-auto space-y-6 pb-20">
      {/* Hero Card do Perfil */}
      <section className="relative bg-[#13151A] border border-white/[0.06] rounded-2xl p-5 overflow-hidden shadow-xl">
        {/* Badge de Status Real */}
        <div className="flex items-start justify-between gap-3">
          <div className="relative">
            <div className="w-20 h-20 rounded-full p-[2px] bg-gradient-to-tr from-[#D4AF37] via-[#D4AF37]/40 to-[#1A1D24]">
              {googleUser?.photoURL ? (
                <img
                  src={googleUser.photoURL}
                  alt={profile.nome}
                  className="w-full h-full rounded-full object-cover border-2 border-[#08090C]"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full rounded-full bg-[#1A1D24] border-2 border-[#08090C] flex items-center justify-center text-xl font-extrabold text-[#D4AF37]">
                  {initials}
                </div>
              )}
            </div>
            <span
              className="w-4 h-4 rounded-full bg-[#10B981] border-2 border-[#13151A] absolute bottom-0.5 right-0.5"
              title="Perfil Ativo"
            />
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1A1D24] border border-[#D4AF37]/30 text-[11px] font-bold text-[#D4AF37]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{onboardingCompleted ? 'Perfil Ativo' : 'Perfil Inicial'}</span>
          </span>
        </div>

        {/* Nome & Resumo */}
        <div className="mt-4 space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight">
              {profile.nome}
            </h1>
            {onboardingCompleted && (
              <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0" />
            )}
          </div>
          <p className="text-xs sm:text-[13px] text-[#9CA3AF]">
            {profile.experiencia} · {profile.diasSelecionados.length} treinos/semana ·{' '}
            {cleanDisplayText(profile.objetivoPrincipal)}
          </p>
        </div>

        {/* Faixa de 3 Métricas Reais */}
        <div className="mt-5 grid grid-cols-3 divide-x divide-white/[0.06] bg-[#0D0F14] border border-white/[0.05] rounded-xl py-3">
          <div className="text-center px-2">
            <div className="font-mono text-lg font-extrabold text-[#F4F5F7]">
              {workoutHistory.length}
            </div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
              Treinos
            </div>
          </div>

          <div className="text-center px-2">
            <div className="font-mono text-lg font-extrabold text-[#F4F5F7]">
              {preferences.privateHistoryMode ? '•••' : formattedWeight}
              <span className="text-xs font-normal text-[#9CA3AF] ml-0.5">
                {preferences.weightUnit}
              </span>
            </div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
              {isDemoValues ? 'Peso (Padrão)' : 'Peso'}
            </div>
          </div>

          <div className="text-center px-2">
            <div className="font-mono text-lg font-extrabold text-[#D4AF37]">
              {profile.diasSelecionados.length}
              <span className="text-xs font-normal text-[#9CA3AF] ml-1">dias/sem</span>
            </div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF] mt-0.5">
              Frequência
            </div>
          </div>
        </div>

        {/* Botão Editar Perfil */}
        <button
          type="button"
          onClick={openEditProfile}
          className="mt-4 w-full h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#F4F5F7] inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Edit3 className="w-4 h-4 text-[#D4AF37]" />
          <span>Editar perfil</span>
        </button>
      </section>

      {/* SEÇÃO 1: TREINAMENTO */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
            Treinamento
          </span>
          <span className="text-[11px] font-bold text-[#D4AF37]">Prescrição Ativa</span>
        </div>

        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05] overflow-hidden">
          <ProfileNavRow
            icon={Dumbbell}
            title="Minha rotina"
            subtitle={`${dynamicWorkouts.length} divisões ativas · Peito, Costas, Pernas e Ombros`}
            onClick={onNavigateToRoutine}
          />
          <ProfileNavRow
            icon={Calendar}
            title="Dias de treino"
            subtitle={formattedDaysSummary}
            onClick={openEditProfile}
          />
          <ProfileNavRow
            icon={Layers}
            title="Preferências de exercícios"
            subtitle={
              profile.preferenciaExercicios || 'Foco em compostos e pesos livres'
            }
            onClick={openEditProfile}
          />
          <ProfileNavRow
            icon={Activity}
            title="Experiência com musculação"
            subtitle={`Nível ${profile.experiencia} · Sessões de ~${
              profile.duracaoMediaMin || 60
            } min`}
            onClick={openEditProfile}
          />
        </div>
      </section>

      {/* SEÇÃO 2: ACOMPANHAMENTO */}
      <section className="space-y-2">
        <div className="px-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
            Acompanhamento
          </span>
        </div>

        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05] overflow-hidden">
          <ProfileNavRow
            icon={History}
            title="Histórico de treinos"
            subtitle={
              workoutHistory.length > 0
                ? `${workoutHistory.length} ${
                    workoutHistory.length === 1
                      ? 'sessão concluída'
                      : 'sessões concluídas'
                  }`
                : 'Nenhuma sessão concluída ainda'
            }
            onClick={onNavigateToHistory}
          />
          <ProfileNavRow
            icon={Ruler}
            title="Medidas e biometria"
            subtitle={
              isDemoValues
                ? `Valores iniciais (${formattedWeight} ${preferences.weightUnit}) · Toque para calibrar`
                : `Peso registrado: ${formattedWeight} ${preferences.weightUnit} · Proporções e circunferências`
            }
            onClick={onNavigateToBiometrics}
          />
          <ProfileNavRow
            icon={Eye}
            title="Scanner corporal 3D"
            subtitle="Visualização anatômica e simetria"
            badge="ATIVO"
            onClick={onNavigateToScanner3D}
          />
        </div>
      </section>

      {/* SEÇÃO 3: FERRAMENTAS */}
      <section className="space-y-2">
        <div className="px-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
            Ferramentas
          </span>
        </div>

        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05] overflow-hidden">
          <ProfileNavRow
            icon={Wand2}
            title="Coach IA"
            subtitle="Assistente pessoal de rotina e ajustes"
            onClick={onNavigateToCoachIa}
          />
          <ProfileNavRow
            icon={Calendar}
            title="Google Agenda"
            subtitle={
              googleUser?.email
                ? `Conectado · ${googleUser.email}`
                : 'Desconectado · Agende seus treinos na nuvem'
            }
            statusDot={googleUser ? 'emerald' : undefined}
            onClick={onNavigateToWorkspace}
          />
          <ProfileNavRow
            icon={BookOpen}
            title="Integrações"
            subtitle="Google Agenda e Gmail OAuth"
            onClick={onNavigateToWorkspace}
          />
        </div>
      </section>

      {/* SEÇÃO 4: APLICATIVO */}
      <section className="space-y-2">
        <div className="px-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#9CA3AF]">
            Aplicativo
          </span>
        </div>

        <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl divide-y divide-white/[0.05] overflow-hidden">
          <ProfileNavRow
            icon={Settings}
            title="Configurações"
            subtitle="Aparência, notificações e som"
            onClick={() => onChangeSubView('settings')}
          />
          <ProfileNavRow
            icon={Database}
            title="Dados e backup"
            subtitle="Exportação JSON/CSV e armazenamento local"
            onClick={() => onChangeSubView('backup')}
          />
          <ProfileNavRow
            icon={RefreshCw}
            title="Configuração inicial (Onboarding)"
            subtitle="Rever apresentação e assistente de boas-vindas"
            onClick={onOpenOnboardingTour}
          />
        </div>
      </section>

      {/* Rodapé do Perfil */}
      <footer className="pt-2 text-center space-y-3">
        <div className="font-mono text-[11px] text-[#9CA3AF]">
          AURUS GYM • Base Biomecânica & Proporção Áurea
        </div>

        {googleUser && (
          <button
            type="button"
            onClick={onLogoutGoogle}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#13151A] hover:bg-rose-950/40 border border-white/[0.06] text-xs font-semibold text-[#9CA3AF] hover:text-rose-300 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Desconectar conta Google</span>
          </button>
        )}
      </footer>
    </div>
  );
}

// ============================================================================
// COMPONENTES AUXILIARES DE UI (LINHAS DE MENU E SWITCH)
// ============================================================================
function ProfileNavRow({
  icon: Icon,
  title,
  subtitle,
  badge,
  statusDot,
  onClick
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  badge?: string;
  statusDot?: 'emerald' | 'gold';
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full p-4 flex items-center justify-between gap-3 text-left hover:bg-[#1A1D24]/70 transition-colors cursor-pointer"
    >
      <div className="flex items-center gap-3.5 min-w-0">
        <div className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-center justify-center text-[#D4AF37] shrink-0">
          <Icon className="w-4 h-4" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-[#F4F5F7] truncate">{title}</span>
            {statusDot === 'emerald' && (
              <span className="w-2 h-2 rounded-full bg-[#10B981] shrink-0" />
            )}
            {badge && (
              <span className="px-2 py-0.5 rounded-md bg-[#10B981]/15 text-[#10B981] text-[10px] font-bold uppercase tracking-wider shrink-0">
                {badge}
              </span>
            )}
          </div>
          <p className="text-xs text-[#9CA3AF] truncate mt-0.5">{subtitle}</p>
        </div>
      </div>

      <ChevronRight className="w-4 h-4 text-[#9CA3AF] shrink-0" />
    </button>
  );
}

function ToggleSwitch({
  checked,
  onChange,
  label
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`w-12 h-7 rounded-full p-0.5 transition-colors shrink-0 cursor-pointer flex items-center ${
        checked ? 'bg-[#D4AF37]' : 'bg-[#252934]'
      }`}
    >
      <span
        className={`w-6 h-6 rounded-full transition-transform shadow-md ${
          checked
            ? 'translate-x-5 bg-[#08090C]'
            : 'translate-x-0 bg-[#9CA3AF]'
        }`}
      />
    </button>
  );
}
