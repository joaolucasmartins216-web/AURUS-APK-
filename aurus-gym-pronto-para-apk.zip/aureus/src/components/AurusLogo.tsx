import React from 'react';

interface AurusLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * Monograma vetorial local confiável da marca AURUS GYM.
 * Substitui as imagens externas quebradas do Stitch por um emblema geométrico em SVG
 * utilizando a paleta oficial (#07080A, #14161B, #1B1E24 e #D4AF37).
 */
export function AurusLogo({ size = 'md', className = '' }: AurusLogoProps) {
  const dimensions =
    size === 'sm' ? 'w-8 h-8 rounded-lg' : size === 'lg' ? 'w-11 h-11 rounded-xl' : 'w-9 h-9 rounded-xl';

  return (
    <div
      className={`${dimensions} bg-[#14161B] border border-[#D4AF37]/35 flex items-center justify-center shrink-0 shadow-[0_0_14px_rgba(212,175,55,0.12)] ${className}`}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-6 h-6"
      >
        {/* Moldura hexagonal sutil */}
        <path
          d="M18 3L31 10.5V25.5L18 33L5 25.5V10.5L18 3Z"
          stroke="#D4AF37"
          strokeOpacity="0.35"
          strokeWidth="1.4"
        />
        {/* Monograma 'A' geométrico estilizado com barra de haltere */}
        <path
          d="M18 8.5L25.5 26H22.2L20.6 22H15.4L13.8 26H10.5L18 8.5ZM19.4 18.8L18 14.9L16.6 18.8H19.4Z"
          fill="#D4AF37"
        />
        {/* Eixo central Φ / Haltere */}
        <rect x="8.5" y="17.2" width="3" height="1.8" rx="0.9" fill="#E6C76A" />
        <rect x="24.5" y="17.2" width="3" height="1.8" rx="0.9" fill="#E6C76A" />
      </svg>
    </div>
  );
}
