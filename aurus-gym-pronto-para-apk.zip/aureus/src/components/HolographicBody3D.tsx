import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { BodyPartAnalysis, BodyPartKey } from '../types';

interface HolographicBody3DProps {
  parts: Record<BodyPartKey, BodyPartAnalysis>;
  selectedPartKey: BodyPartKey;
  onSelectPart: (key: BodyPartKey) => void;
}

export function HolographicBody3D({
  parts,
  selectedPartKey,
  onSelectPart
}: HolographicBody3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [wireframeOnly, setWireframeOnly] = useState(false);
  const [cameraPreset, setCameraPreset] = useState<'front' | 'profile' | 'back'>('front');

  const partMeshesRef = useRef<THREE.Mesh[]>([]);
  const avatarGroupRef = useRef<THREE.Group | null>(null);
  const rotationRef = useRef({ y: 0.25, x: 0.05 });
  const autoRotateRef = useRef(autoRotate);
  const selectedKeyRef = useRef(selectedPartKey);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    selectedKeyRef.current = selectedPartKey;
  }, [selectedPartKey]);

  const getPartHexColor = useCallback((partData?: BodyPartAnalysis) => {
    if (!partData) return 0x38bdf8;
    if (partData.colorZone === 'red') return 0xef4444; // Red: Needs improvement / Priority
    if (partData.colorZone === 'amber') return 0xf59e0b; // Amber: Close to target
    return 0x10b981; // Green: Target reached / Maintenance
  }, []);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 420;
    const height = container.clientHeight || 520;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.3, 6.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'default' });
    } catch {
      // Fallback
      renderer = new THREE.WebGLRenderer({ alpha: true });
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Holographic Ambient & Directional Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLightFront = new THREE.DirectionalLight(0xffffff, 0.9);
    dirLightFront.position.set(3, 5, 5);
    scene.add(dirLightFront);

    const dirLightBack = new THREE.DirectionalLight(0xd4af37, 0.65);
    dirLightBack.position.set(-4, -2, -4);
    scene.add(dirLightBack);

    const avatarGroup = new THREE.Group();
    avatarGroupRef.current = avatarGroup;
    scene.add(avatarGroup);

    // Phi Holographic Scanner Platform Base
    const baseRingGeo = new THREE.RingGeometry(1.15, 1.22, 64);
    const baseRingMat = new THREE.MeshBasicMaterial({
      color: 0xd4af37,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.55
    });
    const baseRing = new THREE.Mesh(baseRingGeo, baseRingMat);
    baseRing.rotation.x = Math.PI / 2;
    baseRing.position.y = -2.05;
    avatarGroup.add(baseRing);

    const innerGridGeo = new THREE.CircleGeometry(1.12, 32);
    const innerGridMat = new THREE.MeshBasicMaterial({
      color: 0x0ea5e9,
      wireframe: true,
      transparent: true,
      opacity: 0.18
    });
    const innerGrid = new THREE.Mesh(innerGridGeo, innerGridMat);
    innerGrid.rotation.x = Math.PI / 2;
    innerGrid.position.y = -2.06;
    avatarGroup.add(innerGrid);

    const meshesList: THREE.Mesh[] = [];

    const createAnatomicalPart = (
      geometry: THREE.BufferGeometry,
      partKey: BodyPartKey | null,
      position: [number, number, number],
      scale: [number, number, number] = [1, 1, 1],
      rotation: [number, number, number] = [0, 0, 0]
    ) => {
      const isNeutral = !partKey;
      const baseColor = isNeutral ? 0x38bdf8 : getPartHexColor(parts[partKey]);

      const solidMat = new THREE.MeshPhongMaterial({
        color: baseColor,
        emissive: baseColor,
        emissiveIntensity: isNeutral ? 0.15 : 0.35,
        transparent: true,
        opacity: isNeutral ? 0.25 : 0.62,
        shininess: 90,
        depthWrite: false
      });

      const wireMat = new THREE.MeshBasicMaterial({
        color: baseColor,
        wireframe: true,
        transparent: true,
        opacity: isNeutral ? 0.2 : 0.55
      });

      const mesh = new THREE.Mesh(geometry, solidMat);
      mesh.position.set(...position);
      mesh.scale.set(...scale);
      mesh.rotation.set(...rotation);
      mesh.userData = { partKey, isSolid: true, wireMat, solidMat };

      const wireMesh = new THREE.Mesh(geometry, wireMat);
      mesh.add(wireMesh);

      avatarGroup.add(mesh);
      if (partKey) {
        meshesList.push(mesh);
      }
      return mesh;
    };

    // 1. Head (Holographic Neutral)
    createAnatomicalPart(new THREE.SphereGeometry(0.24, 20, 20), null, [0, 1.72, 0], [0.88, 1.12, 0.95]);

    // 2. Neck ('pescoco')
    createAnatomicalPart(new THREE.CylinderGeometry(0.11, 0.13, 0.22, 18), 'pescoco', [0, 1.43, 0]);

    // 3. Shoulders / Deltoids & Traps ('ombros')
    createAnatomicalPart(new THREE.SphereGeometry(0.21, 18, 18), 'ombros', [-0.52, 1.18, 0], [1.05, 0.95, 0.95]);
    createAnatomicalPart(new THREE.SphereGeometry(0.21, 18, 18), 'ombros', [0.52, 1.18, 0], [1.05, 0.95, 0.95]);
    createAnatomicalPart(new THREE.CylinderGeometry(0.11, 0.11, 0.96, 16), 'ombros', [0, 1.24, -0.03], [1, 1, 0.65], [0, 0, Math.PI / 2]);

    // 4. Chest / Torax ('peito')
    createAnatomicalPart(new THREE.CylinderGeometry(0.42, 0.33, 0.56, 24), 'peito', [0, 0.92, 0], [1.08, 1, 0.68]);

    // 5. Waist / Core ('cintura')
    createAnatomicalPart(new THREE.CylinderGeometry(0.31, 0.29, 0.42, 24), 'cintura', [0, 0.44, 0], [1.0, 1, 0.66]);

    // 6. Hips / Pelvis ('quadril')
    createAnatomicalPart(new THREE.CylinderGeometry(0.32, 0.34, 0.28, 24), 'quadril', [0, 0.08, 0], [1.04, 1, 0.72]);

    // 7. Arms - Biceps & Triceps ('braco')
    createAnatomicalPart(new THREE.CylinderGeometry(0.125, 0.105, 0.48, 18), 'braco', [-0.6, 0.84, 0], [1, 1, 1], [0, 0, 0.12]);
    createAnatomicalPart(new THREE.CylinderGeometry(0.125, 0.105, 0.48, 18), 'braco', [0.6, 0.84, 0], [1, 1, 1], [0, 0, -0.12]);

    // Forearms and Hands (Neutral)
    createAnatomicalPart(new THREE.CylinderGeometry(0.095, 0.07, 0.46, 16), null, [-0.68, 0.36, 0.04], [1, 1, 1], [-0.1, 0, 0.1]);
    createAnatomicalPart(new THREE.CylinderGeometry(0.095, 0.07, 0.46, 16), null, [0.68, 0.36, 0.04], [1, 1, 1], [-0.1, 0, -0.1]);

    // 8. Thighs - Quads & Hamstrings ('coxa')
    createAnatomicalPart(new THREE.CylinderGeometry(0.195, 0.145, 0.78, 22), 'coxa', [-0.22, -0.48, 0], [1.02, 1, 1.05], [0, 0, -0.03]);
    createAnatomicalPart(new THREE.CylinderGeometry(0.195, 0.145, 0.78, 22), 'coxa', [0.22, -0.48, 0], [1.02, 1, 1.05], [0, 0, 0.03]);

    // Knees (Neutral)
    createAnatomicalPart(new THREE.SphereGeometry(0.135, 16, 16), null, [-0.23, -0.92, 0.02], [1, 0.85, 0.9]);
    createAnatomicalPart(new THREE.SphereGeometry(0.135, 16, 16), null, [0.23, -0.92, 0.02], [1, 0.85, 0.9]);

    // 9. Calves ('panturrilha')
    createAnatomicalPart(new THREE.CylinderGeometry(0.135, 0.085, 0.76, 20), 'panturrilha', [-0.23, -1.38, -0.02]);
    createAnatomicalPart(new THREE.CylinderGeometry(0.135, 0.085, 0.76, 20), 'panturrilha', [0.23, -1.38, -0.02]);

    // Feet (Neutral)
    createAnatomicalPart(new THREE.BoxGeometry(0.16, 0.1, 0.32), null, [-0.23, -1.85, 0.06]);
    createAnatomicalPart(new THREE.BoxGeometry(0.16, 0.1, 0.32), null, [0.23, -1.85, 0.06]);

    partMeshesRef.current = meshesList;

    // Mouse / Touch Dragging and Raycaster Click Selection
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let movedDistance = 0;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      movedDistance = 0;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      startX = clientX;
      startY = clientY;
    };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const deltaX = clientX - startX;
      const deltaY = clientY - startY;
      movedDistance += Math.abs(deltaX) + Math.abs(deltaY);

      rotationRef.current.y += deltaX * 0.01;
      rotationRef.current.x = Math.max(-0.4, Math.min(0.4, rotationRef.current.x + deltaY * 0.006));
      startX = clientX;
      startY = clientY;
    };

    const handlePointerUp = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      isDragging = false;

      // Click hit detection
      if (movedDistance < 8 && !('touches' in e)) {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(partMeshesRef.current, false);
        if (intersects.length > 0) {
          const hitKey = intersects[0].object.userData?.partKey as BodyPartKey;
          if (hitKey && onSelectPart) {
            onSelectPart(hitKey);
          }
        }
      }
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    domElem.addEventListener('touchstart', handlePointerDown, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerUp);

    // Animation Loop
    let animFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      if (autoRotateRef.current && !isDragging) {
        rotationRef.current.y += 0.0055;
      }

      if (avatarGroupRef.current) {
        avatarGroupRef.current.rotation.y = rotationRef.current.y;
        avatarGroupRef.current.rotation.x = rotationRef.current.x;
      }

      partMeshesRef.current.forEach((mesh) => {
        const pKey = mesh.userData.partKey;
        const isSelected = pKey === selectedKeyRef.current;
        const pulse = 0.35 + Math.sin(elapsed * 4.0) * 0.18;

        if (isSelected) {
          mesh.userData.solidMat.emissiveIntensity = 0.8;
        } else if (mesh.userData.isRedZone) {
          mesh.userData.solidMat.emissiveIntensity = pulse;
        } else {
          mesh.userData.solidMat.emissiveIntensity = 0.28;
        }
      });

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 420;
      const h = container.clientHeight || 520;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', handleResize);
      domElem.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      domElem.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
      renderer.dispose();
    };
  }, [getPartHexColor, onSelectPart, parts]);

  // Dynamically update colors when metric values or targets change
  useEffect(() => {
    if (!partMeshesRef.current.length) return;
    partMeshesRef.current.forEach((mesh) => {
      const pKey = mesh.userData.partKey as BodyPartKey;
      const partData = parts[pKey];
      if (!partData) return;
      const hex = getPartHexColor(partData);
      mesh.userData.solidMat.color.setHex(hex);
      mesh.userData.solidMat.emissive.setHex(hex);
      mesh.userData.wireMat.color.setHex(hex);
      mesh.userData.isRedZone = partData.colorZone === 'red';
      mesh.userData.solidMat.opacity = wireframeOnly ? 0.12 : 0.64;
      mesh.userData.wireMat.opacity = wireframeOnly ? 0.85 : 0.5;
    });
  }, [parts, wireframeOnly, getPartHexColor]);

  const applyCameraPreset = (preset: 'front' | 'profile' | 'back') => {
    setCameraPreset(preset);
    setAutoRotate(false);
    if (preset === 'front') rotationRef.current = { y: 0, x: 0.04 };
    if (preset === 'back') rotationRef.current = { y: Math.PI, x: 0.04 };
    if (preset === 'profile') rotationRef.current = { y: -Math.PI / 4, x: 0.06 };
  };

  return (
    <div
      data-testid="holographic-3d-canvas"
      className="relative bg-gradient-to-b from-[#0B0D12] via-[#07080A] to-[#0E1117] border border-zinc-800/90 rounded-2xl overflow-hidden flex flex-col h-[460px] sm:h-[520px] shadow-xl"
    >
      {/* Top HUD */}
      <div className="absolute top-2.5 left-2.5 right-2.5 z-20 flex flex-wrap items-center justify-between gap-1.5 pointer-events-none">
        <div className="bg-[#07080A]/90 backdrop-blur-md border border-zinc-800 px-2.5 py-1.5 rounded-xl pointer-events-auto">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-wider text-[#D4AF37]">
              Scanner Biométrico 3D // Φ 1.618
            </span>
          </div>
          <p className="text-[9px] sm:text-[10px] text-zinc-400">
            Arraste para girar 360° ou toque em uma região
          </p>
        </div>

        {/* View Controls */}
        <div className="flex items-center gap-1 bg-[#07080A]/90 backdrop-blur-md border border-zinc-800 p-1 rounded-xl pointer-events-auto">
          <button
            type="button"
            onClick={() => applyCameraPreset('front')}
            className={`px-2 py-1 min-h-[28px] rounded-lg text-[10px] font-bold transition ${
              cameraPreset === 'front' && !autoRotate
                ? 'bg-[#D4AF37] text-zinc-950'
                : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            Frente
          </button>
          <button
            type="button"
            onClick={() => applyCameraPreset('profile')}
            className={`px-2 py-1 min-h-[28px] rounded-lg text-[10px] font-bold transition ${
              cameraPreset === 'profile' && !autoRotate
                ? 'bg-[#D4AF37] text-zinc-950'
                : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            3/4
          </button>
          <button
            type="button"
            onClick={() => applyCameraPreset('back')}
            className={`px-2 py-1 min-h-[28px] rounded-lg text-[10px] font-bold transition ${
              cameraPreset === 'back' && !autoRotate
                ? 'bg-[#D4AF37] text-zinc-950'
                : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            Costas
          </button>
          <button
            type="button"
            onClick={() => setAutoRotate((prev) => !prev)}
            className={`px-2 py-1 min-h-[28px] rounded-lg text-[10px] font-bold transition ${
              autoRotate
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-zinc-400 hover:bg-zinc-800'
            }`}
          >
            360°
          </button>
          <button
            type="button"
            onClick={() => setWireframeOnly((prev) => !prev)}
            className={`px-2 py-1 min-h-[28px] rounded-lg text-[10px] font-bold transition ${
              wireframeOnly
                ? 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40'
                : 'text-zinc-400 hover:bg-zinc-800'
            }`}
          >
            Raio-X
          </button>
        </div>
      </div>

      {/* Floating Part Selector List */}
      <div className="absolute left-2.5 top-24 bottom-14 z-20 flex flex-col justify-center gap-1 pointer-events-none">
        {Object.values(parts).map((p) => {
          const isSelected = selectedPartKey === p.key;
          const dotColor =
            p.colorZone === 'red'
              ? 'bg-rose-500'
              : p.colorZone === 'amber'
              ? 'bg-amber-400'
              : 'bg-emerald-400';

          return (
            <button
              key={p.key}
              type="button"
              onClick={() => onSelectPart(p.key)}
              className={`pointer-events-auto flex items-center gap-1.5 px-2.5 py-1.5 min-h-[30px] rounded-lg border text-left transition backdrop-blur-md ${
                isSelected
                  ? 'bg-[#12151E]/95 border-[#D4AF37] text-white shadow-md'
                  : 'bg-[#07080A]/80 border-zinc-800/90 text-zinc-300 hover:border-zinc-700'
              }`}
            >
              <span className={`w-2 h-2 rounded-full shrink-0 ${dotColor}`} />
              <span className="text-[10px] sm:text-[11px] font-bold">{p.shortLabel}</span>
            </button>
          );
        })}
      </div>

      {/* Canvas Element */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Bottom Color Legend */}
      <div className="absolute bottom-2.5 left-2.5 right-2.5 z-20 bg-[#07080A]/90 backdrop-blur-md border border-zinc-800/90 rounded-xl px-2.5 py-1.5 flex flex-wrap items-center justify-between gap-1.5 text-[10px] sm:text-[11px]">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-rose-500" />
          <span className="text-rose-300 font-bold">Vermelho: Prioridade</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-400" />
          <span className="text-amber-300 font-bold">Âmbar: Próximo</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-emerald-300 font-bold">Verde: Simetria OK</span>
        </div>
      </div>
    </div>
  );
}
