import React, { useMemo, useState } from 'react';
import {
  Activity,
  ArrowLeft,
  Award,
  CheckCircle2,
  ChevronRight,
  Compass,
  Dumbbell,
  Edit3,
  Eye,
  History,
  Info,
  Layers,
  Plus,
  Ruler,
  Sparkles,
  Target,
  Trash2,
  Wand2
} from 'lucide-react';
import {
  BiometricMetrics,
  BodyPartKey,
  CheckinRecord,
  CompletedWorkout,
  GoldenAnalysis,
  UserProfile
} from '../types';
import { isDemoCheckin, isUserDataConfirmed } from '../utils/dashboardLogic';
import { HolographicBody3D } from './HolographicBody3D';

export type ScannerSubTab = 'scanner_viewport' | 'region_details' | 'measurements_log';

interface Scanner3DViewProps {
  goldenAnalysis: GoldenAnalysis;
  selectedPartKey: BodyPartKey;
  onSelectPart: (key: BodyPartKey) => void;
  onOpenWizard: () => void;
  onGenerateAiWorkout: () => void;
  isGeneratingAi: boolean;
  profile?: UserProfile;
  metrics?: BiometricMetrics;
  onboardingCompleted?: boolean;
  workoutHistory?: CompletedWorkout[];
  checkins?: CheckinRecord[];
  onAddCheckin?: (note: string) => void;
  onDeleteCheckin?: (id: string) => void;
  onSeedDemoEvolution?: () => void;
  onClearDemoCheckins?: () => void;
}

const RECOMMENDED_EXERCISES_BY_PART: Record<BodyPartKey, string[]> = {
  ombros: [
    'Desenvolvimento com Halteres',
    'Elevação Lateral no Cabo',
    'Crucifixo Inverso (Deltoide Posterior)'
  ],
  peito: [
    'Supino Inclinado com Halteres (30°)',
    'Supino Reto com Barra Olímpica',
    'Crossover Polia Alta / Média'
  ],
  braco: [
    'Rosca Direta Barra W',
    'Rosca Inclinada 45° com Halteres',
    'Tríceps Testa & Tríceps Corda'
  ],
  cintura: [
    'Vacuum Abdominal Técnico',
    'Prancha RKC Isométrica',
    'Abdominal Infra na Paralela'
  ],
  coxa: [
    'Agachamento Livre / Hack Machine',
    'Leg Press 45° Amplitude Completa',
    'Stiff com Barra Olímpica'
  ],
  panturrilha: [
    'Panturrilha em Pé na Máquina',
    'Panturrilha Sentado (Sóleo)'
  ],
  pescoco: ['Encolhimento com Halteres', 'Estabilização Cervical Isométrica'],
  quadril: ['Elevação Pélvica com Barra', 'Agachamento Búlgaro com Halteres']
};

export function Scanner3DView({
  goldenAnalysis,
  selectedPartKey,
  onSelectPart,
  onOpenWizard,
  onGenerateAiWorkout,
  isGeneratingAi,
  profile,
  metrics,
  onboardingCompleted = false,
  workoutHistory = [],
  checkins = [],
  onAddCheckin,
  onDeleteCheckin,
  onSeedDemoEvolution,
  onClearDemoCheckins
}: Scanner3DViewProps) {
  const [subTab, setSubTab] = useState<ScannerSubTab>('scanner_viewport');
  const [checkinNote, setCheckinNote] = useState('');

  const selectedPart =
    goldenAnalysis.parts[selectedPartKey] || goldenAnalysis.parts.ombros;

  const isDemoState = useMemo(() => {
    if (!profile || !metrics) return false;
    return !isUserDataConfirmed({
      profile,
      metrics,
      onboardingCompleted
    });
  }, [profile, metrics, onboardingCompleted]);

  const realCheckins = useMemo(
    () => checkins.filter((c) => !isDemoCheckin(c)),
    [checkins]
  );
  const demoCheckins = useMemo(
    () => checkins.filter((c) => isDemoCheckin(c)),
    [checkins]
  );

  const getNeutralRegionStatusText = (part: typeof selectedPart) => {
    if (part.colorZone === 'green') {
      return 'Dentro da referência proporcional';
    }
    if (part.isReductionTarget) {
      return 'Acima da referência — foco em recomposição';
    }
    if (part.colorZone === 'amber') {
      return 'Próximo da referência proporcional';
    }
    return 'Abaixo da referência — prioridade de volume';
  };

  const handleSelectRegionAndInspect = (key: BodyPartKey, switchToDetails = false) => {
    onSelectPart(key);
    if (switchToDetails) {
      setSubTab('region_details');
    }
  };

  const handleCreateQuickCheckin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddCheckin) return;
    onAddCheckin(checkinNote.trim() || 'Registro manual de medidas no Scanner 3D');
    setCheckinNote('');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5 pb-20">
      {/* Cabeçalho Principal do Scanner 3D */}
      <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
              MAPEAMENTO ANATÔMICO
            </span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                isDemoState
                  ? 'bg-[#D4AF37]/15 text-[#D4AF37]'
                  : 'bg-[#10B981]/15 text-[#10B981]'
              }`}
            >
              {isDemoState ? 'Medidas Padrão' : 'Medidas Confirmadas'}
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-[#F4F5F7] tracking-tight mt-0.5">
            Scanner Corporal 3D
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenWizard}
            className="h-10 px-3.5 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#F4F5F7] inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Ruler className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isDemoState ? 'Cadastrar Medidas' : 'Editar Medidas'}</span>
          </button>

          <button
            type="button"
            onClick={onGenerateAiWorkout}
            disabled={isGeneratingAi}
            className="h-10 px-3.5 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 shadow-md transition-transform active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <Wand2 className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
            <span>{isGeneratingAi ? 'Ajustando...' : 'Ajustar Rotina'}</span>
          </button>
        </div>
      </section>

      {/* Sub-navegação das 3 Telas do Grupo 3 (Scanner 3D | Detalhes de Região | Registros de Medidas) */}
      <div
        role="navigation"
        aria-label="Subnavegação do Scanner 3D"
        className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-[#13151A] border border-white/[0.06]"
      >
        <button
          type="button"
          onClick={() => setSubTab('scanner_viewport')}
          aria-pressed={subTab === 'scanner_viewport'}
          className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            subTab === 'scanner_viewport'
              ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Scanner 3D</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('region_details')}
          aria-pressed={subTab === 'region_details'}
          className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            subTab === 'region_details'
              ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span>Região ({selectedPart.shortLabel})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('measurements_log')}
          aria-pressed={subTab === 'measurements_log'}
          className={`h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            subTab === 'measurements_log'
              ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
              : 'text-[#9CA3AF] hover:text-[#F4F5F7]'
          }`}
        >
          <Ruler className="w-3.5 h-3.5" />
          <span>Medidas</span>
        </button>
      </div>

      {/* ==================================================================== */}
      {/* TELA 1: SCANNER 3D (MODELO 3D PROTAGONISTA E DESOBSTRUÍDO)           */}
      {/* ==================================================================== */}
      {subTab === 'scanner_viewport' && (
        <div className="space-y-4">
          {/* Resumo Rápido de Simetria e Índice Áureo */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-3.5">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Simetria Global
              </span>
              <div className="font-mono text-xl font-extrabold text-[#10B981] mt-0.5">
                {goldenAnalysis.overallScore}%
              </div>
              <span className="block text-[11px] text-[#9CA3AF] mt-0.5">
                {goldenAnalysis.greenZones.length} regiões em equilíbrio
              </span>
            </div>

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-3.5">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Índice Áureo
              </span>
              <div className="font-mono text-xl font-extrabold text-[#D4AF37] mt-0.5">
                {goldenAnalysis.indiceAdonisAtual}
              </div>
              <span className="block text-[11px] text-[#9CA3AF] mt-0.5">
                Referência: 1.618
              </span>
            </div>

            <div className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-3.5">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Região Ativa
              </span>
              <div className="text-base font-extrabold text-[#F4F5F7] truncate mt-0.5">
                {selectedPart.shortLabel}
              </div>
              <span className="font-mono block text-[11px] text-[#D4AF37] mt-0.5">
                {selectedPart.current} cm / {selectedPart.ideal} cm
              </span>
            </div>
          </div>

          {/* Viewport Three.js Preservado (HolographicBody3D) */}
          <div className="h-[410px] sm:h-[470px] w-full rounded-2xl overflow-hidden shadow-2xl">
            <HolographicBody3D
              parts={goldenAnalysis.parts}
              selectedPartKey={selectedPartKey}
              onSelectPart={(key) => handleSelectRegionAndInspect(key, false)}
            />
          </div>

          {/* Seletor Rápido de Regiões Abaixo do Modelo 3D (Sem Cobrir o Corpo) */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  SELECIONE UMA REGIÃO ANATÔMICA
                </span>
                <h2 className="text-sm font-extrabold text-[#F4F5F7]">
                  Toque no modelo 3D ou nos grupos abaixo
                </h2>
              </div>

              <button
                type="button"
                onClick={() => setSubTab('region_details')}
                className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-xs font-bold text-[#D4AF37] inline-flex items-center gap-1 transition-colors cursor-pointer shrink-0"
              >
                <span>Ver detalhes</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {goldenAnalysis.partsArray.map((part) => {
                const isSelected = part.key === selectedPartKey;
                const dotColor =
                  part.colorZone === 'green'
                    ? 'bg-[#10B981]'
                    : part.colorZone === 'amber'
                    ? 'bg-[#D4AF37]'
                    : 'bg-rose-500';

                return (
                  <button
                    key={part.key}
                    type="button"
                    onClick={() => handleSelectRegionAndInspect(part.key, false)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#1A1D24] border-[#D4AF37] shadow-md'
                        : 'bg-[#0D0F14] border-white/[0.05] hover:bg-[#1A1D24]/70'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-xs font-bold text-[#F4F5F7] truncate">
                        {part.shortLabel}
                      </span>
                      <span className={`w-2 h-2 rounded-full shrink-0 ${dotColor}`} />
                    </div>
                    <div className="mt-1 flex items-baseline justify-between font-mono text-[11px]">
                      <span className="text-[#9CA3AF]">{part.current} cm</span>
                      <span className="font-bold text-[#D4AF37]">{part.accuracy}%</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TELA 2: DETALHES DE REGIÃO (ANÁLISE TÉCNICA E RECOMENDAÇÕES)         */}
      {/* ==================================================================== */}
      {subTab === 'region_details' && (
        <div className="max-w-xl mx-auto space-y-4">
          {/* Seletor Horizontal de Região */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
            {goldenAnalysis.partsArray.map((part) => {
              const isSelected = part.key === selectedPartKey;
              return (
                <button
                  key={part.key}
                  type="button"
                  onClick={() => onSelectPart(part.key)}
                  className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#D4AF37] text-[#08090C] shadow-sm'
                      : 'bg-[#13151A] border border-white/[0.06] text-[#9CA3AF] hover:text-[#F4F5F7]'
                  }`}
                >
                  {part.shortLabel}
                </button>
              );
            })}
          </div>

          {/* Card Principal de Detalhes da Região */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-5 space-y-5 shadow-xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  ANÁLISE PROPORCIONAL
                </span>
                <h2 className="text-2xl font-extrabold text-[#F4F5F7] mt-0.5">
                  {selectedPart.label}
                </h2>
                <p className="text-xs text-[#9CA3AF] mt-1">
                  {getNeutralRegionStatusText(selectedPart)}
                </p>
              </div>

              <span className="px-3 py-1 rounded-full bg-[#1A1D24] border border-white/[0.08] font-mono text-xs font-bold text-[#D4AF37]">
                {selectedPart.accuracy}% simetria
              </span>
            </div>

            {/* Medida Atual vs Referência */}
            <div className="grid grid-cols-3 gap-2.5">
              <div className="p-3.5 rounded-xl bg-[#1A1D24] border border-white/[0.05]">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Medida Atual
                </span>
                <div className="font-mono text-xl font-extrabold text-[#F4F5F7] mt-1">
                  {selectedPart.current}{' '}
                  <span className="text-xs font-normal text-[#9CA3AF]">cm</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#1A1D24] border border-[#D4AF37]/30">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-[#D4AF37]">
                  Referência
                </span>
                <div className="font-mono text-xl font-extrabold text-[#D4AF37] mt-1">
                  {selectedPart.ideal}{' '}
                  <span className="text-xs font-normal text-[#9CA3AF]">cm</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#1A1D24] border border-white/[0.05]">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  Diferença
                </span>
                <div className="font-mono text-xl font-extrabold text-[#F4F5F7] mt-1">
                  {selectedPart.delta > 0
                    ? `-${selectedPart.delta}`
                    : `+${Math.abs(selectedPart.delta)}`}{' '}
                  <span className="text-xs font-normal text-[#9CA3AF]">cm</span>
                </div>
              </div>
            </div>

            {/* Barra de Progresso Proporcional */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9CA3AF] font-medium">
                  Relação Matemática ({selectedPart.formulaDesc})
                </span>
                <span className="font-mono font-bold text-[#F4F5F7]">
                  {selectedPart.accuracy}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-[#0B0D12] rounded-full overflow-hidden border border-white/[0.05]">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    selectedPart.colorZone === 'green'
                      ? 'bg-[#10B981]'
                      : 'bg-[#D4AF37]'
                  }`}
                  style={{ width: `${Math.min(100, selectedPart.accuracy)}%` }}
                />
              </div>
            </div>

            {/* Prescrição de Volume Semanal */}
            <div className="p-4 rounded-xl bg-[#1A1D24] border border-white/[0.06] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#F4F5F7] flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#D4AF37]" />
                  Volume Semanal Recomendado
                </span>
                <span className="font-mono text-xs font-bold text-[#D4AF37]">
                  {selectedPart.recommendedWeeklySets} séries/sem
                </span>
              </div>
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                {selectedPart.extraSets > 0
                  ? `Inclui +${selectedPart.extraSets} séries semanais adicionais distribuídas na sua rotina para equilibrar esta região.`
                  : 'Volume de manutenção técnica calibrado para preservar a proporção atual.'}
              </p>
            </div>

            {/* Exercícios Recomendados para a Região */}
            <div className="space-y-2.5">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Movimentos Recomendados para {selectedPart.shortLabel}
              </span>
              <div className="space-y-2">
                {(RECOMMENDED_EXERCISES_BY_PART[selectedPart.key] || []).map(
                  (exName, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05] flex items-center justify-between text-xs"
                    >
                      <span className="font-semibold text-[#F4F5F7] flex items-center gap-2">
                        <Dumbbell className="w-3.5 h-3.5 text-[#D4AF37]" />
                        {exName}
                      </span>
                      <span className="font-mono text-[11px] text-[#9CA3AF]">
                        Prioridade #{idx + 1}
                      </span>
                    </div>
                  )
                )}
              </div>
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setSubTab('scanner_viewport')}
                className="flex-1 h-11 rounded-xl bg-[#1A1D24] hover:bg-[#232732] text-xs font-bold text-[#F4F5F7] inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#D4AF37]" />
                <span>Voltar ao Modelo 3D</span>
              </button>

              <button
                type="button"
                onClick={() => setSubTab('measurements_log')}
                className="flex-1 h-11 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Ruler className="w-4 h-4" />
                <span>Atualizar Medida</span>
              </button>
            </div>
          </section>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TELA 3: REGISTROS DE MEDIDAS (HISTÓRICO REAL VS DEMONSTRATIVO)       */}
      {/* ==================================================================== */}
      {subTab === 'measurements_log' && (
        <div className="max-w-xl mx-auto space-y-5">
          {/* Aviso claro caso sejam valores padrão não confirmados */}
          {isDemoState && (
            <section className="bg-[#1A1D24] border border-[#D4AF37]/40 rounded-2xl p-4 flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="text-xs font-bold text-[#D4AF37] flex items-center gap-1.5">
                  <Info className="w-4 h-4 shrink-0" />
                  <span>Valores de Referência Inicial</span>
                </div>
                <p className="text-xs text-[#9CA3AF] leading-relaxed">
                  As circunferências exibidas abaixo são valores iniciais de demonstração. Cadastre suas medidas reais quando desejar calibrar o Scanner 3D.
                </p>
              </div>
              <button
                type="button"
                onClick={onOpenWizard}
                className="px-3 py-2 rounded-xl bg-[#D4AF37] text-[#08090C] text-xs font-bold shrink-0 cursor-pointer"
              >
                Calibrar
              </button>
            </section>
          )}

          {/* Resumo das Circunferências Atuais */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  BIOMETRIA ATUAL
                </span>
                <h2 className="text-base font-extrabold text-[#F4F5F7]">
                  Circunferências Corporais
                </h2>
              </div>

              <button
                type="button"
                onClick={onOpenWizard}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A1D24] hover:bg-[#232732] border border-white/[0.08] text-xs font-bold text-[#D4AF37] cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Editar medidas</span>
              </button>
            </div>

            {metrics && (
              <div className="grid grid-cols-3 gap-2">
                <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05]">
                  <span className="block text-[10px] font-bold uppercase text-[#9CA3AF]">
                    Peso
                  </span>
                  <span className="font-mono text-sm font-extrabold text-[#F4F5F7]">
                    {metrics.peso} kg
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05]">
                  <span className="block text-[10px] font-bold uppercase text-[#9CA3AF]">
                    Altura
                  </span>
                  <span className="font-mono text-sm font-extrabold text-[#F4F5F7]">
                    {metrics.altura} cm
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-[#0D0F14] border border-white/[0.05]">
                  <span className="block text-[10px] font-bold uppercase text-[#D4AF37]">
                    Punho
                  </span>
                  <span className="font-mono text-sm font-extrabold text-[#D4AF37]">
                    {metrics.pulso} cm
                  </span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {goldenAnalysis.partsArray.map((part) => (
                <div
                  key={part.key}
                  onClick={() => handleSelectRegionAndInspect(part.key, true)}
                  className="p-3 rounded-xl bg-[#1A1D24] border border-white/[0.05] hover:border-[#D4AF37]/40 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div>
                    <div className="text-xs font-bold text-[#F4F5F7]">
                      {part.shortLabel}
                    </div>
                    <div className="text-[11px] font-mono text-[#9CA3AF]">
                      Meta: {part.ideal} cm
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-sm font-extrabold text-[#D4AF37]">
                      {part.current} cm
                    </div>
                    <div className="text-[10px] font-mono text-[#9CA3AF]">
                      {part.accuracy}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Salvar Novo Check-in de Medidas */}
          {onAddCheckin && (
            <form
              onSubmit={handleCreateQuickCheckin}
              className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3"
            >
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="text-sm font-bold text-[#F4F5F7]">
                  Registrar Check-in das Medidas Atuais
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={checkinNote}
                  onChange={(e) => setCheckinNote(e.target.value)}
                  placeholder="Observação (ex.: Avaliação mensal em jejum)"
                  className="flex-1 h-11 bg-[#1A1D24] border border-white/[0.08] focus:border-[#D4AF37] rounded-xl px-3.5 text-xs text-[#F4F5F7] placeholder:text-[#9CA3AF] focus:outline-none"
                />
                <button
                  type="submit"
                  className="h-11 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc42] text-[#08090C] text-xs font-bold shrink-0 cursor-pointer"
                >
                  Salvar Check-in
                </button>
              </div>
            </form>
          )}

          {/* Histórico de Check-ins Reais */}
          <section className="bg-[#13151A] border border-white/[0.06] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="text-sm font-bold text-[#F4F5F7]">
                  Histórico de Medidas Reais ({realCheckins.length})
                </h3>
              </div>
            </div>

            {realCheckins.length === 0 ? (
              <div className="p-4 rounded-xl bg-[#1A1D24]/60 border border-white/[0.04] text-center space-y-2">
                <p className="text-xs font-semibold text-[#F4F5F7]">
                  Nenhum check-in corporal registrado ainda.
                </p>
                <p className="text-[11px] text-[#9CA3AF]">
                  Salve um check-in acima após confirmar suas medidas para acompanhar sua evolução.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {realCheckins.map((chk) => (
                  <div
                    key={chk.id}
                    className="p-3.5 rounded-xl bg-[#1A1D24] border border-white/[0.05] flex items-center justify-between gap-3"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#F4F5F7] truncate">
                          {chk.note}
                        </span>
                        <span className="font-mono text-[10px] text-[#9CA3AF]">
                          {chk.dateFormatted}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] text-[#9CA3AF]">
                        <span className="text-[#D4AF37] font-bold">{chk.peso} kg</span>
                        <span>•</span>
                        <span>Ombros: {chk.ombros}cm</span>
                        <span>•</span>
                        <span>Cintura: {chk.cintura}cm</span>
                        <span>•</span>
                        <span>Índice: {chk.indiceAdonis}</span>
                      </div>
                    </div>

                    {onDeleteCheckin && (
                      <button
                        type="button"
                        onClick={() => onDeleteCheckin(chk.id)}
                        aria-label={`Excluir check-in ${chk.note}`}
                        className="p-1.5 rounded-lg bg-[#13151A] text-[#9CA3AF] hover:text-rose-400 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Seção Separada para Simulação Demonstrativa (se existir) */}
          {demoCheckins.length > 0 && (
            <section className="bg-[#13151A] border border-[#D4AF37]/30 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#D4AF37]">
                    MODO DEMONSTRATIVO SEPARADO
                  </span>
                  <h4 className="text-xs font-bold text-[#F4F5F7]">
                    Simulação Trimestral ({demoCheckins.length} registros de exemplo)
                  </h4>
                </div>
                {onClearDemoCheckins && (
                  <button
                    type="button"
                    onClick={onClearDemoCheckins}
                    className="px-2.5 py-1.5 rounded-lg bg-[#1A1D24] text-[11px] font-bold text-rose-300 hover:bg-rose-950/50 cursor-pointer"
                  >
                    Remover Simulação
                  </button>
                )}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
