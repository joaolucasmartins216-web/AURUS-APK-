export interface UserProfile {
  nome: string;
  experiencia: 'Iniciante' | 'Intermediário' | 'Avançado';
  diasSemana: number;
  diasSelecionados: string[]; // e.g. ['seg', 'ter', 'qua', 'qui', 'sex', 'sab']
  esporteComplementar: string;
  focoMobilidade: string;
  objetivoPrincipal: string;
  duracaoMediaMin?: number;
  observacoesFisiologicas?: string;
  modalidadesExtras?: string[];
  preferenciaExercicios?: string;
}

export interface BiometricMetrics {
  idade: number;
  peso: number;
  altura: number;
  pulso: number; // McCallum bone anchor
  ombros: number;
  peito: number;
  cintura: number;
  quadril: number;
  braco: number;
  coxa: number;
  panturrilha: number;
  pescoco: number;
}

export type BodyPartKey =
  | 'ombros'
  | 'peito'
  | 'braco'
  | 'coxa'
  | 'panturrilha'
  | 'pescoco'
  | 'cintura'
  | 'quadril';

export interface BodyPartAnalysis {
  key: BodyPartKey;
  shortLabel: string;
  label: string;
  formulaDesc: string;
  current: number;
  ideal: number;
  delta: number;
  accuracy: number;
  colorZone: 'red' | 'amber' | 'green';
  statusLabel: string;
  extraSets: number;
  recommendedWeeklySets: number;
  needsCardioBoost?: boolean;
  isReductionTarget: boolean;
}

export interface GoldenAnalysis {
  cinturaIdeal: number;
  ombrosIdeais: number;
  indiceAdonisAtual: number;
  peitoIdeal: number;
  bracoIdeal: number;
  coxaIdeal: number;
  panturrilhaIdeal: number;
  pescocoIdeal: number;
  quadrilIdeal: number;
  parts: Record<BodyPartKey, BodyPartAnalysis>;
  partsArray: BodyPartAnalysis[];
  overallScore: number;
  redZones: BodyPartAnalysis[];
  greenZones: BodyPartAnalysis[];
  needsFatLossProtocol: boolean;
}

export interface MobilityItem {
  id: string;
  name: string;
  duration: string;
  focus: string;
}

export interface ExerciseItem {
  id: string;
  name: string;
  targetGroup: BodyPartKey;
  baseSets: number;
  reps: string;
  rest: number;
  cadence: string;
  defaultWeight: number;
  tip: string;
  extraSets?: number;
  totalSets?: number;
  colorZone?: 'red' | 'amber' | 'green';
  statusLabel?: string;
  deltaValue?: number;
  partLabel?: string;
}

export interface CardioBlock {
  mode: string;
  badgeColor: string;
  protocol: string;
  caloriesEst: string;
  stretching: string;
}

export interface WorkoutDay {
  id: string;
  dayName: string;
  shortDay: string;
  title: string;
  subtitle: string;
  focusGroups?: BodyPartKey[];
  mobility: MobilityItem[];
  exercises: ExerciseItem[];
  cardioBlock?: CardioBlock;
  totalDaySets?: number;
}

export interface SetLog {
  setNumber: number;
  weight: number;
  reps: number;
  rpe: number;
  completed: boolean;
}

export interface CheckinRecord {
  id: string;
  note: string;
  peso: number;
  ombros: number;
  cintura: number;
  peito: number;
  braco: number;
  coxa: number;
  panturrilha: number;
  indiceAdonis: number;
  overallScore: number;
  dateFormatted: string;
  timestamp: number;
}

export interface CompletedWorkout {
  id: string;
  sessionId?: string;
  dayId: string;
  dayName: string;
  title: string;
  tonnage: number;
  durationSec: number;
  completedSets: number;
  totalSets: number;
  cardioCompleted: boolean;
  dateFormatted: string;
  timestamp: number;
  startedAtTimestamp?: number;
  sessionRpe?: number;
  sessionNotes?: string;
  exercisesSummary: Array<{
    exerciseId: string;
    name: string;
    targetGroup: BodyPartKey;
    setsCompleted: number;
    totalSets: number;
    maxWeight: number;
    bestSetReps?: number;
    volumeKg?: number;
    isPersonalRecord?: boolean;
    previousBestWeight?: number;
    setsDetail?: Array<{
      setNumber: number;
      weight: number;
      reps: number;
      rpe?: number;
    }>;
  }>;
}

export type WorkoutSessionStatus =
  | 'not_started'
  | 'running'
  | 'paused'
  | 'completed'
  | 'discarded';

export interface StopwatchState {
  status: 'not_started' | 'running' | 'paused';
  startedAtMs: number | null;
  accumulatedElapsedMs: number;
  lastResumedAtMs: number | null;
}

export interface RestTimerState {
  status: 'idle' | 'running' | 'paused' | 'completed';
  targetSec: number;
  endTimeMs: number | null;
  pausedRemainingMs: number;
  contextExerciseId: string | null;
  contextExerciseName: string | null;
  completedSetNumber: number | null;
  nextSetNumber: number | null;
  nextSetWeight: number | null;
  nextSetReps: number | null;
  isModalOpen: boolean;
}

export interface ActiveWorkoutSession {
  sessionId: string;
  dayId: string;
  dayTitle: string;
  status: WorkoutSessionStatus;
  startedAtMs: number;
  updatedAtMs: number;
  activeExerciseIndex: number;
  arenaPhase: 'mobilidade' | 'hipertrofia' | 'cardio';
  mobilityChecked: Record<string, boolean>;
  cardioCompleted: boolean;
  sessionSets: Record<string, SetLog[]>;
  customExercisesAdded: ExerciseItem[];
  stopwatch: StopwatchState;
  restTimer: RestTimerState;
  sessionRpe?: number;
  sessionNotes?: string;
}

export type ExerciseEquipmentCategory =
  | 'barra'
  | 'halteres'
  | 'cabo'
  | 'maquinas'
  | 'livre';

export type ExerciseMuscleFilter =
  | 'all'
  | 'peito'
  | 'costas'
  | 'pernas'
  | 'ombros'
  | 'bracos'
  | 'abdomen'
  | 'panturrilha'
  | 'pescoco';

export interface CatalogExerciseStep {
  title: string;
  description: string;
}

export interface CatalogExercise {
  id: string;
  name: string;
  targetGroup: BodyPartKey;
  muscleFilter: Exclude<ExerciseMuscleFilter, 'all'>;
  primaryMuscleLabel: string;
  auxiliaryMuscles: string[];
  equipmentCategory: ExerciseEquipmentCategory;
  equipmentLabel: string;
  categoryLabel: 'Composto' | 'Isolamento' | 'Estabilidade & Core' | 'Condicionamento';
  difficultyLabel: 'Iniciante' | 'Intermediário' | 'Avançado';
  defaultSets: number;
  defaultReps: string;
  defaultRestSec: number;
  defaultCadence: string;
  defaultWeight: number;
  shortDescription: string;
  biomechanicalSubtitle: string;
  angleCue: string;
  postureCue: string;
  kinematicChainLabel: string;
  executionSteps: CatalogExerciseStep[];
  safetyNotes: string[];
  searchAliases?: string[];
  isCustom?: boolean;
  createdAtMs?: number;
}

export interface AppPreferences {
  enhancedContrast: boolean;
  restSoundEnabled: boolean;
  vibrationEnabled: boolean;
  keepScreenAwake: boolean;
  weightUnit: 'kg' | 'lbs';
  workoutReminderEnabled: boolean;
  preferredWorkoutTime: string;
  weeklySummaryEnabled: boolean;
  textScale: 'default' | 'large';
  reducedMotion: boolean;
  privateHistoryMode: boolean;
  autoSyncCalendar: boolean;
  logRealDurationToCalendar: boolean;
}

export interface BackupData {
  app: string;
  exportedAt: string;
  profile: UserProfile;
  metrics: BiometricMetrics;
  customAiWorkouts: WorkoutDay[] | null;
  lastExerciseWeights: Record<string, number>;
  checkins: CheckinRecord[];
  workoutHistory: CompletedWorkout[];
  activeSession?: ActiveWorkoutSession | null;
  customExercises?: CatalogExercise[];
  preferences?: AppPreferences;
}

export interface GoogleCalendarEvent {
  id: string;
  summary: string;
  description?: string;
  start: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
  end: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
  location?: string;
  htmlLink?: string;
}

export interface GoogleGmailMessage {
  id: string;
  threadId: string;
  snippet?: string;
  subject?: string;
  from?: string;
  date?: string;
  internalDate?: string;
}

